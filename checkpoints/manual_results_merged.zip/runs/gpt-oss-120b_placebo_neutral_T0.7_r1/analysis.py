import pandas as pd
import numpy as np
import json
import statsmodels.formula.api as smf
import warnings

warnings.filterwarnings("ignore")

# 1. Load data
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_placebo_neutral_T0.7_r1/data.csv"
df = pd.read_csv(FILE_PATH)

# 2. Prepare variables
# Average skin tone rating
df["skin_tone"] = df[["rater1", "rater2"]].mean(axis=1)

# Binary outcome: received at least one red card from the referee
df["red_flag"] = (df["redCards"] > 0).astype(int)

# Choose covariates
covariates = ["games", "yellowCards", "position", "leagueCountry"]
# Keep only needed columns plus clustering variable and predictor/outcome
cols_needed = ["skin_tone", "red_flag", "refNum"] + covariates
df = df[cols_needed]

# 3. Missing data handling: listwise deletion
missing_strategy = "listwise_deletion"
df = df.dropna(subset=cols_needed)

# 4. Build formula
# Categorical variables are position and leagueCountry
formula = "red_flag ~ skin_tone + games + yellowCards + C(position) + C(leagueCountry)"

# 5. Fit logistic regression with clustered SE by referee
model = smf.logit(formula=formula, data=df)
result = model.fit(cov_type="cluster", cov_kwds={"groups": df["refNum"]}, disp=0)

# 6. Extract estimand for skin_tone
coef = result.params["skin_tone"]
se = result.bse["skin_tone"]
pval = result.pvalues["skin_tone"]
ci_lower = coef - 1.96 * se
ci_upper = coef + 1.96 * se

# Convert to odds ratio scale
or_est = np.exp(coef)
or_ci_lower = np.exp(ci_lower)
or_ci_upper = np.exp(ci_upper)

# 7. Determine significance
conclusion = "significant_effect" if pval < 0.05 else "no_significant_effect"

# 8. Assemble output
output = {
    "effect_size": float(or_est),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(pval),
    "ci_lower": float(or_ci_lower),
    "ci_upper": float(or_ci_upper),
    "conclusion": conclusion,
    "model_family": "logistic",
    "predictor_used": "average of rater1 and rater2 (skin_tone)",
    "covariates_included": covariates,
    "missing_data_strategy": missing_strategy,
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "listwise deletion of rows with missing skin_tone, games, yellowCards, position, or leagueCountry"
}

print(json.dumps(output, ensure_ascii=False))