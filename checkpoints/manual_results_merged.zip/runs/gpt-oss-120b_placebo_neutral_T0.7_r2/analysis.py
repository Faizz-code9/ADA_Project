import pandas as pd
import numpy as np
import json
import sys
import statsmodels.api as sm
from scipy import stats

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gpt-oss-120b_placebo_neutral_T0.7_r2/data.csv"
df = pd.read_csv(file_path)

# 2. Clean / prepare
# Create continuous skin‑tone predictor as the average of the two raters
df["skin_tone"] = df[["rater1", "rater2"]].mean(axis=1)

# Binary outcome: any red card from the referee?
df["red_flag"] = (df["redCards"] > 0).astype(int)

# Variables we will adjust for
covariate_cols = ["games", "yellowCards", "height", "weight", "position", "leagueCountry"]
# Drop rows with missing data in any of the variables needed
required_cols = ["skin_tone", "red_flag", "refNum"] + covariate_cols
df_clean = df.dropna(subset=required_cols)

# One‑hot encode categorical covariates (drop first to avoid collinearity)
df_dummies = pd.get_dummies(df_clean[["position", "leagueCountry"]], drop_first=True, prefix=["pos", "lg"])
X = pd.concat(
    [
        df_clean[["skin_tone", "games", "yellowCards", "height", "weight"]].reset_index(drop=True),
        df_dummies.reset_index(drop=True),
    ],
    axis=1,
)

y = df_clean["red_flag"].values
clusters = df_clean["refNum"].values

# Add intercept
X = sm.add_constant(X, has_constant="add")

# 3. Fit logistic regression (GLM with binomial family) with clustered SEs
model = sm.GLM(y, X, family=sm.families.Binomial())
result = model.fit(cov_type="cluster", cov_kwds={"groups": clusters})

# 4. Extract primary estimand (odds ratio for skin_tone)
coef = result.params["skin_tone"]
se = result.bse["skin_tone"]
z = coef / se
p_value = 2 * (1 - stats.norm.cdf(abs(z)))
odds_ratio = np.exp(coef)
ci_lower = np.exp(coef - 1.96 * se)
ci_upper = np.exp(coef + 1.96 * se)

conclusion = "significant_effect" if p_value < 0.05 else "no_significant_effect"

# 5. Prepare JSON output
output = {
    "effect_size": float(odds_ratio),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_value),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "logistic",
    "predictor_used": "average_skin_tone = (rater1 + rater2)/2",
    "covariates_included": ["games", "yellowCards", "height", "weight"] + list(df_dummies.columns),
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "rows with missing rater1, rater2, or covariates removed"
}

print(json.dumps(output))