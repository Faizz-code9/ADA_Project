import pandas as pd
import numpy as np
import json
import statsmodels.formula.api as smf

# 1. Load data
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_soccer_confirmatory_T0.7_r1/data.csv"
df = pd.read_csv(FILE_PATH)

# 2. Clean / prepare ---------------------------------------------------------
# Build continuous skin‑tone predictor as the average of the two raters
df["skin_tone"] = df[["rater1", "rater2"]].mean(axis=1)

# Binary outcome: any red card vs none
df["red_any"] = (df["redCards"] > 0).astype(int)

# Choose covariates
covariates = ["games", "yellowCards", "height", "weight", "position", "leagueCountry"]
required_cols = ["skin_tone", "red_any", "refNum"] + covariates

# Drop rows with any missing values in required columns
df_clean = df[required_cols].dropna()

# Record exclusions description
exclusions = "rows with missing rater1/rater2 or any covariate used were removed"

# 3. Fit logistic regression with clustered SE by referee --------------------
# Build formula (categorical vars are encoded via C())
formula = "red_any ~ skin_tone + games + yellowCards + height + weight + C(position) + C(leagueCountry)"
model = smf.logit(formula=formula, data=df_clean)
result = model.fit(disp=0, cov_type="cluster", cov_kwds={"groups": df_clean["refNum"]})

# 4. Extract primary estimand (odds ratio for skin_tone) --------------------
coef = result.params["skin_tone"]
se = result.bse["skin_tone"]
p_val = result.pvalues["skin_tone"]
or_est = np.exp(coef)
ci_lower = np.exp(coef - 1.96 * se)
ci_upper = np.exp(coef + 1.96 * se)

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

# 5. Assemble output ---------------------------------------------------------
output = {
    "effect_size": float(or_est),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "logistic",
    "predictor_used": "average_skin_tone = (rater1 + rater2) / 2",
    "covariates_included": ["games", "yellowCards", "height", "weight", "position", "leagueCountry"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": exclusions
}

print(json.dumps(output, ensure_ascii=False))