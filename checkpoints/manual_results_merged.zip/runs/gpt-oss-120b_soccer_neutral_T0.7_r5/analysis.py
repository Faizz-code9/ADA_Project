import pandas as pd
import numpy as np
import json
import statsmodels.api as sm

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gpt-oss-120b_soccer_neutral_T0.7_r5/data.csv"
df = pd.read_csv(file_path)

# 2. Clean / prepare
# Create continuous skin tone score as the average of rater1 and rater2 (use available rating)
df["skin_tone"] = df[["rater1", "rater2"]].mean(axis=1, skipna=True)

# Define binary outcome: any red card vs none
df["red_any"] = (df["redCards"] > 0).astype(int)

# Choose covariates
covariate_cols = ["games", "yellowCards", "position", "leagueCountry"]
# Keep only rows without missing values in the needed columns
required_cols = ["skin_tone", "red_any", "refNum"] + covariate_cols
df_clean = df[required_cols].dropna()

# Encode categorical covariates
df_dummies = pd.get_dummies(df_clean[["position", "leagueCountry"]], drop_first=True)
X = pd.concat([df_clean[["skin_tone", "games", "yellowCards"]], df_dummies], axis=1)
X = sm.add_constant(X, has_constant='add')
y = df_clean["red_any"]
clusters = df_clean["refNum"]

# 3. Fit logistic regression with clustered SE by referee
logit_model = sm.Logit(y, X)
result = logit_model.fit(disp=False, cov_type="cluster", cov_kwds={"groups": clusters})

# 4. Compute primary estimand (odds ratio for full 0→1 change in skin tone)
beta = result.params["skin_tone"]
se = np.sqrt(result.cov_params().loc["skin_tone", "skin_tone"])
odds_ratio = np.exp(beta)
ci_lower = np.exp(beta - 1.96 * se)
ci_upper = np.exp(beta + 1.96 * se)
p_value = result.pvalues["skin_tone"]

# 5. Assemble output
output = {
    "effect_size": float(odds_ratio),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_value),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if p_value < 0.05 else "no_significant_effect",
    "model_family": "logistic",
    "predictor_used": "average of rater1 and rater2 (skin_tone)",
    "covariates_included": ["games", "yellowCards"] + list(df_dummies.columns),
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "rows with missing skin tone or covariates removed"
}

print(json.dumps(output, ensure_ascii=False))