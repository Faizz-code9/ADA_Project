import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.stats.sandwich_covariance as sw
import json
import warnings

warnings.filterwarnings("ignore")

# ------------------------------------------------------------------
# 1. Load data
# ------------------------------------------------------------------
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_soccer_neutral_T1.0_r3/data.csv"
df = pd.read_csv(FILE_PATH)

# ------------------------------------------------------------------
# 2. Variable construction
# ------------------------------------------------------------------
# Main predictor: average of the two skin‑tone ratings
df["skin_tone"] = df[["rater1", "rater2"]].mean(axis=1)

# Binary outcome: at least one red card from the referee
df["red_flag"] = (df["redCards"] > 0).astype(int)

# Covariates to adjust for (selected a parsimonious set)
covariate_cols = ["games", "yellowCards", "position", "leagueCountry", "refCountry"]
required_cols = ["skin_tone", "red_flag", "refNum"] + covariate_cols

# ------------------------------------------------------------------
# 3. Missing data handling (listwise deletion)
# ------------------------------------------------------------------
df_clean = df.dropna(subset=required_cols)
exclusions = "rows with missing skin tone, position, games or yellowCards removed"

# ------------------------------------------------------------------
# 4. Design matrix (one‑hot for categoricals)
# ------------------------------------------------------------------
df_dummies = pd.get_dummies(df_clean[covariate_cols], drop_first=True, dtype=float)
X = pd.concat([df_clean[["skin_tone"]], df_dummies], axis=1)
X = sm.add_constant(X)          # adds intercept
y = df_clean["red_flag"]

# ------------------------------------------------------------------
# 5. Fit logistic regression (GLM with binomial family)
# ------------------------------------------------------------------
glm = sm.GLM(y, X, family=sm.families.Binomial())
result = glm.fit()

# ------------------------------------------------------------------
# 6. Clustered standard errors by referee (refNum)
# ------------------------------------------------------------------
cluster_ids = df_clean["refNum"]
cov_cluster = sw.cov_cluster(result, cluster_ids)
se_vec = np.sqrt(np.diag(cov_cluster))
# locate the index of the skin_tone coefficient
idx = list(result.params.index).index("skin_tone")
coef = result.params["skin_tone"]
se = se_vec[idx]

# ------------------------------------------------------------------
# 7. Inference for skin tone
# ------------------------------------------------------------------
z = coef / se
p_value = 2 * (1 - sm.stats.norm.cdf(abs(z)))

# Effect size as odds ratio
or_est = np.exp(coef)
ci_lower = np.exp(coef - 1.96 * se)
ci_upper = np.exp(coef + 1.96 * se)

# ------------------------------------------------------------------
# 8. Assemble JSON output
# ------------------------------------------------------------------
output = {
    "effect_size": float(or_est),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_value),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if p_value < 0.05 else "no_significant_effect",
    "model_family": "logistic",
    "predictor_used": "average_skin_tone = (rater1 + rater2) / 2",
    "covariates_included": list(df_dummies.columns),
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": exclusions
}

print(json.dumps(output, ensure_ascii=False))