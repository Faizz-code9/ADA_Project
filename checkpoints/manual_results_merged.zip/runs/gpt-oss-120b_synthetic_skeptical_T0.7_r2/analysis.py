import pandas as pd
import numpy as np
import statsmodels.api as sm
import json
import sys

# -------------------- Load data --------------------
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_synthetic_skeptical_T0.7_r2/data.csv"
df = pd.read_csv(FILE_PATH)

# -------------------- Missing data handling --------------------
missing_strategy = "listwise_deletion"
exclusions = "rows with missing skin_tone removed"
df = df.dropna(subset=["skin_tone"]).reset_index(drop=True)

# -------------------- Variable construction --------------------
# Outcome
y = df["redCards"]

# Main predictor (continuous)
main_pred = "skin_tone"

# Covariates
covariate_cols = [
    "position",
    "height",
    "weight",
    "leagueCountry",
    "games",
    "yellowCards"
]

# One‑hot encode categorical covariates
df_cov = pd.get_dummies(df[covariate_cols], drop_first=True)

# Assemble design matrix with intercept
X = pd.concat([df[[main_pred]], df_cov], axis=1)
X = sm.add_constant(X, has_constant='add')

# -------------------- Model fitting --------------------
# Use Poisson GLM with clustered robust SE by refereeID
model = sm.GLM(y, X, family=sm.families.Poisson())
result = model.fit(cov_type='cluster', cov_kwds={'groups': df['refereeID']})

# -------------------- Extract estimand --------------------
coef = result.params[main_pred]                # log(IRR)
se = result.bse[main_pred]                     # SE of log(IRR)
p_val = result.pvalues[main_pred]
ci_log = result.conf_int().loc[main_pred]      # (lower_log, upper_log)
ci_lower = np.exp(ci_log[0])                   # IRR lower bound
ci_upper = np.exp(ci_log[1])                   # IRR upper bound
effect_size = np.exp(coef)                     # IRR

# -------------------- Conclusion --------------------
conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

# -------------------- Prepare JSON output --------------------
output = {
    "effect_size": float(effect_size),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": main_pred,
    "covariates_included": list(df_cov.columns),
    "missing_data_strategy": missing_strategy,
    "clustering_strategy": "clustered_se",
    "exclusions_applied": exclusions
}

print(json.dumps(output))