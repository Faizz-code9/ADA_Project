import pandas as pd
import numpy as np
import statsmodels.api as sm
from scipy.stats import norm
import json

# 1. Load data
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_disguise_confirmatory_T0.7_r1/data.csv"
df = pd.read_csv(FILE_PATH)

# 2. Clean / prepare
# Average risk evaluator score
df["avg_risk_score"] = df[["risk_evaluator_alpha_score", "risk_evaluator_beta_score"]].mean(axis=1)

# Binary rejection outcome (any rejection vs none)
df["rejection"] = (df["loan_application_rejections"] > 0).astype(int)

# Covariates to adjust for
covariates = [
    "credit_score_index",
    "annual_income_bracket",
    "prior_approved_loans",
    "prior_conditional_loans",
    "prior_denied_loans",
    "repayment_performance_score",
    "formal_inquiry_notices",
    "elevated_risk_warnings"
]

# Keep only needed columns
needed = ["avg_risk_score", "rejection", "loan_officer_id"] + covariates
df_clean = df[needed].copy()

# Missing data strategy: listwise deletion
df_clean = df_clean.dropna()

# 3. Fit logistic regression with clustered SE by loan_officer_id
y = df_clean["rejection"]
X = df_clean[["avg_risk_score"] + covariates]
X = sm.add_constant(X)

logit_result = sm.Logit(y, X).fit(
    disp=False,
    cov_type="cluster",
    cov_kwds={"groups": df_clean["loan_officer_id"]}
)

# 4. Extract primary estimand (odds ratio for avg_risk_score)
coef = logit_result.params["avg_risk_score"]
se = logit_result.bse["avg_risk_score"]
z = coef / se
p_value = 2 * (1 - norm.cdf(abs(z)))
ci_lower_log = coef - 1.96 * se
ci_upper_log = coef + 1.96 * se
odds_ratio = np.exp(coef)
ci_lower = np.exp(ci_lower_log)
ci_upper = np.exp(ci_upper_log)

# 5. Build JSON output
output = {
    "effect_size": float(odds_ratio),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_value),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if p_value < 0.05 else "no_significant_effect",
    "model_family": "logistic",
    "predictor_used": "average_risk_score = (risk_evaluator_alpha_score + risk_evaluator_beta_score) / 2",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "rows with missing risk scores, outcome, or covariates removed"
}

print(json.dumps(output))