import pandas as pd
import numpy as np
import statsmodels.api as sm
import json
import sys

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gpt-oss-120b_synthetic_confirmatory_T0.0_r1/data.csv"
df = pd.read_csv(file_path)

# 2. Missing data handling
missing_strategy = "mean_imputation"
if df["skin_tone"].isnull().any():
    mean_skin = df["skin_tone"].mean()
    df["skin_tone"] = df["skin_tone"].fillna(mean_skin)

# No other missing values per dictionary
exclusions = "none"

# 3. Prepare variables
# Outcome: redCards (count)
y = df["redCards"]

# Offset: log(games) to model rate per game
offset = np.log(df["games"].replace(0, np.nan))
# Replace any zero games (shouldn't exist) with small number to avoid -inf
offset = offset.replace(-np.inf, 0.0)

# Main predictor
X_main = df[["skin_tone"]]

# Covariates
covariate_cols = ["position", "height", "weight", "leagueCountry", "yellowCards"]
X_cov = df[covariate_cols]

# One‑hot encode categorical covariates
X_cov = pd.get_dummies(X_cov, columns=["position", "leagueCountry"], drop_first=True)

# Combine predictors
X = pd.concat([X_main, X_cov], axis=1)

# Add constant for intercept
X = sm.add_constant(X, has_constant='add')

# 4. Fit GEE Poisson model with clustering by refereeID
model = sm.GEE(
    endog=y,
    exog=X,
    groups=df["refereeID"],
    family=sm.families.Poisson(),
    offset=offset
)
result = model.fit()

# 5. Extract estimand for skin_tone
coef = result.params["skin_tone"]
se = result.bse["skin_tone"]
p_val = result.pvalues["skin_tone"]
ci_lower_log, ci_upper_log = result.conf_int().loc["skin_tone"]

# Transform to incidence rate ratio (IRR)
irr = np.exp(coef)
ci_lower = np.exp(ci_lower_log)
ci_upper = np.exp(ci_upper_log)

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

# 6. Build output JSON
output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "gee",
    "predictor_used": "skin_tone",
    "covariates_included": list(X_cov.columns),
    "missing_data_strategy": missing_strategy,
    "clustering_strategy": "clustered_se",
    "exclusions_applied": exclusions
}

print(json.dumps(output))