import pandas as pd
import numpy as np
import statsmodels.api as sm
import json
from datetime import datetime

# 1. Load data
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_soccer_skeptical_T1.0_r1/data.csv"
df = pd.read_csv(FILE_PATH)

# 2. Construct predictor and outcome
df["skin_tone"] = df[["rater1", "rater2"]].mean(axis=1)  # average of the two ratings
df["red_card"] = (df["redCards"] > 0).astype(int)       # binary indicator of any red card

# Approximate player age at start of 2012‑13 season (1 Aug 2012)
def parse_birth(b):
    try:
        return datetime.strptime(b, "%d.%m.%Y")
    except Exception:
        return pd.NaT
df["birth_dt"] = df["birthday"].apply(parse_birth)
season_start = datetime(2012, 8, 1)
df["age"] = (season_start - df["birth_dt"]).dt.days / 365.25

# 3. Choose covariates
covariates = ["games", "position", "leagueCountry", "age", "height", "weight"]
required_cols = ["skin_tone", "red_card", "refNum"] + covariates
df_clean = df.dropna(subset=required_cols)

# Encode categorical variables (position, leagueCountry)
df_enc = pd.get_dummies(df_clean[covariates], columns=["position", "leagueCountry"], drop_first=True)

# Model matrix
X = pd.concat([df_clean["skin_tone"], df_enc], axis=1)
X = sm.add_constant(X, has_constant='add')
y = df_clean["red_card"]

# 4. Fit logistic regression (GLM Binomial) with clustered SE at referee level
glm = sm.GLM(y, X, family=sm.families.Binomial())
glm_res = glm.fit(cov_type="cluster", cov_kwds={"groups": df_clean["refNum"]})

# 5. Extract estimand for skin_tone
coef = glm_res.params["skin_tone"]
se = glm_res.bse["skin_tone"]
p_val = glm_res.pvalues["skin_tone"]
or_est = np.exp(coef)
ci_lower = np.exp(coef - 1.96 * se)
ci_upper = np.exp(coef + 1.96 * se)

# 6. Assemble output
output = {
    "effect_size": float(or_est),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "logistic",
    "predictor_used": "average of rater1 and rater2 (skin_tone)",
    "covariates_included": ["games", "age", "height", "weight"] +
        [col for col in df_enc.columns if col.startswith("position_")] +
        [col for col in df_enc.columns if col.startswith("leagueCountry_")],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "Rows with missing skin tone, outcome, age, or covariates were dropped"
}

print(json.dumps(output, ensure_ascii=False))