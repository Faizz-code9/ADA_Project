import pandas as pd
import numpy as np
import statsmodels.api as sm
from scipy.stats import norm
import json
import warnings

warnings.filterwarnings("ignore", category=RuntimeWarning)

# 1. Load data
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_synthetic_confirmatory_T1.0_r1/data.csv"
df = pd.read_csv(FILE_PATH)

# 2. Missing data handling
missing_strategy = "mean_imputation"
if df["skin_tone"].isnull().any():
    df["skin_tone"] = df["skin_tone"].fillna(df["skin_tone"].mean())

# Ensure no missing values in required columns (listwise deletion for safety)
exclusions = "none"
df = df.dropna(subset=["redCards", "games", "yellowCards", "height", "weight", "position", "leagueCountry"])

# 3. Prepare variables
df["log_games"] = np.log(df["games"])

# Define covariates (including categorical handling in formula)
covariate_terms = [
    "yellowCards",
    "height",
    "weight",
    "C(position)",
    "C(leagueCountry)"
]

formula = "redCards ~ skin_tone + " + " + ".join(covariate_terms)

# 4. Fit Poisson GLM with clustered standard errors by refereeID
model = sm.GLM.from_formula(
    formula,
    data=df,
    family=sm.families.Poisson(),
    offset=df["log_games"]
)
result = model.fit(cov_type="cluster", cov_kwds={"groups": df["refereeID"]})

# 5. Extract estimand for skin_tone
coef = result.params["skin_tone"]
se = result.bse["skin_tone"]
z = coef / se
p_val = 2 * (1 - norm.cdf(abs(z)))
ci_lower = coef - 1.96 * se
ci_upper = coef + 1.96 * se

# Transform to incidence rate ratio (IRR)
irr = np.exp(coef)
irr_ci_lower = np.exp(ci_lower)
irr_ci_upper = np.exp(ci_upper)

# 6. Assemble JSON output
output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(irr_ci_lower),
    "ci_upper": float(irr_ci_upper),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "poisson",
    "predictor_used": "skin_tone (continuous)",
    "covariates_included": ["yellowCards", "height", "weight", "position", "leagueCountry"],
    "missing_data_strategy": missing_strategy,
    "clustering_strategy": "clustered_se",
    "exclusions_applied": exclusions
}

print(json.dumps(output, ensure_ascii=False))