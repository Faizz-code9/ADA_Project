import pandas as pd
import numpy as np
import json
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gpt-oss-120b_synthetic_skeptical_T0.0_r1/data.csv"
df = pd.read_csv(file_path)

# 2. Data cleaning / preparation
# Missing data strategy: listwise deletion for rows with missing skin_tone or games (none for games)
missing_before = df.isnull().sum()
df = df.dropna(subset=['skin_tone', 'games', 'redCards'])
missing_after = df.isnull().sum()

# Exclusions applied description
exclusions = "Rows with missing skin_tone ({} rows) removed".format(missing_before['skin_tone'])

# 3. Model specification
# Use Poisson regression with log(games) as offset to model rate of red cards per game
# Include relevant covariates
formula = (
    "redCards ~ skin_tone + C(position) + height + weight + C(leagueCountry) + yellowCards"
)

# Fit GLM with Poisson family, clustered robust SE by refereeID
model = smf.glm(
    formula=formula,
    data=df,
    family=sm.families.Poisson(),
    offset=np.log(df['games'])
).fit(cov_type='cluster', cov_kwds={'groups': df['refereeID']})

# 4. Extract primary estimand (IRR for skin_tone)
coef = model.params['skin_tone']
se = model.bse['skin_tone']
p_val = model.pvalues['skin_tone']
ci_lower_log, ci_upper_log = model.conf_int().loc['skin_tone']
# Transform to incidence rate ratio scale
irr = np.exp(coef)
ci_lower = np.exp(ci_lower_log)
ci_upper = np.exp(ci_upper_log)

# 5. Determine significance
conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

# Prepare output JSON
output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "skin_tone (continuous)",
    "covariates_included": ["position", "height", "weight", "leagueCountry", "yellowCards"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": exclusions
}

print(json.dumps(output))