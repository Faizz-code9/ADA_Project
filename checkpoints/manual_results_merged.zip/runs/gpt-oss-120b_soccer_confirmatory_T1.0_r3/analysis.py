import pandas as pd
import numpy as np
import json
import statsmodels.api as sm

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gpt-oss-120b_soccer_confirmatory_T1.0_r3/data.csv"
df = pd.read_csv(file_path)

# 2. Clean / prepare
# Create continuous skin tone as mean of rater1 & rater2
df["skin_tone"] = df[["rater1", "rater2"]].mean(axis=1)

# Binary outcome: any red card received from that referee
df["red_flag"] = (df["redCards"] > 0).astype(int)

# Choose covariates
covariates = ["height", "weight", "games", "yellowCards", "position"]
# Drop rows with missing values in any of the needed columns (listwise deletion)
needed_cols = ["skin_tone", "red_flag"] + covariates + ["refNum"]
df_clean = df.dropna(subset=needed_cols).copy()

# Encode categorical position (drop first to avoid collinearity)
position_dummies = pd.get_dummies(df_clean["position"], prefix="pos", drop_first=True)
df_clean = pd.concat([df_clean, position_dummies], axis=1)

# Build design matrix
X_vars = ["skin_tone", "height", "weight", "games", "yellowCards"] + list(position_dummies.columns)
X = sm.add_constant(df_clean[X_vars])
y = df_clean["red_flag"]

# 3. Fit logistic model with clustered SE by referee
model = sm.GLM(y, X, family=sm.families.Binomial())
result = model.fit(cov_type="cluster", cov_kwds={"groups": df_clean["refNum"]})

# 4. Extract primary estimand (odds ratio for full 0→1 change in skin tone)
coef = result.params["skin_tone"]
se = result.bse["skin_tone"]
z = coef / se
p_value = result.pvalues["skin_tone"]
ci_lower_log = coef - 1.96 * se
ci_upper_log = coef + 1.96 * se
or_est = np.exp(coef)
ci_lower = np.exp(ci_lower_log)
ci_upper = np.exp(ci_upper_log)

conclusion = "significant_effect" if p_value < 0.05 else "no_significant_effect"

# 5. Prepare JSON output
output = {
    "effect_size": float(or_est),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_value),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "logistic",
    "predictor_used": "average of rater1 and rater2 (skin_tone)",
    "covariates_included": X_vars,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "removed rows with missing skin tone, outcome, height, weight, games, yellowCards, or position"
}

print(json.dumps(output))