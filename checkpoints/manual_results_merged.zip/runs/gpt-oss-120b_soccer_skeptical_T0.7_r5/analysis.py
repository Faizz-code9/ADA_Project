import pandas as pd
import numpy as np
import json
import statsmodels.formula.api as smf
import statsmodels.api as sm
from scipy import stats

# 1. Load data
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_soccer_skeptical_T0.7_r5/data.csv"
df = pd.read_csv(FILE_PATH)

# 2. Clean / prepare ---------------------------------------------------------
# Continuous skin‑tone predictor: average of the two raters
df["skin_tone"] = df[["rater1", "rater2"]].mean(axis=1)

# Binary outcome: any red card from the referee
df["red_any"] = (df["redCards"] > 0).astype(int)

# Approximate age in 2013 from birthday (format d.m.Y)
def extract_year(b):
    try:
        return int(str(b).split(".")[-1])
    except Exception:
        return np.nan
df["birth_year"] = df["birthday"].apply(extract_year)
df["age_2013"] = 2013 - df["birth_year"]

# Fill missing categorical covariates
df["position"] = df["position"].fillna("Missing")
df["leagueCountry"] = df["leagueCountry"].fillna("Missing")

# Listwise deletion for rows missing any variable needed for the model
required_cols = ["skin_tone", "red_any", "games", "age_2013", "height", "weight"]
df_clean = df.dropna(subset=required_cols)

# 3. Model ------------------------------------------------------------------
# Logistic regression (GLM with Binomial family)
formula = (
    "red_any ~ skin_tone + games + age_2013 + height + weight + "
    "C(position) + C(leagueCountry)"
)
glm_model = smf.glm(formula=formula, data=df_clean, family=sm.families.Binomial())
result = glm_model.fit()

# 4. Primary estimand --------------------------------------------------------
coef = result.params["skin_tone"]
se = result.bse["skin_tone"]
z = coef / se
p_val = 2 * (1 - stats.norm.cdf(abs(z)))
odds_ratio = np.exp(coef)
ci_lower = np.exp(coef - 1.96 * se)
ci_upper = np.exp(coef + 1.96 * se)

# 5. Assemble output ---------------------------------------------------------
output = {
    "effect_size": float(odds_ratio),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "logistic",
    "predictor_used": "average_skin_tone = (rater1 + rater2)/2",
    "covariates_included": ["games", "age_2013", "height", "weight", "position", "leagueCountry"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "removed rows with missing skin_tone, red_any, games, age_2013, height or weight"
}

print(json.dumps(output, ensure_ascii=False))