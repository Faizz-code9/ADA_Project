import pandas as pd
import numpy as np
import json
import statsmodels.api as sm

# 1. Load data
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_soccer_neutral_T0.0_r3/data.csv"
df = pd.read_csv(FILE_PATH)

# 2. Prepare data
# Average skin tone from two raters
df["avg_skin_tone"] = df[["rater1", "rater2"]].mean(axis=1)

# Binary outcome: any red card vs none
df["red_card_any"] = (df["redCards"] > 0).astype(int)

# Covariates to adjust for
covariates = ["games", "yellowCards", "position", "leagueCountry"]

# Keep only needed columns
required = ["avg_skin_tone", "red_card_any", "refNum"] + covariates
df_clean = df[required].copy()

exclusions = "rows with missing avg_skin_tone, redCards, or any covariate removed"
missing_strategy = "listwise_deletion"

# Drop rows with any missing values in the required set
df_clean = df_clean.dropna()

# One‑hot encode categorical covariates (drop_first to avoid collinearity)
df_clean = pd.get_dummies(df_clean, columns=["position", "leagueCountry"], drop_first=True)

# 3. Fit logistic regression with clustered (by referee) robust SE
y = df_clean["red_card_any"]
X = df_clean.drop(columns=["red_card_any", "refNum"])
X = sm.add_constant(X, has_constant='add')
cluster_groups = df_clean["refNum"]

model = sm.GLM(y, X, family=sm.families.Binomial())
result = model.fit(cov_type="cluster", cov_kwds={"groups": cluster_groups})

# 4. Extract primary estimand (odds ratio for a full 0→1 increase in skin tone)
coef_name = "avg_skin_tone"
coef = result.params[coef_name]
se = result.bse[coef_name]
z = coef / se
p_value = 2 * (1 - sm.stats.norm.cdf(abs(z)))
ci_lower_log = coef - 1.96 * se
ci_upper_log = coef + 1.96 * se

odds_ratio = np.exp(coef)
ci_lower_or = np.exp(ci_lower_log)
ci_upper_or = np.exp(ci_upper_log)

conclusion = "significant_effect" if p_value < 0.05 else "no_significant_effect"

# 5. Output JSON
output = {
    "effect_size": float(odds_ratio),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_value),
    "ci_lower": float(ci_lower_or),
    "ci_upper": float(ci_upper_or),
    "conclusion": conclusion,
    "model_family": "logistic",
    "predictor_used": "average_skin_tone = (rater1 + rater2)/2",
    "covariates_included": covariates,
    "missing_data_strategy": missing_strategy,
    "clustering_strategy": "clustered_se",
    "exclusions_applied": exclusions
}

print(json.dumps(output, ensure_ascii=False))