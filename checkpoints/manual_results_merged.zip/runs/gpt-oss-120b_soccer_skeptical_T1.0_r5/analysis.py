import pandas as pd
import numpy as np
import json
import statsmodels.api as sm
import warnings
warnings.filterwarnings("ignore")

# 1. Load data
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_soccer_skeptical_T1.0_r5/data.csv"
df = pd.read_csv(FILE_PATH)

# 2. Build predictor (average skin tone)
df["skin_tone"] = df[["rater1", "rater2"]].mean(axis=1, skipna=True)

# Binary outcome: any red card from this referee
df["red_card_any"] = (df["redCards"] > 0).astype(int)

# Record exclusions
exclusions = []

# Drop rows missing essential variables
init_n = len(df)
df = df.dropna(subset=["skin_tone", "red_card_any"])
exclusions.append(f"dropped {init_n - len(df)} rows with missing skin tone or red card info")

# 3. Derive additional covariates
def calc_age(bday):
    try:
        d, m, y = map(int, bday.split('.'))
        return 2013 - y  # approximate age at end of 2012‑13 season
    except:
        return np.nan

df["age"] = df["birthday"].apply(calc_age)

# Select covariates
covs = ["games", "yellowCards", "age", "height", "weight", "position", "leagueCountry"]
df = df[covs + ["skin_tone", "red_card_any", "refNum"]].copy()

# Impute missing numeric values with column means
for col in ["height", "weight", "age"]:
    df[col] = df[col].fillna(df[col].mean())

# One‑hot encode categoricals (drop first to avoid collinearity)
df = pd.get_dummies(df, columns=["position", "leagueCountry"], drop_first=True)

# Identify covariate columns used in model
covariate_cols = [c for c in df.columns if c not in ["red_card_any", "skin_tone", "refNum"]]

# 4. Fit logistic regression using GLM with clustered robust SE by referee
X = sm.add_constant(df[["skin_tone"] + covariate_cols], has_constant='add')
y = df["red_card_any"]
clusters = df["refNum"]

glm_mod = sm.GLM(y, X, family=sm.families.Binomial())
glm_res = glm_mod.fit(cov_type="cluster", cov_kwds={"groups": clusters})

# Extract coefficient for skin_tone
coef = glm_res.params["skin_tone"]
se = glm_res.bse["skin_tone"]
z = coef / se
p_val = 2 * (1 - sm.stats.norm.cdf(abs(z)))
ci_low = coef - 1.96 * se
ci_high = coef + 1.96 * se

# Convert to odds ratio
or_est = np.exp(coef)
or_low = np.exp(ci_low)
or_high = np.exp(ci_high)

# 5. Assemble JSON output
result = {
    "effect_size": float(or_est),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(or_low),
    "ci_upper": float(or_high),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "logistic",
    "predictor_used": "average_skin_tone",
    "covariates_included": covariate_cols,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "; ".join(exclusions) if exclusions else "none"
}

print(json.dumps(result))