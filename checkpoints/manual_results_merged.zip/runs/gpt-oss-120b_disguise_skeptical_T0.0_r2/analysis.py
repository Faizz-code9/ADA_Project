import pandas as pd
import numpy as np
import statsmodels.api as sm
from scipy.stats import norm
import json

# 1. Load data
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_disguise_skeptical_T0.0_r2/data.csv"
df = pd.read_csv(FILE_PATH)

# 2. Create predictor: average of the two risk scores
df["average_risk_score"] = df[["risk_evaluator_alpha_score", "risk_evaluator_beta_score"]].mean(axis=1)

# 3. Define outcome, predictor, and covariates
outcome = "loan_application_rejections"
predictor = "average_risk_score"
covariates = [
    "credit_score_index",
    "annual_income_bracket",
    "total_applications_reviewed",
    "prior_approved_loans",
    "prior_denied_loans",
    "repayment_performance_score",
    "elevated_risk_warnings",
    "regional_index_a",
    "regional_index_b",
    "employment_specialization"
]

# 4. Subset and drop rows with missing values (listwise deletion)
cols_needed = [outcome, predictor] + covariates
df_model = df[cols_needed].copy()
initial_rows = len(df_model)
df_model = df_model.dropna()
final_rows = len(df_model)
exclusions_desc = f"dropped {initial_rows - final_rows} rows with missing values in outcome, predictor, or covariates"

# 5. One‑hot encode categorical covariate(s)
df_model = pd.get_dummies(df_model, columns=["employment_specialization"], drop_first=True)

# 6. Build design matrix
X = df_model.drop(columns=[outcome])
X = sm.add_constant(X, has_constant='add')
y = df_model[outcome]

# Convert count outcome to binary (any rejection vs none) as per hypothesis
y_binary = (y > 0).astype(int)

# 7. Determine clustering variable if present
if "loan_officer_id" in df.columns:
    cluster_ids = df.loc[df_model.index, "loan_officer_id"]
    clustering_strategy = "clustered_se"
else:
    cluster_ids = None
    clustering_strategy = "none"

# 8. Fit logistic regression
logit_model = sm.Logit(y_binary, X)
if cluster_ids is not None:
    result = logit_model.fit(disp=False, cov_type='cluster', cov_kwds={'groups': cluster_ids})
else:
    result = logit_model.fit(disp=False)

# 9. Extract estimand for the predictor
coef = result.params[predictor]
se = result.bse[predictor]
z = coef / se
p_value = 2 * (1 - norm.cdf(abs(z)))
ci_lower_log = coef - 1.96 * se
ci_upper_log = coef + 1.96 * se
odds_ratio = np.exp(coef)
ci_lower = np.exp(ci_lower_log)
ci_upper = np.exp(ci_upper_log)

# 10. Significance decision
conclusion = "significant_effect" if p_value < 0.05 else "no_significant_effect"

# 11. Assemble JSON output
output = {
    "effect_size": float(odds_ratio),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_value),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "logistic",
    "predictor_used": "average_risk_score",
    "covariates_included": [col for col in X.columns if col not in ("const", predictor)],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": clustering_strategy,
    "exclusions_applied": exclusions_desc
}

print(json.dumps(output))