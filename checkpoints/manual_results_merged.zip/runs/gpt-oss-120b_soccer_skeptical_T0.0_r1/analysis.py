import pandas as pd
import numpy as np
import json
import statsmodels.api as sm

# 1. Load data
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_soccer_skeptical_T0.0_r1/data.csv"
df = pd.read_csv(FILE_PATH)

# 2. Clean / prepare ---------------------------------------------------------
# Keep rows with both skin‑tone ratings
df = df.dropna(subset=["rater1", "rater2"])

# Continuous skin‑tone predictor (average of two raters)
df["skin_tone"] = df[["rater1", "rater2"]].mean(axis=1)

# Binary outcome: any red card from this referee?
df["red_any"] = (df["redCards"] > 0).astype(int)

# Covariates to adjust for
covariate_cols = ["games", "yellowCards", "height", "weight", "position", "leagueCountry"]

# Fill missing categorical values
df["position"] = df["position"].fillna("Missing")
df["leagueCountry"] = df["leagueCountry"].fillna("Missing")

# Drop rows with missing numeric covariates
df = df.dropna(subset=["games", "yellowCards", "height", "weight"])

# One‑hot encode categoricals (drop first to avoid collinearity)
df_dummies = pd.get_dummies(df[covariate_cols], drop_first=True)

# Design matrix
X = pd.concat([df["skin_tone"], df_dummies], axis=1)
X = sm.add_constant(X)  # intercept
y = df["red_any"]

# 3. Fit logistic regression with clustered SE by referee number ----------
if "refNum" in df.columns:
    result = sm.Logit(y, X).fit(
        disp=False,
        cov_type="cluster",
        cov_kwds={"groups": df["refNum"]},
    )
else:
    result = sm.Logit(y, X).fit(disp=False)

# 4. Extract estimand for skin_tone -----------------------------------------
coef = result.params["skin_tone"]
se = result.bse["skin_tone"]
z = coef / se
p_value = 2 * (1 - sm.stats.norm.cdf(abs(z)))
ci_lower_log = coef - 1.96 * se
ci_upper_log = coef + 1.96 * se
odds_ratio = np.exp(coef)
ci_lower = np.exp(ci_lower_log)
ci_upper = np.exp(ci_upper_log)

# 5. Assemble JSON output ----------------------------------------------------
output = {
    "effect_size": float(odds_ratio),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_value),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if p_value < 0.05 else "no_significant_effect",
    "model_family": "logistic",
    "predictor_used": "average of rater1 and rater2 (skin_tone)",
    "covariates_included": covariate_cols,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "rows with missing rater1/rater2 or numeric covariates removed"
}

print(json.dumps(output, ensure_ascii=False))