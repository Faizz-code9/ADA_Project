import pandas as pd
import numpy as np
import statsmodels.api as sm
import json
import warnings

warnings.filterwarnings("ignore")

# 1. Load data
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_disguise_confirmatory_T0.0_r1/data.csv"
df = pd.read_csv(FILE_PATH, low_memory=False)

# 2. Build predictor: average of alpha and beta scores
df["risk_score"] = df[["risk_evaluator_alpha_score", "risk_evaluator_beta_score"]].mean(axis=1)

# Binary outcome: any rejection
df["rejection_flag"] = (df["loan_application_rejections"] > 0).astype(int)

# Covariates to adjust for
covariates = [
    "credit_score_index",
    "annual_income_bracket",
    "prior_approved_loans",
    "prior_denied_loans",
    "elevated_risk_warnings",
    "formal_inquiry_notices",
    "regional_index_a",
    "regional_index_b",
]

# Keep only needed columns
cols_needed = ["risk_score", "rejection_flag", "loan_officer_id"] + covariates
df_sub = df[cols_needed].copy()

# 3. Missing data strategy: listwise deletion
initial_n = len(df_sub)
df_sub.dropna(inplace=True)
final_n = len(df_sub)
exclusions_desc = f"dropped {initial_n - final_n} rows with missing data"

# 4. Design matrix
X = sm.add_constant(df_sub[["risk_score"] + covariates], has_constant='add')
y = df_sub["rejection_flag"]

# 5. Fit logistic regression with clustered SEs by loan_officer_id
clusters = df_sub["loan_officer_id"]
logit_res = sm.Logit(y, X).fit(disp=False, cov_type="cluster", cov_kwds={"groups": clusters})

# 6. Extract estimand for risk_score
coef = logit_res.params["risk_score"]
se = logit_res.bse["risk_score"]
p_val = logit_res.pvalues["risk_score"]
ci_log = logit_res.conf_int().loc["risk_score"]
ci_lower_log, ci_upper_log = ci_log[0], ci_log[1]

# Convert log-odds to odds ratio
odds_ratio = np.exp(coef)
ci_lower = np.exp(ci_lower_log)
ci_upper = np.exp(ci_upper_log)

# 7. Significance decision
conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

# 8. Assemble JSON output
output = {
    "effect_size": float(odds_ratio),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "logistic",
    "predictor_used": "average_risk_score = (risk_evaluator_alpha_score + risk_evaluator_beta_score)/2",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": exclusions_desc
}

print(json.dumps(output, ensure_ascii=False))