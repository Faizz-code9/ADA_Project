import pandas as pd
import numpy as np
import json
import statsmodels.api as sm
import statsmodels.formula.api as smf
from scipy.stats import norm

# 1. Load data
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_soccer_skeptical_T0.7_r2/data.csv"
df = pd.read_csv(FILE_PATH)

# 2. Clean / prepare
# Average skin‑tone score from the two raters
df["skin_tone_avg"] = df[["rater1", "rater2"]].mean(axis=1)

# Exclude rows missing the predictor or essential exposure information
mask_missing = df["skin_tone_avg"].isna() | df["games"].isna()
exclusions_applied = "rows with missing rater1/rater2 or games removed"
df = df.loc[~mask_missing].copy()

# Offset for exposure (rate per game)
df["log_games"] = np.log(df["games"])

# 3. Fit Poisson regression (count of red cards) with offset and clustered SE by referee
formula = "redCards ~ skin_tone_avg"
glm_model = smf.glm(formula=formula,
                    data=df,
                    family=sm.families.Poisson(),
                    offset=df["log_games"])
glm_result = glm_model.fit(cov_type="cluster", cov_kwds={"groups": df["refNum"]})

# 4. Extract primary estimand (incidence rate ratio for a full 0→1 change in skin tone)
coef = glm_result.params["skin_tone_avg"]
se = glm_result.bse["skin_tone_avg"]
z = coef / se
p_value = 2 * (1 - norm.cdf(abs(z)))
irr = np.exp(coef)
ci_lower = np.exp(coef - 1.96 * se)
ci_upper = np.exp(coef + 1.96 * se)

conclusion = "significant_effect" if p_value < 0.05 else "no_significant_effect"

# 5. JSON output
output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_value),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "average_skin_tone = (rater1 + rater2) / 2",
    "covariates_included": [],                     # only offset (games) used, no additional covariates
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": exclusions_applied
}

print(json.dumps(output))