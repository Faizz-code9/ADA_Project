import pandas as pd
import numpy as np
import json
import statsmodels.api as sm
from scipy.stats import norm

# 1. Load data
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_placebo_skeptical_T0.0_r2/data.csv"
df = pd.read_csv(FILE_PATH)

# 2. Prepare predictor and outcome
df["avg_skin"] = df[["rater1", "rater2"]].mean(axis=1)
df["red_binary"] = (df["redCards"] > 0).astype(int)

# 3. Define covariates and handle missing data
covariates = ["games", "yellowCards", "height", "weight", "position", "leagueCountry"]
required = ["avg_skin", "red_binary", "refNum"] + covariates
df_clean = df.dropna(subset=required)

exclusions = "rows with missing avg_skin, red_binary, refNum, games, yellowCards, height, weight, position, or leagueCountry removed"

# 4. Build design matrix (include categorical dummies)
cat_cols = ["position", "leagueCountry"]
df_dummies = pd.get_dummies(df_clean[cat_cols], drop_first=True, dtype=float)
X = pd.concat([
    df_clean[["avg_skin", "games", "yellowCards", "height", "weight"]].astype(float),
    df_dummies
], axis=1)
X = sm.add_constant(X, has_constant='add')
y = df_clean["red_binary"]

# 5. Fit logistic regression with clustered SE by referee (refNum)
clusters = df_clean["refNum"]
model = sm.GLM(y, X, family=sm.families.Binomial())
result = model.fit(cov_type="cluster", cov_kwds={"groups": clusters})

# 6. Extract estimand for avg_skin
coef = result.params["avg_skin"]
se = result.bse["avg_skin"]
z = coef / se
p_value = 2 * (1 - norm.cdf(abs(z)))
odds_ratio = np.exp(coef)
ci_lower = np.exp(coef - 1.96 * se)
ci_upper = np.exp(coef + 1.96 * se)

# 7. Assemble JSON output
output = {
    "effect_size": float(odds_ratio),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_value),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if p_value < 0.05 else "no_significant_effect",
    "model_family": "logistic",
    "predictor_used": "average_skin_tone = (rater1 + rater2)/2",
    "covariates_included": ["games", "yellowCards", "height", "weight"] + list(df_dummies.columns),
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": exclusions
}

print(json.dumps(output, ensure_ascii=False))