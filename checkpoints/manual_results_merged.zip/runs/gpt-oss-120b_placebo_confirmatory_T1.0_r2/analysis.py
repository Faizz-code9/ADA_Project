import pandas as pd
import numpy as np
import json
import statsmodels.api as sm
from scipy.stats import norm

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gpt-oss-120b_placebo_confirmatory_T1.0_r2/data.csv"
df = pd.read_csv(file_path)

# 2. Cleaning & preparation
# Average skin tone from two raters
df["skin_tone"] = df[["rater1", "rater2"]].mean(axis=1, skipna=False)

# Approximate age in 2013 season from birthday (format dd.mm.yyyy)
def extract_year(b):
    try:
        return int(str(b).split(".")[-1])
    except Exception:
        return np.nan

df["birth_year"] = df["birthday"].apply(extract_year)
df["age"] = 2013 - df["birth_year"]

# Binary outcome: any red card from this referee
df["red_card_any"] = (df["redCards"] > 0).astype(int)

# Covariates we will adjust for
base_covariates = ["games", "age"]

# Encode categorical predictors
df = pd.get_dummies(df, columns=["position", "leagueCountry"], drop_first=True)

# Gather all covariate column names after dummies
covariate_cols = base_covariates + [
    col for col in df.columns if col.startswith("position_") or col.startswith("leagueCountry_")
]

# Variables needed for the model
model_vars = ["skin_tone", "red_card_any", "refNum"] + covariate_cols

# Listwise deletion for any missing in the variables used
df_model = df[model_vars].dropna()

# Record exclusions description
exclusions = f"Dropped {len(df) - len(df_model)} rows due to missing skin tone, age, or covariates."

# 3. Fit logistic regression with clustered (by referee) robust SE
y = df_model["red_card_any"]
X = df_model[["skin_tone"] + covariate_cols]
X = sm.add_constant(X, has_constant="add")

glm = sm.GLM(y, X, family=sm.families.Binomial())
# Cluster-robust covariance using refNum as cluster identifier
result = glm.fit(cov_type="cluster", cov_kwds={"groups": df_model["refNum"]})

beta = result.params["skin_tone"]
se = result.bse["skin_tone"]

# 4. Primary estimand: odds ratio for a full 0 → 1 increase in skin tone
odds_ratio = np.exp(beta)
ci_lower = np.exp(beta - 1.96 * se)
ci_upper = np.exp(beta + 1.96 * se)
z = beta / se
p_value = 2 * (1 - norm.cdf(abs(z)))

conclusion = "significant_effect" if p_value < 0.05 else "no_significant_effect"

# 5. JSON output
output = {
    "effect_size": float(odds_ratio),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_value),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "logistic",
    "predictor_used": "average of rater1 and rater2 (skin_tone)",
    "covariates_included": covariate_cols,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": exclusions
}

print(json.dumps(output, ensure_ascii=False))