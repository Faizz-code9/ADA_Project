import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

# 1. Load data
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_soccer_neutral_T0.7_r1/data.csv"
df = pd.read_csv(FILE_PATH)

# 2. Prepare data
# Create continuous skin tone predictor as average of rater1 and rater2
df["skin_tone"] = df[["rater1", "rater2"]].mean(axis=1)

# Variables to keep
covariates = ["games", "yellowCards", "position", "leagueCountry"]
required = ["redCards", "skin_tone"] + covariates + ["refNum"]

# Drop rows with any missing values in required columns
df_clean = df[required].dropna()

# Exclusions description
exclusions = f"dropped {len(df) - len(df_clean)} rows with missing values in required columns"

# Encode categorical variables
df_clean = pd.get_dummies(df_clean, columns=["position", "leagueCountry"], drop_first=True)

# Define outcome (binary) – redCards >0 treated as 1
df_clean["red_card_binary"] = (df_clean["redCards"] > 0).astype(int)

# 3. Fit logistic regression with clustered SE by referee
X_vars = ["skin_tone"] + [col for col in df_clean.columns if col.startswith("position_") or col.startswith("leagueCountry_")] + ["games", "yellowCards"]
X = df_clean[X_vars]
X = sm.add_constant(X, has_constant='add')
y = df_clean["red_card_binary"]

logit_mod = sm.Logit(y, X)
result = logit_mod.fit(disp=False, cov_type="cluster", cov_kwds={"groups": df_clean["refNum"]})

# 4. Extract estimand
coef = result.params["skin_tone"]
se = result.bse["skin_tone"]
pval = result.pvalues["skin_tone"]
ci_low_log, ci_upp_log = result.conf_int().loc["skin_tone"]
# Transform to odds ratio scale
or_est = np.exp(coef)
ci_low = np.exp(ci_low_log)
ci_upp = np.exp(ci_upp_log)

conclusion = "significant_effect" if pval < 0.05 else "no_significant_effect"

# 5. Output JSON
output = {
    "effect_size": float(or_est),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(pval),
    "ci_lower": float(ci_low),
    "ci_upper": float(ci_upp),
    "conclusion": conclusion,
    "model_family": "logistic",
    "predictor_used": "average of rater1 and rater2 (skin_tone)",
    "covariates_included": X_vars,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": exclusions
}

print(json.dumps(output, ensure_ascii=False))