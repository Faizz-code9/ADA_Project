import pandas as pd
import numpy as np
import json
import statsmodels.api as sm

# ------------------------------
# 1. Load data
# ------------------------------
path = "/kaggle/working/outputs/runs/gpt-oss-120b_soccer_neutral_T0.7_r3/data.csv"
df = pd.read_csv(path)

# ------------------------------
# 2. Clean / prepare
# ------------------------------
# Average skin‑tone score (continuous 0‑1)
df["skin_tone"] = df[["rater1", "rater2"]].mean(axis=1)

# Binary outcome: did the player receive at least one red card from this referee?
df["red_flag"] = (df["redCards"] > 0).astype(int)

# Covariates we will adjust for
covariates = ["games", "height", "weight", "yellowCards", "position", "leagueCountry"]

# Keep only rows with non‑missing values for all required columns
required = ["skin_tone", "red_flag", "refNum"] + covariates
df_clean = df[required].dropna()

exclusions = "rows with missing rater1/rater2, height, weight, position, games, yellowCards removed"

# Encode categorical variables (position, leagueCountry) with dummy variables
df_enc = pd.get_dummies(df_clean, columns=["position", "leagueCountry"], drop_first=True)

# ------------------------------
# 3. Fit logistic model with clustered SE by referee
# ------------------------------
y = df_enc["red_flag"]
X = df_enc.drop(columns=["red_flag", "refNum"])
X = sm.add_constant(X, has_constant='add')

# Use GLM with binomial family; request cluster‑robust covariance
model = sm.GLM(y, X, family=sm.families.Binomial())
result = model.fit(cov_type="cluster", cov_kwds={"groups": df_enc["refNum"]})

# ------------------------------
# 4. Extract primary estimand (odds ratio for a full 0→1 change in skin tone)
# ------------------------------
coef = result.params["skin_tone"]
se = result.bse["skin_tone"]
p_val = result.pvalues["skin_tone"]
or_val = np.exp(coef)
ci_lower = np.exp(coef - 1.96 * se)
ci_upper = np.exp(coef + 1.96 * se)

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

# ------------------------------
# 5. Assemble JSON output
# ------------------------------
output = {
    "effect_size": float(or_val),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "logistic",
    "predictor_used": "average_rater_score = (rater1 + rater2)/2",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": exclusions
}

print(json.dumps(output, ensure_ascii=False))