import pandas as pd
import numpy as np
import statsmodels.api as sm
from scipy.stats import norm
import json

# 1. Load data
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_placebo_confirmatory_T0.0_r2/data.csv"
df = pd.read_csv(FILE_PATH)

# 2. Cleaning / preparation
# Keep rows with both skin‑tone ratings
df = df.dropna(subset=["rater1", "rater2"])

# Build continuous skin‑tone predictor (average of two raters)
df["skin_tone"] = df[["rater1", "rater2"]].mean(axis=1)

# Binary outcome: any red card from this referee?
df["red_any"] = (df["redCards"] > 0).astype(int)

# Choose covariates that are mostly complete
covariate_cols = ["games", "yellowCards", "position", "leagueCountry"]
df = df.dropna(subset=covariate_cols)

# One‑hot encode categorical covariates, drop first to avoid collinearity
df_dummies = pd.get_dummies(df[covariate_cols], drop_first=True, dtype=float)

# Assemble design matrix
X = pd.concat([df["skin_tone"], df_dummies], axis=1)
X = sm.add_constant(X, has_constant='add')
y = df["red_any"]

# 3. Fit logistic regression with clustered SE on referee
logit_model = sm.Logit(y, X, missing='raise')
try:
    # Initial fit
    fit_res = logit_model.fit(disp=0)
    # Clustered robust covariance
    result = fit_res.get_robustcov_results(cov_type="cluster", groups=df["refNum"])
    clustering_used = "clustered_se"
except Exception:
    # Fallback to standard fit if clustering fails
    result = logit_model.fit(disp=0)
    clustering_used = "none"

# 4. Extract primary estimand (odds ratio for skin_tone)
coef = result.params["skin_tone"]
se = result.bse["skin_tone"]
z = coef / se
p_value = 2 * (1 - norm.cdf(abs(z)))
or_est = np.exp(coef)
ci_lower = np.exp(coef - 1.96 * se)
ci_upper = np.exp(coef + 1.96 * se)

# 5. Build output JSON
output = {
    "effect_size": float(or_est),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_value),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if p_value < 0.05 else "no_significant_effect",
    "model_family": "logistic",
    "predictor_used": "average of rater1 and rater2 (skin_tone)",
    "covariates_included": list(df_dummies.columns),
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": clustering_used,
    "exclusions_applied": "rows missing rater1/rater2 or selected covariates were removed"
}

print(json.dumps(output, ensure_ascii=False))