import pandas as pd
import numpy as np
import statsmodels.api as sm
from scipy.stats import norm
import json

# 1. Load data
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_soccer_confirmatory_T0.7_r5/data.csv"
df = pd.read_csv(FILE_PATH)

# 2. Prepare data
# Predictor: average of rater1 and rater2
df["skin"] = df[["rater1", "rater2"]].mean(axis=1)

# Outcome: binary indicator of any red card
df["red_binary"] = (df["redCards"] > 0).astype(int)

# Covariates for adjustment
covariates = ["games", "yellowCards"]

# Exclusions: drop rows missing skin, outcome, referee ID, or covariates
required_cols = ["skin", "red_binary", "refNum"] + covariates
df_clean = df.dropna(subset=required_cols)

exclusions_desc = "rows with missing rater1/rater2, redCards, refNum, or covariates removed"

# 3. Fit logistic regression with clustered (by referee) robust SE
X = df_clean[["skin"] + covariates]
X = sm.add_constant(X, has_constant='add')
y = df_clean["red_binary"]

logit_fit = sm.Logit(y, X).fit(
    disp=0,
    cov_type="cluster",
    cov_kwds={"groups": df_clean["refNum"]},
)

# 4. Extract estimand (odds ratio for skin tone)
coef = logit_fit.params["skin"]
se = logit_fit.bse["skin"]
z = coef / se
p_value = 2 * (1 - norm.cdf(abs(z)))
odds_ratio = np.exp(coef)
ci_lower = np.exp(coef - 1.96 * se)
ci_upper = np.exp(coef + 1.96 * se)

conclusion = "significant_effect" if p_value < 0.05 else "no_significant_effect"

# 5. Output JSON
output = {
    "effect_size": float(odds_ratio),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_value),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "logistic",
    "predictor_used": "average of rater1 and rater2 (skin)",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": exclusions_desc
}

print(json.dumps(output))