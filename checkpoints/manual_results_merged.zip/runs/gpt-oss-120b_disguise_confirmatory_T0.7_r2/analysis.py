import pandas as pd
import numpy as np
import json
import statsmodels.api as sm

# 1. Load data
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_disguise_confirmatory_T0.7_r2/data.csv"
df = pd.read_csv(FILE_PATH)

# 2. Construct predictor (average of two risk scores) and binary outcome
df["risk_score_avg"] = df[["risk_evaluator_alpha_score", "risk_evaluator_beta_score"]].mean(axis=1)
df["rejection"] = (df["loan_application_rejections"] > 0).astype(int)

# 3. Choose covariates for adjustment (numeric variables)
covariates = [
    "credit_score_index",
    "annual_income_bracket",
    "prior_approved_loans",
    "prior_conditional_loans",
    "prior_denied_loans",
    "repayment_performance_score",
    "formal_inquiry_notices",
    "elevated_risk_warnings",
]

# 4. Missing data handling
# Keep only needed columns
cols_needed = ["risk_score_avg", "rejection"] + covariates + ["loan_officer_id"]
df = df[cols_needed]

# Listwise deletion for predictor and outcome
df = df.dropna(subset=["risk_score_avg", "rejection"])

# Mean impute remaining numeric covariates
for col in covariates:
    if df[col].isnull().any():
        df[col] = df[col].fillna(df[col].mean())

# 5. Model fitting: logistic regression with cluster-robust SE by loan officer
X = df[["risk_score_avg"] + covariates]
X = sm.add_constant(X, has_constant='add')
y = df["rejection"]
clusters = df["loan_officer_id"]

logit_res = sm.Logit(y, X).fit(disp=0, cov_type="cluster", cov_kwds={"groups": clusters})

# 6. Extract estimand for main predictor
coef = logit_res.params["risk_score_avg"]
se = logit_res.bse["risk_score_avg"]
pval = logit_res.pvalues["risk_score_avg"]
ci_lower_log, ci_upper_log = logit_res.conf_int().loc["risk_score_avg"]
odds_ratio = np.exp(coef)
ci_lower = np.exp(ci_lower_log)
ci_upper = np.exp(ci_upper_log)

# 7. Assemble JSON result
result = {
    "effect_size": float(odds_ratio),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(pval),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if pval < 0.05 else "no_significant_effect",
    "model_family": "logistic",
    "predictor_used": "average of risk_evaluator_alpha_score and risk_evaluator_beta_score",
    "covariates_included": covariates,
    "missing_data_strategy": "mean_imputation",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "rows with missing risk evaluator scores removed (listwise deletion)"
}

print(json.dumps(result, ensure_ascii=False))