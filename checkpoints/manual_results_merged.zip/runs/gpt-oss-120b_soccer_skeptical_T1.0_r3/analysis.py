import pandas as pd
import numpy as np
import json
import statsmodels.api as sm

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gpt-oss-120b_soccer_skeptical_T1.0_r3/data.csv"
df = pd.read_csv(file_path)

# 2. Build predictor: average skin‑tone score
df["avg_skin_tone"] = df[["rater1", "rater2"]].mean(axis=1)

# Binary outcome: any red card received from that referee
df["red_any"] = (df["redCards"] > 0).astype(int)

# Variables to keep
keep_cols = [
    "avg_skin_tone", "red_any", "games", "height", "weight",
    "position", "leagueCountry", "refNum"
]

# 2a. Listwise deletion for required fields
df_clean = df.dropna(subset=keep_cols)

# 2b. Encode categoricals (position, leagueCountry) – drop first level
cat_vars = ["position", "leagueCountry"]
dummies = pd.get_dummies(df_clean[cat_vars], drop_first=True, prefix_sep="_")
df_model = pd.concat(
    [df_clean[["red_any", "avg_skin_tone", "games", "height", "weight"]], dummies],
    axis=1,
)

# Design matrix with intercept
X = sm.add_constant(df_model.drop(columns=["red_any"]), has_constant='add')
y = df_model["red_any"]

# 3. Fit logistic regression (GLM Binomial) with clustered robust SE by referee
glm = sm.GLM(y, X, family=sm.families.Binomial())
res = glm.fit(cov_type="cluster", cov_kwds={"groups": df_clean["refNum"]})

# 4. Extract estimand for avg_skin_tone
coef = res.params["avg_skin_tone"]
se = res.bse["avg_skin_tone"]
z = coef / se
p_val = 2 * (1 - sm.stats.norm.cdf(abs(z)))
ci_low_log = coef - 1.96 * se
ci_upp_log = coef + 1.96 * se
odds_ratio = np.exp(coef)
ci_low = np.exp(ci_low_log)
ci_upp = np.exp(ci_upp_log)

# 5. JSON output
output = {
    "effect_size": float(odds_ratio),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_low),
    "ci_upper": float(ci_upp),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "logistic",
    "predictor_used": "average_skin_tone = (rater1 + rater2) / 2",
    "covariates_included": ["games", "height", "weight"] + list(dummies.columns),
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "removed rows with missing rater1/rater2, weight, position, height, games, leagueCountry, or refNum"
}

print(json.dumps(output, ensure_ascii=False))