import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.stats.sandwich_covariance as sw
import json

# 1. Load data
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_disguise_neutral_T1.0_r2/data.csv"
df = pd.read_csv(FILE_PATH)

# 2. Outcome: binary rejection (any rejection vs none)
df["rejection"] = (df["loan_application_rejections"] > 0).astype(int)

# 3. Predictor of interest: average of the two risk evaluator scores
df["risk_score_avg"] = df[["risk_evaluator_alpha_score", "risk_evaluator_beta_score"]].mean(axis=1)

# 4. Choose covariates (numeric, plausible confounders)
covariates = [
    "credit_score_index",
    "annual_income_bracket",
    "prior_approved_loans",
    "prior_denied_loans",
    "repayment_performance_score",
    "elevated_risk_warnings",
    "total_applications_reviewed",
]

# Columns needed for the model
model_cols = ["rejection", "risk_score_avg"] + covariates + ["loan_officer_id"]

# 5. Missing data handling: listwise deletion
df_model = df[model_cols].dropna()
missing_strategy = "listwise_deletion"

# 6. Design matrix
y = df_model["rejection"]
X = df_model[["risk_score_avg"] + covariates]
X = sm.add_constant(X, has_constant='add')

# 7. Fit logistic regression (maximum likelihood)
logit_res = sm.Logit(y, X).fit(disp=0)

# 8. Cluster-robust covariance by loan_officer_id
clusters = df_model["loan_officer_id"]
cluster_cov = sw.cov_cluster(logit_res, clusters)
se = np.sqrt(np.diag(cluster_cov))

# Extract statistics for the main predictor
coef = logit_res.params["risk_score_avg"]
se_coef = se[logit_res.params.index.get_loc("risk_score_avg")]
p_val = logit_res.pvalues["risk_score_avg"]
ci_lower_log = coef - 1.96 * se_coef
ci_upper_log = coef + 1.96 * se_coef

# Convert log‑odds coefficient to odds ratio (full 0‑1 change)
or_est = np.exp(coef)
or_ci_lower = np.exp(ci_lower_log)
or_ci_upper = np.exp(ci_upper_log)

# 9. Assemble output
output = {
    "effect_size": float(or_est),
    "effect_type": "odds_ratio",
    "standard_error": float(se_coef),
    "p_value": float(p_val),
    "ci_lower": float(or_ci_lower),
    "ci_upper": float(or_ci_upper),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "logistic",
    "predictor_used": "average of risk_evaluator_alpha_score and risk_evaluator_beta_score",
    "covariates_included": covariates,
    "missing_data_strategy": missing_strategy,
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "rows with missing values in any modeling variable were removed"
}

print(json.dumps(output, ensure_ascii=False))