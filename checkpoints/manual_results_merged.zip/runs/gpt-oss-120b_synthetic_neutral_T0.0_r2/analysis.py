import pandas as pd
import numpy as np
import json
import statsmodels.api as sm

# 1. Load data
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_synthetic_neutral_T0.0_r2/data.csv"
df = pd.read_csv(FILE_PATH)

# 2. Data cleaning / preparation
missing_strategy = "mean_imputation"
if df["skin_tone"].isnull().any():
    df["skin_tone"] = df["skin_tone"].fillna(df["skin_tone"].mean())

# Binary outcome: any red card received
df["redCard_any"] = (df["redCards"] > 0).astype(int)

# Main predictor
predictor = "skin_tone"

# Covariates to adjust for
covariates = [
    "games",
    "yellowCards",
    "height",
    "weight",
]

# One‑hot encode categorical variables (drop first level)
cat_vars = ["position", "leagueCountry"]
df = pd.get_dummies(df, columns=cat_vars, drop_first=True, dtype=int)

# Assemble design matrix
X_cols = [predictor] + covariates + \
         [c for c in df.columns if c.startswith("position_") or c.startswith("leagueCountry_")]
X = df[X_cols]
X = sm.add_constant(X, has_constant='add')
y = df["redCard_any"]

# 3. Fit logistic regression with clustered robust SE by refereeID
model = sm.Logit(y, X, missing='drop')
result = model.fit(disp=0, cov_type='cluster', cov_kwds={'groups': df["refereeID"]})

# 4. Extract primary estimand (odds ratio for skin_tone)
coef = result.params[predictor]
se = result.bse[predictor]
p_val = result.pvalues[predictor]

# 95% CI on log‑odds, then transform to odds ratio
ci_low_log = coef - 1.96 * se
ci_upp_log = coef + 1.96 * se
ci_low = np.exp(ci_low_log)
ci_upp = np.exp(ci_upp_log)
odds_ratio = np.exp(coef)

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

# 5. JSON output
output = {
    "effect_size": float(odds_ratio),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_low),
    "ci_upper": float(ci_upp),
    "conclusion": conclusion,
    "model_family": "logistic",
    "predictor_used": predictor,
    "covariates_included": covariates + [c for c in df.columns if c.startswith("position_") or c.startswith("leagueCountry_")],
    "missing_data_strategy": missing_strategy,
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "none"
}

print(json.dumps(output, ensure_ascii=False))