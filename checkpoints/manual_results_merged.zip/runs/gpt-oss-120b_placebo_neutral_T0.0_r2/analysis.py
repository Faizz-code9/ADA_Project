import pandas as pd
import numpy as np
import json
import statsmodels.api as sm

# ----------------------------------------------------------------------
# 1. Load data
# ----------------------------------------------------------------------
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_placebo_neutral_T0.0_r2/data.csv"
df = pd.read_csv(FILE_PATH)

# ----------------------------------------------------------------------
# 2. Clean / prepare
# ----------------------------------------------------------------------
# Average skin‑tone score
df["avg_skin_tone"] = df[["rater1", "rater2"]].mean(axis=1)

# Binary outcome: any red card vs none
df["red_any"] = (df["redCards"] > 0).astype(int)

# Numeric covariates we will keep (all have few missing values)
numeric_cov = ["games", "yellowCards", "height", "weight"]

# Columns that must be present
required = ["avg_skin_tone", "red_any", "refNum"] + numeric_cov + ["position", "leagueCountry"]
df_clean = df.dropna(subset=required)

# Record exclusions
exclusions = f"dropped {len(df) - len(df_clean)} rows with missing skin tone, outcome, or covariates"

# One‑hot encode categorical variables (drop_first to avoid collinearity)
df_clean = pd.get_dummies(df_clean, columns=["position", "leagueCountry"], drop_first=True)

# Identify dummy columns created
dummy_cols = [c for c in df_clean.columns if c.startswith("position_") or c.startswith("leagueCountry_")]

# ----------------------------------------------------------------------
# 3. Fit logistic regression (clustered SE by referee)
# ----------------------------------------------------------------------
y = df_clean["red_any"]
X = df_clean[["avg_skin_tone"] + numeric_cov + dummy_cols]
X = sm.add_constant(X, has_constant='add')

logit_model = sm.Logit(y, X)
logit_res = logit_model.fit(disp=0)

# Clustered robust standard errors by referee identifier
logit_robust = logit_res.get_robustcov_results(cov_type="cluster", groups=df_clean["refNum"])

# ----------------------------------------------------------------------
# 4. Primary estimand (odds ratio for a full 0→1 change in skin tone)
# ----------------------------------------------------------------------
coef = logit_robust.params["avg_skin_tone"]
se = logit_robust.bse["avg_skin_tone"]
p_val = logit_robust.pvalues["avg_skin_tone"]
odds_ratio = np.exp(coef)
ci_lower = np.exp(coef - 1.96 * se)
ci_upper = np.exp(coef + 1.96 * se)

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

# ----------------------------------------------------------------------
# 5. JSON output
# ----------------------------------------------------------------------
output = {
    "effect_size": float(odds_ratio),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "logistic",
    "predictor_used": "average_skin_tone = (rater1 + rater2)/2",
    "covariates_included": numeric_cov + dummy_cols,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": exclusions
}

print(json.dumps(output, ensure_ascii=False))