import pandas as pd
import numpy as np
import json
import statsmodels.api as sm

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gpt-oss-120b_disguise_confirmatory_T1.0_r1/data.csv"
df = pd.read_csv(file_path)

# 2. Data preparation
# Continuous predictor: average of alpha and beta scores
df["average_risk_score"] = df[["risk_evaluator_alpha_score", "risk_evaluator_beta_score"]].mean(axis=1)

# Binary outcome: any rejection (0 = none, 1 = at least one)
df["rejection_binary"] = (df["loan_application_rejections"] > 0).astype(int)

# Covariates (numeric variables only to avoid high‑cardinality dummies)
covariates = [
    "credit_score_index",
    "annual_income_bracket",
    "prior_approved_loans",
    "prior_conditional_loans",
    "prior_denied_loans",
    "repayment_performance_score",
    "formal_inquiry_notices",
    "elevated_risk_warnings",
    "total_applications_reviewed",
    "regional_index_a",
    "regional_index_b"
]

# Subset required columns
required = ["average_risk_score", "rejection_binary", "loan_officer_id"] + covariates
df_model = df[required].copy()

# Missing data strategy: listwise deletion
initial_n = len(df_model)
df_model.dropna(inplace=True)
final_n = len(df_model)
exclusions_desc = f"{initial_n - final_n} rows with missing values removed"

# 3. Fit logistic regression with clustered robust SEs (cluster by loan officer)
X = df_model[["average_risk_score"] + covariates]
X = sm.add_constant(X, has_constant='add')
y = df_model["rejection_binary"]

glm_binom = sm.GLM(y, X, family=sm.families.Binomial())
result = glm_binom.fit(cov_type="cluster", cov_kwds={"groups": df_model["loan_officer_id"]})

# 4. Extract primary estimand (odds ratio for average_risk_score)
coef = result.params["average_risk_score"]
se_log = result.bse["average_risk_score"]
p_val = result.pvalues["average_risk_score"]
ci_log = result.conf_int().loc["average_risk_score"]
odds_ratio = np.exp(coef)
ci_lower_or = np.exp(ci_log[0])
ci_upper_or = np.exp(ci_log[1])
# Delta method SE for odds ratio
se_or = odds_ratio * se_log

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

# 5. JSON output
output = {
    "effect_size": float(odds_ratio),
    "effect_type": "odds_ratio",
    "standard_error": float(se_or),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower_or),
    "ci_upper": float(ci_upper_or),
    "conclusion": conclusion,
    "model_family": "logistic",
    "predictor_used": "average_risk_score = (risk_evaluator_alpha_score + risk_evaluator_beta_score) / 2",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": exclusions_desc
}

print(json.dumps(output))