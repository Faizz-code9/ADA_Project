import pandas as pd
import numpy as np
import json
import statsmodels.api as sm
import statsmodels.stats.sandwich_covariance as sw

# 1. Load data
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_soccer_confirmatory_T1.0_r1/data.csv"
df = pd.read_csv(FILE_PATH)

# 2. Clean & prepare ---------------------------------------------------------
# Keep rows with both skin tone ratings
df = df.dropna(subset=["rater1", "rater2"])

# Average skin tone (continuous 0‑1)
df["avg_skin"] = (df["rater1"] + df["rater2"]) / 2.0

# Binary outcome: any red card from this referee
df["red_flag"] = (df["redCards"] > 0).astype(int)

# Covariates to adjust for (chosen a priori)
covariate_cols = ["games", "yellowCards", "position", "leagueCountry"]

# Fill missing categorical entries with a placeholder
df["position"] = df["position"].fillna("Missing")
df["leagueCountry"] = df["leagueCountry"].fillna("Missing")

# Drop rows missing required numeric covariates
df = df.dropna(subset=["games", "yellowCards"])

# 3. Build design matrix ----------------------------------------------------
X_numeric = df[["avg_skin", "games", "yellowCards"]].copy()

# One‑hot encode categoricals (drop_first to avoid perfect collinearity)
X_pos = pd.get_dummies(df["position"], prefix="pos", drop_first=True)
X_league = pd.get_dummies(df["leagueCountry"], prefix="league", drop_first=True)

X = pd.concat([X_numeric, X_pos, X_league], axis=1)
X = sm.add_constant(X, has_constant='add')
y = df["red_flag"]

# 4. Fit logistic regression -------------------------------------------------
logit_mod = sm.Logit(y, X)
res = logit_mod.fit(disp=0)

# 5. Cluster-robust standard errors (cluster on referee ID) -----------------
cluster_ids = df["refNum"]
cov_cluster = sw.cov_cluster(res, cluster_ids)
se_cluster = np.sqrt(np.diag(cov_cluster))

# Extract coefficient, SE, and compute odds ratio & CI
coef = res.params["avg_skin"]
se = se_cluster[res.params.index.get_loc("avg_skin")]
z = coef / se
p_value = 2 * (1 - sm.stats.norm.cdf(abs(z)))
odds_ratio = np.exp(coef)
ci_lower = np.exp(coef - 1.96 * se)
ci_upper = np.exp(coef + 1.96 * se)

conclusion = "significant_effect" if p_value < 0.05 else "no_significant_effect"

# 6. JSON output ------------------------------------------------------------
output = {
    "effect_size": float(odds_ratio),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_value),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "logistic",
    "predictor_used": "average_skin_tone = (rater1 + rater2) / 2",
    "covariates_included": ["games", "yellowCards", "position", "leagueCountry"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "Rows with missing rater1/rater2 or missing games/yellowCards/position excluded (listwise deletion)"
}

print(json.dumps(output))