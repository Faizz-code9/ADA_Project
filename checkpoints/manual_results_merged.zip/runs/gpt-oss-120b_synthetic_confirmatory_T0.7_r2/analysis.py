import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gpt-oss-120b_synthetic_confirmatory_T0.7_r2/data.csv"
df = pd.read_csv(file_path)

# 2. Missing data handling (listwise deletion)
initial_n = len(df)
df = df.dropna(subset=['skin_tone']).reset_index(drop=True)
final_n = len(df)
missing_strategy = "listwise_deletion"
exclusions = f"rows with missing skin_tone removed ({(initial_n-final_n)/initial_n:.1%})"

# 3. Define outcome and predictors
# Use Poisson regression for count outcome redCards
# Build formula with categorical variables
formula = ("redCards ~ skin_tone + C(position) + height + weight + "
           "C(leagueCountry) + games + yellowCards")

# 4. Fit Poisson GLM with clustered SE by refereeID
model = sm.GLM.from_formula(formula,
                            data=df,
                            family=sm.families.Poisson())
results = model.fit(cov_type='cluster',
                    cov_kwds={'groups': df['refereeID']})

# 5. Extract estimand for skin_tone
coef = results.params['skin_tone']
se = results.bse['skin_tone']
z = results.tvalues['skin_tone']
p_val = results.pvalues['skin_tone']
ci_low_log, ci_upp_log = results.conf_int().loc['skin_tone']

# Transform to incidence rate ratio (IRR)
irr = np.exp(coef)
ci_low = np.exp(ci_low_log)
ci_upp = np.exp(ci_upp_log)

# 6. Determine significance
conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

# 7. Prepare output JSON
output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_low),
    "ci_upper": float(ci_upp),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "skin_tone (continuous)",
    "covariates_included": ["C(position)", "height", "weight", "C(leagueCountry)", "games", "yellowCards"],
    "missing_data_strategy": missing_strategy,
    "clustering_strategy": "clustered_se",
    "exclusions_applied": exclusions
}

print(json.dumps(output, ensure_ascii=False))