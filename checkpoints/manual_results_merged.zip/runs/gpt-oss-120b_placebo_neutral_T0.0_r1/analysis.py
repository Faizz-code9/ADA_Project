import pandas as pd
import numpy as np
import json
import statsmodels.api as sm

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gpt-oss-120b_placebo_neutral_T0.0_r1/data.csv"
df = pd.read_csv(file_path)

# 2. Clean / prepare ---------------------------------------------------------
# Average skin‑tone rating
df["skin_tone"] = df[["rater1", "rater2"]].mean(axis=1)

# Binary outcome: any red card vs none
df["red_binary"] = (df["redCards"] > 0).astype(int)

# Covariates to adjust for
covariates = ["games", "yellowCards", "leagueCountry"]

# Keep rows with complete information for variables needed
required = ["skin_tone", "red_binary", "games", "yellowCards", "leagueCountry", "refNum"]
df_clean = df.dropna(subset=required)

# One‑hot encode leagueCountry (drop first to avoid collinearity)
df_clean = pd.get_dummies(df_clean, columns=["leagueCountry"], drop_first=True)

# Design matrix
X_cols = ["skin_tone", "games", "yellowCards"] + \
         [c for c in df_clean.columns if c.startswith("leagueCountry_")]
X = df_clean[X_cols]
X = sm.add_constant(X, has_constant='add')
y = df_clean["red_binary"]

# 3. Fit logistic regression with clustered robust SE by referee -------------
result = sm.Logit(y, X).fit(disp=0,
                            cov_type="cluster",
                            cov_kwds={"groups": df_clean["refNum"]})

# 4. Extract primary estimand (skin_tone) ------------------------------------
coef = result.params["skin_tone"]
se = result.bse["skin_tone"]
z = coef / se
p_val = 2 * (1 - sm.stats.norm.cdf(abs(z)))
ci_low_log = coef - 1.96 * se
ci_upp_log = coef + 1.96 * se
odds_ratio = np.exp(coef)
ci_low = np.exp(ci_low_log)
ci_upp = np.exp(ci_upp_log)

# 5. JSON output -------------------------------------------------------------
output = {
    "effect_size": float(odds_ratio),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_low),
    "ci_upper": float(ci_upp),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "logistic",
    "predictor_used": "average_skin_tone",
    "covariates_included": ["games", "yellowCards"] + [c for c in X_cols if c.startswith("leagueCountry_")],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "rows with missing skin_tone, redCards, games, yellowCards, leagueCountry, or refNum were removed"
}

print(json.dumps(output))