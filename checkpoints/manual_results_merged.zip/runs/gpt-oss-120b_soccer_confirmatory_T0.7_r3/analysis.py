import pandas as pd
import numpy as np
import statsmodels.api as sm
from scipy.stats import norm
import json

# 1. Load data
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_soccer_confirmatory_T0.7_r3/data.csv"
df = pd.read_csv(FILE_PATH)

# 2. Predictor: average skin tone from two raters
df["skin_tone"] = df[["rater1", "rater2"]].mean(axis=1, skipna=True)

# Outcome: binary indicator of any red card
df["red_card"] = (df["redCards"] > 0).astype(int)

# 2b. Define covariates for adjustment
covariates = ["games", "yellowCards", "height", "weight", "position", "leagueCountry", "refNum"]

# 2c. Listwise deletion for missing essential variables
df = df.dropna(subset=["skin_tone", "red_card"] + covariates)

# 2d. Impute missing categoricals with a placeholder
df["position"] = df["position"].fillna("Missing")
df["leagueCountry"] = df["leagueCountry"].fillna("Missing")

# 3. Build design matrix
cat_vars = ["position", "leagueCountry"]
df_dummies = pd.get_dummies(df[cat_vars], drop_first=True, dtype=float)

X = pd.concat(
    [
        df[["skin_tone", "games", "yellowCards", "height", "weight"]].astype(float),
        df_dummies,
    ],
    axis=1,
)
X = sm.add_constant(X, has_constant="add")
y = df["red_card"]

# 4. Fit logistic regression with clustered robust SE (cluster by referee number)
model = sm.Logit(y, X)
result = model.fit(disp=0, cov_type="cluster", cov_kwds={"groups": df["refNum"]})

# 5. Extract estimand for skin_tone
coef = result.params["skin_tone"]
se = result.bse["skin_tone"]
z = coef / se
p_value = 2 * (1 - norm.cdf(abs(z)))
ci_lower = coef - 1.96 * se
ci_upper = coef + 1.96 * se

# Convert to odds ratio scale
or_est = np.exp(coef)
or_ci_lower = np.exp(ci_lower)
or_ci_upper = np.exp(ci_upper)

conclusion = "significant_effect" if p_value < 0.05 else "no_significant_effect"

output = {
    "effect_size": float(or_est),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_value),
    "ci_lower": float(or_ci_lower),
    "ci_upper": float(or_ci_upper),
    "conclusion": conclusion,
    "model_family": "logistic",
    "predictor_used": "average of rater1 and rater2 (skin_tone)",
    "covariates_included": ["games", "yellowCards", "height", "weight"] + list(df_dummies.columns),
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "rows with missing skin_tone or any covariate removed",
}

print(json.dumps(output, ensure_ascii=False))