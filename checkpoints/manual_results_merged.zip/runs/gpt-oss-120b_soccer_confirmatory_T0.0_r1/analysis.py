import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

# 1. Load data
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_soccer_confirmatory_T0.0_r1/data.csv"
df = pd.read_csv(FILE_PATH)

# 2. Clean / prepare ---------------------------------------------------------
# Exclude rows missing skin‑tone ratings
df = df.dropna(subset=["rater1", "rater2"])

# Continuous skin‑tone predictor (average of two raters)
df["skin_tone"] = df[["rater1", "rater2"]].mean(axis=1)

# Binary outcome: any red card from this referee
df["red_any"] = (df["redCards"] > 0).astype(int)

# Impute missing categorical covariates with a placeholder
df["position"] = df["position"].fillna("Missing")
df["leagueCountry"] = df["leagueCountry"].fillna("Missing")

# Covariates to adjust for
numeric_covs = ["games", "yellowCards", "height", "weight"]
pos_dummies = pd.get_dummies(df["position"], prefix="pos", drop_first=True)
league_dummies = pd.get_dummies(df["leagueCountry"], prefix="lg", drop_first=True)

X = pd.concat([df[["skin_tone"] + numeric_covs], pos_dummies, league_dummies], axis=1)
X = sm.add_constant(X, has_constant='add')
y = df["red_any"]
clusters = df["refNum"]

# 3. Fit logistic regression with clustered robust SEs -----------------------
result = sm.Logit(y, X, missing='drop').fit(
    disp=0,
    cov_type="cluster",
    cov_kwds={"groups": clusters}
)

# 4. Extract estimand for skin_tone -----------------------------------------
coef = result.params["skin_tone"]
se = result.bse["skin_tone"]
z = coef / se
p_value = 2 * (1 - sm.stats.norm.cdf(abs(z)))
ci_lower = coef - 1.96 * se
ci_upper = coef + 1.96 * se

# Convert to odds ratio
or_est = np.exp(coef)
or_ci_lower = np.exp(ci_lower)
or_ci_upper = np.exp(ci_upper)

# 5. JSON output ------------------------------------------------------------
output = {
    "effect_size": float(or_est),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_value),
    "ci_lower": float(or_ci_lower),
    "ci_upper": float(or_ci_upper),
    "conclusion": "significant_effect" if p_value < 0.05 else "no_significant_effect",
    "model_family": "logistic",
    "predictor_used": "average_skin_tone = (rater1 + rater2) / 2",
    "covariates_included": numeric_covs + list(pos_dummies.columns) + list(league_dummies.columns),
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "rows missing rater1 or rater2 removed"
}

print(json.dumps(output, ensure_ascii=False))