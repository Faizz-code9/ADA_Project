import pandas as pd
import numpy as np
import json
import statsmodels.api as sm

# 1. Load data
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_placebo_confirmatory_T0.7_r1/data.csv"
df = pd.read_csv(FILE_PATH)

# 2. Clean / prepare
# Drop rows missing skin tone ratings
df = df.dropna(subset=["rater1", "rater2"])

# Build continuous skin tone predictor (average of two raters)
df["avg_skin_tone"] = (df["rater1"] + df["rater2"]) / 2.0

# Binary outcome: any red card received from the referee
df["red_any"] = (df["redCards"] > 0).astype(int)

# Choose covariates
covariates = ["games", "position", "leagueCountry", "height", "weight"]
# Drop rows with missing values in any of the analysis variables
analysis_cols = ["red_any", "avg_skin_tone"] + covariates + ["refNum"]
df = df.dropna(subset=analysis_cols)

# Encode categorical variables
df = pd.get_dummies(df, columns=["position", "leagueCountry"], drop_first=True)

# Build design matrix
X_vars = ["avg_skin_tone"] + [col for col in df.columns if col.startswith("position_") or col.startswith("leagueCountry_")] + ["games", "height", "weight"]
X = df[X_vars]
X = sm.add_constant(X, has_constant='add')
y = df["red_any"]

# 3. Fit logistic regression with clustered SE by referee
model = sm.Logit(y, X)
result = model.fit(disp=0, cov_type='cluster', cov_kwds={'groups': df["refNum"]})

# 4. Extract primary estimand (odds ratio for a full 0→1 increase in skin tone)
coef = result.params["avg_skin_tone"]
se = result.bse["avg_skin_tone"]
z = coef / se
p_value = result.pvalues["avg_skin_tone"]
or_est = np.exp(coef)
ci_lower = np.exp(coef - 1.96 * se)
ci_upper = np.exp(coef + 1.96 * se)

conclusion = "significant_effect" if p_value < 0.05 else "no_significant_effect"

# 5. Prepare JSON output
output = {
    "effect_size": float(or_est),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_value),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "logistic",
    "predictor_used": "average_skin_tone = (rater1 + rater2) / 2",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "rows with missing rater1/rater2 or any covariate (games, position, leagueCountry, height, weight) were removed"
}

print(json.dumps(output))