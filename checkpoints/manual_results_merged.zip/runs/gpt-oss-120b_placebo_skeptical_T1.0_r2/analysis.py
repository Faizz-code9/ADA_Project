import pandas as pd
import numpy as np
import json
import statsmodels.api as sm
import statsmodels.stats.sandwich_covariance as sw

# 1. Load data
path = "/kaggle/working/outputs/runs/gpt-oss-120b_placebo_skeptical_T1.0_r2/data.csv"
df = pd.read_csv(path)

# 2. Build continuous skin‑tone predictor (average of two raters)
df["skin_tone"] = df[["rater1", "rater2"]].mean(axis=1, skipna=True)

# 3. Binary outcome: any red card from that referee?
df["red_flag"] = (df["redCards"] > 0).astype(int)

# 4. Choose covariates that are plausibly related to red cards
covariates = ["games", "height", "weight", "position", "leagueCountry"]
# Keep only rows with complete information for predictor, outcome, covariates, and referee identifier
required_cols = ["skin_tone", "red_flag", "refNum"] + covariates
df_clean = df[required_cols].dropna()

# 5. One‑hot encode categorical covariates
df_enc = pd.get_dummies(df_clean, columns=["position", "leagueCountry"], drop_first=True)

# 6. Design matrix
X = df_enc.drop(columns=["red_flag", "refNum"])
X = sm.add_constant(X, has_constant='add')
y = df_enc["red_flag"]

# 7. Fit logistic regression
logit_model = sm.Logit(y, X)
logit_res = logit_model.fit(disp=False)

# 8. Clustered robust covariance by referee (refNum)
cluster_cov = sw.cov_cluster(logit_res, df_enc["refNum"])
# Standard errors from clustered covariance
se_cluster = np.sqrt(np.diag(cluster_cov))

# 9. Extract estimand for skin_tone
coef = logit_res.params["skin_tone"]
se = se_cluster[logit_res.params.index.get_loc("skin_tone")]
z = coef / se
p_val = 2 * (1 - sm.stats.norm.cdf(abs(z)))
ci_low_log = coef - 1.96 * se
ci_upp_log = coef + 1.96 * se
or_est = np.exp(coef)
ci_low = np.exp(ci_low_log)
ci_upp = np.exp(ci_upp_log)

# 10. Significance decision
conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

# 11. Assemble JSON output
output = {
    "effect_size": float(or_est),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_low),
    "ci_upper": float(ci_upp),
    "conclusion": conclusion,
    "model_family": "logistic",
    "predictor_used": "average of rater1 and rater2 (skin_tone)",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "rows with missing skin_tone, outcome, covariates, or refNum removed"
}

print(json.dumps(output))