import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

# 1. Load data
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_soccer_neutral_T1.0_r5/data.csv"
df = pd.read_csv(FILE_PATH)

# 2. Prepare data ---------------------------------------------------------------
# Continuous skin‑tone predictor: mean of the two raters
df["skin_tone"] = df[["rater1", "rater2"]].mean(axis=1)

# Exclude rows missing skin tone (listwise deletion for the main predictor)
exclusions = "rows with missing rater1 or rater2 removed"
df = df.dropna(subset=["skin_tone"])

# Binary outcome: any red card from that referee
df["red_any"] = (df["redCards"] > 0).astype(int)

# Covariates (chosen for low missingness & relevance)
covariates = [
    "games", "victories", "defeats", "goals",
    "yellowCards", "height", "weight",
    "leagueCountry", "position"
]

numeric_vars = ["games", "victories", "defeats", "goals",
                "yellowCards", "height", "weight"]
categorical_vars = ["leagueCountry", "position"]

# Impute numeric missing with column mean
for col in numeric_vars:
    if df[col].isnull().any():
        df[col] = df[col].fillna(df[col].mean())

# Impute categorical missing with mode
for col in categorical_vars:
    if df[col].isnull().any():
        df[col] = df[col].fillna(df[col].mode().iloc[0])

# One‑hot encode categoricals (drop first to avoid multicollinearity)
dummies = pd.get_dummies(df[categorical_vars], drop_first=True, prefix_sep="_")
X = pd.concat([df[["skin_tone"] + numeric_vars], dummies], axis=1)

# Add intercept
X = sm.add_constant(X, prepend=False)

y = df["red_any"]

# 3. Fit logistic regression with clustered robust SE (cluster by referee)
logit_res = sm.Logit(y, X).fit(
    cov_type="cluster",
    cov_kwds={"groups": df["refNum"]},
    disp=False
)

# 4. Extract estimator for skin tone
coef = logit_res.params["skin_tone"]
se_log = logit_res.bse["skin_tone"]
p_val = logit_res.pvalues["skin_tone"]
odds_ratio = np.exp(coef)
ci_lower = np.exp(coef - 1.96 * se_log)
ci_upper = np.exp(coef + 1.96 * se_log)

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

# 5. Output JSON ---------------------------------------------------------------
output = {
    "effect_size": float(odds_ratio),
    "effect_type": "odds_ratio",
    "standard_error": float(se_log),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "logistic",
    "predictor_used": "average_rater1_rater2",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": exclusions
}

print(json.dumps(output))