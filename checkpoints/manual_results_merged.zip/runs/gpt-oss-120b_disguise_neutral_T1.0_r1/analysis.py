import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

# 1. Load data
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_disguise_neutral_T1.0_r1/data.csv"
df = pd.read_csv(FILE_PATH)

# 2. Prepare data --------------------------------------------------------------
# Predictor: average of the two risk evaluator scores
df["average_risk_score"] = df[["risk_evaluator_alpha_score", "risk_evaluator_beta_score"]].mean(axis=1)

# Binary outcome: any rejection (0 = none, 1 = at least one)
df["rejection_bin"] = (df["loan_application_rejections"] > 0).astype(int)

# Covariates to adjust for (numeric, low missingness)
covariates = [
    "credit_score_index",
    "annual_income_bracket",
    "prior_approved_loans",
    "prior_conditional_loans",
    "prior_denied_loans",
    "repayment_performance_score",
    "formal_inquiry_notices",
    "elevated_risk_warnings",
    "total_applications_reviewed",
    "regional_index_a",
    "regional_index_b"
]

# Columns needed for the model
required_cols = ["rejection_bin", "average_risk_score"] + covariates + ["loan_officer_id"]
df_model = df[required_cols].dropna()

exclusions_applied = "rows with missing risk scores, outcome, or covariates removed"

# 3. Fit logistic regression with cluster-robust SE (cluster by loan_officer_id)
X = df_model[["average_risk_score"] + covariates]
X = sm.add_constant(X, has_constant='add')
y = df_model["rejection_bin"]

# Using GLM to easily obtain cluster-robust covariance
glm = sm.GLM(y, X, family=sm.families.Binomial())
glm_fit = glm.fit(cov_type="cluster", cov_kwds={"groups": df_model["loan_officer_id"]})

# 4. Extract estimand (odds ratio for a full 0‑1 increase in risk score)
coef = glm_fit.params["average_risk_score"]
se = glm_fit.bse["average_risk_score"]
p_val = glm_fit.pvalues["average_risk_score"]
odds_ratio = np.exp(coef)
ci_lower = np.exp(coef - 1.96 * se)
ci_upper = np.exp(coef + 1.96 * se)

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

# 5. Output JSON ---------------------------------------------------------------
output = {
    "effect_size": float(odds_ratio),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "logistic",
    "predictor_used": "average_risk_score",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": exclusions_applied
}

print(json.dumps(output))