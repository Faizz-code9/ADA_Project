import pandas as pd
import numpy as np
import json
import statsmodels.api as sm
import statsmodels.formula.api as smf
from scipy.stats import norm

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gpt-oss-120b_soccer_skeptical_T0.7_r3/data.csv"
df = pd.read_csv(file_path)

# 2. Cleaning & preparation
# Exclude rows missing either rater1 or rater2
missing_mask = df['rater1'].isna() | df['rater2'].isna()
exclusions_applied = f"dropped {missing_mask.sum()} rows with missing rater1/rater2"
df = df.loc[~missing_mask].copy()

# Continuous skin‑tone predictor: average of two raters
df['average_skin_tone'] = (df['rater1'] + df['rater2']) / 2.0

# Covariates
df['position'] = df['position'].fillna('Unknown')
df['leagueCountry'] = df['leagueCountry'].fillna('Unknown')
covariate_terms = [
    'games',
    'yellowCards',
    'C(position)',
    'C(leagueCountry)'
]

# 3. Model: Poisson GLM with clustered robust SE by referee (refNum)
formula = 'redCards ~ average_skin_tone + ' + ' + '.join(covariate_terms)
glm = smf.glm(formula=formula, data=df, family=sm.families.Poisson())
# Fit with clustered covariance
results = glm.fit(cov_type='cluster', cov_kwds={'groups': df['refNum']})

# 4. Primary estimand: incidence rate ratio for a full 0→1 change in skin tone
coef = results.params['average_skin_tone']
se = results.bse['average_skin_tone']
irr = np.exp(coef)                     # effect size
irr_se = irr * se                      # delta method SE for IRR
z = coef / se
p_value = 2 * (1 - norm.cdf(abs(z)))
ci_lower = np.exp(coef - 1.96 * se)
ci_upper = np.exp(coef + 1.96 * se)

conclusion = "significant_effect" if p_value < 0.05 else "no_significant_effect"

# 5. JSON output
output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(irr_se),
    "p_value": float(p_value),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "average_skin_tone = (rater1 + rater2)/2",
    "covariates_included": ["games", "yellowCards", "position", "leagueCountry"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": exclusions_applied
}

print(json.dumps(output, ensure_ascii=False))