import pandas as pd
import numpy as np
import statsmodels.api as sm
import json
import warnings
from scipy import stats

warnings.filterwarnings("ignore")

# 1. Load data
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_disguise_neutral_T0.0_r1/data.csv"
df = pd.read_csv(FILE_PATH)

# 2. Outcome: any rejection (binary)
df["rejection_any"] = (df["loan_application_rejections"] > 0).astype(int)

# 3. Main predictor: average of the two risk evaluator scores
df["risk_score"] = df[["risk_evaluator_alpha_score", "risk_evaluator_beta_score"]].mean(axis=1)

# 4. Covariates (numeric, plausible confounders)
covariates = [
    "credit_score_index",
    "annual_income_bracket",
    "prior_approved_loans",
    "prior_denied_loans",
    "repayment_performance_score",
    "formal_inquiry_notices",
    "elevated_risk_warnings",
    "total_applications_reviewed",
    "regional_index_a",
    "regional_index_b",
]

# 5. Listwise deletion for rows missing any needed variable
required = ["rejection_any", "risk_score", "loan_officer_id"] + covariates
df_clean = df[required].dropna()

# 6. Design matrix
X = df_clean[["risk_score"] + covariates]
X = sm.add_constant(X, has_constant='add')
y = df_clean["rejection_any"]
officer_ids = df_clean["loan_officer_id"]

# 7. Fit logistic regression via GLM (allows clustered robust SE)
glm = sm.GLM(y, X, family=sm.families.Binomial())
result = glm.fit()

# 8. Cluster-robust covariance (cluster by loan officer)
robust_res = result.get_robustcov_results(cov_type="cluster", groups=officer_ids)

# 9. Extract coefficient for risk_score
coef = robust_res.params["risk_score"]
se = robust_res.bse["risk_score"]
z = coef / se
p_value = 2 * (1 - stats.norm.cdf(abs(z)))
odds_ratio = np.exp(coef)
ci_lower = np.exp(coef - 1.96 * se)
ci_upper = np.exp(coef + 1.96 * se)

# 10. Conclusion
conclusion = "significant_effect" if p_value < 0.05 else "no_significant_effect"

# 11. JSON output
output = {
    "effect_size": float(odds_ratio),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_value),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "logistic",
    "predictor_used": "average of risk_evaluator_alpha_score and risk_evaluator_beta_score",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "rows with missing risk scores, outcome, or covariates removed"
}

print(json.dumps(output, ensure_ascii=False))