import pandas as pd
import numpy as np
import json
import statsmodels.api as sm
import statsmodels.formula.api as smf
from scipy.stats import norm

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gpt-oss-120b_synthetic_neutral_T0.7_r1/data.csv"
df = pd.read_csv(file_path)

# 2. Data cleaning / preparation
missing_strategy = "mean_imputation"
if df["skin_tone"].isnull().any():
    df["skin_tone"] = df["skin_tone"].fillna(df["skin_tone"].mean())

exclusions = "none"

# Categorical encoding for formula handling
df["position"] = df["position"].astype("category")
df["leagueCountry"] = df["leagueCountry"].astype("category")
df["refereeID"] = df["refereeID"].astype("category")

# Offset for exposure (games played)
df["log_games"] = np.log(df["games"])

# 3. Model: Poisson GLM with clustered standard errors by referee
formula = (
    "redCards ~ skin_tone + C(position) + height + weight + C(leagueCountry) + yellowCards"
)
model = smf.glm(
    formula=formula,
    data=df,
    family=sm.families.Poisson(),
    offset=df["log_games"]
)
result = model.fit(cov_type="cluster", cov_kwds={"groups": df["refereeID"]})

# 4. Primary estimand: Incidence Rate Ratio (IRR) for a full 0→1 change in skin_tone
coef = result.params["skin_tone"]
se_coef = result.bse["skin_tone"]
z_val = coef / se_coef
p_value = 2 * norm.sf(abs(z_val))

irr = np.exp(coef)                     # point estimate
se_irr = irr * se_coef                  # delta method SE for IRR
ci_lower = np.exp(coef - 1.96 * se_coef)
ci_upper = np.exp(coef + 1.96 * se_coef)

conclusion = "significant_effect" if p_value < 0.05 else "no_significant_effect"

# 5. Output JSON
output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se_irr),
    "p_value": float(p_value),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "skin_tone",
    "covariates_included": ["position", "height", "weight", "leagueCountry", "yellowCards"],
    "missing_data_strategy": missing_strategy,
    "clustering_strategy": "clustered_se",
    "exclusions_applied": exclusions
}

print(json.dumps(output, ensure_ascii=False))