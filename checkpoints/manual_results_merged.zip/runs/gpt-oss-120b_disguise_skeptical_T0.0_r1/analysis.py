import pandas as pd
import numpy as np
import json
import statsmodels.api as sm
import statsmodels.stats.sandwich_covariance as sw

# ----------------------------------------------------------------------
# 1. Load data
# ----------------------------------------------------------------------
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_disguise_skeptical_T0.0_r1/data.csv"
df = pd.read_csv(FILE_PATH)

# ----------------------------------------------------------------------
# 2. Data preparation
# ----------------------------------------------------------------------
# Average risk evaluator score (continuous 0‑1)
df["average_risk_score"] = df[["risk_evaluator_alpha_score", "risk_evaluator_beta_score"]].mean(axis=1)

# Binary outcome: any rejection vs none
df["rejection"] = (df["loan_application_rejections"] > 0).astype(int)

# Covariates to adjust for (chosen a priori)
base_covariates = [
    "credit_score_index",
    "annual_income_bracket",
    "prior_approved_loans",
    "prior_denied_loans",
    "regional_index_a",
]

# Employment specialization – keep top 5 categories, lump others
emp_counts = df["employment_specialization"].value_counts(dropna=False)
top5 = emp_counts.nlargest(5).index.tolist()
df["employment_specialization_clean"] = np.where(
    df["employment_specialization"].isin(top5),
    df["employment_specialization"],
    "Other"
)
emp_dummies = pd.get_dummies(df["employment_specialization_clean"], prefix="emp", drop_first=True)
df = pd.concat([df, emp_dummies], axis=1)

# Full list of covariates
covariates = base_covariates + list(emp_dummies.columns)

# Columns required for the analysis
required_cols = ["average_risk_score", "rejection", "loan_officer_id"] + covariates

# ----------------------------------------------------------------------
# 3. Missing data handling – listwise deletion
# ----------------------------------------------------------------------
df_clean = df[required_cols].dropna()
exclusions_desc = (
    f"dropped rows with missing values in any of {required_cols} "
    f"(original {len(df)} rows, retained {len(df_clean)})"
)

# ----------------------------------------------------------------------
# 4. Model fitting – logistic regression with clustered SEs
# ----------------------------------------------------------------------
X = df_clean[["average_risk_score"] + covariates]
X = sm.add_constant(X, has_constant='add')
y = df_clean["rejection"]

logit_mod = sm.Logit(y, X)
logit_res = logit_mod.fit(disp=0)

# Clustered (by loan_officer_id) robust covariance matrix
cluster_groups = df_clean["loan_officer_id"]
cov_cluster = sw.cov_cluster(logit_res, cluster_groups)
se_cluster = np.sqrt(np.diag(cov_cluster))

# ----------------------------------------------------------------------
# 5. Extract primary estimand (odds ratio for average_risk_score)
# ----------------------------------------------------------------------
coef = logit_res.params["average_risk_score"]
se = se_cluster[logit_res.params.index.get_loc("average_risk_score")]
z = coef / se
p_val = 2 * (1 - sm.stats.norm.cdf(abs(z)))
ci_lower_log = coef - 1.96 * se
ci_upper_log = coef + 1.96 * se

or_est = np.exp(coef)
ci_lower = np.exp(ci_lower_log)
ci_upper = np.exp(ci_upper_log)

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

# ----------------------------------------------------------------------
# 6. Assemble JSON output
# ----------------------------------------------------------------------
output = {
    "effect_size": float(or_est),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "logistic",
    "predictor_used": "average_risk_score",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": exclusions_desc
}

print(json.dumps(output, ensure_ascii=False))