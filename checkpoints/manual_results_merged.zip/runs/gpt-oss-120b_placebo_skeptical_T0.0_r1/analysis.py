import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gpt-oss-120b_placebo_skeptical_T0.0_r1/data.csv"
df = pd.read_csv(file_path)

# 2. Prepare data
# Create continuous skin‑tone predictor as the average of the two raters
df["skin_tone"] = df[["rater1", "rater2"]].mean(axis=1)

# Binary outcome: any red card vs none
df["red_binary"] = (df["redCards"] > 0).astype(int)

# Select covariates (reasonable controls)
covariates = ["games", "yellowCards", "position", "leagueCountry"]
# Keep only rows without missing values in variables used
required_cols = ["skin_tone", "red_binary"] + covariates + ["refNum"]
df_clean = df.dropna(subset=required_cols)

# Encode categorical covariates
df_enc = pd.get_dummies(df_clean[covariates], drop_first=True)
X = pd.concat([df_clean["skin_tone"], df_enc], axis=1)
X = sm.add_constant(X)  # intercept

y = df_clean["red_binary"]
clusters = df_clean["refNum"]

# 3. Fit logistic regression with clustered SEs
logit_model = sm.Logit(y, X)
result = logit_model.fit(disp=0, cov_type="cluster", cov_kwds={"groups": clusters})

# 4. Extract primary estimand (odds ratio for full 0→1 change in skin tone)
coef = result.params["skin_tone"]
se = np.sqrt(result.cov_params().loc["skin_tone", "skin_tone"])
odds_ratio = np.exp(coef)
ci_lower = np.exp(coef - 1.96 * se)
ci_upper = np.exp(coef + 1.96 * se)
p_value = result.pvalues["skin_tone"]

# 5. Build output JSON
output = {
    "effect_size": float(odds_ratio),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_value),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if p_value < 0.05 else "no_significant_effect",
    "model_family": "logistic",
    "predictor_used": "average_skin_tone = (rater1 + rater2)/2",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "rows with missing skin_tone, redCards, games, yellowCards, position, leagueCountry, or refNum were dropped"
}

print(json.dumps(output, ensure_ascii=False))