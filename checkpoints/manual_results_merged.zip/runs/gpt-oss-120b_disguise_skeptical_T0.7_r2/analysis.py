import pandas as pd
import numpy as np
import statsmodels.api as sm
from scipy import stats
import json

# 1. Load data
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_disguise_skeptical_T0.7_r2/data.csv"
df = pd.read_csv(FILE_PATH)

# 2. Prepare predictor (average risk score) and binary outcome
df["risk_score_avg"] = df[["risk_evaluator_alpha_score", "risk_evaluator_beta_score"]].mean(axis=1)
df["reject_binary"] = (df["loan_application_rejections"] > 0).astype(int)

# Columns required for analysis
required_cols = [
    "reject_binary", "risk_score_avg", "credit_score_index", "annual_income_bracket",
    "employment_specialization", "prior_approved_loans", "prior_conditional_loans",
    "prior_denied_loans", "repayment_performance_score", "formal_inquiry_notices",
    "elevated_risk_warnings", "total_applications_reviewed",
    "regional_index_a", "regional_index_b", "loan_officer_id"
]

# Listwise deletion of rows with missing values in required columns
df_clean = df.dropna(subset=required_cols).copy()
exclusions_desc = f"dropped {len(df) - len(df_clean)} rows with missing required data"

# Encode categorical employment_specialization (treat missing as its own category)
df_clean.loc[:, "employment_specialization"] = df_clean["employment_specialization"].fillna("MISSING")
emp_dummies = pd.get_dummies(df_clean["employment_specialization"], prefix="emp", drop_first=True)
df_clean = pd.concat([df_clean, emp_dummies], axis=1)

# Define predictor and covariates
predictor = "risk_score_avg"
covariates = [
    "credit_score_index", "annual_income_bracket", "prior_approved_loans",
    "prior_conditional_loans", "prior_denied_loans", "repayment_performance_score",
    "formal_inquiry_notices", "elevated_risk_warnings", "total_applications_reviewed",
    "regional_index_a", "regional_index_b"
] + list(emp_dummies.columns)

X = df_clean[[predictor] + covariates]
X = sm.add_constant(X)  # intercept
y = df_clean["reject_binary"]

# 3. Fit logistic regression
logit_model = sm.Logit(y, X, missing='raise')
logit_result = logit_model.fit(disp=0)

# 4. Clustered robust standard errors by loan_officer_id
cluster_ids = df_clean["loan_officer_id"]
logit_clustered = logit_result.get_robustcov_results(cov_type="cluster", groups=cluster_ids)

# 5. Extract estimand for risk_score_avg
coef = logit_clustered.params[predictor]
se = logit_clustered.bse[predictor]
z = coef / se
p_value = 2 * (1 - stats.norm.cdf(abs(z)))
odds_ratio = np.exp(coef)
ci_lower = np.exp(coef - 1.96 * se)
ci_upper = np.exp(coef + 1.96 * se)

conclusion = "significant_effect" if p_value < 0.05 else "no_significant_effect"

# 6. JSON output
output = {
    "effect_size": float(odds_ratio),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_value),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "logistic",
    "predictor_used": "average of risk_evaluator_alpha_score and risk_evaluator_beta_score",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": exclusions_desc
}

print(json.dumps(output))