import pandas as pd
import numpy as np
import statsmodels.formula.api as smf
import json

# 1. Load data
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_soccer_skeptical_T0.7_r1/data.csv"
df = pd.read_csv(FILE_PATH)

# 2. Build predictor: average skin tone from the two raters
df["skin_tone"] = df[["rater1", "rater2"]].mean(axis=1)

# Binary outcome: any red card received from the referee
df["red_flag"] = (df["redCards"] > 0).astype(int)

# Covariates to adjust for (chosen to capture exposure and game context)
covariates = ["games", "height", "weight", "position", "leagueCountry"]
required_cols = ["skin_tone", "red_flag", "refNum"] + covariates
df = df[required_cols]

# 3. Missing data handling: listwise deletion
initial_n = len(df)
df = df.dropna()
exclusions = f"dropped {initial_n - len(df)} rows with missing values"

# 4. Logistic regression with clustered robust SE by referee (refNum)
formula = "red_flag ~ skin_tone + games + height + weight + C(position) + C(leagueCountry)"
# Fit with cluster-robust covariance
result = smf.logit(formula=formula, data=df).fit(
    disp=0,
    cov_type="cluster",
    cov_kwds={"groups": df["refNum"]},
)

# 5. Extract estimand for skin_tone
coef = result.params["skin_tone"]
se = result.bse["skin_tone"]
p_val = result.pvalues["skin_tone"]
odds_ratio = np.exp(coef)
z = 1.96
ci_lower = np.exp(coef - z * se)
ci_upper = np.exp(coef + z * se)

# 6. Conclusion based on two‑sided p‑value
conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

# 7. Assemble JSON output
output = {
    "effect_size": float(odds_ratio),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "logistic",
    "predictor_used": "average_skin_tone = (rater1 + rater2)/2",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": exclusions,
}

print(json.dumps(output))