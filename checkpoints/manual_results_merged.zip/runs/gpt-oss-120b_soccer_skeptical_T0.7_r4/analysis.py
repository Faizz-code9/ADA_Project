import pandas as pd
import numpy as np
import json
import statsmodels.api as sm

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gpt-oss-120b_soccer_skeptical_T0.7_r4/data.csv"
df = pd.read_csv(file_path)

# 2. Clean / prepare
exclusions = "Rows with missing rater1 or rater2 removed"
df = df.dropna(subset=["rater1", "rater2"])

# Continuous skin‑tone predictor: average of the two raters
df["avg_skin_tone"] = (df["rater1"] + df["rater2"]) / 2.0

# Binary outcome: any red card received from this referee
df["red_any"] = (df["redCards"] > 0).astype(int)

# Covariates (numeric & categorical)
covariate_cols = ["games", "yellowCards", "position", "leagueCountry"]
df["games"] = df["games"].fillna(0)
df["yellowCards"] = df["yellowCards"].fillna(0)

# One‑hot encode categoricals, drop first to avoid collinearity
df_dummies = pd.get_dummies(df[covariate_cols], drop_first=True)

# Design matrix
X = pd.concat([df[["avg_skin_tone"]], df_dummies], axis=1)
X = sm.add_constant(X, has_constant='add')
y = df["red_any"]

# 3. Fit logistic regression with clustered robust SE by referee number
cluster_groups = df["refNum"]
logit_mod = sm.Logit(y, X)
result = logit_mod.fit(disp=False, cov_type="cluster", cov_kwds={"groups": cluster_groups})

# 4. Extract estimator for avg_skin_tone
coef = result.params["avg_skin_tone"]
se = result.bse["avg_skin_tone"]
z = coef / se
p_value = 2 * (1 - sm.stats.norm.cdf(abs(z)))
odds_ratio = np.exp(coef)
ci_lower = np.exp(coef - 1.96 * se)
ci_upper = np.exp(coef + 1.96 * se)

# 5. JSON output
output = {
    "effect_size": float(odds_ratio),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_value),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if p_value < 0.05 else "no_significant_effect",
    "model_family": "logistic",
    "predictor_used": "average_skin_tone = (rater1 + rater2)/2",
    "covariates_included": covariate_cols,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": exclusions
}

print(json.dumps(output, ensure_ascii=False))