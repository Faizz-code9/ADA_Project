import pandas as pd
import numpy as np
import statsmodels.api as sm
from scipy.stats import norm
import json

# 1. Load data
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_synthetic_neutral_T0.7_r2/data.csv"
df = pd.read_csv(FILE_PATH)

# 2. Missing data handling
missing_strategy = "mean_imputation"
if df["skin_tone"].isnull().any():
    df["skin_tone"] = df["skin_tone"].fillna(df["skin_tone"].mean())

exclusions = "none"

# 3. Encode categoricals
cat_vars = ["position", "leagueCountry"]
df = pd.get_dummies(df, columns=cat_vars, drop_first=True, dtype=float)

# 4. Define outcome, predictor, covariates
y = df["redCards"]
predictor = "skin_tone"

covariate_cols = [
    "games",
    "yellowCards",
    "height",
    "weight"
] + [c for c in df.columns if c.startswith("position_") or c.startswith("leagueCountry_")]

X = df[[predictor] + covariate_cols]
X = sm.add_constant(X, has_constant='add')

# 5. Fit Poisson GLM with clustered SE by refereeID
clusters = df["refereeID"]
model = sm.GLM(y, X, family=sm.families.Poisson())
result = model.fit(cov_type="cluster", cov_kwds={"groups": clusters})

# 6. Extract estimator for skin_tone
coef = result.params[predictor]
se = result.bse[predictor]
z = coef / se
p_val = 2 * (1 - norm.cdf(abs(z)))

# 7. Compute Incidence Rate Ratio (IRR) and 95% CI
irr = np.exp(coef)
ci_lower = np.exp(coef - 1.96 * se)
ci_upper = np.exp(coef + 1.96 * se)

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
    "effect_size": irr,
    "effect_type": "irr",
    "standard_error": se,
    "p_value": p_val,
    "ci_lower": ci_lower,
    "ci_upper": ci_upper,
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": predictor,
    "covariates_included": covariate_cols,
    "missing_data_strategy": missing_strategy,
    "clustering_strategy": "clustered_se",
    "exclusions_applied": exclusions
}

print(json.dumps(output))