import pandas as pd
import numpy as np
import statsmodels.api as sm
import json
import sys

# 1. Load data
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_soccer_neutral_T0.0_r1/data.csv"
df = pd.read_csv(FILE_PATH)

# 2. Clean / prepare
# Create continuous skin‑tone predictor as the average of the two raters
df["skin_tone"] = df[["rater1", "rater2"]].mean(axis=1)

# Binary outcome: any red card vs none
df["red_flag"] = (df["redCards"] > 0).astype(int)

# Variables we will adjust for
covariate_cols = ["games", "yellowCards", "position", "leagueCountry"]

# Drop rows with missing values in any variable needed for the model
required = ["skin_tone", "red_flag"] + covariate_cols + ["refNum"]
initial_n = len(df)
df = df.dropna(subset=required)
final_n = len(df)

# Record exclusions
exclusions = f"dropped {initial_n - final_n} rows due to missing skin_tone, redCards, games, yellowCards, position, leagueCountry, or refNum"

# Encode categorical covariates
df = pd.get_dummies(df, columns=["position", "leagueCountry"], drop_first=True)

# Build design matrix
X_vars = ["skin_tone", "games", "yellowCards"] + \
         [col for col in df.columns if col.startswith("position_") or col.startswith("leagueCountry_")]
X = df[X_vars]
X = sm.add_constant(X, has_constant='add')
y = df["red_flag"]

# 3. Fit logistic regression with clustered robust SE (cluster by referee)
model = sm.GLM(y, X, family=sm.families.Binomial())
result = model.fit(cov_type="cluster", cov_kwds={"groups": df["refNum"]})

# 4. Extract primary estimand (odds ratio for skin_tone)
coef = result.params["skin_tone"]
se = np.sqrt(result.cov_params().loc["skin_tone", "skin_tone"])
p_val = result.pvalues["skin_tone"]
or_est = np.exp(coef)
ci_lower = np.exp(coef - 1.96 * se)
ci_upper = np.exp(coef + 1.96 * se)

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

# 5. Prepare JSON output
output = {
    "effect_size": float(or_est),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "logistic",
    "predictor_used": "average_skin_tone = (rater1 + rater2) / 2",
    "covariates_included": ["games", "yellowCards", "position", "leagueCountry"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": exclusions
}

print(json.dumps(output))