import pandas as pd
import numpy as np
import statsmodels.formula.api as smf
import statsmodels.api as sm
import json
import sys

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gpt-oss-120b_synthetic_skeptical_T0.7_r1/data.csv"
df = pd.read_csv(file_path)

# 2. Clean / prepare
# Impute missing skin_tone with mean
missing_strategy = "mean_imputation"
if df["skin_tone"].isnull().any():
    mean_skin = df["skin_tone"].mean()
    df["skin_tone"] = df["skin_tone"].fillna(mean_skin)

# Ensure numeric types
df["games"] = df["games"].astype(int)
df["redCards"] = df["redCards"].astype(int)

# No exclusions
exclusions = "none"

# 3. Model specification
# Use Poisson GLM with offset = log(games) (exposure)
# Covariates: yellowCards, height, weight, position (categorical), leagueCountry (categorical)
covariates = ["yellowCards", "height", "weight", "position", "leagueCountry"]
formula = "redCards ~ skin_tone + " + " + ".join(covariates)
offset = np.log(df["games"].replace(0, np.nan)).fillna(0)  # avoid -inf if games==0

# Fit Poisson GLM
model = smf.glm(formula=formula, data=df, family=sm.families.Poisson(), offset=offset)
result = model.fit()

# 4. Primary estimand (IRR for skin_tone)
coef = result.params["skin_tone"]
se = result.bse["skin_tone"]
p_val = result.pvalues["skin_tone"]
effect_size = np.exp(coef)  # incidence rate ratio
ci_lower = np.exp(coef - 1.96 * se)
ci_upper = np.exp(coef + 1.96 * se)

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

# 5. Assemble output
output = {
    "effect_size": float(effect_size),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "skin_tone",
    "covariates_included": covariates,
    "missing_data_strategy": missing_strategy,
    "clustering_strategy": "none",
    "exclusions_applied": exclusions
}

print(json.dumps(output))