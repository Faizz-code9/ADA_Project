import pandas as pd
import numpy as np
import statsmodels.api as sm
import json
from datetime import datetime

# 1. Load data
data_path = "/kaggle/working/outputs/runs/gpt-oss-120b_soccer_confirmatory_T1.0_r2/data.csv"
df = pd.read_csv(data_path)

# 2. Construct predictor (average skin tone) and binary outcome (any red card)
df["avg_skin"] = df[["rater1", "rater2"]].mean(axis=1)
df["red_any"] = (df["redCards"] > 0).astype(int)

# Derive approximate age (season 2012-2013 -> use year 2013)
def compute_age(bday):
    try:
        d = datetime.strptime(bday, "%d.%m.%Y")
        return 2013 - d.year
    except Exception:
        return np.nan

df["age"] = df["birthday"].apply(compute_age)

# Choose a modest set of covariates to avoid singularity
covariates = ["games", "height", "weight", "age"]

# Rows needed for analysis
required_cols = ["avg_skin", "red_any", "refNum"] + covariates
df_clean = df.dropna(subset=required_cols)

# 3. Build design matrix
X = df_clean[["avg_skin"] + covariates].copy()
X = sm.add_constant(X)  # adds intercept
y = df_clean["red_any"]

# 4. Fit logistic regression with clustered standard errors by referee (refNum)
model = sm.GLM(y, X, family=sm.families.Binomial())
result = model.fit(cov_type="cluster", cov_kwds={"groups": df_clean["refNum"]})

# Extract estimator for avg_skin
beta = result.params["avg_skin"]
se = result.bse["avg_skin"]
p_val = result.pvalues["avg_skin"]
odds_ratio = np.exp(beta)
ci_lower = np.exp(beta - 1.96 * se)
ci_upper = np.exp(beta + 1.96 * se)

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
    "effect_size": float(odds_ratio),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "logistic",
    "predictor_used": "average of rater1 and rater2 (avg_skin)",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "rows with missing avg_skin, redCards, age, or selected covariates removed"
}

print(json.dumps(output, ensure_ascii=False))