import pandas as pd
import numpy as np
import json
import statsmodels.api as sm
import statsmodels.formula.api as smf
from scipy import stats

# 1. Load data
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_placebo_confirmatory_T0.0_r1/data.csv"
df = pd.read_csv(FILE_PATH)

# 2. Clean / prepare
# Continuous skin tone predictor: average of the two raters
df["skin_tone"] = df[["rater1", "rater2"]].mean(axis=1)

# Binary outcome: any red card from this referee
df["red_any"] = (df["redCards"] > 0).astype(int)

# Covariates (numeric) with low missingness
covariates = ["games", "yellowCards", "height", "weight"]
df["leagueCountry"] = df["leagueCountry"].astype("category")

# Listwise deletion for required columns
required = ["skin_tone", "red_any", "refNum"] + covariates + ["leagueCountry"]
df_clean = df.dropna(subset=required)

exclusions_desc = "rows with missing rater1 or rater2 removed"

# 3. Fit logistic regression with clustered (by referee) robust SE
formula = "red_any ~ skin_tone + games + yellowCards + height + weight + C(leagueCountry)"
model = smf.logit(formula=formula, data=df_clean)
result = model.fit(disp=0)

# Cluster-robust covariance matrix
cov_cluster = sm.stats.sandwich_covariance.cov_cluster(result, df_clean["refNum"])
se_vec = np.sqrt(np.diag(cov_cluster))
# Index of skin_tone coefficient
idx = result.params.index.get_loc("skin_tone")
coef = result.params["skin_tone"]
se = se_vec[idx]

# 4. Primary estimand: odds ratio for a full 0→1 change in skin tone
z = coef / se
p_value = 2 * (1 - stats.norm.cdf(abs(z)))
or_est = np.exp(coef)
ci_lower = np.exp(coef - 1.96 * se)
ci_upper = np.exp(coef + 1.96 * se)

conclusion = "significant_effect" if p_value < 0.05 else "no_significant_effect"

# 5. JSON output
output = {
    "effect_size": float(or_est),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_value),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "logistic",
    "predictor_used": "average of rater1 and rater2 (skin_tone)",
    "covariates_included": covariates + ["leagueCountry"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": exclusions_desc
}

print(json.dumps(output))