import pandas as pd
import numpy as np
import statsmodels.api as sm
import json
import sys

# 1. Load data
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_synthetic_confirmatory_T0.7_r1/data.csv"
df = pd.read_csv(FILE_PATH)

# 2. Missing data handling (mean imputation for skin_tone)
missing_strategy = "mean_imputation"
if df["skin_tone"].isnull().any():
    mean_skin = df["skin_tone"].mean()
    df["skin_tone"] = df["skin_tone"].fillna(mean_skin)

# No row exclusions applied
exclusions = "none"

# 3. Prepare covariates
# Categorical variables will be handled via patsy-style formula (pandas get_dummies)
categorical_cols = ["position", "leagueCountry"]
df = pd.get_dummies(df, columns=categorical_cols, drop_first=True)

# Define predictor and covariates
predictor = "skin_tone"
covariates = [
    "height",
    "weight",
    "games",
    "yellowCards",
] + [c for c in df.columns if c.startswith("position_") or c.startswith("leagueCountry_")]

# 4. Fit Negative Binomial GLM
formula = "redCards ~ " + " + ".join([predictor] + covariates)
model = sm.GLM.from_formula(formula, data=df, family=sm.families.NegativeBinomial())
# Clustered robust SE by refereeID
if "refereeID" in df.columns:
    clusters = df["refereeID"]
    results = model.fit(cov_type="cluster", cov_kwds={"groups": clusters})
    clustering = "clustered_se"
else:
    results = model.fit()
    clustering = "none"

# 5. Extract primary estimand (IRR for skin_tone)
beta = results.params[predictor]
se = results.bse[predictor]
p_val = results.pvalues[predictor]
irr = np.exp(beta)
ci_lower = np.exp(beta - 1.96 * se)
ci_upper = np.exp(beta + 1.96 * se)

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "negative_binomial",
    "predictor_used": predictor,
    "covariates_included": covariates,
    "missing_data_strategy": missing_strategy,
    "clustering_strategy": clustering,
    "exclusions_applied": exclusions
}

print(json.dumps(output))