import pandas as pd
import numpy as np
import statsmodels.api as sm
from scipy import stats
import json

# 1. Load data
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_soccer_neutral_T0.7_r4/data.csv"
df = pd.read_csv(FILE_PATH)

# 2. Clean / prepare -----------------------------------------------------------
# Average skin‑tone rating
df["avg_skin"] = df[["rater1", "rater2"]].mean(axis=1)

# Binary outcome: any red card from this referee?
df["redCard_bin"] = (df["redCards"] > 0).astype(int)

# Select variables
covariates = ["games", "yellowCards", "position", "leagueCountry"]
cols_needed = ["avg_skin", "redCard_bin"] + covariates + ["refNum"]
df = df[cols_needed]

# Listwise deletion of rows with any missing values in selected columns
df = df.dropna()

# One‑hot encode categoricals, drop first to avoid collinearity
df = pd.get_dummies(df, columns=["position", "leagueCountry"], drop_first=True)

# Outcome, predictor, covariates
y = df["redCard_bin"]
X = df.drop(columns=["redCard_bin", "refNum"])
X = sm.add_constant(X)  # intercept

# 3. Fit logistic regression with clustered robust SE (cluster by referee)
model = sm.GLM(y, X, family=sm.families.Binomial())
results = model.fit(cov_type="cluster", cov_kwds={"groups": df["refNum"]})

# 4. Primary estimand: odds ratio for a full 0→1 change in avg_skin --------------
coef = results.params["avg_skin"]
se = results.bse["avg_skin"]
z = coef / se
p_value = 2 * stats.norm.sf(abs(z))  # two‑sided p‑value

# 95% CI on log‑odds, then exponentiate to odds ratio scale
ci_low_log = coef - 1.96 * se
ci_upp_log = coef + 1.96 * se
or_est = np.exp(coef)
ci_low = np.exp(ci_low_log)
ci_upp = np.exp(ci_upp_log)

conclusion = "significant_effect" if p_value < 0.05 else "no_significant_effect"

# 5. Assemble JSON output ------------------------------------------------------
output = {
    "effect_size": float(or_est),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_value),
    "ci_lower": float(ci_low),
    "ci_upper": float(ci_upp),
    "conclusion": conclusion,
    "model_family": "logistic",
    "predictor_used": "avg_skin (average of rater1 and rater2)",
    "covariates_included": [col for col in X.columns if col not in ("const", "avg_skin")],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "rows with missing avg_skin, redCards, games, yellowCards, position, leagueCountry dropped"
}

print(json.dumps(output))