import pandas as pd
import numpy as np
import json
import statsmodels.api as sm
import statsmodels.formula.api as smf
from scipy.stats import norm

# 1. Load data
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_synthetic_neutral_T0.0_r1/data.csv"
df = pd.read_csv(FILE_PATH)

# 2. Clean / prepare
# Impute missing skin_tone with mean (8% missing)
skin_mean = df["skin_tone"].mean()
df["skin_tone"] = df["skin_tone"].fillna(skin_mean)

# Create binary outcome: any red card?
df["redCard_any"] = (df["redCards"] > 0).astype(int)

# Covariates to adjust for
covariates = ["position", "height", "weight", "leagueCountry", "games", "yellowCards"]

# 3. Fit model – logistic GEE with clustering by refereeID
formula = "redCard_any ~ skin_tone + C(position) + height + weight + C(leagueCountry) + games + yellowCards"
gee_model = smf.gee(formula,
                    groups="refereeID",
                    data=df,
                    family=sm.families.Binomial())
gee_result = gee_model.fit()

# 4. Extract primary estimand (odds ratio for skin_tone)
coef = gee_result.params["skin_tone"]
se = gee_result.bse["skin_tone"]
z = coef / se
p_value = 2 * (1 - norm.cdf(abs(z)))
ci_log_lower = coef - 1.96 * se
ci_log_upper = coef + 1.96 * se
or_est = np.exp(coef)
ci_lower = np.exp(ci_log_lower)
ci_upper = np.exp(ci_log_upper)

conclusion = "significant_effect" if p_value < 0.05 else "no_significant_effect"

# 5. Prepare JSON output
output = {
    "effect_size": float(or_est),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_value),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "logistic",
    "predictor_used": "skin_tone (continuous, 0=very light to 1=very dark)",
    "covariates_included": covariates,
    "missing_data_strategy": "mean_imputation",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "none"
}

print(json.dumps(output))