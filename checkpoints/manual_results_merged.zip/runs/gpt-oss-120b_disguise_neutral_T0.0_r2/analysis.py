import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.stats.sandwich_covariance as sw
import json

# ----------------------------------------------------------------------
# 1. Load data
# ----------------------------------------------------------------------
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_disguise_neutral_T0.0_r2/data.csv"
df = pd.read_csv(FILE_PATH)

# ----------------------------------------------------------------------
# 2. Construct predictor (average of the two risk scores)
# ----------------------------------------------------------------------
df["avg_risk_score"] = df[["risk_evaluator_alpha_score", "risk_evaluator_beta_score"]].mean(axis=1)

# Binary outcome: any rejection (0 = none, 1 = at least one)
df["rejection_flag"] = (df["loan_application_rejections"] > 0).astype(int)

# ----------------------------------------------------------------------
# 3. Choose covariates (numeric, limited missingness)
# ----------------------------------------------------------------------
covariates = [
    "credit_score_index",
    "annual_income_bracket",
    "prior_approved_loans",
    "prior_denied_loans",
    "repayment_performance_score",
    "elevated_risk_warnings",
    "total_applications_reviewed",
    "loan_officer_jurisdiction",
    "regional_index_a",
    "regional_index_b",
]

# ----------------------------------------------------------------------
# 4. Missing data handling: listwise deletion for all used columns
# ----------------------------------------------------------------------
required = ["avg_risk_score", "rejection_flag", "loan_officer_id"] + covariates
initial_n = len(df)
df_clean = df.dropna(subset=required)
final_n = len(df_clean)
exclusions_desc = f"dropped {initial_n - final_n} rows with missing predictor, outcome, or covariates"

# ----------------------------------------------------------------------
# 5. Design matrix
# ----------------------------------------------------------------------
X = df_clean[["avg_risk_score"] + covariates]
X = sm.add_constant(X, has_constant='add')
y = df_clean["rejection_flag"]

# ----------------------------------------------------------------------
# 6. Fit logistic regression
# ----------------------------------------------------------------------
logit_mod = sm.Logit(y, X)
logit_res = logit_mod.fit(disp=0)

# ----------------------------------------------------------------------
# 7. Cluster-robust standard errors (cluster by loan_officer_id)
# ----------------------------------------------------------------------
clusters = df_clean["loan_officer_id"]
cov_cluster = sw.cov_cluster(logit_res, groups=clusters)
se_cluster = np.sqrt(np.diag(cov_cluster))

# Extract coefficient, SE, p‑value for the main predictor
coef = logit_res.params["avg_risk_score"]
se = se_cluster[logit_res.params.index.get_loc("avg_risk_score")]
z_stat = coef / se
p_val = 2 * (1 - sm.stats.norm.cdf(abs(z_stat)))

# Confidence interval on log‑odds scale
z_crit = 1.96
ci_low_log = coef - z_crit * se
ci_upp_log = coef + z_crit * se

# Transform to odds ratio
odds_ratio = np.exp(coef)
ci_low = np.exp(ci_low_log)
ci_upp = np.exp(ci_upp_log)

# ----------------------------------------------------------------------
# 8. Assemble JSON output
# ----------------------------------------------------------------------
output = {
    "effect_size": float(odds_ratio),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_low),
    "ci_upper": float(ci_upp),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "logistic",
    "predictor_used": "average_risk_score",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": exclusions_desc
}

print(json.dumps(output, ensure_ascii=False))