import pandas as pd
import numpy as np
import json
import statsmodels.api as sm
from scipy.stats import norm

# 1. Load data
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_soccer_neutral_T1.0_r1/data.csv"
df = pd.read_csv(FILE_PATH)

# 2. Prepare data -------------------------------------------------------------
# Predictor: average of rater1 and rater2
df["avg_skin_tone"] = df[["rater1", "rater2"]].mean(axis=1)

# Exclude rows missing predictor or outcome
missing_mask = df["avg_skin_tone"].isna() | df["redCards"].isna()
exclusions_desc = "rows with missing rater1 or rater2 removed"
df = df.loc[~missing_mask].copy()

# Outcome: binary indicator for any red card
df["redCard_any"] = (df["redCards"] > 0).astype(int)

# Covariates ---------------------------------------------------------------
# Continuous: games (median imputation if needed)
df["games"] = df["games"].fillna(df["games"].median())

# Categorical: position, leagueCountry (add placeholder for missing)
df["position"] = df["position"].fillna("Missing")
df["leagueCountry"] = df["leagueCountry"].fillna("Missing")

# Build design matrix
covariate_cols = ["games"]
pos_dummies = pd.get_dummies(df["position"], prefix="pos", drop_first=True)
lg_dummies = pd.get_dummies(df["leagueCountry"], prefix="lg", drop_first=True)

X = pd.concat([df[["avg_skin_tone"] + covariate_cols], pos_dummies, lg_dummies], axis=1)
X = sm.add_constant(X, has_constant='add')
y = df["redCard_any"]

# 3. Fit logistic regression --------------------------------------------------
logit_model = sm.Logit(y, X, missing='drop')
result = logit_model.fit(disp=0)

# 4. Extract primary estimand -------------------------------------------------
beta = result.params["avg_skin_tone"]
se_beta = result.bse["avg_skin_tone"]
z = beta / se_beta
p_value = 2 * (1 - norm.cdf(abs(z)))

odds_ratio = np.exp(beta)
ci_lower = np.exp(beta - 1.96 * se_beta)
ci_upper = np.exp(beta + 1.96 * se_beta)

conclusion = "significant_effect" if p_value < 0.05 else "no_significant_effect"

# 5. Assemble JSON output -----------------------------------------------------
output = {
    "effect_size": float(odds_ratio),
    "effect_type": "odds_ratio",
    "standard_error": float(se_beta),
    "p_value": float(p_value),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "logistic",
    "predictor_used": "average of rater1 and rater2 (avg_skin_tone)",
    "covariates_included": ["games"] + list(pos_dummies.columns) + list(lg_dummies.columns),
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": exclusions_desc
}

print(json.dumps(output))