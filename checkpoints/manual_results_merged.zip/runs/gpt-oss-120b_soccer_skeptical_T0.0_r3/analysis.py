import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

# ----------------------------------------------------------------------
# 1. Load data
# ----------------------------------------------------------------------
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_soccer_skeptical_T0.0_r3/data.csv"
df = pd.read_csv(FILE_PATH)

# ----------------------------------------------------------------------
# 2. Missing data handling & predictor construction
# ----------------------------------------------------------------------
missing_strategy = "listwise_deletion"

# Rows missing essential variables are removed
initial_n = len(df)
df = df.dropna(subset=["rater1", "rater2", "redCards", "refNum"])

# Continuous skin‑tone score (average of two raters)
df["skin_tone"] = df[["rater1", "rater2"]].mean(axis=1)

# Binary outcome: any red card vs none
df["red_binary"] = (df["redCards"] > 0).astype(int)

# Simple mean imputation for height and weight (small % missing)
for col in ["height", "weight"]:
    if col in df.columns:
        df[col] = df[col].fillna(df[col].mean())

exclusions = f"dropped {initial_n - len(df)} rows with missing rater1/rater2/redCards/refNum"

# ----------------------------------------------------------------------
# 3. Covariates
# ----------------------------------------------------------------------
# Core numeric covariates
covariate_cols = ["games", "yellowCards", "height", "weight"]

# Categorical covariates to be dummy‑encoded
cat_cols = ["position", "leagueCountry"]
df = pd.get_dummies(df, columns=cat_cols, drop_first=True, dtype=float)

# Assemble design matrix
dummy_cols = [c for c in df.columns if c.startswith("position_") or c.startswith("leagueCountry_")]
X = df[["skin_tone"] + covariate_cols + dummy_cols].copy()
X = sm.add_constant(X, has_constant='add')

# Ensure no remaining NaNs (should be none after imputation)
X = X.fillna(0)

y = df["red_binary"]

# ----------------------------------------------------------------------
# 4. Model fitting (logistic regression with clustered SE by referee)
# ----------------------------------------------------------------------
logit_mod = sm.Logit(y, X)
logit_res = logit_mod.fit(disp=0)

# Clustered robust covariance (clusters = referee number)
clustered_res = logit_res.get_robustcov_results(cov_type="cluster", groups=df["refNum"])

# ----------------------------------------------------------------------
# 5. Extract primary estimand (odds ratio for full 0→1 skin‑tone change)
# ----------------------------------------------------------------------
coef = clustered_res.params["skin_tone"]
se = clustered_res.bse["skin_tone"]
pval = clustered_res.pvalues["skin_tone"]
ci_low = coef - 1.96 * se
ci_upp = coef + 1.96 * se

or_est = np.exp(coef)
or_ci_low = np.exp(ci_low)
or_ci_upp = np.exp(ci_upp)

conclusion = "significant_effect" if pval < 0.05 else "no_significant_effect"

# ----------------------------------------------------------------------
# 6. JSON output
# ----------------------------------------------------------------------
output = {
    "effect_size": float(or_est),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(pval),
    "ci_lower": float(or_ci_low),
    "ci_upper": float(or_ci_upp),
    "conclusion": conclusion,
    "model_family": "logistic",
    "predictor_used": "average_skin_tone = (rater1 + rater2)/2",
    "covariates_included": covariate_cols + dummy_cols,
    "missing_data_strategy": missing_strategy,
    "clustering_strategy": "clustered_se",
    "exclusions_applied": exclusions
}

print(json.dumps(output, ensure_ascii=False))