import pandas as pd
import numpy as np
import json
import statsmodels.api as sm
import statsmodels.stats.sandwich_covariance as sw

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gpt-oss-120b_placebo_skeptical_T0.7_r1/data.csv"
df = pd.read_csv(file_path)

# 2. Create continuous skin‑tone predictor (average of two raters)
df["skin_tone"] = df[["rater1", "rater2"]].mean(axis=1)

# Exclude rows without a skin‑tone rating
exclusions = "rows missing rater1 or rater2 removed"
df = df.dropna(subset=["skin_tone"]).copy()

# Binary outcome: any red card received from that referee?
df["red_binary"] = (df["redCards"] > 0).astype(int)

# 3. Impute other missing values
# Numeric columns → mean imputation
num_cols = ["height", "weight", "games", "yellowCards", "yellowReds"]
for col in num_cols:
    if df[col].isnull().any():
        df[col] = df[col].fillna(df[col].mean())

# Categorical columns → mode imputation
cat_cols = ["position", "leagueCountry"]
for col in cat_cols:
    if df[col].isnull().any():
        df[col] = df[col].fillna(df[col].mode()[0])

# 4. Build design matrix
X = df[["skin_tone"] + num_cols].copy()

# One‑hot encode categorical covariates (drop first to avoid collinearity)
X = pd.concat(
    [
        X,
        pd.get_dummies(df["position"], prefix="position", drop_first=True),
        pd.get_dummies(df["leagueCountry"], prefix="league", drop_first=True),
    ],
    axis=1,
)

# Add intercept
X = sm.add_constant(X, has_constant="add")

y = df["red_binary"]

# 5. Fit logistic regression
logit_model = sm.Logit(y, X)
logit_res = logit_model.fit(disp=False)

# 6. Clustered robust standard errors (cluster by referee number)
cluster_ids = df["refNum"]
cov_cluster = sw.cov_cluster(logit_res, cluster_ids)
se_cluster = np.sqrt(np.diag(cov_cluster))

# Extract coefficient and SE for skin_tone
coef = logit_res.params["skin_tone"]
se = se_cluster[logit_res.params.index.get_loc("skin_tone")]

# Wald test statistics
z = coef / se
p_value = 2 * (1 - sm.stats.norm.cdf(abs(z)))

# Odds ratio and 95% CI
odds_ratio = np.exp(coef)
ci_lower = np.exp(coef - 1.96 * se)
ci_upper = np.exp(coef + 1.96 * se)

# 7. Assemble JSON output
output = {
    "effect_size": float(odds_ratio),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_value),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if p_value < 0.05 else "no_significant_effect",
    "model_family": "logistic",
    "predictor_used": "average of rater1 and rater2 (skin_tone)",
    "covariates_included": ["games", "yellowCards", "yellowReds", "height", "weight",
                            "position", "leagueCountry"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": exclusions
}

print(json.dumps(output, ensure_ascii=False))