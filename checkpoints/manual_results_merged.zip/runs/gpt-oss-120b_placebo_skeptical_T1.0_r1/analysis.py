import pandas as pd
import numpy as np
import json
import statsmodels.api as sm

# ----------------------------------------------------------------------
# 1. Load data
# ----------------------------------------------------------------------
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_placebo_skeptical_T1.0_r1/data.csv"
df = pd.read_csv(FILE_PATH)

# ----------------------------------------------------------------------
# 2. Data preparation
# ----------------------------------------------------------------------
# Predictor: average of the two skin‑tone ratings
df["skin_tone"] = df[["rater1", "rater2"]].mean(axis=1)

# Outcome: count of red cards (already integer)
# Use exposure = number of games (must be >0)
df = df[df["games"] > 0]                     # drop any zero‑game rows (unlikely)
df["log_exposure"] = np.log(df["games"])

# Choose a parsimonious set of covariates to avoid collinearity
covariates = ["yellowCards", "height", "weight", "refCountry"]

# Columns required for the analysis
required = ["skin_tone", "redCards", "log_exposure", "refNum"] + covariates
df_clean = df[required].dropna()

# Record exclusion information
exclusions = f"dropped {len(df) - len(df_clean)} rows due to missing data or zero games"

# ----------------------------------------------------------------------
# 3. Build design matrix
# ----------------------------------------------------------------------
X = df_clean[["skin_tone"] + covariates]
X = sm.add_constant(X, prepend=False)   # adds a column named 'const'

y = df_clean["redCards"]
offset = df_clean["log_exposure"]

# ----------------------------------------------------------------------
# 4. Fit Poisson regression (log link) to obtain an incidence rate ratio
# ----------------------------------------------------------------------
poisson_model = sm.GLM(y, X, family=sm.families.Poisson(), offset=offset)
poisson_res = poisson_model.fit()

# ----------------------------------------------------------------------
# 5. Cluster‑robust SEs by referee (refNum)
# ----------------------------------------------------------------------
cluster_res = poisson_res.get_robustcov_results(cov_type="cluster",
                                                groups=df_clean["refNum"])

# ----------------------------------------------------------------------
# 6. Extract estimator for skin_tone
# ----------------------------------------------------------------------
coef = cluster_res.params["skin_tone"]
se = cluster_res.bse["skin_tone"]
z = coef / se
p_value = 2 * (1 - sm.stats.norm.cdf(abs(z)))
ci_low_log = coef - 1.96 * se
ci_upp_log = coef + 1.96 * se

irr = np.exp(coef)
ci_low = np.exp(ci_low_log)
ci_upp = np.exp(ci_upp_log)

# ----------------------------------------------------------------------
# 7. Assemble JSON output
# ----------------------------------------------------------------------
output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_value),
    "ci_lower": float(ci_low),
    "ci_upper": float(ci_upp),
    "conclusion": "significant_effect" if p_value < 0.05 else "no_significant_effect",
    "model_family": "poisson",
    "predictor_used": "average of rater1 and rater2 (skin_tone)",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": exclusions
}

print(json.dumps(output))