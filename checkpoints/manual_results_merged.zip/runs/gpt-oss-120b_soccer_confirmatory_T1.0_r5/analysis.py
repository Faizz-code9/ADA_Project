import pandas as pd
import numpy as np
import statsmodels.api as sm
from scipy import stats
import json

# 1. Load data
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_soccer_confirmatory_T1.0_r5/data.csv"
df = pd.read_csv(FILE_PATH)

# 2. Clean / prepare ---------------------------------------------------------
# Average skin tone from the two raters
df["skin_tone"] = df[["rater1", "rater2"]].mean(axis=1)

# Binary outcome: did the player receive any red card from this referee?
df["red_any"] = (df["redCards"] > 0).astype(int)

# Selected covariates (reasonable controls)
covariates = ["games", "yellowCards", "position"]

# Rows with missing values in any required column are dropped (listwise deletion)
required = ["skin_tone", "red_any", "refNum"] + covariates
df_clean = df.dropna(subset=required).copy()

# One‑hot encode position (drop first to avoid perfect collinearity)
df_clean = pd.get_dummies(df_clean, columns=["position"], drop_first=True)

# Build design matrix
position_cols = [c for c in df_clean.columns if c.startswith("position_")]
X_vars = ["skin_tone", "games", "yellowCards"] + position_cols
X = df_clean[X_vars]
X = sm.add_constant(X, prepend=False)          # adds intercept named 'const'
y = df_clean["red_any"]

# 3. Fit logistic regression with clustered SE by referee --------------------
logit_res = sm.Logit(y, X).fit(
    disp=0,
    cov_type="cluster",
    cov_kwds={"groups": df_clean["refNum"]}   # clustering variable
)

# 4. Extract estimand ---------------------------------------------------------
coef = logit_res.params["skin_tone"]
se = logit_res.bse["skin_tone"]
z = coef / se
p_val = 2 * (1 - stats.norm.cdf(abs(z)))
ci_low_log = coef - 1.96 * se
ci_upp_log = coef + 1.96 * se

# Convert log‑odds to odds ratio
odds_ratio = np.exp(coef)
ci_low = np.exp(ci_low_log)
ci_upp = np.exp(ci_upp_log)

# 5. JSON output -------------------------------------------------------------
output = {
    "effect_size": float(odds_ratio),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_low),
    "ci_upper": float(ci_upp),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "logistic",
    "predictor_used": "average of rater1 and rater2 (skin_tone)",
    "covariates_included": [var for var in X_vars if var != "skin_tone"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "rows missing rater1/rater2, games, yellowCards, position, or refNum were dropped"
}

print(json.dumps(output))