import pandas as pd
import numpy as np
import statsmodels.api as sm
from scipy.stats import norm
import json

# 1. Load data
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_soccer_confirmatory_T0.7_r2/data.csv"
df = pd.read_csv(FILE_PATH)

# 2. Clean / prepare
# Drop rows missing either rater1 or rater2 (listwise deletion)
df = df.dropna(subset=["rater1", "rater2"]).copy()

# Create continuous skin‑tone predictor as the average of the two raters
df["avg_skin"] = (df["rater1"] + df["rater2"]) / 2.0

# Ensure outcome is integer count
df["redCards"] = df["redCards"].astype(int)

# Use number of games as exposure; remove any zero‑game rows (should not exist)
df = df[df["games"] > 0].copy()
df["log_games"] = np.log(df["games"])

# Choose covariates for adjustment
covariates = ["yellowCards", "yellowReds"]
X = df[["avg_skin"] + covariates]
X = sm.add_constant(X, has_constant='add')

# 3. Fit Poisson GLM with clustered robust SE by referee (refNum)
model = sm.GLM(
    endog=df["redCards"],
    exog=X,
    family=sm.families.Poisson(),
    offset=df["log_games"]
)
result = model.fit(cov_type="cluster", cov_kwds={"groups": df["refNum"]})

# 4. Primary estimand: incidence rate ratio (IRR) for a full 0‑1 change in skin tone
coef = result.params["avg_skin"]
se = result.bse["avg_skin"]
z = coef / se
p_val = 2 * (1 - norm.cdf(abs(z)))
ci_low_coef = coef - 1.96 * se
ci_upp_coef = coef + 1.96 * se
irr = np.exp(coef)
ci_low = np.exp(ci_low_coef)
ci_upp = np.exp(ci_upp_coef)

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

# 5. Output JSON
output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_low),
    "ci_upper": float(ci_upp),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "average_skin_tone = (rater1 + rater2) / 2",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "rows with missing rater1 or rater2 removed"
}
print(json.dumps(output))