import pandas as pd
import numpy as np
import json
import statsmodels.formula.api as smf
import statsmodels.api as sm

# 1. Load data
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_synthetic_skeptical_T1.0_r1/data.csv"
df = pd.read_csv(FILE_PATH)

# 2. Cleaning / preparation
# Impute missing skin_tone with mean (mean_imputation)
skin_mean = df["skin_tone"].mean()
df["skin_tone"] = df["skin_tone"].fillna(skin_mean)

# Ensure numeric types
df["redCards"] = pd.to_numeric(df["redCards"], errors="coerce")
df["games"] = pd.to_numeric(df["games"], errors="coerce")

# No rows are dropped beyond the imputation
exclusions = "none"

# 3. Model specification
# Use a Poisson GLM with log(games) as offset to model rate of red cards per game
# Include plausible covariates and cluster-robust SE by refereeID
formula = (
    "redCards ~ skin_tone + games + yellowCards + height + weight + "
    "C(position) + C(leagueCountry)"
)

# Fit the model with clustered standard errors
model = smf.glm(
    formula=formula,
    data=df,
    family=sm.families.Poisson(),
    offset=np.log(df["games"])
).fit(cov_type="cluster", cov_kwds={"groups": df["refereeID"]})

# 4. Extract estimand (IRR for skin_tone)
coef = model.params["skin_tone"]
se = model.bse["skin_tone"]
p_val = model.pvalues["skin_tone"]
ci_lower_log, ci_upper_log = model.conf_int().loc["skin_tone"]
irr = np.exp(coef)
ci_lower = np.exp(ci_lower_log)
ci_upper = np.exp(ci_upper_log)

# 5. Build result JSON
result = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "poisson",
    "predictor_used": "skin_tone",
    "covariates_included": [
        "games",
        "yellowCards",
        "height",
        "weight",
        "position",
        "leagueCountry"
    ],
    "missing_data_strategy": "mean_imputation",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": exclusions
}

print(json.dumps(result, ensure_ascii=False))