import pandas as pd
import numpy as np
import statsmodels.formula.api as smf
from scipy.stats import norm
import json

# 1. Load data
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_placebo_confirmatory_T0.7_r2/data.csv"
df = pd.read_csv(FILE_PATH)

# 2. Prepare data
# Binary outcome: any red card
df["red_binary"] = (df["redCards"] > 0).astype(int)

# Average skin tone from the two raters
df["skin_tone"] = df[["rater1", "rater2"]].mean(axis=1)

# Covariates to adjust for
covariates = ["games", "yellowCards", "height", "weight",
              "position", "leagueCountry"]

# Keep rows with complete data for predictor, outcome, covariates, and referee identifier
required = ["skin_tone", "red_binary", "refNum"] + covariates
df_clean = df.dropna(subset=required)

# 3. Fit logistic regression with clustered (by referee) robust SEs
formula = "red_binary ~ skin_tone + games + yellowCards + height + weight + C(position) + C(leagueCountry)"
model = smf.logit(formula=formula, data=df_clean)

# Use clustered covariance directly in fit
result = model.fit(disp=0, cov_type="cluster", cov_kwds={"groups": df_clean["refNum"]})

# 4. Extract primary estimand (odds ratio for a full 0→1 increase in skin tone)
coef = result.params["skin_tone"]
se = result.bse["skin_tone"]
z = coef / se
p_value = 2 * (1 - norm.cdf(abs(z)))  # two‑sided p‑value

odds_ratio = np.exp(coef)
ci_lower = np.exp(coef - 1.96 * se)
ci_upper = np.exp(coef + 1.96 * se)

conclusion = "significant_effect" if p_value < 0.05 else "no_significant_effect"

# 5. Assemble JSON output
output = {
    "effect_size": float(odds_ratio),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_value),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "logistic",
    "predictor_used": "average of rater1 and rater2 (skin_tone)",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "rows with missing skin_tone, redCards, refNum, or any covariate removed"
}

print(json.dumps(output))