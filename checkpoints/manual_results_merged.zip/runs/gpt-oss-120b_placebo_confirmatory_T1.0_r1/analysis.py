import pandas as pd
import numpy as np
import json
import statsmodels.api as sm
from scipy.stats import norm

# ------------------------------------------------------------------
# 1. Load data
# ------------------------------------------------------------------
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_placebo_confirmatory_T1.0_r1/data.csv"
df = pd.read_csv(FILE_PATH)

# ------------------------------------------------------------------
# 2. Prepare predictor, outcome, and covariates
# ------------------------------------------------------------------
# Average skin‑tone rating
df["skin_tone"] = df[["rater1", "rater2"]].mean(axis=1, skipna=True)

# Mean‑impute any remaining missing skin tone values
skin_mean = df["skin_tone"].mean()
df["skin_tone"] = df["skin_tone"].fillna(skin_mean)

# Binary outcome: any red card vs none
df["red_binary"] = (df["redCards"] > 0).astype(int)

# Covariates to adjust for
covariate_cols = ["height", "weight", "games", "position"]
pre_drop_len = len(df)
df = df.dropna(subset=covariate_cols)
exclusions_desc = f"dropped {pre_drop_len - len(df)} rows with missing height/weight/games/position"

# One‑hot encode position (drop first to avoid collinearity)
df = pd.get_dummies(df, columns=["position"], drop_first=True)

# Design matrix
predictor = "skin_tone"
base_vars = ["height", "weight", "games"]
position_vars = [c for c in df.columns if c.startswith("position_")]
X_vars = [predictor] + base_vars + position_vars
X = df[X_vars]
X = sm.add_constant(X, has_constant='add')
y = df["red_binary"]

# ------------------------------------------------------------------
# 3. Fit logistic model with clustered (by referee) robust SEs
# ------------------------------------------------------------------
cluster_groups = df["refNum"]
glm_binom = sm.GLM(y, X, family=sm.families.Binomial())
result = glm_binom.fit(cov_type="cluster", cov_kwds={"groups": cluster_groups})

# ------------------------------------------------------------------
# 4. Extract estimand for skin_tone
# ------------------------------------------------------------------
coef = result.params[predictor]
se = np.sqrt(result.cov_params().loc[predictor, predictor])
z = coef / se
p_value = 2 * (1 - norm.cdf(abs(z)))
ci_low_log = coef - 1.96 * se
ci_upp_log = coef + 1.96 * se
odds_ratio = np.exp(coef)
ci_low = np.exp(ci_low_log)
ci_upp = np.exp(ci_upp_log)

conclusion = "significant_effect" if p_value < 0.05 else "no_significant_effect"

# ------------------------------------------------------------------
# 5. Assemble JSON output
# ------------------------------------------------------------------
output = {
    "effect_size": float(odds_ratio),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_value),
    "ci_lower": float(ci_low),
    "ci_upper": float(ci_upp),
    "conclusion": conclusion,
    "model_family": "logistic",
    "predictor_used": "average of rater1 and rater2 (skin_tone)",
    "covariates_included": X_vars,
    "missing_data_strategy": "mean_imputation",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": exclusions_desc
}

print(json.dumps(output))