import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

# ---------- Load data ----------
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_soccer_skeptical_T1.0_r2/data.csv"
df = pd.read_csv(FILE_PATH)

# ---------- Build predictor ----------
# Continuous skin‑tone score: average of the two raters
df["skin_tone"] = df[["rater1", "rater2"]].mean(axis=1)

# ---------- Outcome ----------
df["red_any"] = (df["redCards"] > 0).astype(int)

# ---------- Covariates ----------
covariate_cols = ["games", "position", "leagueCountry", "refCountry"]
# Remove rows with missing values in any column needed for analysis
df = df.dropna(subset=["skin_tone", "red_any"] + covariate_cols)

# One‑hot encode categoricals (drop first to avoid collinearity)
df = pd.get_dummies(df, columns=["position", "leagueCountry", "refCountry"], drop_first=True)

# ---------- Design matrix ----------
y = df["red_any"]
X = df.drop(columns=[
    "playerShort", "player", "club", "birthday", "height", "weight",
    "photoID", "rater1", "rater2", "refNum", "Alpha_3",
    "meanIAT", "nIAT", "seIAT", "meanExp", "nExp", "seExp",
    "redCards", "red_any"
])
# Ensure predictor is present
if "skin_tone" not in X.columns:
    raise RuntimeError("skin_tone column missing after processing.")

# Add intercept
X = sm.add_constant(X, prepend=False)

# ---------- Model fitting ----------
# Clustered (by referee) robust SEs
cluster_groups = df["refNum"]
logit_res = sm.Logit(y, X).fit(
    disp=0,
    method="lbfgs",
    maxiter=1000,
    cov_type="cluster",
    cov_kwds={"groups": cluster_groups}
)

# ---------- Extract estimand ----------
coef = logit_res.params["skin_tone"]
se = logit_res.bse["skin_tone"]
z = coef / se
p_value = 2 * (1 - sm.stats.norm.cdf(abs(z)))

# 95% CI on log‑odds scale, then exponentiate to odds ratio
ci_low_log = coef - 1.96 * se
ci_upp_log = coef + 1.96 * se
odds_ratio = np.exp(coef)
ci_low = np.exp(ci_low_log)
ci_upp = np.exp(ci_upp_log)

# ---------- JSON output ----------
output = {
    "effect_size": float(odds_ratio),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_value),
    "ci_lower": float(ci_low),
    "ci_upper": float(ci_upp),
    "conclusion": "significant_effect" if p_value < 0.05 else "no_significant_effect",
    "model_family": "logistic",
    "predictor_used": "average of rater1 and rater2 (skin_tone)",
    "covariates_included": [col for col in X.columns if col not in ("const", "skin_tone")],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "Rows with missing rater1/rater2, games, position, leagueCountry, or refCountry were removed."
}

print(json.dumps(output))