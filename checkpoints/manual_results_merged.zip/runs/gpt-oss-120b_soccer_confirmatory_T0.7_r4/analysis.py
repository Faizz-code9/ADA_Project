import pandas as pd
import numpy as np
import statsmodels.api as sm
import json
import sys

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gpt-oss-120b_soccer_confirmatory_T0.7_r4/data.csv"
df = pd.read_csv(file_path)

# 2. Cleaning / preparation
# Exclude rows missing skin‑tone ratings
exclusions = "rows missing rater1 or rater2 removed"
df = df.dropna(subset=["rater1", "rater2"])

# Build continuous skin‑tone predictor (average of two raters)
df["avg_skin"] = (df["rater1"] + df["rater2"]) / 2.0

# Binary outcome: any red card vs none
df["red_any"] = (df["redCards"] > 0).astype(int)

# Select covariates (listwise deletion for any missing in these)
covariate_cols = ["games", "yellowCards", "height", "weight"]
df = df.dropna(subset=covariate_cols + ["avg_skin", "red_any", "refNum"])

# Encode categorical position (drop first to avoid collinearity)
position_dummies = pd.get_dummies(df["position"], prefix="pos", drop_first=True)
df = pd.concat([df, position_dummies], axis=1)

# Build design matrix
predictor_used = "average_skin_tone = (rater1 + rater2)/2"
X_cols = ["avg_skin", "games", "yellowCards", "height", "weight"] + list(position_dummies.columns)
X = df[X_cols]
X = sm.add_constant(X, has_constant='add')

y = df["red_any"]

# 3. Fit logistic model with clustered SE by referee
model = sm.GLM(y, X, family=sm.families.Binomial())
result = model.fit(cov_type="cluster", cov_kwds={"groups": df["refNum"]})

# 4. Compute primary estimand (odds ratio for avg_skin)
coef = result.params["avg_skin"]
se = result.bse["avg_skin"]
odds_ratio = np.exp(coef)
ci_lower = np.exp(coef - 1.96 * se)
ci_upper = np.exp(coef + 1.96 * se)
p_value = result.pvalues["avg_skin"]

# 5. Assemble output JSON
output = {
    "effect_size": float(odds_ratio),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_value),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if p_value < 0.05 else "no_significant_effect",
    "model_family": "logistic",
    "predictor_used": predictor_used,
    "covariates_included": X_cols,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": exclusions
}

print(json.dumps(output))