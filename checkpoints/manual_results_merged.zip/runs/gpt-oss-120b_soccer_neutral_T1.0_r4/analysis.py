import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

# 1. Load data
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_soccer_neutral_T1.0_r4/data.csv"
df = pd.read_csv(FILE_PATH)

# 2. Clean / prepare -----------------------------------------------------------
# Binary outcome: any red card received from the referee
df["red_flag"] = (df["redCards"] > 0).astype(int)

# Predictor: average of the two skin‑tone ratings
df["avg_skin"] = df[["rater1", "rater2"]].mean(axis=1)

# Variables needed for the model
required_cols = ["avg_skin", "red_flag", "games", "yellowCards",
                 "position", "leagueCountry", "refNum"]
df = df.dropna(subset=required_cols)

# Impute missing position (if any) with mode
if df["position"].isna().any():
    df["position"] = df["position"].fillna(df["position"].mode().iloc[0])

# 3. Design matrix -------------------------------------------------------------
# Categorical covariates
cat_cols = ["position", "leagueCountry"]
dummies = pd.get_dummies(df[cat_cols], drop_first=True)

X = pd.concat(
    [
        df[["avg_skin", "games", "yellowCards"]],
        dummies,
    ],
    axis=1,
)
X = sm.add_constant(X, prepend=False)  # adds column 'const' as intercept

y = df["red_flag"]

# 4. Fit logistic regression with clustered (by referee) SE --------------------
glm_binom = sm.GLM(y, X, family=sm.families.Binomial())
res = glm_binom.fit(cov_type="cluster", cov_kwds={"groups": df["refNum"]})

# 5. Extract primary estimand --------------------------------------------------
coef = res.params["avg_skin"]
se = res.bse["avg_skin"]
p_val = res.pvalues["avg_skin"]
ci_lower = coef - 1.96 * se
ci_upper = coef + 1.96 * se

odds_ratio = np.exp(coef)
ci_lower_or = np.exp(ci_lower)
ci_upper_or = np.exp(ci_upper)

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

# 6. Assemble JSON output ------------------------------------------------------
output = {
    "effect_size": float(odds_ratio),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower_or),
    "ci_upper": float(ci_upper_or),
    "conclusion": conclusion,
    "model_family": "logistic",
    "predictor_used": "average_skin_tone",
    "covariates_included": ["games", "yellowCards"] + list(dummies.columns),
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "rows missing avg_skin, red_flag, games, yellowCards, position, leagueCountry, or refNum removed"
}

print(json.dumps(output))