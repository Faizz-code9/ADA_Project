import pandas as pd
import numpy as np
import statsmodels.api as sm
from scipy.stats import norm
import json

# 1. Load data
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_synthetic_confirmatory_T1.0_r2/data.csv"
df = pd.read_csv(FILE_PATH)

# 2. Missing data handling (listwise deletion for variables used)
required_cols = [
    "redCards", "skin_tone", "games", "yellowCards",
    "height", "weight", "position", "leagueCountry", "refereeID"
]
df = df.dropna(subset=required_cols)

# 3. Design matrix
categorical = ["position", "leagueCountry"]
dummies = pd.get_dummies(df[categorical], drop_first=True)
X = pd.concat([
    df["skin_tone"],
    df["games"],
    df["yellowCards"],
    df["height"],
    df["weight"],
    dummies
], axis=1)
X = sm.add_constant(X, has_constant='add')
y = df["redCards"]

# 4. Fit Poisson GLM with clustered robust SE (by refereeID)
model = sm.GLM(y, X, family=sm.families.Poisson())
result = model.fit(cov_type="cluster", cov_kwds={"groups": df["refereeID"]})

# 5. Extract primary estimand (IRR for skin_tone)
coef = result.params["skin_tone"]
se = result.bse["skin_tone"]
z = coef / se
p_val = 2 * (1 - norm.cdf(abs(z)))
ci_low_log = coef - 1.96 * se
ci_upp_log = coef + 1.96 * se
irr = np.exp(coef)
ci_low = np.exp(ci_low_log)
ci_upp = np.exp(ci_upp_log)

# 6. JSON output
output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_low),
    "ci_upper": float(ci_upp),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "poisson",
    "predictor_used": "skin_tone (continuous 0‑1)",
    "covariates_included": ["games", "yellowCards", "height", "weight"] + list(dummies.columns),
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "rows with missing skin_tone or covariates removed"
}

print(json.dumps(output, ensure_ascii=False))