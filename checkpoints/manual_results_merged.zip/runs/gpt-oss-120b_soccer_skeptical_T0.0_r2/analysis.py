import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gpt-oss-120b_soccer_skeptical_T0.0_r2/data.csv"
df = pd.read_csv(file_path)

# 2. Clean / prepare
# Exclude rows missing any variable needed for the model
required_cols = [
    "rater1", "rater2", "redCards", "height", "weight",
    "position", "games", "yellowCards", "leagueCountry", "refNum"
]
df = df.dropna(subset=required_cols)

# Build continuous skin‑tone predictor as the average of the two raters
df["skin_tone"] = df[["rater1", "rater2"]].mean(axis=1)

# Binary outcome: any red card from that referee
df["red_card_any"] = (df["redCards"] > 0).astype(int)

# Encode categorical variables (drop_first to avoid collinearity)
df["position"] = df["position"].astype("category")
df["leagueCountry"] = df["leagueCountry"].astype("category")
position_dummies = pd.get_dummies(df["position"], prefix="pos", drop_first=True)
league_dummies = pd.get_dummies(df["leagueCountry"], prefix="lg", drop_first=True)

# Assemble design matrix
X = pd.concat(
    [
        df["skin_tone"],
        df[["height", "weight", "games", "yellowCards"]],
        position_dummies,
        league_dummies,
    ],
    axis=1,
)
X = sm.add_constant(X)  # intercept

y = df["red_card_any"]

# 3. Fit logistic regression with clustered robust SE by referee (refNum)
cluster_groups = df["refNum"]
logit_model = sm.Logit(y, X)
result = logit_model.fit(disp=False, cov_type="cluster", cov_kwds={"groups": cluster_groups})

# 4. Extract primary estimand (odds ratio for full 0→1 change in skin tone)
coef = result.params["skin_tone"]
se = result.bse["skin_tone"]
p_val = result.pvalues["skin_tone"]
ci_lower_log, ci_upper_log = result.conf_int().loc["skin_tone"]
odds_ratio = np.exp(coef)
ci_lower = np.exp(ci_lower_log)
ci_upper = np.exp(ci_upper_log)

# 5. Prepare JSON output
output = {
    "effect_size": float(odds_ratio),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "logistic",
    "predictor_used": "average_skin_tone",
    "covariates_included": [
        "height",
        "weight",
        "games",
        "yellowCards",
        "position (dummy vars)",
        "leagueCountry (dummy vars)"
    ],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "rows with missing rater1/rater2 or required covariates removed"
}

print(json.dumps(output))