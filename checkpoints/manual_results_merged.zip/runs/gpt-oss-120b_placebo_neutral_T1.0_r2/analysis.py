import pandas as pd
import numpy as np
import statsmodels.formula.api as smf
import json

# 1. Load data
path = "/kaggle/working/outputs/runs/gpt-oss-120b_placebo_neutral_T1.0_r2/data.csv"
df = pd.read_csv(path)

# 2. Clean & prepare
# Build continuous skin tone predictor as the average of the two raters
df["skin_tone"] = df[["rater1", "rater2"]].mean(axis=1)

# Binary outcome: any red card vs none
df["red_flag"] = (df["redCards"] > 0).astype(int)

# Handle missing position (12% missing) by creating a category
df["position"] = df["position"].fillna("Missing")

# Listwise deletion for rows missing skin tone or essential covariates
required_cols = ["skin_tone", "red_flag", "games", "yellowCards", "position", "leagueCountry", "refNum"]
df = df.dropna(subset=required_cols)

# 3. Fit logistic regression with clustered SE by referee
formula = "red_flag ~ skin_tone + games + yellowCards + C(position) + C(leagueCountry)"
model = smf.logit(formula=formula, data=df)
result = model.fit(cov_type="cluster", cov_kwds={"groups": df["refNum"]}, disp=False)

# 4. Compute estimand (odds ratio) and inference
coef = result.params["skin_tone"]
se = result.bse["skin_tone"]
z = coef / se
p_value = result.pvalues["skin_tone"]
ci_lower_log = coef - 1.96 * se
ci_upper_log = coef + 1.96 * se
odds_ratio = np.exp(coef)
ci_lower = np.exp(ci_lower_log)
ci_upper = np.exp(ci_upper_log)

conclusion = "significant_effect" if p_value < 0.05 else "no_significant_effect"

# 5. Assemble output
output = {
    "effect_size": float(odds_ratio),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_value),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "logistic",
    "predictor_used": "average_skin_tone = (rater1 + rater2) / 2",
    "covariates_included": ["games", "yellowCards", "position", "leagueCountry"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "rows with missing rater1 or rater2 dropped (≈14.7%); missing position set to 'Missing' category"
}

print(json.dumps(output))