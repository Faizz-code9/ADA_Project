import pandas as pd
import numpy as np
import json
import warnings
import statsmodels.formula.api as smf
import statsmodels.api as sm

warnings.filterwarnings("ignore")

# 1. Load data
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_synthetic_confirmatory_T0.0_r2/data.csv"
df = pd.read_csv(FILE_PATH)

# 2. Missing data handling
missing_strategy = "mean_imputation"
if df["skin_tone"].isnull().any():
    df["skin_tone"] = df["skin_tone"].fillna(df["skin_tone"].mean())

exclusions = "none"

# 3. Model specification
# Categorical predictors: position, leagueCountry
# Continuous covariates: games, yellowCards, height, weight
formula = (
    "redCards ~ skin_tone + games + yellowCards + height + weight + "
    "C(position) + C(leagueCountry)"
)

# 4. Fit Poisson GLM with clustered robust SE (cluster by refereeID)
poisson_family = sm.families.Poisson()
model = smf.glm(formula=formula, data=df, family=poisson_family)
result = model.fit(cov_type="cluster", cov_kwds={"groups": df["refereeID"]})

# 5. Extract estimand for skin_tone
coef = result.params["skin_tone"]
se = result.bse["skin_tone"]
p_val = result.pvalues["skin_tone"]
ci_lower_log, ci_upper_log = result.conf_int().loc["skin_tone"]
irr = np.exp(coef)
ci_lower = np.exp(ci_lower_log)
ci_upper = np.exp(ci_upper_log)

# 6. Conclusion
conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

# 7. Output JSON
output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "skin_tone (continuous, 0=very light to 1=very dark)",
    "covariates_included": [
        "games",
        "yellowCards",
        "height",
        "weight",
        "position",
        "leagueCountry"
    ],
    "missing_data_strategy": missing_strategy,
    "clustering_strategy": "clustered_se",
    "exclusions_applied": exclusions
}

print(json.dumps(output))