import pandas as pd
import numpy as np
import statsmodels.api as sm
from scipy.stats import norm
import json

# ----------------------------------------------------------------------
# 1. Load data
# ----------------------------------------------------------------------
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_soccer_neutral_T1.0_r2/data.csv"
df = pd.read_csv(FILE_PATH)

# ----------------------------------------------------------------------
# 2. Prepare variables
# ----------------------------------------------------------------------
# Average skin tone from the two raters
df["avg_skin"] = df[["rater1", "rater2"]].mean(axis=1, skipna=True)

# Binary outcome: at least one red card from the referee
df["red"] = (df["redCards"] > 0).astype(int)

# Covariates we will adjust for
covariates = ["games", "position", "leagueCountry", "height", "weight"]

# Columns required for analysis (predictor, outcome, covariates, clustering id)
required_cols = ["avg_skin", "red"] + covariates + ["refNum"]
df_clean = df.dropna(subset=required_cols)

# ----------------------------------------------------------------------
# 3. Encode categorical variables (position, leagueCountry)
# ----------------------------------------------------------------------
df_enc = pd.get_dummies(df_clean, columns=["position", "leagueCountry"], drop_first=True)

# Keep only numeric columns for the model matrix
numeric_cols = df_enc.select_dtypes(include=[np.number]).columns.tolist()
# Ensure predictor and outcome are retained
numeric_cols = [c for c in numeric_cols if c not in ["red", "refNum"]]

X = df_enc[numeric_cols]
X = sm.add_constant(X, prepend=False)  # adds intercept as "const"
y = df_enc["red"]

# ----------------------------------------------------------------------
# 4. Fit logistic regression
# ----------------------------------------------------------------------
logit_model = sm.GLM(y, X, family=sm.families.Binomial())
logit_result = logit_model.fit()

# ----------------------------------------------------------------------
# 5. Clustered standard errors by referee (refNum)
# ----------------------------------------------------------------------
clustered = logit_result.get_robustcov_results(cov_type="cluster", groups=df_enc["refNum"])

# ----------------------------------------------------------------------
# 6. Extract estimand for avg_skin
# ----------------------------------------------------------------------
predictor = "avg_skin"
coef = clustered.params[predictor]
se = clustered.bse[predictor]
z = coef / se
p_val = 2 * (1 - norm.cdf(abs(z)))
ci_low = coef - 1.96 * se
ci_upp = coef + 1.96 * se

# Convert log-odds to odds ratio
or_est = np.exp(coef)
or_ci_low = np.exp(ci_low)
or_ci_upp = np.exp(ci_upp)

# ----------------------------------------------------------------------
# 7. Assemble output
# ----------------------------------------------------------------------
output = {
    "effect_size": float(or_est),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(or_ci_low),
    "ci_upper": float(or_ci_upp),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "logistic",
    "predictor_used": "average_skin_tone = mean(rater1, rater2)",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "rows with missing avg_skin, redCards, games, position, leagueCountry, height, weight removed"
}

print(json.dumps(output))