import pandas as pd
import numpy as np
import json
import sys
import statsmodels.api as sm

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gpt-oss-120b_disguise_confirmatory_T1.0_r2/data.csv"
df = pd.read_csv(file_path)

# 2. Prepare data
# Outcome: binary rejection flag
df["rejected"] = (df["loan_application_rejections"] > 0).astype(int)

# Predictor: average of alpha and beta scores
df["risk_score_avg"] = df[["risk_evaluator_alpha_score", "risk_evaluator_beta_score"]].mean(axis=1)

# Variables to include as covariates
covariate_cols = [
    "credit_score_index",
    "annual_income_bracket",
    "prior_approved_loans",
    "prior_conditional_loans",
    "prior_denied_loans",
    "employment_specialization"
]

# 2a. Missing data handling – listwise deletion
required_cols = ["rejected", "risk_score_avg"] + covariate_cols
df_clean = df[required_cols].dropna()

exclusions_desc = "rows with missing risk scores, outcome, or covariates removed"

# 2b. Encode categorical covariate
df_clean = pd.get_dummies(df_clean, columns=["employment_specialization"], drop_first=True)

# 3. Fit logistic regression (binary outcome)
y = df_clean["rejected"]
X = df_clean.drop(columns=["rejected"])
X = sm.add_constant(X, has_constant='add')
logit_model = sm.Logit(y, X)
result = logit_model.fit(disp=False)

# 4. Extract estimand
predictor_name = "risk_score_avg"
coef = result.params[predictor_name]
se_log = result.bse[predictor_name]
p_val = result.pvalues[predictor_name]

# Odds ratio and 95% CI
or_val = np.exp(coef)
ci_lower = np.exp(coef - 1.96 * se_log)
ci_upper = np.exp(coef + 1.96 * se_log)

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

# 5. Assemble JSON output
output = {
    "effect_size": float(or_val),
    "effect_type": "odds_ratio",
    "standard_error": float(se_log),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "logistic",
    "predictor_used": "average of risk_evaluator_alpha_score and risk_evaluator_beta_score",
    "covariates_included": [c for c in X.columns if c not in ["const", predictor_name]],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": exclusions_desc
}

print(json.dumps(output, ensure_ascii=False))