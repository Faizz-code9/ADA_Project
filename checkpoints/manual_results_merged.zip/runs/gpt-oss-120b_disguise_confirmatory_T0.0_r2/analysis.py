import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

# 1. Load data
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_disguise_confirmatory_T0.0_r2/data.csv"
df = pd.read_csv(FILE_PATH)

# 2. Construct predictor: average of the two risk scores
df["avg_risk_score"] = df[["risk_evaluator_alpha_score", "risk_evaluator_beta_score"]].mean(axis=1)

# Binary outcome: any rejection (0 vs >0)
df["rejection_flag"] = (df["loan_application_rejections"] > 0).astype(int)

# Covariates to adjust for (numeric columns)
covariates = [
    "credit_score_index",
    "annual_income_bracket",
    "prior_approved_loans",
    "prior_denied_loans",
    "elevated_risk_warnings",
    "formal_inquiry_notices",
    "regional_index_a",
    "regional_index_b",
]

# Keep only needed columns
cols_needed = ["avg_risk_score", "rejection_flag", "loan_officer_id"] + covariates
data = df[cols_needed].copy()

# 2b. Missing data strategy: listwise deletion
initial_rows = len(data)
data = data.dropna()
final_rows = len(data)
exclusions_desc = f"dropped {initial_rows - final_rows} rows with missing values"

# 3. Fit logistic regression with clustered standard errors by loan_officer_id
X = data[["avg_risk_score"] + covariates]
X = sm.add_constant(X, has_constant='add')
y = data["rejection_flag"]
clusters = data["loan_officer_id"]

glm_binom = sm.GLM(y, X, family=sm.families.Binomial())
result = glm_binom.fit(cov_type="cluster", cov_kwds={"groups": clusters})

# 4. Extract estimand for avg_risk_score
coef = result.params["avg_risk_score"]
se_log = result.bse["avg_risk_score"]
z_val = coef / se_log
p_value = 2 * (1 - sm.stats.norm.cdf(abs(z_val)))
odds_ratio = np.exp(coef)
ci_lower = np.exp(coef - 1.96 * se_log)
ci_upper = np.exp(coef + 1.96 * se_log)

conclusion = "significant_effect" if p_value < 0.05 else "no_significant_effect"

# 5. Prepare JSON output
output = {
    "effect_size": float(odds_ratio),
    "effect_type": "odds_ratio",
    "standard_error": float(se_log),
    "p_value": float(p_value),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "logistic",
    "predictor_used": "avg_risk_score",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": exclusions_desc
}

print(json.dumps(output))