import pandas as pd
import numpy as np
import statsmodels.api as sm
import json
from datetime import datetime

# ----------------------------------------------------------------------
# 1. Load data
# ----------------------------------------------------------------------
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_soccer_neutral_T0.7_r2/data.csv"
df = pd.read_csv(FILE_PATH)

# ----------------------------------------------------------------------
# 2. Cleaning / preparation
# ----------------------------------------------------------------------
missing_data_strategy = "listwise_deletion"

# Required columns for analysis
required_cols = ["rater1", "rater2", "redCards", "games",
                 "yellowCards", "position", "leagueCountry",
                 "birthday", "refNum"]
df = df.dropna(subset=required_cols)

# Continuous skin‑tone predictor (average of two raters)
df["skin_tone"] = df[["rater1", "rater2"]].mean(axis=1)

# Binary outcome: any red card from this referee?
df["red_card_any"] = (df["redCards"] > 0).astype(int)

# Compute player age as of 1 July 2012
def parse_bday(b):
    try:
        return datetime.strptime(b, "%d.%m.%Y")
    except Exception:
        return pd.NaT

df["birth_date"] = df["birthday"].apply(parse_bday)
ref_date = datetime(2012, 7, 1)
df["age"] = (ref_date - df["birth_date"]).dt.days / 365.25
df = df.dropna(subset=["age"])

# Categorical covariates – one‑hot encode (drop first to avoid collinearity)
df["position"] = df["position"].astype(str)
df["leagueCountry"] = df["leagueCountry"].astype(str)

position_dummies = pd.get_dummies(df["position"], prefix="pos", drop_first=True)
league_dummies = pd.get_dummies(df["leagueCountry"], prefix="lg", drop_first=True)

# Assemble design matrix
covariate_cols = ["skin_tone", "games", "yellowCards", "age"]
X = df[covariate_cols].join(position_dummies).join(league_dummies)
X = sm.add_constant(X, has_constant='add')
y = df["red_card_any"]

# ----------------------------------------------------------------------
# 3. Fit logistic regression with clustered SE by referee
# ----------------------------------------------------------------------
glm_bin = sm.GLM(y, X, family=sm.families.Binomial())
result = glm_bin.fit(cov_type="cluster", cov_kwds={"groups": df["refNum"]})

# ----------------------------------------------------------------------
# 4. Extract primary estimand (odds ratio for skin tone)
# ----------------------------------------------------------------------
coef = result.params["skin_tone"]
se = result.bse["skin_tone"]
p_val = result.pvalues["skin_tone"]
ci_lower_log, ci_upper_log = result.conf_int().loc["skin_tone"]

or_est = np.exp(coef)
ci_lower = np.exp(ci_lower_log)
ci_upper = np.exp(ci_upper_log)

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

# ----------------------------------------------------------------------
# 5. JSON output
# ----------------------------------------------------------------------
output = {
    "effect_size": float(or_est),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "logistic",
    "predictor_used": "average_skin_tone = (rater1 + rater2)/2",
    "covariates_included": (
        ["games", "yellowCards", "age"] +
        list(position_dummies.columns) +
        list(league_dummies.columns)
    ),
    "missing_data_strategy": missing_data_strategy,
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "rows with missing rater1/rater2, position, birthday, or age removed"
}

print(json.dumps(output, ensure_ascii=False))