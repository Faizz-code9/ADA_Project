import pandas as pd
import numpy as np
import statsmodels.api as sm
import json
import sys

# 1. Load data
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_synthetic_neutral_T1.0_r2/data.csv"
df = pd.read_csv(FILE_PATH)

# 2. Missing data handling
missing_strategy = "mean_imputation"
if df["skin_tone"].isnull().any():
    mean_skin = df["skin_tone"].mean()
    df["skin_tone"] = df["skin_tone"].fillna(mean_skin)

# No other missingness reported, so no further imputation

# 3. Define outcome and predictors
y = df["redCards"]

# Build design matrix
# Categorical variables to dummies (drop first to avoid collinearity)
cat_vars = ["position", "leagueCountry"]
df_dummies = pd.get_dummies(df[cat_vars], drop_first=True)

# Continuous covariates
cont_vars = ["height", "weight", "games", "yellowCards", "skin_tone"]
X = pd.concat([df[cont_vars], df_dummies], axis=1)

# Add intercept
X = sm.add_constant(X, has_constant='add')

# 4. Fit Poisson regression with clustered SE by refereeID
cluster_var = df["refereeID"]
model = sm.GLM(y, X, family=sm.families.Poisson())
results = model.fit(cov_type="cluster", cov_kwds={"groups": cluster_var})

# Extract estimand for skin_tone
beta = results.params["skin_tone"]
se_log = results.bse["skin_tone"]
p_val = results.pvalues["skin_tone"]

# Effect size (IRR) and its SE via delta method
irr = np.exp(beta)
se_irr = irr * se_log  # delta method

# 95% CI for IRR
z = 1.96
ci_lower = np.exp(beta - z * se_log)
ci_upper = np.exp(beta + z * se_log)

# Conclusion
conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

# Prepare output JSON
output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se_irr),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "skin_tone",
    "covariates_included": ["height", "weight", "games", "yellowCards"] + list(df_dummies.columns),
    "missing_data_strategy": missing_strategy,
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "none"
}

print(json.dumps(output))