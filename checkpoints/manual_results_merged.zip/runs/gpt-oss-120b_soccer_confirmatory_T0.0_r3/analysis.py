import pandas as pd
import numpy as np
import json
from scipy.stats import norm
import statsmodels.formula.api as smf

# 1. Load data
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_soccer_confirmatory_T0.0_r3/data.csv"
df = pd.read_csv(FILE_PATH)

# 2. Clean / prepare ---------------------------------------------------------
# Exclude rows missing skin‑tone ratings
exclusions = "rows with missing rater1 or rater2 removed"
df = df.dropna(subset=["rater1", "rater2"])

# Continuous skin‑tone predictor (average of two raters)
df["skin_tone"] = df[["rater1", "rater2"]].mean(axis=1)

# Binary outcome: any red card from this referee?
df["red_any"] = (df["redCards"] > 0).astype(int)

# Approximate age in 2013 season from birthday
def parse_birth(b):
    try:
        return pd.to_datetime(b, dayfirst=True, errors='coerce')
    except Exception:
        return pd.NaT
df["birth_date"] = df["birthday"].apply(parse_birth)
df["age"] = 2013 - df["birth_date"].dt.year
median_age = df["age"].median()
df["age"] = df["age"].fillna(median_age)

# Fill missing categorical covariates
df["position"] = df["position"].fillna("Missing")
df["leagueCountry"] = df["leagueCountry"].fillna("Missing")

# Covariates to adjust for
covariates = ["games", "yellowCards", "age", "C(position)", "C(leagueCountry)"]

# 3. Fit logistic regression with clustered SEs on referee (refNum) ----------
formula = "red_any ~ skin_tone + " + " + ".join(covariates)
logit_mod = smf.logit(formula=formula, data=df)
result = logit_mod.fit(disp=0, cov_type="cluster", cov_kwds={"groups": df["refNum"]})

# 4. Primary estimand (odds ratio for a full 0→1 change in skin tone) -------
coef = result.params["skin_tone"]
se = result.bse["skin_tone"]
z = coef / se
p_val = 2 * (1 - norm.cdf(abs(z)))
or_est = np.exp(coef)
ci_lower = np.exp(coef - 1.96 * se)
ci_upper = np.exp(coef + 1.96 * se)

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

# 5. JSON output -------------------------------------------------------------
output = {
    "effect_size": float(or_est),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "logistic",
    "predictor_used": "average_skin_tone = (rater1 + rater2)/2",
    "covariates_included": ["games", "yellowCards", "age", "position", "leagueCountry"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": exclusions
}

print(json.dumps(output))