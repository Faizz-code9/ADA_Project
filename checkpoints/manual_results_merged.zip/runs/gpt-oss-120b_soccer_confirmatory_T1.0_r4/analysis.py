import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gpt-oss-120b_soccer_confirmatory_T1.0_r4/data.csv"
df = pd.read_csv(file_path)

# 2. Prepare data
# Continuous skin tone predictor: average of the two raters
df["skin_tone"] = df[["rater1", "rater2"]].mean(axis=1)

# Outcome: count of red cards (already integer, many zeros)
# Keep only rows with non‑missing skin tone and essential covariates
covariates = ["games", "yellowCards", "height", "weight"]
needed = ["skin_tone", "redCards", "refNum"] + covariates
df_sub = df[needed].copy()

# Record exclusions
exclusions = []
initial_n = len(df_sub)
df_sub = df_sub.dropna()
exclusions.append(f"dropped {initial_n - len(df_sub)} rows with missing values")

# Remove columns with zero variance (can cause singular matrix)
for col in covariates:
    if df_sub[col].nunique() <= 1:
        df_sub = df_sub.drop(columns=col)
        covariates.remove(col)

# Design matrix
X = df_sub[["skin_tone"] + covariates]
X = sm.add_constant(X, has_constant='add')
y = df_sub["redCards"]
clusters = df_sub["refNum"]

# 3. Fit Poisson GLM with clustered robust SE
glm = sm.GLM(y, X, family=sm.families.Poisson())
result = glm.fit(cov_type="cluster", cov_kwds={"groups": clusters})

# 4. Extract estimand (incidence rate ratio for full 0→1 change in skin tone)
coef = result.params["skin_tone"]
se = result.bse["skin_tone"]
irr = np.exp(coef)
ci_lower = np.exp(coef - 1.96 * se)
ci_upper = np.exp(coef + 1.96 * se)
z = coef / se
p_value = 2 * (1 - sm.stats.norm.cdf(abs(z)))

# 5. Assemble JSON output
output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_value),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if p_value < 0.05 else "no_significant_effect",
    "model_family": "poisson",
    "predictor_used": "average_skin_tone = (rater1 + rater2)/2",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "; ".join(exclusions) if exclusions else "none"
}

print(json.dumps(output, ensure_ascii=False))