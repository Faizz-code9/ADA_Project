import pandas as pd
import numpy as np
import statsmodels.api as sm
from scipy.stats import norm
import json

# 1. Load data
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_disguise_neutral_T0.7_r2/data.csv"
df = pd.read_csv(FILE_PATH)

# 2. Prepare data
# Binary outcome: any rejection (1) vs none (0)
df["rejection_binary"] = (df["loan_application_rejections"] > 0).astype(int)

# Main predictor: average of the two risk evaluator scores
df["average_risk_score"] = df[["risk_evaluator_alpha_score", "risk_evaluator_beta_score"]].mean(axis=1)

# Covariates to adjust for (numeric, low missingness)
covariates = [
    "credit_score_index",
    "annual_income_bracket",
    "prior_approved_loans",
    "prior_denied_loans",
    "repayment_performance_score",
    "elevated_risk_warnings",
    "regional_index_a",
    "regional_index_b",
]

# Keep rows with complete data for outcome, predictor, covariates, and clustering id
required = ["rejection_binary", "average_risk_score", "loan_officer_id"] + covariates
df_clean = df.dropna(subset=required)

# 3. Fit logistic regression
X = df_clean[["average_risk_score"] + covariates]
X = sm.add_constant(X, has_constant='add')
y = df_clean["rejection_binary"]

logit = sm.Logit(y, X)
result = logit.fit(disp=0)

# Cluster-robust covariance matrix by loan_officer_id
cluster_ids = df_clean["loan_officer_id"]
cov_cluster = sm.stats.sandwich_covariance.cov_cluster(result, cluster_ids)
se_cluster = np.sqrt(np.diag(cov_cluster))

# Extract coefficient, SE, and compute statistics for the main predictor
coef = result.params["average_risk_score"]
se = se_cluster[result.params.index.get_loc("average_risk_score")]
z = coef / se
p_value = 2 * (1 - norm.cdf(abs(z)))

# Odds ratio and 95% CI
odds_ratio = np.exp(coef)
ci_lower = np.exp(coef - 1.96 * se)
ci_upper = np.exp(coef + 1.96 * se)

# 4. Output JSON
output = {
    "effect_size": float(odds_ratio),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_value),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if p_value < 0.05 else "no_significant_effect",
    "model_family": "logistic",
    "predictor_used": "average_risk_score",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "rows with missing outcome, predictor, covariates, or loan_officer_id removed"
}

print(json.dumps(output))