import pandas as pd
import numpy as np
import json
import statsmodels.api as sm
from datetime import datetime
from scipy.stats import norm

# ----------------------------------------------------------------------
# 1. Load data
# ----------------------------------------------------------------------
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_soccer_neutral_T0.0_r2/data.csv"
df = pd.read_csv(FILE_PATH)

# ----------------------------------------------------------------------
# 2. Cleaning & preparation
# ----------------------------------------------------------------------
# Drop rows missing essential variables for the primary analysis
df = df.dropna(subset=["rater1", "rater2", "redCards", "refNum", "birthday"])

# Build continuous skin‑tone predictor (average of two raters)
df["avg_skin_tone"] = df[["rater1", "rater2"]].mean(axis=1)

# Binary outcome: any red card from that referee?
df["red_any"] = (df["redCards"] > 0).astype(int)

# Derive approximate age (season 2013, reference date 30 June 2013)
def parse_age(bday):
    try:
        d = datetime.strptime(bday, "%d.%m.%Y")
        # Age at 30 June 2013
        age = 2013 - d.year - ((d.month, d.day) > (6, 30))
        return age
    except Exception:
        return np.nan

df["age"] = df["birthday"].apply(parse_age)

# Drop rows where age could not be parsed
df = df.dropna(subset=["age"])

# ----------------------------------------------------------------------
# 3. Covariates
# ----------------------------------------------------------------------
# Numeric covariates we want to adjust for
numeric_covs = ["games", "yellowCards", "height", "weight", "age"]

# Impute missing numeric covariates with column means (mean_imputation)
for col in numeric_covs:
    if col in df.columns:
        mean_val = df[col].mean()
        df[col] = df[col].fillna(mean_val)

# Categorical covariates to be one‑hot encoded
cat_cols = ["position", "leagueCountry"]
df = pd.get_dummies(df, columns=cat_cols, drop_first=True)

# Assemble design matrix
predictor = "avg_skin_tone"
X_cols = [predictor] + numeric_covs + \
         [c for c in df.columns if c.startswith("position_") or c.startswith("leagueCountry_")]
X = df[X_cols]
X = sm.add_constant(X, has_constant='add')
y = df["red_any"]

# Ensure no remaining NaNs or infinite values
X = X.replace([np.inf, -np.inf], np.nan).fillna(0)

# ----------------------------------------------------------------------
# 4. Model fitting (logistic regression with clustered SE by referee)
# ----------------------------------------------------------------------
logit_model = sm.Logit(y, X)
result = logit_model.fit(disp=0, cov_type='cluster', cov_kwds={'groups': df["refNum"]})

# ----------------------------------------------------------------------
# 5. Primary estimand extraction (odds ratio for a full 0→1 change in skin tone)
# ----------------------------------------------------------------------
coef = result.params[predictor]
se = result.bse[predictor]
z = coef / se
p_value = 2 * (1 - norm.cdf(abs(z)))

# 95% CI on log‑odds, then exponentiate to odds ratio scale
ci_log_lower, ci_log_upper = result.conf_int().loc[predictor]
ci_lower = np.exp(ci_log_lower)
ci_upper = np.exp(ci_log_upper)
odds_ratio = np.exp(coef)

# ----------------------------------------------------------------------
# 6. JSON output
# ----------------------------------------------------------------------
output = {
    "effect_size": float(odds_ratio),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_value),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if p_value < 0.05 else "no_significant_effect",
    "model_family": "logistic",
    "predictor_used": predictor,
    "covariates_included": numeric_covs + 
        [c for c in df.columns if c.startswith("position_") or c.startswith("leagueCountry_")],
    "missing_data_strategy": "mean_imputation",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "rows with missing rater1/rater2, redCards, refNum, birthday, or unparsable age removed"
}

print(json.dumps(output, ensure_ascii=False))