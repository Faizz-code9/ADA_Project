import pandas as pd
import numpy as np
import json
import statsmodels.api as sm
from scipy.stats import norm

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gpt-oss-120b_placebo_skeptical_T0.7_r2/data.csv"
df = pd.read_csv(file_path)

# 2. Clean & prepare
# Average skin‑tone rating
df["skin_tone"] = df[["rater1", "rater2"]].mean(axis=1)

# Binary outcome: any red card vs none
df["red_any"] = (df["redCards"] > 0).astype(int)

# Covariates (chosen for low missingness & relevance)
covariates = ["games", "yellowCards", "position", "leagueCountry"]

# Drop rows with missing values in any required column
cols_needed = ["skin_tone", "red_any"] + covariates + ["refNum"]
df_clean = df.dropna(subset=cols_needed)

# Encode categoricals
df_enc = pd.get_dummies(df_clean[covariates], drop_first=True)

# Design matrix
X = pd.concat([df_clean["skin_tone"], df_enc], axis=1)
X = sm.add_constant(X, has_constant='add')
y = df_clean["red_any"]

# 3. Fit logistic regression (GLM) with clustered robust SE by referee (refNum)
glm_mod = sm.GLM(y, X, family=sm.families.Binomial())
glm_res = glm_mod.fit()

# Clustered covariance matrix
cluster_groups = df_clean["refNum"]
cov_cluster = sm.stats.sandwich_covariance.cov_cluster(glm_res, cluster_groups)
# Replace covariance matrix with clustered version
glm_res_clustered = glm_res.get_robustcov_results(cov_type='custom', cov=cov_cluster)

# 4. Primary estimand: odds ratio for full 0→1 change in skin_tone
coef = glm_res_clustered.params["skin_tone"]
se = glm_res_clustered.bse["skin_tone"]
z = coef / se
p_value = 2 * (1 - norm.cdf(abs(z)))
ci_low_log = coef - 1.96 * se
ci_upp_log = coef + 1.96 * se
odds_ratio = np.exp(coef)
ci_low = np.exp(ci_low_log)
ci_upp = np.exp(ci_upp_log)

# 5. JSON output
output = {
    "effect_size": float(odds_ratio),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_value),
    "ci_lower": float(ci_low),
    "ci_upper": float(ci_upp),
    "conclusion": "significant_effect" if p_value < 0.05 else "no_significant_effect",
    "model_family": "logistic",
    "predictor_used": "average of rater1 and rater2 (skin_tone)",
    "covariates_included": list(df_enc.columns),
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "rows with missing skin_tone, games, yellowCards, position, leagueCountry removed"
}

print(json.dumps(output, ensure_ascii=False))