import pandas as pd
import numpy as np
import json
import statsmodels.api as sm

# ----------------------------------------------------------------------
# 1. Load data
# ----------------------------------------------------------------------
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_placebo_neutral_T1.0_r1/data.csv"
df = pd.read_csv(FILE_PATH)

# ----------------------------------------------------------------------
# 2. Data cleaning & variable construction
# ----------------------------------------------------------------------
# Average skin‑tone rating
df["skin_tone"] = df[["rater1", "rater2"]].mean(axis=1)

# Binary outcome: at least one red card from the referee
df["red_flag"] = (df["redCards"] > 0).astype(int)

# Columns we will treat as covariates (numeric or categorical that we will dummy)
covariates = [
    "games",
    "yellowCards",
    "height",
    "weight",
    "leagueCountry",
    "position"
]

# Essential columns for analysis
essential_cols = ["skin_tone", "red_flag"] + covariates
mask = df[essential_cols].notnull().all(axis=1)
exclusions_desc = f"Dropped {(~mask).sum()} rows with missing essential data"
df_clean = df.loc[mask].copy()

# Dummy‑code categorical covariates, drop first level to avoid collinearity
df_clean = pd.get_dummies(df_clean, columns=["leagueCountry", "position"], drop_first=True)

# ----------------------------------------------------------------------
# 3. Build design matrix (numeric only)
# ----------------------------------------------------------------------
# Keep only numeric columns
numeric_df = df_clean.select_dtypes(include=[np.number])

# Remove outcome and other non‑predictor numeric columns
predictor_cols = [c for c in numeric_df.columns if c not in ["red_flag", "redCards", "rater1", "rater2", "refNum"]]

# Ensure skin_tone is first for easy reference
predictor_cols = ["skin_tone"] + [c for c in predictor_cols if c != "skin_tone"]

X = numeric_df[predictor_cols]
X = sm.add_constant(X, has_constant='add')
y = numeric_df["red_flag"]

# ----------------------------------------------------------------------
# 4. Fit logistic regression with clustered robust SE (by referee)
# ----------------------------------------------------------------------
logit_model = sm.Logit(y, X)
logit_res = logit_model.fit(disp=0)

# Clustered covariance (referee identifier)
cluster_ids = df_clean["refNum"]
robust_res = logit_res.get_robustcov_results(cov_type="cluster", groups=cluster_ids)

# ----------------------------------------------------------------------
# 5. Extract primary estimand (skin_tone) as odds ratio
# ----------------------------------------------------------------------
coef = robust_res.params["skin_tone"]
se = robust_res.bse["skin_tone"]
p_val = robust_res.pvalues["skin_tone"]
ci_log = robust_res.conf_int().loc["skin_tone"]
ci_lower = np.exp(ci_log[0])
ci_upper = np.exp(ci_log[1])
odds_ratio = np.exp(coef)

# ----------------------------------------------------------------------
# 6. Assemble JSON output
# ----------------------------------------------------------------------
output = {
    "effect_size": float(odds_ratio),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "logistic",
    "predictor_used": "average of rater1 and rater2 (skin_tone)",
    "covariates_included": [c for c in X.columns if c not in ["const", "skin_tone"]],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": exclusions_desc
}

print(json.dumps(output))