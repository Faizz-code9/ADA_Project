import pandas as pd
import numpy as np
import json
import statsmodels.api as sm
import statsmodels.formula.api as smf
from scipy.stats import norm

# 1. Load data
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_synthetic_skeptical_T1.0_r2/data.csv"
df = pd.read_csv(FILE_PATH)

# 2. Missing data handling
missing_strategy = "mean_imputation"
if df["skin_tone"].isnull().any():
    mean_skin = df["skin_tone"].mean()
    df["skin_tone"] = df["skin_tone"].fillna(mean_skin)

# Ensure required columns are present and drop rows with missing outcome/predictor
df = df.dropna(subset=["redCards", "skin_tone"])
exclusions = "listwise deletion of rows with missing skin_tone"

# 3. Model specification
# Use GEE with Poisson family to obtain an incidence rate ratio (IRR)
# Cluster by refereeID to account for multiple observations per referee
formula = ("redCards ~ skin_tone + games + yellowCards + height + weight + "
           "C(position) + C(leagueCountry)")

gee_model = smf.gee(
    formula,
    groups=df["refereeID"],
    data=df,
    family=sm.families.Poisson(),
    cov_struct=sm.cov_struct.Exchangeable()
)
result = gee_model.fit()

# 4. Extract estimand for skin_tone
coef = result.params["skin_tone"]                # log(IRR)
se_log = result.bse["skin_tone"]                # SE of log(IRR)
z = coef / se_log
p_value = 2 * (1 - norm.cdf(abs(z)))

# Convert to IRR
effect_size = np.exp(coef)                      # IRR
se_effect = effect_size * se_log                # delta method SE for IRR
ci_lower = np.exp(coef - 1.96 * se_log)         # 95% CI lower bound (IRR)
ci_upper = np.exp(coef + 1.96 * se_log)         # 95% CI upper bound (IRR)

# 5. Significance decision
conclusion = "significant_effect" if p_value < 0.05 else "no_significant_effect"

# 6. Prepare output JSON
output = {
    "effect_size": float(effect_size),
    "effect_type": "irr",
    "standard_error": float(se_effect),
    "p_value": float(p_value),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "gee",
    "predictor_used": "skin_tone (continuous)",
    "covariates_included": [
        "games",
        "yellowCards",
        "height",
        "weight",
        "position",
        "leagueCountry"
    ],
    "missing_data_strategy": missing_strategy,
    "clustering_strategy": "gee",
    "exclusions_applied": exclusions
}

print(json.dumps(output))