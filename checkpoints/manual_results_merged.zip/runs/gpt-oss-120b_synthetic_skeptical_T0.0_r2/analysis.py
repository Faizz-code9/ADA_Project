import pandas as pd
import numpy as np
import json
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gpt-oss-120b_synthetic_skeptical_T0.0_r2/data.csv"
df = pd.read_csv(file_path)

# 2. Cleaning / preparation
missing_before = df['skin_tone'].isna().sum()
df = df.dropna(subset=['skin_tone'])
missing_data_strategy = "listwise_deletion"

# Ensure integer type for count outcome
df['redCards'] = df['redCards'].astype(int)

# 3. Model: Poisson GLM with clustered SE by refereeID
formula = (
    "redCards ~ skin_tone + games + yellowCards + height + weight + "
    "C(position) + C(leagueCountry)"
)

# Fit with clustered robust covariance
if 'refereeID' in df.columns:
    result = smf.glm(formula=formula, data=df, family=sm.families.Poisson()).fit(
        cov_type='cluster',
        cov_kwds={'groups': df['refereeID']}
    )
    clustering_strategy = "clustered_se"
else:
    result = smf.glm(formula=formula, data=df, family=sm.families.Poisson()).fit()
    clustering_strategy = "none"

# 4. Primary estimand: incidence rate ratio (IRR) for skin_tone
coef = result.params['skin_tone']
se = result.bse['skin_tone']
p_val = result.pvalues['skin_tone']
ci_lower_coef, ci_upper_coef = result.conf_int().loc['skin_tone']

effect_size = np.exp(coef)            # IRR
ci_lower = np.exp(ci_lower_coef)
ci_upper = np.exp(ci_upper_coef)

# 5. Conclusion
alpha = 0.05
conclusion = "significant_effect" if p_val < alpha else "no_significant_effect"

# Covariates (excluding main predictor)
covariates = [
    "games",
    "yellowCards",
    "height",
    "weight",
    "position",
    "leagueCountry"
]

# Exclusions description
exclusions_applied = (
    f"dropped {missing_before} rows with missing skin_tone"
    if missing_before > 0 else "none"
)

# 6. Output JSON
output = {
    "effect_size": float(effect_size),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "skin_tone",
    "covariates_included": covariates,
    "missing_data_strategy": missing_data_strategy,
    "clustering_strategy": clustering_strategy,
    "exclusions_applied": exclusions_applied
}

print(json.dumps(output))