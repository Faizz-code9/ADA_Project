import pandas as pd
import numpy as np
import json
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gpt-oss-120b_synthetic_neutral_T1.0_r1/data.csv"
df = pd.read_csv(file_path)

# 2. Missing data handling (mean imputation for skin_tone)
missing_strategy = "mean_imputation"
if df["skin_tone"].isnull().any():
    mean_tone = df["skin_tone"].mean()
    df["skin_tone"] = df["skin_tone"].fillna(mean_tone)

# No rows excluded based on other criteria
exclusions = "none"

# 3. Prepare design matrix
# Categorical variables: position, leagueCountry, refereeID (for clustering only)
categorical_vars = ["position", "leagueCountry"]
df = pd.get_dummies(df, columns=categorical_vars, drop_first=True)

# Define outcome and exposure
y = df["redCards"]
# Use log(games) as offset to model rate per game
offset = np.log(df["games"].replace(0, np.nan)).fillna(0)  # guard against zero games

# Main predictor and covariates
predictor = "skin_tone"
covariates = ["skin_tone", "height", "weight", "yellowCards"] + \
            [col for col in df.columns if col.startswith("position_") or col.startswith("leagueCountry_")]

X = df[covariates]
X = sm.add_constant(X, prepend=False)  # statsmodels adds constant automatically if needed

# 4. Fit Poisson GLM with clustered robust SE by refereeID
model = sm.GLM(y, X, family=sm.families.Poisson(), offset=offset)
result = model.fit(cov_type="cluster", cov_kwds={"groups": df["refereeID"]})

# Extract estimand for skin_tone
coef = result.params[predictor]
se = result.bse[predictor]
z = result.tvalues[predictor]
p_value = result.pvalues[predictor]

# IRR and CI on IRR scale
irr = np.exp(coef)
ci_lower = np.exp(coef - 1.96 * se)
ci_upper = np.exp(coef + 1.96 * se)

conclusion = "significant_effect" if p_value < 0.05 else "no_significant_effect"

output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_value),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": predictor,
    "covariates_included": covariates,
    "missing_data_strategy": missing_strategy,
    "clustering_strategy": "clustered_se",
    "exclusions_applied": exclusions
}

print(json.dumps(output))