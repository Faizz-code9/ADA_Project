import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

# 1. Load data
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_soccer_skeptical_T1.0_r4/data.csv"
df = pd.read_csv(FILE_PATH)

# 2. Prepare data
# Continuous skin‑tone predictor: average of the two raters
df["skin_tone"] = df[["rater1", "rater2"]].mean(axis=1)

# Binary outcome: did the player receive any red card from this referee?
df["red_card_any"] = (df["redCards"] > 0).astype(int)

# Covariates to adjust for (chosen a small set to avoid over‑fitting)
covariates = ["games", "yellowCards", "height", "weight"]
cols_needed = ["skin_tone", "red_card_any", "refNum"] + covariates
df_clean = df[cols_needed].copy()

# Missing‑value handling: listwise deletion
exclusions_applied = "rows with missing skin tone or covariates removed"
df_clean = df_clean.dropna()

# 3. Fit logistic regression with clustered (by referee) robust SEs
y = df_clean["red_card_any"]
X = df_clean[["skin_tone"] + covariates]
X = sm.add_constant(X, prepend=False)          # adds intercept as the last column
cluster_groups = df_clean["refNum"]

logit_model = sm.Logit(y, X)
result = logit_model.fit(disp=0, cov_type="cluster", cov_kwds={"groups": cluster_groups})

# 4. Extract primary estimand (odds ratio for a full 0→1 change in skin tone)
beta = result.params["skin_tone"]
se = result.bse["skin_tone"]
z = beta / se
p_value = 2 * (1 - sm.stats.norm.cdf(abs(z)))
ci_low_log = beta - 1.96 * se
ci_upp_log = beta + 1.96 * se
or_est = np.exp(beta)
ci_low = np.exp(ci_low_log)
ci_upp = np.exp(ci_upp_log)

# 5. Assemble JSON output
output = {
    "effect_size": float(or_est),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_value),
    "ci_lower": float(ci_low),
    "ci_upper": float(ci_upp),
    "conclusion": "significant_effect" if p_value < 0.05 else "no_significant_effect",
    "model_family": "logistic",
    "predictor_used": "average_skin_tone = (rater1 + rater2) / 2",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": exclusions_applied
}

print(json.dumps(output))