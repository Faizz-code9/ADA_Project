import pandas as pd
import numpy as np
import json
import statsmodels.formula.api as smf
import statsmodels.api as sm

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gpt-oss-120b_soccer_confirmatory_T0.0_r2/data.csv"
df = pd.read_csv(file_path)

# 2. Clean / prepare ---------------------------------------------------------
# Exclude rows missing skin‑tone ratings
exclusions = "rows with missing rater1 or rater2 removed"
df = df.dropna(subset=["rater1", "rater2", "redCards"]).copy()

# Continuous skin‑tone predictor (average of two raters)
df["avg_skin"] = (df["rater1"] + df["rater2"]) / 2.0

# Approximate age from birthday (year 2013 season)
df["birthday_dt"] = pd.to_datetime(df["birthday"], format="%d.%m.%Y", errors="coerce", dayfirst=True)
df["age"] = 2013 - df["birthday_dt"].dt.year
median_age = df["age"].median()
df["age"] = df["age"].fillna(median_age)

# Impute missing numeric covariates with mean (mean_imputation)
numeric_cols = ["height", "weight", "games", "age"]
for col in numeric_cols:
    df[col] = df[col].fillna(df[col].mean())

# Fill missing categoricals with a placeholder
df["position"] = df["position"].fillna("Unknown")
df["leagueCountry"] = df["leagueCountry"].fillna("Unknown")

# 3. Model specification ----------------------------------------------------
predictor = "avg_skin"
covariates = ["games", "height", "weight", "age", "C(position)", "C(leagueCountry)"]
formula = f"redCards ~ {predictor} + " + " + ".join(covariates)

# Fit Poisson GLM with clustered robust SE by referee (refNum)
model = smf.glm(formula=formula, data=df, family=sm.families.Poisson())
result = model.fit(cov_type="cluster", cov_kwds={"groups": df["refNum"]})

# 4. Primary estimand (Incidence Rate Ratio) ---------------------------------
coef = result.params[predictor]
se = result.bse[predictor]
p_val = result.pvalues[predictor]
ci_log = result.conf_int().loc[predictor]
irr = np.exp(coef)
ci_lower = np.exp(ci_log[0])
ci_upper = np.exp(ci_log[1])

# 5. Assemble JSON output ----------------------------------------------------
output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "poisson",
    "predictor_used": "average_skin_tone = (rater1 + rater2)/2",
    "covariates_included": ["games", "height", "weight", "age", "position", "leagueCountry"],
    "missing_data_strategy": "mean_imputation",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": exclusions
}

print(json.dumps(output, ensure_ascii=False))