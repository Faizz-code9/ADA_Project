import pandas as pd
import numpy as np
import json
import sys
import statsmodels.api as sm

# 1. Load data
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_disguise_neutral_T0.7_r1/data.csv"
df = pd.read_csv(FILE_PATH)

# 2. Data cleaning / preparation
# Create continuous predictor as the average of alpha and beta scores
df["risk_score_avg"] = df[["risk_evaluator_alpha_score", "risk_evaluator_beta_score"]].mean(axis=1)

# Outcome: binary rejection (any rejection vs none)
df["rejection_binary"] = (df["loan_application_rejections"] > 0).astype(int)

# Select covariates (numeric, relatively complete)
covariates = [
    "credit_score_index",
    "annual_income_bracket",
    "prior_approved_loans",
    "prior_denied_loans",
    "formal_inquiry_notices",
    "elevated_risk_warnings",
    "regional_index_a",
    "regional_index_b"
]

# Columns needed for the analysis
required_cols = ["risk_score_avg", "rejection_binary"] + covariates
df_model = df[required_cols].copy()

# Missing data strategy: listwise deletion
initial_n = len(df_model)
df_model.dropna(inplace=True)
final_n = len(df_model)
exclusions_desc = f"dropped {initial_n - final_n} rows with missing predictor, outcome or covariates"

# 3. Fit logistic regression
X = df_model[["risk_score_avg"] + covariates]
X = sm.add_constant(X)  # intercept
y = df_model["rejection_binary"]

logit_model = sm.Logit(y, X)
result = logit_model.fit(disp=0)

# 4. Compute primary estimand (odds ratio for risk_score_avg)
coef = result.params["risk_score_avg"]
se = result.bse["risk_score_avg"]
p_val = result.pvalues["risk_score_avg"]
ci_low, ci_upp = result.conf_int().loc["risk_score_avg"]

odds_ratio = np.exp(coef)
ci_lower = np.exp(ci_low)
ci_upper = np.exp(ci_upp)

# Determine significance
conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

# 5. Assemble output JSON
output = {
    "effect_size": float(odds_ratio),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "logistic",
    "predictor_used": "risk_score_avg (average of risk_evaluator_alpha_score & risk_evaluator_beta_score)",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": exclusions_desc
}

print(json.dumps(output, ensure_ascii=False))