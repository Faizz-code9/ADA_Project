import pandas as pd
import numpy as np
import json
import statsmodels.api as sm
from scipy.stats import norm

# 1. Load data
FILE_PATH = "/kaggle/working/outputs/runs/gpt-oss-120b_disguise_skeptical_T0.7_r1/data.csv"
df = pd.read_csv(FILE_PATH)

# 2. Outcome: any rejection (binary)
df["rejection_flag"] = (df["loan_application_rejections"] > 0).astype(int)

# 3. Predictor: average of alpha and beta scores (continuous 0‑1)
df["risk_score_avg"] = df[["risk_evaluator_alpha_score", "risk_evaluator_beta_score"]].mean(axis=1)

# 4. Covariates (continuous)
covariate_cols = [
    "credit_score_index",
    "annual_income_bracket",
    "prior_approved_loans",
    "prior_conditional_loans",
    "prior_denied_loans",
    "repayment_performance_score",
    "formal_inquiry_notices",
    "elevated_risk_warnings",
    "total_applications_reviewed",
    "regional_index_a",
    "regional_index_b"
]

# 5. Categorical covariate: employment_specialization (handle missing)
df["employment_specialization"] = df["employment_specialization"].fillna("MISSING")
emp_dummies = pd.get_dummies(df["employment_specialization"], prefix="emp", drop_first=True)

# 6. Assemble modeling dataframe
model_df = pd.concat(
    [df[["rejection_flag", "risk_score_avg", "loan_officer_id"] + covariate_cols], emp_dummies],
    axis=1
)

# 7. Missing data strategy: listwise deletion
model_df = model_df.dropna()

# 8. Design matrices
y = model_df["rejection_flag"]
X = model_df.drop(columns=["rejection_flag", "loan_officer_id"])
X = sm.add_constant(X, has_constant='add')

# 9. Fit logistic regression with clustered robust SE (by loan_officer_id)
clusters = model_df["loan_officer_id"]
logit_res = sm.Logit(y, X).fit(disp=False, cov_type="cluster", cov_kwds={"groups": clusters})

# 10. Extract estimator for risk_score_avg
coef = logit_res.params["risk_score_avg"]
se = logit_res.bse["risk_score_avg"]
z = coef / se
p_value = 2 * (1 - norm.cdf(abs(z)))
ci_lower_log = coef - 1.96 * se
ci_upper_log = coef + 1.96 * se
odds_ratio = np.exp(coef)
ci_lower = np.exp(ci_lower_log)
ci_upper = np.exp(ci_upper_log)

# 11. JSON output
output = {
    "effect_size": float(odds_ratio),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_value),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if p_value < 0.05 else "no_significant_effect",
    "model_family": "logistic",
    "predictor_used": "risk_score_avg (mean of alpha and beta scores)",
    "covariates_included": covariate_cols + list(emp_dummies.columns),
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "rows with missing predictor, outcome, or covariates removed"
}

print(json.dumps(output, ensure_ascii=False))