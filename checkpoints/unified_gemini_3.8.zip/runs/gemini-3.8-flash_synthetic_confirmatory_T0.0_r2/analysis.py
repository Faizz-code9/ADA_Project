import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

def main():
    path = "/kaggle/working/outputs/runs/gemini-3.8-flash_synthetic_confirmatory_T0.0_r2/data.csv"
    df = pd.read_csv(path)

    # Missing data strategy: listwise deletion for missing skin_tone
    initial_len = len(df)
    df = df.dropna(subset=['skin_tone']).copy()
    exclusions = f"Removed {initial_len - len(df)} rows with missing skin_tone"

    # Outcome: redCards (count, 0 to 3)
    # Exposure / offset: log(games)
    # Predictor: skin_tone (continuous from 0 to 1)
    # Covariates: position, height, weight, leagueCountry, yellowCards
    # Model: Poisson or Negative Binomial regression with cluster-robust standard errors on playerID
    
    # Check dispersion or fit negative binomial / poisson
    # Poisson model with robust/clustered SEs is standard and robust for rate ratio estimation
    covariates = ['position', 'height', 'weight', 'leagueCountry', 'yellowCards']
    formula = "redCards ~ skin_tone + position + height + weight + leagueCountry + yellowCards"

    # Use Poisson GLM with offset = log(games)
    # Clustered standard errors at playerID level
    model = smf.glm(
        formula=formula,
        data=df,
        family=sm.families.Poisson(),
        offset=np.log(df['games'])
    )
    result = model.fit(cov_type='cluster', cov_kwds={'groups': df['playerID']})

    beta = result.params['skin_tone']
    se_beta = result.bse['skin_tone']
    p_value = float(result.pvalues['skin_tone'])

    # Primary estimand: Incidence Rate Ratio (IRR) for full change from 0 to 1
    irr = float(np.exp(beta))
    ci_lower = float(np.exp(beta - 1.96 * se_beta))
    ci_upper = float(np.exp(beta + 1.96 * se_beta))
    # Delta method standard error for IRR = exp(beta) * se_beta
    se_irr = float(irr * se_beta)

    conclusion = "significant_effect" if p_value < 0.05 else "no_significant_effect"

    output = {
        "effect_size": round(irr, 4),
        "effect_type": "irr",
        "standard_error": round(se_irr, 4),
        "p_value": round(p_value, 6),
        "ci_lower": round(ci_lower, 4),
        "ci_upper": round(ci_upper, 4),
        "conclusion": conclusion,
        "model_family": "poisson",
        "predictor_used": "skin_tone",
        "covariates_included": covariates,
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "clustered_se",
        "exclusions_applied": exclusions
    }

    print(json.dumps(output, indent=2))

if __name__ == '__main__':
    main()