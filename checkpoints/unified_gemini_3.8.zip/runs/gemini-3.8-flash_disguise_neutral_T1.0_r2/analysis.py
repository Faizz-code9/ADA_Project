import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

# 1. Load data
data_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_disguise_neutral_T1.0_r2/data.csv"
df = pd.read_csv(data_path)

# Predictor: average of alpha and beta risk evaluation scores
# The outcome: loan_application_rejections (values 0, 1, 2; mean 0.01256)
# Can model as binary (any rejections: > 0) or Poisson / negative binomial.
# Notice primary estimand says: "the ratio effect of the risk evaluator score on loan_application_rejections
# (an odds ratio for a binary outcome, or an incidence rate ratio for a count model; set effect_type accordingly),
# for the full change from 0 to 1. Use a continuous 0-1 score (alpha, beta or their average; say which in predictor_used)."

df["risk_score_avg"] = (df["risk_evaluator_alpha_score"] + df["risk_evaluator_beta_score"]) / 2.0
df["rejection_binary"] = (df["loan_application_rejections"] > 0).astype(int)

# Relevant covariates
covariates = [
    "credit_score_index",
    "annual_income_bracket",
    "total_applications_reviewed",
    "prior_approved_loans",
    "prior_conditional_loans",
    "prior_denied_loans",
    "repayment_performance_score",
    "formal_inquiry_notices",
    "elevated_risk_warnings",
]

# Drop missing values in predictor, outcome, and covariates
analysis_cols = ["rejection_binary", "risk_score_avg", "applicant_id"] + covariates
model_df = df[analysis_cols].dropna().copy()

# Fit Logistic Regression with clustered standard errors at applicant_id level
X = model_df[["risk_score_avg"] + covariates]
X = sm.add_constant(X)
y = model_df["rejection_binary"]

logit_mod = sm.Logit(y, X)
fit_res = logit_mod.fit(cov_type="cluster", cov_kwds={"groups": model_df["applicant_id"]}, disp=False)

beta = fit_res.params["risk_score_avg"]
se = fit_res.bse["risk_score_avg"]
pval = fit_res.pvalues["risk_score_avg"]
ci_low_coef, ci_high_coef = fit_res.conf_int().loc["risk_score_avg"]

odds_ratio = float(np.exp(beta))
ci_lower = float(np.exp(ci_low_coef))
ci_upper = float(np.exp(ci_high_coef))
# Delta method for SE of odds ratio: SE(OR) approx OR * SE(beta)
or_se = float(odds_ratio * se)

output = {
    "effect_size": odds_ratio,
    "effect_type": "odds_ratio",
    "standard_error": or_se,
    "p_value": float(pval),
    "ci_lower": ci_lower,
    "ci_upper": ci_upper,
    "conclusion": "significant_effect" if pval < 0.05 else "no_significant_effect",
    "model_family": "logistic",
    "predictor_used": "average of risk_evaluator_alpha_score and risk_evaluator_beta_score",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "dropped rows with missing risk scores or covariates",
}

print(json.dumps(output, indent=2))