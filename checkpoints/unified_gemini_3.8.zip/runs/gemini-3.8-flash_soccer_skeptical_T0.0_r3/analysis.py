import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

# 1. Load data
data_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_soccer_skeptical_T0.0_r3/data.csv"
df = pd.read_csv(data_path)

# 2. Data Cleaning & Variable Construction
# Predictor: average of rater1 and rater2
df["skintone"] = (df["rater1"] + df["rater2"]) / 2.0

# Relevant columns
# Red cards is count per dyad, games is exposure
analysis_cols = ["redCards", "skintone", "games", "playerShort", "position", "weight", "height"]
df_clean = df.dropna(subset=["redCards", "skintone", "games"]).copy()

# Add log games as offset
df_clean = df_clean[df_clean["games"] > 0].copy()
df_clean["log_games"] = np.log(df_clean["games"])

# Fit Poisson regression model with exposure/offset (log_games)
# Clustered standard errors at player level because skin tone is invariant within player
X = sm.add_constant(df_clean[["skintone"]])
y = df_clean["redCards"]

poisson_model = sm.GLM(
    y,
    X,
    family=sm.families.Poisson(),
    offset=df_clean["log_games"]
)

# Cluster standard errors by player
fit_res = poisson_model.fit(cov_type="cluster", cov_kwds={"groups": df_clean["playerShort"]})

# Extract results for skintone
# Primary estimand: ratio effect of skin tone for full change from 0 to 1 (IRR)
beta = fit_res.params["skintone"]
se_beta = fit_res.bse["skintone"]
p_val = fit_res.pvalues["skintone"]

irr = float(np.exp(beta))
ci_lower = float(np.exp(beta - 1.96 * se_beta))
ci_upper = float(np.exp(beta + 1.96 * se_beta))

# Delta method for SE of IRR: SE(exp(beta)) = exp(beta) * SE(beta)
irr_se = float(irr * se_beta)

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
    "effect_size": irr,
    "effect_type": "irr",
    "standard_error": irr_se,
    "p_value": float(p_val),
    "ci_lower": ci_lower,
    "ci_upper": ci_upper,
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "mean of rater1 and rater2",
    "covariates_included": ["offset(log(games))"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "dropped rows with missing skin tone ratings (rater1/rater2) or games <= 0"
}

print(json.dumps(output, indent=2))