import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

def run_analysis():
    file_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_soccer_skeptical_T0.7_r1/data.csv"
    df = pd.read_csv(file_path)

    # Missing data strategy: listwise deletion for predictor and key covariates
    # Predictor: average of rater1 and rater2
    # Ensure both raters are present
    df = df.dropna(subset=['rater1', 'rater2', 'games', 'redCards']).copy()
    df['skin_tone'] = (df['rater1'] + df['rater2']) / 2.0
    
    # Red cards as count outcome with log(games) as offset
    # Negative Binomial or Poisson model. Red cards is rare count, Poisson regression with exposure/offset log(games)
    # is standard. Let's use Poisson GLM with robust / clustered standard errors by player.
    # Clustering on playerShort accounts for repeated observations of players.
    
    # Covariates: leagueCountry, position (impute missing position or keep 'Unknown')
    df['position'] = df['position'].fillna('Unknown')
    
    # We include position and leagueCountry as controls, along with player height/weight if available, but
    # position + leagueCountry are the most relevant structural confounders.
    # Clean games to ensure > 0
    df = df[df['games'] > 0].copy()
    df['log_games'] = np.log(df['games'])

    # Fit Poisson GLM
    formula = "redCards ~ skin_tone + C(leagueCountry) + C(position)"
    model = smf.glm(
        formula=formula,
        data=df,
        family=sm.families.Poisson(),
        offset=df['log_games']
    )
    
    # Cluster standard errors on player
    res = model.fit(cov_type='cluster', cov_kwds={'groups': df['playerShort']})
    
    beta = res.params['skin_tone']
    se_beta = res.bse['skin_tone']
    
    # Estimand: Incidence Rate Ratio (IRR) for full change from 0 to 1
    irr = np.exp(beta)
    ci_lower = np.exp(beta - 1.96 * se_beta)
    ci_upper = np.exp(beta + 1.96 * se_beta)
    # Delta method standard error for IRR = irr * se_beta
    se_irr = irr * se_beta
    p_value = res.pvalues['skin_tone']

    conclusion = "significant_effect" if p_value < 0.05 else "no_significant_effect"

    output = {
        "effect_size": float(irr),
        "effect_type": "irr",
        "standard_error": float(se_irr),
        "p_value": float(p_value),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": conclusion,
        "model_family": "poisson",
        "predictor_used": "average of rater1 and rater2",
        "covariates_included": ["leagueCountry", "position", "log_games (offset)"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "clustered_se",
        "exclusions_applied": "Excluded rows with missing skin tone ratings or games <= 0"
    }

    print(json.dumps(output))

if __name__ == "__main__":
    run_analysis()