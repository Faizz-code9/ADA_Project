import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

# File path
data_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_soccer_skeptical_T1.0_r1/data.csv"

# Load data
df = pd.read_csv(data_path)

# Drop missing values for skin tone raters and key variables
# rater1 and rater2 have 14.7% missingness
df = df.dropna(subset=['rater1', 'rater2', 'redCards', 'games', 'playerShort']).copy()

# Construct continuous 0-1 skin-tone score (average of rater1 and rater2)
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2.0

# Red cards is count outcome, games is exposure/offset
# Aggregate to player-referee pairs, games > 0
df = df[df['games'] > 0].copy()

# Fit a Poisson GLM with log link, offset=log(games), clustered standard errors by player
# Controlling for leagueCountry if desired, or position, but standard many-analysts core model:
# redCards ~ skin_tone with offset(log(games)), clustered on playerShort
df['log_games'] = np.log(df['games'])

# Let's adjust for leagueCountry to account for baseline card rates across leagues
leagues = pd.get_dummies(df['leagueCountry'], drop_first=True, dtype=float)
X = pd.concat([df[['skin_tone']], leagues], axis=1)
X = sm.add_constant(X)
y = df['redCards']

model = sm.GLM(
    y,
    X,
    family=sm.families.Poisson(),
    offset=df['log_games']
)

# Cluster robust standard errors at the player level (playerShort)
fit = model.fit(cov_type='cluster', cov_kwds={'groups': df['playerShort']})

# Primary estimand: ratio effect for full change (0 to 1), which is IRR = exp(beta)
beta = fit.params['skin_tone']
se_beta = fit.bse['skin_tone']
p_val = fit.pvalues['skin_tone']
ci_lower_beta = fit.conf_int().loc['skin_tone', 0]
ci_upper_beta = fit.conf_int().loc['skin_tone', 1]

irr = np.exp(beta)
# Delta method for SE of IRR = exp(beta) * se_beta
se_irr = irr * se_beta
ci_lower_irr = np.exp(ci_lower_beta)
ci_upper_irr = np.exp(ci_upper_beta)

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se_irr),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower_irr),
    "ci_upper": float(ci_upper_irr),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "average of rater1 and rater2",
    "covariates_included": list(leagues.columns),
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "removed rows with missing skin tone ratings (rater1, rater2) or games <= 0"
}

print(json.dumps(output, indent=2))