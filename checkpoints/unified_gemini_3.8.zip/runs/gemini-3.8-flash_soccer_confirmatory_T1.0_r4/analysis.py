import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

# 1. Load data
data_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_soccer_confirmatory_T1.0_r4/data.csv"
df = pd.read_csv(data_path)

# 2. Exclusions and Preprocessing
# Drop rows with missing values in rater1 or rater2
df = df.dropna(subset=['rater1', 'rater2', 'games', 'redCards', 'playerShort']).copy()

# Average skin tone rating (continuous 0 to 1)
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2.0

# 3. Model setup: Poisson regression with log(games) as exposure (offset)
# Clustering on player level to account for repeated player observations across referees
df['log_games'] = np.log(df['games'])

# Model formula: redCards ~ skin_tone with offset log_games
X = sm.add_constant(df[['skin_tone']])
y = df['redCards']
offset = df['log_games']

poisson_mod = sm.GLM(
    y,
    X,
    family=sm.families.Poisson(),
    offset=offset
)

# Fit with robust/clustered standard errors clustered on player
res = poisson_mod.fit(cov_type='cluster', cov_kwds={'groups': df['playerShort']})

beta = res.params['skin_tone']
se_beta = res.bse['skin_tone']
irr = float(np.exp(beta))
irr_ci_lower = float(np.exp(beta - 1.96 * se_beta))
irr_ci_upper = float(np.exp(beta + 1.96 * se_beta))
p_value = float(res.pvalues['skin_tone'])

# Standard error of IRR via delta method: SE(IRR) = IRR * SE(beta)
se_irr = float(irr * se_beta)

conclusion = "significant_effect" if p_value < 0.05 else "no_significant_effect"

output = {
    "effect_size": irr,
    "effect_type": "irr",
    "standard_error": se_irr,
    "p_value": p_value,
    "ci_lower": irr_ci_lower,
    "ci_upper": irr_ci_upper,
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "mean of rater1 and rater2",
    "covariates_included": ["log(games) as offset"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "Excluded rows with missing rater1 or rater2"
}

print(json.dumps(output, indent=2))