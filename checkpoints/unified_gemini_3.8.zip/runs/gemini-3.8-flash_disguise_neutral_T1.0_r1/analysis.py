import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

# 1. Load data
data_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_disguise_neutral_T1.0_r1/data.csv"
df = pd.read_csv(data_path)

# Predictor: average of alpha and beta risk evaluation scores
df["risk_evaluator_score"] = (
    df["risk_evaluator_alpha_score"] + df["risk_evaluator_beta_score"]
) / 2.0

# Outcome: loan_application_rejections (values 0, 1, 2)
# Since loan_application_rejections is a count / rate of rejections, we can use Poisson / NegBin or Logistic (binary indicator: rejected > 0).
# The prompt states: "an odds ratio for a binary outcome, or an incidence rate ratio for a count model; set effect_type accordingly, for the full change from 0 to 1."
# Let's check Poisson/negative binomial or logistic. Rejection is rare (mean 0.01256, max 2). Poisson regression with robust/clustered SEs or Logistic regression:
# Binary indicator (rejection > 0) or Poisson count.
# Since it asks for "an odds ratio for a binary outcome, or an incidence rate ratio for a count model",
# let's model as logistic regression where outcome = (loan_application_rejections > 0).astype(int), or Poisson regression on the count.
# A Poisson model directly models the count of rejections, with IRR as effect_size.
# Or logistic regression on (loan_application_rejections > 0). Let's see: count model Poisson with IRR is very natural for rejections count.
# Wait, let's check total_applications_reviewed as an offset or exposure if count, or logistic.
# With total_applications_reviewed, log(total_applications_reviewed) could be an offset, or logistic regression P(rejection > 0).
# Logistic regression is very standard and robust for binary / hurdle outcomes. Let's make y = (df['loan_application_rejections'] > 0).astype(int).
# Wait, can we do logistic regression? If binary outcome, effect_type is 'odds_ratio'.
# If count model (Poisson), effect_type is 'irr'.
# Let's use logistic regression for loan rejection (any rejection: loan_application_rejections > 0)
# Wait, what if we use Poisson regression for loan_application_rejections?
# In Poisson regression, IRR = exp(beta).
# Let's consider: applicants are reviewed by loan officers. Each row is an applicant-officer pairing.
# Clusters: applicant_id or loan_officer_id.
# Let's check covariates: credit_score_index, annual_income_bracket, prior_approved_loans, prior_conditional_loans, prior_denied_loans, repayment_performance_score, formal_inquiry_notices, elevated_risk_warnings, total_applications_reviewed.

covariates = [
    "credit_score_index",
    "annual_income_bracket",
    "total_applications_reviewed",
    "prior_approved_loans",
    "prior_conditional_loans",
    "prior_denied_loans",
    "repayment_performance_score",
    "formal_inquiry_notices",
    "elevated_risk_warnings",
]

cols_needed = (
    ["loan_application_rejections", "risk_evaluator_score", "applicant_id"]
    + covariates
)
df_clean = df.dropna(subset=cols_needed).copy()
df_clean["rejected_binary"] = (
    df_clean["loan_application_rejections"] > 0
).astype(int)

# Fit Logistic regression with cluster-robust standard errors on applicant_id
X = sm.add_constant(df_clean[["risk_evaluator_score"] + covariates])
y = df_clean["rejected_binary"]

logit_mod = sm.Logit(y, X)
fit_res = logit_mod.fit(
    cov_type="cluster",
    cov_kwds={"groups": df_clean["applicant_id"]},
    disp=False,
)

beta = fit_res.params["risk_evaluator_score"]
se = fit_res.bse["risk_evaluator_score"]
p_val = fit_res.pvalues["risk_evaluator_score"]
ci_low_beta, ci_high_beta = fit_res.conf_int().loc["risk_evaluator_score"]

or_val = np.exp(beta)
or_low = np.exp(ci_low_beta)
or_high = np.exp(ci_high_beta)
# Delta method for standard error of OR: SE(OR) = OR * SE(beta)
se_or = or_val * se

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
    "effect_size": float(or_val),
    "effect_type": "odds_ratio",
    "standard_error": float(se_or),
    "p_value": float(p_val),
    "ci_lower": float(or_low),
    "ci_upper": float(or_high),
    "conclusion": conclusion,
    "model_family": "logistic",
    "predictor_used": "average of risk_evaluator_alpha_score and risk_evaluator_beta_score",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "dropped rows with missing values in predictor, outcome, or covariates",
}

print(json.dumps(output, indent=2))