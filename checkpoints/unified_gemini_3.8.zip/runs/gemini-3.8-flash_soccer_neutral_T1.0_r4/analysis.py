import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

# File path
data_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_soccer_neutral_T1.0_r4/data.csv"

# Load data
df = pd.read_csv(data_path)

# Drop rows missing rater1 or rater2
df = df.dropna(subset=['rater1', 'rater2', 'games', 'redCards', 'playerShort']).copy()

# Average skin tone rating
df['skintone'] = (df['rater1'] + df['rater2']) / 2.0

# Aggregate to player level to properly model player-level red cards given total games exposure
# Many many-analysts teams aggregate at player level or use clustered models.
# Modeling at the dyad level with Poisson GLM clustered on player (or player level) is standard.
# Let's aggregate to player level:
player_df = df.groupby('playerShort').agg({
    'redCards': 'sum',
    'games': 'sum',
    'skintone': 'first',
    'height': 'first',
    'weight': 'first',
    'position': 'first'
}).reset_index()

# Drop missing position/height/weight or keep listwise deletion on used covariates
# Using position and games offset in Poisson model
player_df = player_df.dropna(subset=['skintone', 'games', 'redCards']).copy()

# Fit Poisson regression with offset log(games)
# Let's adjust for position if available or fit with skin tone alone/position
# To maximize sample size and avoid missing position drops (12%), let's see if position is needed or fit on complete cases
player_df_cc = player_df.dropna(subset=['position', 'height', 'weight']).copy()
# Create position dummies
pos_dummies = pd.get_dummies(player_df_cc['position'], drop_first=True, dtype=float)
X = pd.concat([player_df_cc[['skintone', 'height', 'weight']], pos_dummies], axis=1)
X = sm.add_constant(X)
y = player_df_cc['redCards']
offset = np.log(player_df_cc['games'])

# Fit Poisson GLM
model = sm.GLM(y, X, family=sm.families.Poisson(), offset=offset)
res = model.fit(cov_type='HC1') # Robust SE

coef = res.params['skintone']
se = res.bse['skintone']
irr = np.exp(coef)
ci_low = np.exp(coef - 1.959964 * se)
ci_high = np.exp(coef + 1.959964 * se)
pval = res.pvalues['skintone']

output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(pval),
    "ci_lower": float(ci_low),
    "ci_upper": float(ci_high),
    "conclusion": "significant_effect" if pval < 0.05 else "no_significant_effect",
    "model_family": "poisson",
    "predictor_used": "mean of rater1 and rater2",
    "covariates_included": ["height", "weight", "position", "log(games)_offset"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "aggregated to player level; dropped rows with missing skin tone ratings or covariates"
}

print(json.dumps(output))