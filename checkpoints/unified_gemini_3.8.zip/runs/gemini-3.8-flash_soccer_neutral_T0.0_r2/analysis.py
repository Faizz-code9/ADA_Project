import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

# 1. Load data
data_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_soccer_neutral_T0.0_r2/data.csv"
df = pd.read_csv(data_path)

# 2. Data preparation
# Define predictor: average of rater1 and rater2
# Exclude rows where skin tone rating or games is missing
df_clean = df.dropna(subset=['rater1', 'rater2', 'games', 'redCards']).copy()
df_clean['skin_tone'] = (df_clean['rater1'] + df_clean['rater2']) / 2.0

# Keep only rows where games > 0
df_clean = df_clean[df_clean['games'] > 0].copy()

# Add covariates: position, leagueCountry, height, weight
# Impute missing position as 'Unknown' to avoid dropping rows
df_clean['position'] = df_clean['position'].fillna('Unknown')
# For height and weight, fill missing with mean
df_clean['height'] = df_clean['height'].fillna(df_clean['height'].mean())
df_clean['weight'] = df_clean['weight'].fillna(df_clean['weight'].mean())

covariates = ['position', 'leagueCountry', 'height', 'weight']
# Create design matrix
formula = 'redCards ~ skin_tone + C(position) + C(leagueCountry) + height + weight'
# Using Poisson regression with log(games) offset
# Cluster standard errors by player (playerShort)
y = df_clean['redCards']
offset = np.log(df_clean['games'])

import statsmodels.formula.api as smf
poisson_mod = smf.poisson('redCards ~ skin_tone + C(position) + C(leagueCountry) + height + weight',
                          data=df_clean,
                          offset=offset)

# Fit model with clustered SEs on player
res = poisson_mod.fit(cov_type='cluster', cov_kwds={'groups': df_clean['playerShort']}, disp=False)

# Extract effect size for skin_tone (IRR = exp(beta))
beta = res.params['skin_tone']
se_beta = res.bse['skin_tone']
p_val = res.pvalues['skin_tone']
ci_lower_beta, ci_upper_beta = res.conf_int().loc['skin_tone']

irr = float(np.exp(beta))
ci_lower = float(np.exp(ci_lower_beta))
ci_upper = float(np.exp(ci_upper_beta))
# Standard error of IRR via delta method: se(exp(b)) = exp(b) * se(b)
se_irr = float(irr * se_beta)

output = {
    "effect_size": irr,
    "effect_type": "irr",
    "standard_error": se_irr,
    "p_value": float(p_val),
    "ci_lower": ci_lower,
    "ci_upper": ci_upper,
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "poisson",
    "predictor_used": "average of rater1 and rater2",
    "covariates_included": covariates,
    "missing_data_strategy": "other",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "dropped rows missing skin tone ratings (rater1, rater2) or zero games; mean imputed height/weight; unknown category for position"
}

print(json.dumps(output))