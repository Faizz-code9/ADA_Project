import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

# File path
data_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_soccer_skeptical_T0.0_r1/data.csv"

# Load data
df = pd.read_csv(data_path)

# Drop missing values in the primary predictor (rater1, rater2) and outcome
df = df.dropna(subset=["rater1", "rater2", "redCards", "games"]).copy()

# Filter out rows where games <= 0 if any (offset requires games > 0)
df = df[df["games"] > 0].copy()

# Skin tone as average of rater1 and rater2 (range 0 to 1)
df["skin_tone"] = (df["rater1"] + df["rater2"]) / 2.0

# Exposure offset: log(games)
df["log_games"] = np.log(df["games"])

# Fit a Poisson regression model for redCards with offset=log(games) and clustered SEs by player
# Controlling for position if available (or general standard model)
# To ensure robust convergence across 100k+ rows and account for player clustering:
X = df[["skin_tone"]]
X = sm.add_constant(X)
y = df["redCards"]
offset = df["log_games"]

# Fit Poisson model with cluster-robust standard errors on playerShort
model = sm.GLM(y, X, offset=offset, family=sm.families.Poisson())
res = model.fit(cov_type="cluster", cov_kwds={"groups": df["playerShort"]})

# Extract results for skin_tone (beta, se, p-value, ci)
beta = res.params["skin_tone"]
se_beta = res.bse["skin_tone"]
pval = res.pvalues["skin_tone"]
ci_lower_beta, ci_upper_beta = res.conf_int().loc["skin_tone"]

# Compute Incidence Rate Ratio (IRR) for full change from 0 to 1
irr = float(np.exp(beta))
ci_lower_irr = float(np.exp(ci_lower_beta))
ci_upper_irr = float(np.exp(ci_upper_beta))
# SE of IRR via delta method: SE(IRR) = exp(beta) * SE(beta)
se_irr = float(irr * se_beta)

conclusion = "significant_effect" if pval < 0.05 else "no_significant_effect"

output = {
    "effect_size": round(irr, 4),
    "effect_type": "irr",
    "standard_error": round(se_irr, 4),
    "p_value": round(float(pval), 4),
    "ci_lower": round(ci_lower_irr, 4),
    "ci_upper": round(ci_upper_irr, 4),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "mean of rater1 and rater2",
    "covariates_included": ["log(games) [offset]"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "dropped rows missing rater1 or rater2 (21,407 rows) and games <= 0",
}

print(json.dumps(output, indent=2))