import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

def main():
    file_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_synthetic_confirmatory_T0.7_r1/data.csv"
    df = pd.read_csv(file_path)

    # Missing data strategy: listwise deletion for missing skin_tone or other model variables
    initial_len = len(df)
    df_clean = df.dropna(subset=['skin_tone', 'redCards', 'games', 'position', 'height', 'weight', 'leagueCountry', 'playerID']).copy()
    exclusions_applied = f"Dropped {initial_len - len(df_clean)} rows with missing values"

    # Outcome is count of red cards over number of games (exposure).
    # Model: Poisson or Negative Binomial regression with log(games) offset, clustering SE by playerID
    formula = "redCards ~ skin_tone + C(position) + height + weight + C(leagueCountry)"
    
    # Fit Poisson model with offset = log(games) and cluster-robust standard errors on playerID
    model = smf.poisson(formula, data=df_clean, offset=np.log(df_clean['games']))
    res = model.fit(cov_type='cluster', cov_kwds={'groups': df_clean['playerID']}, disp=False)

    beta = res.params['skin_tone']
    se_beta = res.bse['skin_tone']
    p_val = res.pvalues['skin_tone']
    ci_low_beta, ci_high_beta = res.conf_int().loc['skin_tone']

    # Incidence Rate Ratio (IRR) for full change from 0 to 1
    irr = float(np.exp(beta))
    ci_lower = float(np.exp(ci_low_beta))
    ci_upper = float(np.exp(ci_high_beta))

    # Delta method standard error for IRR = exp(beta) * se(beta)
    irr_se = float(irr * se_beta)

    conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

    covariates = ["position", "height", "weight", "leagueCountry", "games (as offset)"]

    output = {
        "effect_size": float(irr),
        "effect_type": "irr",
        "standard_error": irr_se,
        "p_value": float(p_val),
        "ci_lower": ci_lower,
        "ci_upper": ci_upper,
        "conclusion": conclusion,
        "model_family": "poisson",
        "predictor_used": "skin_tone",
        "covariates_included": covariates,
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "clustered_se",
        "exclusions_applied": exclusions_applied
    }

    print(json.dumps(output))

if __name__ == "__main__":
    main()