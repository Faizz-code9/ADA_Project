import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

# 1. Load Data
file_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_soccer_confirmatory_T0.7_r2/data.csv"
df = pd.read_csv(file_path)

# 2. Data Cleaning & Variable Construction
# Predictor: average of rater1 and rater2
# Exclude missing rater values (photoID missingness)
df = df.dropna(subset=['rater1', 'rater2', 'games', 'redCards', 'playerShort']).copy()
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2.0

# Aggregate to player level to avoid complex referee clustering or fit directly at dyad level with cluster SEs.
# A standard Poisson / Negative Binomial or Logistic model with clustered standard errors on player.
# Since redCards is a count (0, 1, 2) per dyad and games is the exposure,
# we can use a Poisson regression with offset log(games) or aggregate per player.
# Alternatively, Poisson GLM on dyads clustered on playerShort.
df['log_games'] = np.log(df['games'])

# Model: redCards ~ skin_tone + C(leagueCountry) + position (fill na or omit)
# Let's adjust for leagueCountry, height, weight, and position (treated as categorical, filling missing as 'Unknown').
df['position'] = df['position'].fillna('Unknown')
df['height'] = df['height'].fillna(df['height'].median())
df['weight'] = df['weight'].fillna(df['weight'].median())

# Fit GLM Poisson with offset log(games) and cluster-robust standard errors on playerShort
formula = "redCards ~ skin_tone + height + weight + C(leagueCountry) + C(position)"
# Using smf.glm
import statsmodels.formula.api as smf

model = smf.glm(
    formula=formula,
    data=df,
    family=sm.families.Poisson(),
    offset=df['log_games']
)

# Fit with cluster-robust standard errors clustered by player
results = model.fit(cov_type='cluster', cov_kwds={'groups': df['playerShort']})

# Extract estimand: Incidence Rate Ratio (IRR) for skin_tone (0 to 1 full change)
coef = results.params['skin_tone']
# For cluster robust SE of log-rate ratio:
se = results.bse['skin_tone']
pval = results.pvalues['skin_tone']

# 95% CI on log scale, then exponentiate
ci_lower_log, ci_upper_log = results.conf_int().loc['skin_tone']
irr = np.exp(coef)
ci_lower = np.exp(ci_lower_log)
ci_upper = np.exp(ci_upper_log)
# Delta method SE for IRR: se(exp(b)) ~ exp(b) * se(b)
se_irr = irr * se

conclusion = "significant_effect" if pval < 0.05 else "no_significant_effect"

out = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se_irr),
    "p_value": float(pval),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "mean(rater1, rater2)",
    "covariates_included": ["height", "weight", "leagueCountry", "position"],
    "missing_data_strategy": "other",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "dropped rows missing skin tone ratings (rater1, rater2)"
}

print(json.dumps(out))