import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
data_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_synthetic_neutral_T0.0_r1/data.csv"
df = pd.read_csv(data_path)

# 2. Clean & handle missing data
# skin_tone has ~8% missing values. Listwise deletion is standard here.
initial_len = len(df)
df = df.dropna(subset=["skin_tone", "redCards", "games"]).copy()

# Add log exposure
df["log_games"] = np.log(df["games"])

# 3. Model Fitting
# Poisson / Negative Binomial regression with exposure/offset log(games)
# Clustered standard errors on playerID because multiple dyad observations per player.
formula = "redCards ~ skin_tone + height + weight + C(position) + C(leagueCountry)"

try:
    # Try Negative Binomial regression first to account for potential overdispersion
    nb_mod = smf.glm(
        formula=formula,
        data=df,
        offset=df["log_games"],
        family=sm.families.NegativeBinomial()
    )
    res = nb_mod.fit(cov_type="cluster", cov_kwds={"groups": df["playerID"]})
    model_family = "negative_binomial"
except Exception:
    # Fallback to Poisson if NB fails
    poiss_mod = smf.glm(
        formula=formula,
        data=df,
        offset=df["log_games"],
        family=sm.families.Poisson()
    )
    res = poiss_mod.fit(cov_type="cluster", cov_kwds={"groups": df["playerID"]})
    model_family = "poisson"

# 4. Extract primary estimand (IRR for full change from 0 to 1 in skin_tone)
beta = res.params["skin_tone"]
se_beta = res.bse["skin_tone"]
pval = float(res.pvalues["skin_tone"])

# IRR = exp(beta)
irr = float(np.exp(beta))
# Using delta method for standard error of IRR: SE(exp(beta)) = exp(beta) * SE(beta)
se_irr = float(irr * se_beta)

ci_lower = float(np.exp(beta - 1.959964 * se_beta))
ci_upper = float(np.exp(beta + 1.959964 * se_beta))

conclusion = "significant_effect" if pval < 0.05 else "no_significant_effect"

output = {
    "effect_size": round(irr, 4),
    "effect_type": "irr",
    "standard_error": round(se_irr, 4),
    "p_value": round(pval, 6),
    "ci_lower": round(ci_lower, 4),
    "ci_upper": round(ci_upper, 4),
    "conclusion": conclusion,
    "model_family": model_family,
    "predictor_used": "skin_tone",
    "covariates_included": ["height", "weight", "position", "leagueCountry", "log(games)_offset"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "dropped missing skin_tone observations"
}

print(json.dumps(output, indent=2))