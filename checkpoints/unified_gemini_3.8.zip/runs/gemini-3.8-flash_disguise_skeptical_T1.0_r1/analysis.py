import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

# File path
data_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_disguise_skeptical_T1.0_r1/data.csv"

# Load data
df = pd.read_csv(data_path)

# Predictor: average of risk_evaluator_alpha_score and risk_evaluator_beta_score
# Both are continuous 0-1 scores
df["risk_evaluator_score"] = (
    df["risk_evaluator_alpha_score"] + df["risk_evaluator_beta_score"]
) / 2.0

# Outcome: loan_application_rejections
# Unique values: 0, 1, 2. Mean is 0.01256. Can be modeled via logistic regression (binary: >0 vs 0)
# or Poisson/negative binomial or logistic regression on binary indicator.
# Let's inspect loan_application_rejections as binary: (loan_application_rejections > 0).astype(int)
df["rejection_binary"] = (df["loan_application_rejections"] > 0).astype(int)

# Covariates to control for confounding
covariates = [
    "credit_score_index",
    "annual_income_bracket",
    "total_applications_reviewed",
    "prior_approved_loans",
    "prior_conditional_loans",
    "prior_denied_loans",
    "repayment_performance_score",
    "formal_inquiry_notices",
    "elevated_risk_warnings",
]

# Analysis dataframe
model_cols = [
    "rejection_binary",
    "risk_evaluator_score",
    "applicant_id",
    "loan_officer_id",
] + covariates
df_clean = df.dropna(subset=model_cols).copy()

# Fit logistic regression model with clustered standard errors at applicant level
# Using statsmodels Logit
X = df_clean[["risk_evaluator_score"] + covariates]
X = sm.add_constant(X)
y = df_clean["rejection_binary"]
groups = df_clean["applicant_id"]

logit_model = sm.Logit(y, X)
res = logit_model.fit(
    cov_type="cluster", cov_kwds={"groups": groups}, disp=False
)

# Target estimand: Odds Ratio for full change (0 to 1) in risk_evaluator_score
# beta is the coefficient for risk_evaluator_score
beta = res.params["risk_evaluator_score"]
se_beta = res.bse["risk_evaluator_score"]
p_val = float(res.pvalues["risk_evaluator_score"])

# 95% CI on log-odds scale then exponentiate
ci_lower_log = res.conf_int().loc["risk_evaluator_score", 0]
ci_upper_log = res.conf_int().loc["risk_evaluator_score", 1]

odds_ratio = float(np.exp(beta))
ci_lower_or = float(np.exp(ci_lower_log))
ci_upper_or = float(np.exp(ci_upper_log))

# Using delta method for standard error of OR: SE(OR) = OR * SE(beta)
se_or = float(odds_ratio * se_beta)

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
    "effect_size": odds_ratio,
    "effect_type": "odds_ratio",
    "standard_error": se_or,
    "p_value": p_val,
    "ci_lower": ci_lower_or,
    "ci_upper": ci_upper_or,
    "conclusion": conclusion,
    "model_family": "logistic",
    "predictor_used": "average of risk_evaluator_alpha_score and risk_evaluator_beta_score",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "dropped rows with missing values in model variables",
}

print(json.dumps(output, indent=2))