import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# Load dataset
file_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_synthetic_neutral_T0.0_r2/data.csv"
df = pd.read_csv(file_path)

# Handle missing data
initial_len = len(df)
df = df.dropna(subset=["skin_tone", "redCards", "games", "position", "height", "weight", "leagueCountry"]).copy()
exclusions = f"Removed {initial_len - len(df)} rows with missing values (listwise deletion)."

# Fit Poisson or Negative Binomial regression with exposure / log(games) offset
# Outcome is count of redCards, games is number of games (exposure).
# Since clustering at player or referee level is relevant, cluster robust SE on playerID.
covariates = ["position", "leagueCountry", "height", "weight"]

formula = "redCards ~ skin_tone + C(position) + C(leagueCountry) + height + weight"
model = smf.glm(
    formula=formula,
    data=df,
    family=sm.families.Poisson(),
    exposure=df["games"]
)

# Fit with cluster-robust standard errors at playerID level
results = model.fit(cov_type="cluster", cov_kwds={"groups": df["playerID"]})

# Extract skin_tone coefficient, SE, p-value, CI
beta = results.params["skin_tone"]
se_beta = results.bse["skin_tone"]
p_value = float(results.pvalues["skin_tone"])

# Primary estimand: Incidence Rate Ratio (IRR) for full change from 0 to 1
irr = float(np.exp(beta))
ci_lower = float(np.exp(beta - 1.95996 * se_beta))
ci_upper = float(np.exp(beta + 1.95996 * se_beta))

# Standard error of IRR via delta method: SE(exp(beta)) = exp(beta) * SE(beta)
se_irr = float(irr * se_beta)

conclusion = "significant_effect" if p_value < 0.05 else "no_significant_effect"

output = {
    "effect_size": round(irr, 4),
    "effect_type": "irr",
    "standard_error": round(se_irr, 4),
    "p_value": round(p_value, 6),
    "ci_lower": round(ci_lower, 4),
    "ci_upper": round(ci_upper, 4),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "skin_tone",
    "covariates_included": covariates + ["games (exposure)"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": exclusions
}

print(json.dumps(output))