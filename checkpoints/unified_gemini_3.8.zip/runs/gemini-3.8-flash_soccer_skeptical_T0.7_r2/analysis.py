import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

file_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_soccer_skeptical_T0.7_r2/data.csv"
df = pd.read_csv(file_path)

# Drop rows missing skin tone ratings
df = df.dropna(subset=["rater1", "rater2"]).copy()

# Compute average skin tone score (continuous 0-1)
df["skin_tone"] = (df["rater1"] + df["rater2"]) / 2.0

# In this dataset, redCards is a count outcome, and games is the exposure (offset).
# Check exclusions: games must be > 0 (min games is 1 according to dictionary)
df = df[df["games"] > 0].copy()

# Fit a Poisson or Negative Binomial regression with log(games) as exposure / offset.
# Clustering at the player level or referee level. Let's use Poisson GLM with cluster-robust standard errors (on playerShort).
# Covariates: position (handled or omitted; position has 12% missing, let's keep clean: position or leagueCountry)
# To avoid losing rows due to missing position, let's fill missing position with 'Unknown' or control for leagueCountry.
df["position"] = df["position"].fillna("Unknown")

# Model redCards ~ skin_tone + C(leagueCountry) + C(position)
covariates = ["skin_tone", "leagueCountry", "position"]
data_subset = df[["redCards", "games", "playerShort", "skin_tone", "leagueCountry", "position"]].dropna()

X = pd.get_dummies(data_subset[["skin_tone", "leagueCountry", "position"]], drop_first=True, dtype=float)
X = sm.add_constant(X)
y = data_subset["redCards"]
exposure = data_subset["games"]

# Fit Poisson GLM with offset log(games)
poisson_model = sm.GLM(
    y,
    X,
    family=sm.families.Poisson(),
    exposure=exposure
)

# Robust cluster SE on playerShort
fit_res = poisson_model.fit(cov_type="cluster", cov_kwds={"groups": data_subset["playerShort"]})

beta = fit_res.params["skin_tone"]
se_beta = fit_res.bse["skin_tone"]
p_val = fit_res.pvalues["skin_tone"]
ci_lower_beta, ci_upper_beta = fit_res.conf_int().loc["skin_tone"]

# Estimand is incidence rate ratio (IRR) for full change from 0 to 1
irr = float(np.exp(beta))
ci_lower_irr = float(np.exp(ci_lower_beta))
ci_upper_irr = float(np.exp(ci_upper_beta))
# SE of IRR via delta method: SE(IRR) = IRR * SE(beta)
se_irr = float(irr * se_beta)

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
    "effect_size": irr,
    "effect_type": "irr",
    "standard_error": se_irr,
    "p_value": float(p_val),
    "ci_lower": ci_lower_irr,
    "ci_upper": ci_upper_irr,
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "average of rater1 and rater2 (skin_tone)",
    "covariates_included": ["leagueCountry", "position"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "dropped rows missing rater1 or rater2"
}

print(json.dumps(output))