import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

# File path
file_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_soccer_neutral_T1.0_r2/data.csv"

# Load data
df = pd.read_csv(file_path)

# Prepare skin tone predictor: average of rater1 and rater2
# Exclude rows where skin tone rating is missing
df = df.dropna(subset=["rater1", "rater2", "redCards", "games", "playerShort"]).copy()

df["skin_tone"] = (df["rater1"] + df["rater2"]) / 2.0

# Aggregate to player level or fit directly with offset / log(games)
# In standard many-analysts soccer analysis, redCards is modeled given games exposure.
# Let's use Poisson / Negative Binomial or Logistic regression.
# For binary/count: each dyad has `redCards` (count: 0, 1, 2) and `games` exposure.
# A Poisson GLM with log(games) offset and cluster-robust standard errors at the player level (playerShort).
# Covariates: leagueCountry (or club/position if present), games exposure.
# Let's check missingness in potential covariates:
# leagueCountry has 0 missing. Let's include leagueCountry dummies.
covariates = ["leagueCountry"]
df_model = df[["redCards", "skin_tone", "games", "playerShort", "leagueCountry"]].dropna().copy()

# Add log(games) as offset
df_model["log_games"] = np.log(df_model["games"])

# Create design matrix
X = pd.get_dummies(df_model[["leagueCountry"]], drop_first=True, dtype=float)
X.insert(0, "skin_tone", df_model["skin_tone"])
X = sm.add_constant(X)

y = df_model["redCards"]
offset = df_model["log_games"]

# Fit Poisson GLM with clustered standard errors on playerShort
poisson_model = sm.GLM(
    y,
    X,
    family=sm.families.Poisson(),
    offset=offset
)

# Cluster on playerShort
fit_res = poisson_model.fit(cov_type="cluster", cov_kwds={"groups": df_model["playerShort"]})

beta = fit_res.params["skin_tone"]
se_beta = fit_res.bse["skin_tone"]
p_val = fit_res.pvalues["skin_tone"]

# IRR for full change (0 to 1) is exp(beta)
irr = float(np.exp(beta))
ci_lower = float(np.exp(beta - 1.95996 * se_beta))
ci_upper = float(np.exp(beta + 1.95996 * se_beta))

# Standard error of IRR via Delta method: se(IRR) = IRR * se_beta
se_irr = float(irr * se_beta)

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
    "effect_size": irr,
    "effect_type": "irr",
    "standard_error": se_irr,
    "p_value": float(p_val),
    "ci_lower": ci_lower,
    "ci_upper": ci_upper,
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "mean of rater1 and rater2 (skin_tone)",
    "covariates_included": ["leagueCountry"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "Excluded rows with missing skin tone ratings (rater1, rater2)"
}

print(json.dumps(output))