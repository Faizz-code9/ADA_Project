import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

def main():
    file_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_synthetic_confirmatory_T1.0_r1/data.csv"
    df = pd.read_csv(file_path)

    # Missing data strategy: listwise deletion for missing skin_tone
    initial_len = len(df)
    df_clean = df.dropna(subset=['skin_tone']).copy()
    exclusions = f"Dropped {initial_len - len(df_clean)} rows with missing skin_tone"

    # Outcome is redCards (count, 0 to 3) with games as exposure / offset
    # Negative binomial or Poisson regression with log(games) offset
    # Since redCards are grouped by player-referee pairs, clustering on playerID or refereeID
    # Clustered standard errors on playerID (since skin_tone is assigned at player level)
    df_clean['log_games'] = np.log(df_clean['games'])

    # Covariates: position, height, weight, leagueCountry, yellowCards
    formula = "redCards ~ skin_tone + C(position) + height + weight + C(leagueCountry) + yellowCards"

    # Poisson model with exposure (log_games)
    model = smf.poisson(formula, data=df_clean, offset=df_clean['log_games'])
    
    # Cluster on playerID
    fit_res = model.fit(cov_type='cluster', cov_kwds={'groups': df_clean['playerID']}, disp=False)

    beta = fit_res.params['skin_tone']
    se = fit_res.bse['skin_tone']
    p_val = fit_res.pvalues['skin_tone']

    # Incidence rate ratio (IRR) for full change 0 to 1
    irr = np.exp(beta)
    ci_lower = np.exp(beta - 1.959964 * se)
    ci_upper = np.exp(beta + 1.959964 * se)
    # Delta method standard error for IRR = exp(beta) * se
    irr_se = irr * se

    conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

    covariates = ["position", "height", "weight", "leagueCountry", "yellowCards", "games (as log offset)"]

    result = {
        "effect_size": float(irr),
        "effect_type": "irr",
        "standard_error": float(irr_se),
        "p_value": float(p_val),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": conclusion,
        "model_family": "poisson",
        "predictor_used": "skin_tone",
        "covariates_included": covariates,
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "clustered_se",
        "exclusions_applied": exclusions
    }

    print(json.dumps(result, indent=2))

if __name__ == "__main__":
    main()