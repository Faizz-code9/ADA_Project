import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

file_path = (
    "/kaggle/working/outputs/runs/gemini-3.8-flash_disguise_neutral_T0.7_r1/data.csv"
)

# Load data
cols_to_load = [
    "applicant_id",
    "loan_officer_id",
    "risk_evaluator_alpha_score",
    "risk_evaluator_beta_score",
    "loan_application_rejections",
    "credit_score_index",
    "annual_income_bracket",
    "total_applications_reviewed",
    "prior_approved_loans",
    "prior_conditional_loans",
    "prior_denied_loans",
    "repayment_performance_score",
    "formal_inquiry_notices",
    "elevated_risk_warnings",
    "financial_jurisdiction",
]

df = pd.read_csv(file_path, usecols=cols_to_load)

# Drop missing values in the primary variables and covariates
df = df.dropna(
    subset=[
        "risk_evaluator_alpha_score",
        "risk_evaluator_beta_score",
        "credit_score_index",
        "annual_income_bracket",
    ]
).copy()

# Average score of alpha and beta
df["risk_evaluator_score_mean"] = (
    df["risk_evaluator_alpha_score"] + df["risk_evaluator_beta_score"]
) / 2.0

# Outcome is binary/count: loan_application_rejections (values 0, 1, 2)
# Since the prompt asks for: "the ratio effect of the risk evaluator score on loan_application_rejections
# (an odds ratio for a binary outcome, or an incidence rate ratio for a count model; set effect_type accordingly),
# for the full change from 0 to 1."
# Let's fit a Poisson GLM / count model or logistic model.
# Since loan_application_rejections is count (values 0, 1, 2) with total_applications_reviewed as potential exposure or covariate,
# a Poisson regression with cluster-robust standard errors (clustered by applicant_id) is ideal for IRR.

covariates = [
    "credit_score_index",
    "annual_income_bracket",
    "total_applications_reviewed",
    "prior_approved_loans",
    "prior_conditional_loans",
    "prior_denied_loans",
    "repayment_performance_score",
    "formal_inquiry_notices",
    "elevated_risk_warnings",
]

# One-hot encode financial_jurisdiction
jurisdiction_dummies = pd.get_dummies(
    df["financial_jurisdiction"], prefix="jur", drop_first=True, dtype=float
)
X = pd.concat(
    [df[["risk_evaluator_score_mean"] + covariates], jurisdiction_dummies], axis=1
)
X = sm.add_constant(X)
y = df["loan_application_rejections"]

# Fit Poisson GLM with cluster-robust standard errors clustered at applicant_id
model = sm.GLM(y, X, family=sm.families.Poisson())
fit_result = model.fit(
    cov_type="cluster", cov_kwds={"groups": df["applicant_id"]}
)

# Extract estimand: IRR for risk_evaluator_score_mean
param_name = "risk_evaluator_score_mean"
beta = fit_result.params[param_name]
se = fit_result.bse[param_name]
p_val = fit_result.pvalues[param_name]

# 95% CI on log scale, then exponentiate
ci_low_log = beta - 1.959964 * se
ci_high_log = beta + 1.959964 * se

irr = np.exp(beta)
ci_lower = np.exp(ci_low_log)
ci_upper = np.exp(ci_high_log)

# Standard error of IRR via delta method: se(IRR) = IRR * se(beta)
irr_se = irr * se

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(irr_se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "risk_evaluator_score_mean (average of alpha and beta scores)",
    "covariates_included": covariates + list(jurisdiction_dummies.columns),
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "dropped rows with missing risk scores or covariates",
}

print(json.dumps(output))