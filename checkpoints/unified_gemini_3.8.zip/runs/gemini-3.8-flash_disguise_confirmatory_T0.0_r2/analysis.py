import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

file_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_disguise_confirmatory_T0.0_r2/data.csv"
df = pd.read_csv(file_path)

# Predictor: average of risk_evaluator_alpha_score and risk_evaluator_beta_score
# Both are continuous 0-1 scores with identical missingness (21,407 rows missing)
df["risk_evaluator_score"] = (
    df["risk_evaluator_alpha_score"] + df["risk_evaluator_beta_score"]
) / 2.0

# Outcome: loan_application_rejections
# Unique values: 0, 1, 2 (mean 0.01256, sd 0.1129). It's a count of rejections, mostly 0 and 1.
# Binary indicator (rejected > 0) or count model (Poisson / Negative Binomial).
# The prompt states:
# "Primary estimand: the ratio effect of the risk evaluator score on loan_application_rejections
# (an odds ratio for a binary outcome, or an incidence rate ratio for a count model; set effect_type accordingly),
# for the full change from 0 to 1. Use a continuous 0-1 score (alpha, beta or their average; say which in predictor_used).
# Do not dichotomize the predictor."

# Let's consider a logistic regression for any rejection (loan_application_rejections > 0)
# or Poisson regression. In loan audit datasets (like judge/officer designs or audit pairs),
# binary outcome (rejection: yes/no) with logistic regression or Poisson regression for rejections count.
# Notice loan_application_rejections max is 2, 98.8% are 0.
# Logistic regression for rejection (>=1) is standard and widely used in audit studies.
# But let's check if Poisson with IRR is natural since the prompt explicitly allows both:
# "(an odds ratio for a binary outcome, or an incidence rate ratio for a count model; set effect_type accordingly)"
# Let's use logistic regression with binary outcome `rejected = (loan_application_rejections > 0).astype(int)`
# Or Poisson regression on loan_application_rejections.
# Let's use logistic regression for binary rejection: loan_application_rejections > 0.
df["rejected"] = (df["loan_application_rejections"] > 0).astype(int)

# Covariates: credit_score_index, annual_income_bracket, total_applications_reviewed, prior_approved_loans, prior_conditional_loans, prior_denied_loans
covariates = [
    "credit_score_index",
    "annual_income_bracket",
    "total_applications_reviewed",
    "prior_approved_loans",
    "prior_denied_loans",
]

cols_needed = (
    ["rejected", "risk_evaluator_score", "applicant_id"] + covariates
)
analysis_df = df[cols_needed].dropna().copy()

# Fit Logistic regression with clustered standard errors at applicant level
X = analysis_df[["risk_evaluator_score"] + covariates]
X = sm.add_constant(X)
y = analysis_df["rejected"]
groups = analysis_df["applicant_id"]

model = sm.Logit(y, X)
fit_res = model.fit(cov_type="cluster", cov_kwds={"groups": groups}, disp=False)

# Extract effect of risk_evaluator_score
coef = fit_res.params["risk_evaluator_score"]
se = fit_res.bse["risk_evaluator_score"]
p_val = fit_res.pvalues["risk_evaluator_score"]
ci_lower_log = fit_res.conf_int().loc["risk_evaluator_score", 0]
ci_upper_log = fit_res.conf_int().loc["risk_evaluator_score", 1]

# Odds ratio
odds_ratio = np.exp(coef)
ci_lower_or = np.exp(ci_lower_log)
ci_upper_or = np.exp(ci_upper_log)
# Delta method SE for odds ratio: se(OR) approx OR * se(log_or)
se_or = odds_ratio * se

output = {
    "effect_size": float(odds_ratio),
    "effect_type": "odds_ratio",
    "standard_error": float(se_or),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower_or),
    "ci_upper": float(ci_upper_or),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "logistic",
    "predictor_used": "average of risk_evaluator_alpha_score and risk_evaluator_beta_score",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "none",
}

print(json.dumps(output, indent=2))