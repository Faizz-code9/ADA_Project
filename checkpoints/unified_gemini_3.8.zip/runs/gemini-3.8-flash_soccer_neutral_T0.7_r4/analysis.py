import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

# File path
DATA_PATH = "/kaggle/working/outputs/runs/gemini-3.8-flash_soccer_neutral_T0.7_r4/data.csv"

# Load data
df = pd.read_csv(DATA_PATH)

# Drop missing ratings (rater1, rater2)
df = df.dropna(subset=["rater1", "rater2"]).copy()

# Compute skin tone as the average of rater1 and rater2
df["skin_tone"] = (df["rater1"] + df["rater2"]) / 2.0

# Prepare outcome and exposure
# redCards is count of red cards, games is the number of games played in the dyad
df = df[df["games"] > 0].copy()

# Select covariates: height, weight, position (indicator), games (exposure/log offset)
# Position has some missing values; fill with 'Unknown' to avoid dropping 12% of data
df["position"] = df["position"].fillna("Unknown")
df["height"] = df["height"].fillna(df["height"].median())
df["weight"] = df["weight"].fillna(df["weight"].median())

# Fit a Poisson GLM with log link, offset = log(games), clustering SE by player
# Grouping variable: playerShort
pos_dummies = pd.get_dummies(df["position"], drop_first=True, dtype=float)
X = pd.concat([df[["skin_tone", "height", "weight"]], pos_dummies], axis=1)
X = sm.add_constant(X)
y = df["redCards"]
offset = np.log(df["games"])

# Fit Poisson GLM
model = sm.GLM(y, X, family=sm.families.Poisson(), offset=offset)
fit_res = model.fit(cov_type="cluster", cov_kwds={"groups": df["playerShort"]})

# Extract results for skin_tone (continuous 0 to 1, effect size for full change is exp(coef))
coef = fit_res.params["skin_tone"]
se = fit_res.bse["skin_tone"]
irr = np.exp(coef)
ci_lower = np.exp(coef - 1.96 * se)
ci_upper = np.exp(coef + 1.96 * se)
p_value = fit_res.pvalues["skin_tone"]

output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_value),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if p_value < 0.05 else "no_significant_effect",
    "model_family": "poisson",
    "predictor_used": "average of rater1 and rater2 (continuous 0-1)",
    "covariates_included": ["height", "weight", "position"],
    "missing_data_strategy": "listwise_deletion for ratings, median imputation for height and weight, missing category for position",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "rows missing rater1 or rater2"
}

print(json.dumps(output, indent=2))