import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

# File path
data_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_disguise_skeptical_T0.7_r1/data.csv"

# Load data
df = pd.read_csv(data_path)

# Predictor: average of risk_evaluator_alpha_score and risk_evaluator_beta_score
# Also note this is an audit disguise dataset (like judge sentencing / ethnicity bias).
# Here loan_application_rejections is the outcome (0, 1, 2; mostly 0).
# Let's inspect the estimand:
# "the ratio effect of the risk evaluator score on loan_application_rejections (an odds ratio for a binary outcome, or an incidence rate ratio for a count model; set effect_type accordingly), for the full change from 0 to 1. Use a continuous 0-1 score (alpha, beta or their average; say which in predictor_used). Do not dichotomize the predictor."

# Let's define the average risk score
df["risk_evaluator_mean_score"] = (
    df["risk_evaluator_alpha_score"] + df["risk_evaluator_beta_score"]
) / 2.0

# Outcome: loan_application_rejections
# We can use Poisson regression or Logistic regression. Since loan_application_rejections is counts (0, 1, 2) or binary,
# let's look at Poisson regression for count model, or logistic if dichotomized.
# A Poisson GLM fits counts naturally, with log link, giving an incidence rate ratio (IRR) = exp(beta).
# Let's use Poisson GLM, or Logistic regression where y > 0.
# The prompt says: "(an odds ratio for a binary outcome, or an incidence rate ratio for a count model; set effect_type accordingly), for the full change from 0 to 1."
# Poisson GLM with robust / clustered standard errors by applicant_id or loan_officer_id.
# Clustering at loan_officer_id or applicant_id? Both exist. applicant_id has 2,053 unique values, loan_officer_id has 3,147.
# Let's cluster by applicant_id (or loan_officer_id). Clustered SE by applicant_id makes sense as applicants have repeated reviews.

# Potential covariates: credit_score_index, annual_income_bracket, total_applications_reviewed, prior_approved_loans, prior_denied_loans
covariates = [
    "credit_score_index",
    "annual_income_bracket",
    "total_applications_reviewed",
    "prior_approved_loans",
    "prior_denied_loans",
    "repayment_performance_score",
]

cols_needed = (
    ["loan_application_rejections", "risk_evaluator_mean_score", "applicant_id"]
    + covariates
)
df_clean = df.dropna(subset=cols_needed).copy()

X = df_clean[["risk_evaluator_mean_score"] + covariates]
X = sm.add_constant(X)
y = df_clean["loan_application_rejections"]

# Fit Poisson GLM
model = sm.GLM(y, X, family=sm.families.Poisson())
# Cluster robust standard errors on applicant_id
result = model.fit(
    cov_type="cluster", cov_kwds={"groups": df_clean["applicant_id"]}
)

# Extract effect for risk_evaluator_mean_score
param_idx = "risk_evaluator_mean_score"
coef = result.params[param_idx]
se_coef = result.bse[param_idx]
p_val = result.pvalues[param_idx]
ci_lower_coef = result.conf_int().loc[param_idx, 0]
ci_upper_coef = result.conf_int().loc[param_idx, 1]

irr = float(np.exp(coef))
ci_lower = float(np.exp(ci_lower_coef))
ci_upper = float(np.exp(ci_upper_coef))
# SE of IRR by delta method: SE(exp(b)) = exp(b) * SE(b)
se_irr = float(irr * se_coef)

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
    "effect_size": round(irr, 4),
    "effect_type": "irr",
    "standard_error": round(se_irr, 4),
    "p_value": round(float(p_val), 6),
    "ci_lower": round(ci_lower, 4),
    "ci_upper": round(ci_upper, 4),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "risk_evaluator_mean_score (average of alpha and beta scores)",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "dropped rows with missing values in predictor, outcome, or covariates",
}

print(json.dumps(output, indent=2))