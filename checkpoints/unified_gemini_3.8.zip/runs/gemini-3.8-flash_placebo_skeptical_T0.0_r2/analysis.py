import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

# 1. Load the dataset
data_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_placebo_skeptical_T0.0_r2/data.csv"
df = pd.read_csv(data_path)

# 2. Data Cleaning & Variable Construction
# Predictor: average of rater1 and rater2
# Exclude rows with missing skin tone ratings
df = df.dropna(subset=["rater1", "rater2"]).copy()
df["skin_tone"] = (df["rater1"] + df["rater2"]) / 2.0

# Outcome: redCards
# Covariates: games (exposure/log offset or covariate), position, leagueCountry
# Keep games > 0
df = df[df["games"] > 0].copy()

# Fill missing position as 'Unknown' to avoid losing 12% of data
df["position"] = df["position"].fillna("Unknown")

# Select relevant covariates
# Standardizing or including key confounders: leagueCountry, position, games
df["log_games"] = np.log(df["games"])

# Fit a Poisson GLM with log(games) as offset and cluster-robust standard errors on playerShort
# Formula: redCards ~ skin_tone + C(leagueCountry) + C(position) with offset = log(games)
covariates = ["skin_tone", "leagueCountry", "position"]
model_df = df[["redCards", "skin_tone", "leagueCountry", "position", "log_games", "playerShort"]].dropna()

# Create dummy variables
X = pd.get_dummies(model_df[["skin_tone", "leagueCountry", "position"]], drop_first=True, dtype=float)
X = sm.add_constant(X)
y = model_df["redCards"]
offset = model_df["log_games"]
clusters = model_df["playerShort"]

# Fit Poisson model with cluster-robust standard errors
poisson_model = sm.GLM(
    y,
    X,
    family=sm.families.Poisson(),
    offset=offset
)
res = poisson_model.fit(cov_type="cluster", cov_kwds={"groups": clusters})

# Skin tone coefficient (log IRR)
beta = res.params["skin_tone"]
se_beta = res.bse["skin_tone"]
pval = res.pvalues["skin_tone"]
ci_lower_beta, ci_upper_beta = res.conf_int().loc["skin_tone"]

# Compute IRR and CI on IRR scale
irr = float(np.exp(beta))
irr_ci_lower = float(np.exp(ci_lower_beta))
irr_ci_upper = float(np.exp(ci_upper_beta))
# Using delta method for IRR standard error: SE(IRR) = IRR * SE(beta)
irr_se = float(irr * se_beta)

conclusion = "significant_effect" if pval < 0.05 else "no_significant_effect"

output = {
    "effect_size": irr,
    "effect_type": "irr",
    "standard_error": irr_se,
    "p_value": float(pval),
    "ci_lower": irr_ci_lower,
    "ci_upper": irr_ci_upper,
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "average of rater1 and rater2",
    "covariates_included": ["leagueCountry", "position", "log_games_offset"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "Excluded rows with missing rater1 or rater2, or games <= 0"
}

print(json.dumps(output, indent=2))