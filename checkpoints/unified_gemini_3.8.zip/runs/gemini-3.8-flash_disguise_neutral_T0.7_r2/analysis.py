import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

# File path
data_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_disguise_neutral_T0.7_r2/data.csv"

# Load data
df = pd.read_csv(data_path)

# Predictor: average of risk_evaluator_alpha_score and risk_evaluator_beta_score
# Both are continuous 0-1 scores
df["risk_evaluator_avg_score"] = (
    df["risk_evaluator_alpha_score"] + df["risk_evaluator_beta_score"]
) / 2.0

# Outcome: loan_application_rejections (binary: values 0, 1, 2; mostly 0/1 or count)
# Outcome has 3 unique values: 0, 1, 2. Let's inspect logistic (rejections > 0) or Poisson.
# Task specifies: "an odds ratio for a binary outcome, or an incidence rate ratio for a count model; set effect_type accordingly"
# A logistic regression on binary rejection (loan_application_rejections > 0) or Poisson GLM.
# Poisson GLM with offset/exposure or simple Poisson regression for loan_application_rejections.
# Alternatively, binary indicator: y = (loan_application_rejections > 0).astype(int), or Poisson regression.
# Let's check Poisson: y is count of rejections, with log-link, IRR is standard.
# Or logistic regression on (loan_application_rejections > 0). Let's use Poisson GLM or Logistic.
# Since mean is 0.01256 and unique values are 0, 1, 2, Poisson GLM provides incidence rate ratio (IRR) directly for the count.
# Or Logistic regression: y_binary = (df['loan_application_rejections'] > 0).astype(int).
# Let's fit logistic regression: y = (df['loan_application_rejections'] > 0).astype(int).
# Wait, let's see which is cleaner. Poisson GLM: effect_type = 'irr', or Logistic: effect_type = 'odds_ratio'.
# Either is explicitly allowed: "an odds ratio for a binary outcome, or an incidence rate ratio for a count model; set effect_type accordingly"
# Let's use logistic regression with binary outcome (rejection >= 1 vs 0).

df["rejected_binary"] = (df["loan_application_rejections"] > 0).astype(int)

# Covariates to control for confounding
covariates = [
    "credit_score_index",
    "annual_income_bracket",
    "total_applications_reviewed",
    "prior_approved_loans",
    "prior_conditional_loans",
    "prior_denied_loans",
    "repayment_performance_score",
    "formal_inquiry_notices",
    "elevated_risk_warnings",
]

cols_needed = (
    ["rejected_binary", "risk_evaluator_avg_score", "loan_officer_id"]
    + covariates
)
df_clean = df.dropna(subset=cols_needed).copy()

# Fit logistic model with clustered standard errors at loan officer level
X = df_clean[["risk_evaluator_avg_score"] + covariates]
X = sm.add_constant(X)
y = df_clean["rejected_binary"]

model = sm.Logit(y, X)
res = model.fit(
    cov_type="cluster",
    cov_kwds={"groups": df_clean["loan_officer_id"]},
    disp=False,
)

pred_name = "risk_evaluator_avg_score"
beta = res.params[pred_name]
se = res.bse[pred_name]
p_val = res.pvalues[pred_name]

# Odds ratio for full 0 to 1 change
odds_ratio = np.exp(beta)
ci_lower = np.exp(beta - 1.959964 * se)
ci_upper = np.exp(beta + 1.959964 * se)
# SE of odds ratio via delta method: SE(exp(beta)) = exp(beta) * SE(beta)
se_or = odds_ratio * se

output = {
    "effect_size": float(odds_ratio),
    "effect_type": "odds_ratio",
    "standard_error": float(se_or),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": (
        "significant_effect" if p_val < 0.05 else "no_significant_effect"
    ),
    "model_family": "logistic",
    "predictor_used": "risk_evaluator_avg_score (average of alpha and beta scores)",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "dropped rows with missing risk scores or covariates",
}

print(json.dumps(output, indent=2))