import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_soccer_confirmatory_T1.0_r3/data.csv"
df = pd.read_csv(file_path)

# 2. Data Cleaning & Preparation
# Drop rows missing raters or games <= 0
df = df.dropna(subset=['rater1', 'rater2', 'redCards', 'games']).copy()
df = df[df['games'] > 0].copy()

# Average skin tone rating (continuous 0 to 1)
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2.0

# Optional covariates: position (handle missing as 'Unknown'), height, weight
df['position'] = df['position'].fillna('Unknown')
# Impute median height/weight if missing to retain sample size
df['height'] = df['height'].fillna(df['height'].median())
df['weight'] = df['weight'].fillna(df['weight'].median())

# Fit a negative binomial or Poisson count model for red cards with exposure = log(games)
# Red cards are rare counts. A Poisson or Negative Binomial regression with log(games) offset is standard.
# Cluster on player to account for repeated player observations.
df['log_games'] = np.log(df['games'])

# Design matrix: skin_tone + covariates
covars = ['height', 'weight']
pos_dummies = pd.get_dummies(df['position'], drop_first=True, dtype=float)
X = pd.concat([df[['skin_tone'] + covars], pos_dummies], axis=1)
X = sm.add_constant(X)
y = df['redCards']
exposure = df['log_games']

# Poisson model with robust clustered standard errors at player level
model = sm.GLM(
    y, X, 
    family=sm.families.Poisson(), 
    offset=exposure
)
result = model.fit(cov_type='cluster', cov_kwds={'groups': df['playerShort']})

# Extract estimand (Incidence Rate Ratio for 1-unit increase in skin tone)
beta = result.params['skin_tone']
se_beta = result.bse['skin_tone']
irr = float(np.exp(beta))
ci_low = float(np.exp(beta - 1.96 * se_beta))
ci_high = float(np.exp(beta + 1.96 * se_beta))
p_val = float(result.pvalues['skin_tone'])
# Delta method SE for IRR: se(exp(beta)) = exp(beta) * se(beta)
irr_se = float(irr * se_beta)

output = {
    "effect_size": irr,
    "effect_type": "irr",
    "standard_error": irr_se,
    "p_value": p_val,
    "ci_lower": ci_low,
    "ci_upper": ci_high,
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "poisson",
    "predictor_used": "average of rater1 and rater2 (skin_tone)",
    "covariates_included": ["height", "weight", "position", "log_games (offset)"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "Excluded rows missing rater1 or rater2, and rows with games <= 0"
}

print(json.dumps(output, indent=2))