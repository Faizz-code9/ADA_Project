import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

def main():
    file_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_synthetic_skeptical_T0.7_r1/data.csv"
    df = pd.read_csv(file_path)

    # Missing data strategy: listwise deletion for missing skin_tone
    initial_len = len(df)
    df_clean = df.dropna(subset=['skin_tone']).copy()
    dropped_rows = initial_len - len(df_clean)

    # Outcome is redCards (count: 0, 1, 2, 3), games is exposure.
    # Poisson regression or Negative Binomial regression with log(games) as offset.
    # Check for clustering by referee or player: clustered SE at refereeID or playerID.
    # Given referee bias is examined across referees and players, clustering by refereeID is standard,
    # or using robust/sandwich cluster SE.
    # Model: redCards ~ skin_tone + position + height + weight + leagueCountry + yellowCards, offset=log(games)
    
    # Negative binomial / Poisson regression
    formula = "redCards ~ skin_tone + C(position) + height + weight + C(leagueCountry) + yellowCards"
    
    # Fit Poisson model with offset
    poisson_model = smf.poisson(formula, data=df_clean, offset=np.log(df_clean['games']))
    # Use clustered standard errors by refereeID
    res = poisson_model.fit(cov_type='cluster', cov_kwds={'groups': df_clean['refereeID']}, disp=False)

    # Check alpha/dispersion: if needed or robust SE takes care of overdispersion. Clustered sandwich SE accounts for overdispersion and clustering.
    param_name = 'skin_tone'
    beta = res.params[param_name]
    se = res.bse[param_name]
    p_val = res.pvalues[param_name]
    
    # Primary estimand: IRR for full change from 0 to 1
    irr = float(np.exp(beta))
    ci_lower = float(np.exp(beta - 1.96 * se))
    ci_upper = float(np.exp(beta + 1.96 * se))
    # Standard error of IRR via delta method: se(IRR) = IRR * se(beta)
    irr_se = float(irr * se)

    conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

    output = {
        "effect_size": irr,
        "effect_type": "irr",
        "standard_error": irr_se,
        "p_value": float(p_val),
        "ci_lower": ci_lower,
        "ci_upper": ci_upper,
        "conclusion": conclusion,
        "model_family": "poisson",
        "predictor_used": "skin_tone",
        "covariates_included": ["position", "height", "weight", "leagueCountry", "yellowCards", "games (offset)"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "clustered_se",
        "exclusions_applied": f"Dropped {dropped_rows} rows with missing skin_tone"
    }

    print(json.dumps(output, indent=2))

if __name__ == '__main__':
    main()