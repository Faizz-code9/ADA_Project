import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

# 1. Load data
data_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_soccer_confirmatory_T1.0_r5/data.csv"
df = pd.read_csv(data_path)

# 2. Data Cleaning & Variable Construction
# Predictor: average of rater1 and rater2
df = df.dropna(subset=['rater1', 'rater2', 'redCards', 'games']).copy()
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2.0

# Outcome: red cards. Each row represents 'games' played between player and ref.
# To model red cards, Poisson/Negative Binomial regression with log(games) exposure is standard and robust.
# Alternatively, binary logistic regression for whether at least one red card was given, or binomial glm.
# Here, primary estimand is ratio effect (IRR) using Poisson regression with robust/clustered standard errors.
# We include player position (grouped or filled), leagueCountry, and cluster by playerShort.

df['has_position'] = df['position'].fillna('Unknown')
df['log_games'] = np.log(df['games'])

# Design matrix: skin_tone, leagueCountry, position
covariates = ['leagueCountry', 'has_position']
X = pd.get_dummies(df[['skin_tone'] + covariates], drop_first=True, dtype=float)
X = sm.add_constant(X)
y = df['redCards']
exposure = df['games']

# 3. Fit Poisson GLM with cluster-robust standard errors (clustered by player)
model = sm.GLM(
    y, 
    X, 
    family=sm.families.Poisson(), 
    exposure=exposure
)
# Cluster on player
result = model.fit(cov_type='cluster', cov_kwds={'groups': df['playerShort']})

# 4. Extract primary estimand (skin_tone IRR)
coef = result.params['skin_tone']
se = result.bse['skin_tone']
p_val = result.pvalues['skin_tone']
ci_low_log, ci_upp_log = result.conf_int().loc['skin_tone']

irr = np.exp(coef)
ci_lower = np.exp(ci_low_log)
ci_upper = np.exp(ci_upp_log)
# Delta method for SE of IRR: SE(exp(beta)) ~ exp(beta) * SE(beta)
se_irr = irr * se

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se_irr),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "average of rater1 and rater2",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "dropped rows with missing rater1, rater2, redCards, or games"
}

print(json.dumps(output, indent=2))