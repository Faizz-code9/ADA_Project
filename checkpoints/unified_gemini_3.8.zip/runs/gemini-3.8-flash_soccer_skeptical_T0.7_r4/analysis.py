import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

def run_analysis():
    data_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_soccer_skeptical_T0.7_r4/data.csv"
    df = pd.read_csv(data_path)
    
    # Exclude rows with missing rater scores
    df_clean = df.dropna(subset=['rater1', 'rater2', 'games', 'redCards']).copy()
    
    # Predictor: average of rater1 and rater2 (continuous 0-1)
    df_clean['skintone'] = (df_clean['rater1'] + df_clean['rater2']) / 2.0
    
    # Outcome: redCards as count, games as exposure
    # Poisson regression with exposure = games
    # Include position if available or other basic covariates, but position has 12% missing.
    # Standard many-analysts approach: Poisson GLM with cluster-robust standard errors on player
    # Let's adjust for height, weight, and leagueCountry to control for basic player/league characteristics
    model_df = df_clean.dropna(subset=['skintone', 'games', 'redCards', 'height', 'weight', 'leagueCountry']).copy()
    
    # Filter out games <= 0 if any
    model_df = model_df[model_df['games'] > 0]
    
    # Fit Poisson regression with offset = log(games)
    # Using statsmodels GLM
    formula = "redCards ~ skintone + height + weight + C(leagueCountry)"
    import statsmodels.formula.api as smf
    
    model = smf.glm(
        formula=formula,
        data=model_df,
        family=sm.families.Poisson(),
        offset=np.log(model_df['games'])
    )
    
    # Cluster standard errors by player
    results = model.fit(cov_type='cluster', cov_kwds={'groups': model_df['playerShort']})
    
    coef = float(results.params['skintone'])
    se = float(results.bse['skintone'])
    p_val = float(results.pvalues['skintone'])
    
    # Incidence Rate Ratio (IRR) for a 0 -> 1 change in skin tone
    irr = float(np.exp(coef))
    ci_lower = float(np.exp(coef - 1.95996 * se))
    ci_upper = float(np.exp(coef + 1.95996 * se))
    
    conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"
    
    out = {
        "effect_size": irr,
        "effect_type": "irr",
        "standard_error": se,
        "p_value": p_val,
        "ci_lower": ci_lower,
        "ci_upper": ci_upper,
        "conclusion": conclusion,
        "model_family": "poisson",
        "predictor_used": "average of rater1 and rater2",
        "covariates_included": ["height", "weight", "leagueCountry"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "clustered_se",
        "exclusions_applied": "dropped rows with missing skin tone ratings, height, weight, or games <= 0"
    }
    
    print(json.dumps(out))

if __name__ == '__main__':
    run_analysis()