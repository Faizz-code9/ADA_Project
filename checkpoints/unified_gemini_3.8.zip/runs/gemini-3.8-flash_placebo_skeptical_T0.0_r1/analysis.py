import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

def main():
    file_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_placebo_skeptical_T0.0_r1/data.csv"
    df = pd.read_csv(file_path)

    # Exclude rows missing rater1 or rater2
    df = df.dropna(subset=['rater1', 'rater2', 'games', 'redCards']).copy()

    # Predictor: average of rater1 and rater2
    df['skin_tone'] = (df['rater1'] + df['rater2']) / 2.0

    # Ensure games > 0 for offset
    df = df[df['games'] > 0].copy()
    df['log_games'] = np.log(df['games'])

    # Standard model for soccer referee bias (Silberzahn et al. 2018):
    # Poisson / Negative Binomial regression with exposure = games
    # Adjusting for position, leagueCountry, height, weight
    covariates = ['leagueCountry', 'position', 'height', 'weight']
    df_clean = df.dropna(subset=['skin_tone', 'redCards', 'games', 'refNum'] + covariates).copy()

    # Fit Poisson model with log(games) offset and clustered standard errors by refNum
    formula = "redCards ~ skin_tone + C(leagueCountry) + C(position) + height + weight"
    model = smf.poisson(formula, data=df_clean, offset=df_clean['log_games'])
    res = model.fit(cov_type='cluster', cov_kwds={'groups': df_clean['refNum']}, disp=False)

    beta = res.params['skin_tone']
    se_beta = res.bse['skin_tone']
    irr = float(np.exp(beta))
    ci_lower = float(np.exp(beta - 1.95996 * se_beta))
    ci_upper = float(np.exp(beta + 1.95996 * se_beta))
    irr_se = float(irr * se_beta) # Delta method standard error for IRR
    p_val = float(res.pvalues['skin_tone'])

    conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

    output = {
        "effect_size": irr,
        "effect_type": "irr",
        "standard_error": irr_se,
        "p_value": p_val,
        "ci_lower": ci_lower,
        "ci_upper": ci_upper,
        "conclusion": conclusion,
        "model_family": "poisson",
        "predictor_used": "mean of rater1 and rater2",
        "covariates_included": covariates,
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "clustered_se",
        "exclusions_applied": "Dropped missing ratings, non-positive games, and missing covariate rows"
    }

    print(json.dumps(output, indent=2))

if __name__ == '__main__':
    main()