import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

# 1. Load data
data_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_soccer_confirmatory_T1.0_r1/data.csv"
df = pd.read_csv(data_path)

# 2. Data Cleaning & Variable Construction
# Predictor: average of rater1 and rater2
df["skin_tone"] = (df["rater1"] + df["rater2"]) / 2.0

# Outcome: redCards
# Total exposure: games
# Exclude missing skin_tone or missing position/games
covars = ["position"]
sub_cols = ["redCards", "games", "skin_tone", "playerShort"] + covars
df_clean = df.dropna(subset=["skin_tone", "games", "redCards"]).copy()
# Filter games > 0
df_clean = df_clean[df_clean["games"] > 0]

# Handling position missingness by categorizing as "Unknown" to preserve sample size or listwise deletion
# Common standard is listwise deletion on missing position or adjusting for it
df_clean = df_clean.dropna(subset=["position", "playerShort"])

# Fit a Poisson GLM / Negative Binomial / Logistic
# Given redCards are count data per player-referee dyad with games as exposure, Poisson regression with log(games) offset is standard.
# Account for clustering at the player level (playerShort) using clustered standard errors.
df_clean["log_games"] = np.log(df_clean["games"])

# Position dummies
pos_dummies = pd.get_dummies(df_clean["position"], drop_first=True, dtype=float)
X = pd.concat([pd.Series(1.0, index=df_clean.index, name="const"), df_clean[["skin_tone"]], pos_dummies], axis=1)
y = df_clean["redCards"]
offset = df_clean["log_games"]
groups = df_clean["playerShort"]

# Fit Poisson GLM with cluster-robust standard errors
poisson_model = sm.GLM(
    y,
    X,
    family=sm.families.Poisson(),
    offset=offset
)
result = poisson_model.fit(cov_type="cluster", cov_kwds={"groups": groups})

coef = result.params["skin_tone"]
se = result.bse["skin_tone"]
p_val = result.pvalues["skin_tone"]
ci_lower_log = result.conf_int().loc["skin_tone", 0]
ci_upper_log = result.conf_int().loc["skin_tone", 1]

# Primary estimand: ratio effect (IRR for Poisson model) for full change from 0 to 1
irr = np.exp(coef)
ci_lower_irr = np.exp(ci_lower_log)
ci_upper_irr = np.exp(ci_upper_log)
# Delta method SE for exp(coef): SE(IRR) = IRR * SE(coef)
se_irr = irr * se

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se_irr),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower_irr),
    "ci_upper": float(ci_upper_irr),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "average of rater1 and rater2",
    "covariates_included": ["position"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "dropped rows with missing skin tone ratings or position"
}

print(json.dumps(output))