import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

file_path = (
    "/kaggle/working/outputs/runs/gemini-3.8-flash_disguise_confirmatory_T0.7_r1/data.csv"
)
df = pd.read_csv(file_path)

# Predictor: average of alpha and beta risk evaluation scores
df["risk_evaluator_score"] = (
    df["risk_evaluator_alpha_score"] + df["risk_evaluator_beta_score"]
) / 2.0

# Outcome: loan_application_rejections (count: 0, 1, 2)
# Hypothesis: higher risk evaluation scores -> rejected significantly more often.
# Model: Poisson or Negative Binomial / Logistic.
# Since loan_application_rejections is a count (unique values 3: 0, 1, 2), Poisson regression models rejections rate/count.
# Let's check covariates: credit_score_index, annual_income_bracket, total_applications_reviewed, financial_jurisdiction.
# Total applications reviewed can serve as an exposure / control variable.

cols_needed = [
    "loan_application_rejections",
    "risk_evaluator_score",
    "credit_score_index",
    "annual_income_bracket",
    "total_applications_reviewed",
    "applicant_id",
]

df_clean = df.dropna(subset=cols_needed).copy()

# Add log of total_applications_reviewed as offset or control for exposure
df_clean["log_applications"] = np.log(df_clean["total_applications_reviewed"])

# Fit Poisson regression with clustered standard errors at applicant_id level
X = df_clean[
    ["risk_evaluator_score", "credit_score_index", "annual_income_bracket"]
]
X = sm.add_constant(X)
y = df_clean["loan_application_rejections"]

model = sm.GLM(
    y,
    X,
    family=sm.families.Poisson(),
    offset=df_clean["log_applications"],
)
result = model.fit(
    cov_type="cluster", cov_kwds={"groups": df_clean["applicant_id"]}
)

# Extract estimand (IRR for full change 0 to 1 of risk_evaluator_score)
beta = result.params["risk_evaluator_score"]
se = result.bse["risk_evaluator_score"]
irr = float(np.exp(beta))
p_value = float(result.pvalues["risk_evaluator_score"])
ci_lower = float(np.exp(beta - 1.96 * se))
ci_upper = float(np.exp(beta + 1.96 * se))

# Delta method standard error for IRR = exp(beta) * se(beta)
se_irr = float(irr * se)

conclusion = "significant_effect" if p_value < 0.05 else "no_significant_effect"

output = {
    "effect_size": irr,
    "effect_type": "irr",
    "standard_error": se_irr,
    "p_value": p_value,
    "ci_lower": ci_lower,
    "ci_upper": ci_upper,
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "average of risk_evaluator_alpha_score and risk_evaluator_beta_score",
    "covariates_included": [
        "credit_score_index",
        "annual_income_bracket",
        "log_applications_offset",
    ],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "none",
}

print(json.dumps(output))