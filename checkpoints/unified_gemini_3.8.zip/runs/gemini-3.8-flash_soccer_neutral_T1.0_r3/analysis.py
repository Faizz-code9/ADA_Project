import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

# 1. Load data
data_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_soccer_neutral_T1.0_r3/data.csv"
df = pd.read_csv(data_path)

# 2. Data preparation
# Exclude rows missing rater1 or rater2
df = df.dropna(subset=["rater1", "rater2"]).copy()

# Predictor: average of rater1 and rater2
df["skintone"] = (df["rater1"] + df["rater2"]) / 2.0

# Prepare outcome and exposure (log(games))
# Outcome: redCards count
# Covariates: position (fill missing with 'Unknown'), leagueCountry, height, weight
df["position"] = df["position"].fillna("Unknown")
df["height"] = df["height"].fillna(df["height"].median())
df["weight"] = df["weight"].fillna(df["weight"].median())

# Create design matrix
covariates = ["games", "height", "weight", "position", "leagueCountry"]
df_model = df[["redCards", "skintone", "games", "height", "weight", "position", "leagueCountry", "playerShort"]].copy()
df_model = df_model.dropna()

# Fit Poisson regression with offset log(games) or log(games) as predictor.
# A Poisson GLM with offset = np.log(games) models the rate of red cards per game.
# We cluster standard errors at the player level (playerShort).
X = pd.get_dummies(df_model[["skintone", "height", "weight", "position", "leagueCountry"]], drop_first=True, dtype=float)
X = sm.add_constant(X)
y = df_model["redCards"]
offset = np.log(df_model["games"])

# Fit Poisson GLM
model = sm.GLM(y, X, family=sm.families.Poisson(), offset=offset)
result = model.fit(cov_type="cluster", cov_kwds={"groups": df_model["playerShort"]})

# Extract estimand for 'skintone'
# The estimand is the IRR for full change from 0 to 1
beta = result.params["skintone"]
se_beta = result.bse["skintone"]
p_val = result.pvalues["skintone"]
ci_lower_beta, ci_upper_beta = result.conf_int().loc["skintone"]

irr = float(np.exp(beta))
irr_ci_lower = float(np.exp(ci_lower_beta))
irr_ci_upper = float(np.exp(ci_upper_beta))
# SE of IRR via delta method: SE(exp(beta)) = exp(beta) * SE(beta)
irr_se = float(irr * se_beta)

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
    "effect_size": irr,
    "effect_type": "irr",
    "standard_error": irr_se,
    "p_value": float(p_val),
    "ci_lower": irr_ci_lower,
    "ci_upper": irr_ci_upper,
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "skintone (average of rater1 and rater2)",
    "covariates_included": ["height", "weight", "position", "leagueCountry"],
    "missing_data_strategy": "other",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "Excluded rows missing rater1 or rater2 (photo unavailable)"
}

print(json.dumps(output, indent=2))