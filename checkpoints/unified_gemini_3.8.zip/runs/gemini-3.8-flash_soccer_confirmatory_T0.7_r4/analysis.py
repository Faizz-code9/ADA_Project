import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

# 1. Load data
data_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_soccer_confirmatory_T0.7_r4/data.csv"
df = pd.read_csv(data_path)

# 2. Data Cleaning & Variable Construction
# Predictor: average of rater1 and rater2
df = df.dropna(subset=["rater1", "rater2", "redCards", "games", "playerShort"]).copy()
df["skin_tone"] = (df["rater1"] + df["rater2"]) / 2.0

# Aggregate to player level to avoid pseudo-replication across referees, or fit a count model
# A standard Poisson or Negative Binomial GLM with log(games) offset is standard for the many-analysts soccer dataset.
# Let's aggregate by player: total red cards, total games, skin tone, height, weight
player_df = df.groupby("playerShort").agg({
    "redCards": "sum",
    "games": "sum",
    "skin_tone": "first",
    "height": "first",
    "weight": "first"
}).reset_index()

# Drop missing covariates
player_df = player_df.dropna(subset=["skin_tone", "redCards", "games", "height", "weight"]).copy()
player_df = player_df[player_df["games"] > 0].copy()

# Add log(games) offset
player_df["log_games"] = np.log(player_df["games"])

# Model: Negative Binomial or Poisson GLM
# Let's use Poisson GLM with robust standard errors (quasi-poisson equivalent)
# Covariates: height, weight
X = player_df[["skin_tone", "height", "weight"]]
X = sm.add_constant(X)
y = player_df["redCards"]
offset = player_df["log_games"]

# Fit Poisson model with robust (HC1) covariance to handle overdispersion/clustering
model = sm.GLM(y, X, family=sm.families.Poisson(), offset=offset)
res = model.fit(cov_type='HC1')

# Primary estimand: Incidence Rate Ratio (IRR) for full change from 0 to 1
beta = res.params["skin_tone"]
se = res.bse["skin_tone"]
p_val = res.pvalues["skin_tone"]
irr = np.exp(beta)

# 95% CI on IRR scale
ci_lower_log = beta - 1.959964 * se
ci_upper_log = beta + 1.959964 * se
ci_lower = np.exp(ci_lower_log)
ci_upper = np.exp(ci_upper_log)

# Standard error of IRR via delta method: SE(IRR) = IRR * SE(beta)
irr_se = irr * se

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(irr_se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "mean of rater1 and rater2",
    "covariates_included": ["height", "weight"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "aggregated to player level; dropped cases with missing skin tone, height, or weight"
}

print(json.dumps(output, indent=2))