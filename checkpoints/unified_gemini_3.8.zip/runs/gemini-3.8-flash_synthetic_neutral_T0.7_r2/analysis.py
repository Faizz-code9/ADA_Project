import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
data_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_synthetic_neutral_T0.7_r2/data.csv"
df = pd.read_csv(data_path)

# 2. Data Cleaning & Preparation
# Drop missing values in skin_tone (listwise deletion)
initial_len = len(df)
df = df.dropna(subset=['skin_tone']).copy()
exclusions = f"Dropped {initial_len - len(df)} rows with missing skin_tone"

# Covariates: position, height, weight, leagueCountry, yellowCards
# Exposure offset: log(games)
df['log_games'] = np.log(df['games'])

# Model choice: Poisson or Negative Binomial regression with clustered standard errors on refereeID or playerID
# Since players are nested in dyad with referees, we can fit a Poisson / Negative Binomial GLM with offset=log(games)
# Let's check Poisson GLM with robust clustered SE on playerID (or refereeID; playerID is the unit of skin_tone).
# Clustering on playerID accounts for non-independence of repeated player observations across referees.
formula = "redCards ~ skin_tone + C(position) + height + weight + C(leagueCountry) + yellowCards"

# Fit Poisson GLM with offset
model = smf.glm(
    formula=formula,
    data=df,
    family=sm.families.Poisson(),
    offset=df['log_games']
)

# Robust cluster-adjusted standard errors by playerID
results = model.fit(cov_type='cluster', cov_kwds={'groups': df['playerID']})

# Extract results for skin_tone
coef = results.params['skin_tone']
se_coef = results.bse['skin_tone']
pval = results.pvalues['skin_tone']

# Estimand is incidence rate ratio (IRR) for full change from 0 to 1
irr = float(np.exp(coef))
ci_lower = float(np.exp(coef - 1.959964 * se_coef))
ci_upper = float(np.exp(coef + 1.959964 * se_coef))
# Standard error for IRR via delta method: se(exp(b)) = exp(b) * se(b)
irr_se = float(irr * se_coef)

conclusion = "significant_effect" if pval < 0.05 else "no_significant_effect"

output = {
    "effect_size": irr,
    "effect_type": "irr",
    "standard_error": irr_se,
    "p_value": float(pval),
    "ci_lower": ci_lower,
    "ci_upper": ci_upper,
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "skin_tone",
    "covariates_included": ["position", "height", "weight", "leagueCountry", "yellowCards", "log(games)"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": exclusions
}

print(json.dumps(output))