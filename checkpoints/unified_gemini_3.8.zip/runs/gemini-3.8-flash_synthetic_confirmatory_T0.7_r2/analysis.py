import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
data_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_synthetic_confirmatory_T0.7_r2/data.csv"
df = pd.read_csv(data_path)

# 2. Clean and prepare data
# Missing values in skin_tone (8%) - apply listwise deletion for complete case analysis on required variables
initial_len = len(df)
df_clean = df.dropna(subset=['skin_tone', 'redCards', 'games', 'position', 'height', 'weight', 'leagueCountry', 'playerID']).copy()
exclusions = f"Removed {initial_len - len(df_clean)} rows with missing skin_tone"

# 3. Fit statistical model
# Count model: Poisson / Negative Binomial regression with log(games) exposure offset
# redCards is a count outcome with repeated measures on players
df_clean['log_games'] = np.log(df_clean['games'])

formula = "redCards ~ skin_tone + C(position) + height + weight + C(leagueCountry)"
covariates = ["position", "height", "weight", "leagueCountry"]

# Fit Poisson model with offset and cluster-robust standard errors by playerID
model = smf.poisson(formula, data=df_clean, offset=df_clean['log_games'])
res = model.fit(cov_type='cluster', cov_kwds={'groups': df_clean['playerID']}, disp=False)

# 4. Extract primary estimand (IRR for full change from 0 to 1)
coef = res.params['skin_tone']
se_coef = res.bse['skin_tone']
p_value = float(res.pvalues['skin_tone'])
ci_lower_coef, ci_upper_coef = res.conf_int().loc['skin_tone']

irr = float(np.exp(coef))
irr_ci_lower = float(np.exp(ci_lower_coef))
irr_ci_upper = float(np.exp(ci_upper_coef))

# Delta method standard error for IRR: SE(exp(beta)) = exp(beta) * SE(beta)
se_irr = float(irr * se_coef)

conclusion = "significant_effect" if p_value < 0.05 else "no_significant_effect"

output = {
    "effect_size": irr,
    "effect_type": "irr",
    "standard_error": se_irr,
    "p_value": p_value,
    "ci_lower": irr_ci_lower,
    "ci_upper": irr_ci_upper,
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "skin_tone",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": exclusions
}

print(json.dumps(output, indent=2))