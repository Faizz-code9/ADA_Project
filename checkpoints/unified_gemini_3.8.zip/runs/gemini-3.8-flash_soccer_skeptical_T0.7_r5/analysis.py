import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
data_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_soccer_skeptical_T0.7_r5/data.csv"
df = pd.read_csv(data_path)

# 2. Data cleaning & variable preparation
# Main predictor: average of rater1 and rater2
df = df.dropna(subset=['rater1', 'rater2', 'games', 'redCards']).copy()
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2.0

# Account for exposure: log(games) as offset
df['log_games'] = np.log(df['games'])

# Optional covariates: position (handle missing as 'Unknown')
df['position_clean'] = df['position'].fillna('Unknown')

# Subset columns to drop missing in covariates if any
df = df.dropna(subset=['height', 'weight']).copy()

# 3. Fit Poisson regression model with clustered standard errors on player level
# Primary estimand: IRR for full change from 0 to 1
formula = "redCards ~ skin_tone + height + weight + C(position_clean) + C(leagueCountry)"

poisson_mod = smf.poisson(formula, data=df, offset=df['log_games'])
res = poisson_mod.fit(cov_type='cluster', cov_kwds={'groups': df['playerShort']}, disp=False)

# 4. Extract estimates
coef = res.params['skin_tone']
se = res.bse['skin_tone']
p_val = res.pvalues['skin_tone']

# Incidence Rate Ratio
irr = np.exp(coef)
ci_lower = np.exp(coef - 1.959964 * se)
ci_upper = np.exp(coef + 1.959964 * se)

# IRR standard error via delta method: SE(IRR) = IRR * SE(coef)
irr_se = irr * se

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(irr_se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "skin_tone (average of rater1 and rater2)",
    "covariates_included": ["height", "weight", "position_clean", "leagueCountry", "log_games (offset)"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "Excluded rows with missing skin tone ratings, height, or weight"
}

print(json.dumps(output, indent=2))