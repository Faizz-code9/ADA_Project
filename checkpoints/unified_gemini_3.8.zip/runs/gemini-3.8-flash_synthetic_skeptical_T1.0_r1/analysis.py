import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

file_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_synthetic_skeptical_T1.0_r1/data.csv"
df = pd.read_csv(file_path)

# Drop missing values in skin_tone
df_clean = df.dropna(subset=['skin_tone']).copy()

# Outcome is count of redCards with exposure 'games'
# Poisson regression with log(games) as offset
# Cluster SE at refereeID or playerID level (playerID is level of skin_tone, refereeID gives cards)
# Let's fit a Poisson regression with cluster-robust standard errors on refereeID or playerID.
# Standard soccer crowd-sourcing analysis uses Poisson / NegBin with exposure=games or log(games).
covariates = ['position', 'height', 'weight', 'leagueCountry', 'yellowCards']
formula = "redCards ~ skin_tone + C(position) + height + weight + C(leagueCountry) + yellowCards"

# Offset is log(games)
offset = np.log(df_clean['games'])

model = smf.glm(
    formula=formula,
    data=df_clean,
    family=sm.families.Poisson(),
    offset=offset
)

# Fit with cluster-robust standard errors at the playerID level (since skin_tone is assigned at player level)
# Or cluster by refereeID. In statsmodels, cov_type='cluster', cov_kwds={'groups': df_clean['playerID']}
res = model.fit(cov_type='cluster', cov_kwds={'groups': df_clean['playerID']})

coef = res.params['skin_tone']
se_coef = res.bse['skin_tone']
p_val = res.pvalues['skin_tone']
irr = np.exp(coef)
ci_lower = np.exp(coef - 1.96 * se_coef)
ci_upper = np.exp(coef + 1.96 * se_coef)
# Standard error of IRR via delta method: se(IRR) = IRR * se(coef)
se_irr = irr * se_coef

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se_irr),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "skin_tone",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "dropped rows with missing skin_tone"
}

print(json.dumps(output))