import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
data_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_synthetic_skeptical_T1.0_r2/data.csv"
df = pd.read_csv(data_path)

# 2. Data preparation
# Exclude missing skin_tone
initial_len = len(df)
df_clean = df.dropna(subset=['skin_tone']).copy()
exclusions = f"Removed {initial_len - len(df_clean)} rows with missing skin_tone"

# Outcome: redCards count with exposure = games (log(games) as offset)
# Poisson / Negative binomial regression
# Covariates: position, height, weight, leagueCountry, yellowCards
# Clustering by refereeID or playerID. Since dyads are player-referee, GEE or clustered SE by refereeID / playerID.
# Using Poisson GLM with offset log(games) and clustered SE on refereeID (or playerID).

formula = "redCards ~ skin_tone + C(position) + height + weight + C(leagueCountry) + yellowCards"

# Fit Poisson model with log(games) as offset
# Using statsmodels GLM with Poisson family and clustered standard errors by refereeID
cov_cols = ["position", "height", "weight", "leagueCountry", "yellowCards"]

model = smf.glm(
    formula=formula,
    data=df_clean,
    family=sm.families.Poisson(),
    offset=np.log(df_clean['games'])
)

# Fit with robust cluster-adjusted standard errors by refereeID
results = model.fit(cov_type='cluster', cov_kwds={'groups': df_clean['refereeID']})

# Extract skin_tone coefficient, SE, p-value, CI
coef = results.params['skin_tone']
se = results.bse['skin_tone']
pval = results.pvalues['skin_tone']
ci_low_coef, ci_high_coef = results.conf_int().loc['skin_tone']

# Estimand is Incidence Rate Ratio (IRR) for full change from 0 to 1
irr = np.exp(coef)
# Standard error for IRR via delta method: SE(exp(b)) = exp(b) * SE(b)
irr_se = irr * se
irr_ci_low = np.exp(ci_low_coef)
irr_ci_high = np.exp(ci_high_coef)

conclusion = "significant_effect" if pval < 0.05 else "no_significant_effect"

output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(irr_se),
    "p_value": float(pval),
    "ci_lower": float(irr_ci_low),
    "ci_upper": float(irr_ci_high),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "skin_tone",
    "covariates_included": cov_cols,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": exclusions
}

print(json.dumps(output))