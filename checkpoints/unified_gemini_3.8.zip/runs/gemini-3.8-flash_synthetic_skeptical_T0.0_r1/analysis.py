import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
data_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_synthetic_skeptical_T0.0_r1/data.csv"
df = pd.read_csv(data_path)

# 2. Clean and prepare data
# Missing values in skin_tone (8%), listwise deletion
initial_len = len(df)
df = df.dropna(subset=['skin_tone']).copy()
exclusions = f"Removed {initial_len - len(df)} rows with missing skin_tone"

# 3. Fit Model
# Outcome: redCards is a count variable (0 to 3) with exposure = games.
# Poisson or Negative Binomial regression with offset np.log(games) is standard.
# Account for clustering by playerID or refereeID using cluster-robust SEs (e.g. playerID).
formula = "redCards ~ skin_tone + height + weight + C(position) + C(leagueCountry)"

# Fit Poisson GLM with offset=log(games) and clustered SE on playerID
model = smf.glm(
    formula=formula,
    data=df,
    family=sm.families.Poisson(),
    offset=np.log(df['games'])
)

# Cluster robust standard errors at the player level (since skin_tone is assigned at player level)
res = model.fit(cov_type='cluster', cov_kwds={'groups': df['playerID']})

# Extract skin_tone parameters
coef = res.params['skin_tone']
se_coef = res.bse['skin_tone']
pval = res.pvalues['skin_tone']
ci_coef_lower, ci_coef_upper = res.conf_int().loc['skin_tone']

# Estimand is Incidence Rate Ratio (IRR) for full change from 0 to 1
irr = float(np.exp(coef))
ci_lower = float(np.exp(ci_coef_lower))
ci_upper = float(np.exp(ci_coef_upper))
# Standard error for IRR via delta method: SE(IRR) = IRR * SE(coef)
se_irr = float(irr * se_coef)

conclusion = "significant_effect" if pval < 0.05 else "no_significant_effect"

output = {
    "effect_size": irr,
    "effect_type": "irr",
    "standard_error": se_irr,
    "p_value": float(pval),
    "ci_lower": ci_lower,
    "ci_upper": ci_upper,
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "skin_tone",
    "covariates_included": ["height", "weight", "position", "leagueCountry", "games (as offset)"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": exclusions
}

print(json.dumps(output))