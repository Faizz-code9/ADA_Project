import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

# File path
data_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_soccer_neutral_T0.7_r2/data.csv"

# Load data
df = pd.read_csv(data_path)

# Drop missing ratings
df = df.dropna(subset=["rater1", "rater2"]).copy()

# Compute mean skin tone rating
df["skin_tone"] = (df["rater1"] + df["rater2"]) / 2.0

# Binary red card indicator (whether at least one red card received in the dyad)
# Primary estimand: odds ratio for red cards
df["has_red"] = (df["redCards"] > 0).astype(int)

# Covariates to adjust for confounding
# games (exposure), position (dummy coded, fill missing as 'Unknown'), leagueCountry
df["position"] = df["position"].fillna("Unknown")
df["log_games"] = np.log(df["games"])

# Include relevant covariates
covar_cols = ["position", "leagueCountry"]
df_model = pd.get_dummies(df[["skin_tone", "log_games", "has_red", "playerShort"] + covar_cols], 
                          columns=covar_cols, drop_first=True)

# Define X and y
y = df_model["has_red"]
X_cols = [c for c in df_model.columns if c not in ["has_red", "playerShort"]]
X = sm.add_constant(df_model[X_cols].astype(float))

# Fit logistic regression with clustering at player level (dyadic data)
logit_mod = sm.Logit(y, X)
fit_res = logit_mod.fit(cov_type="cluster", cov_kwds={"groups": df_model["playerShort"]}, disp=False)

# Extract skin_tone results
coef = fit_res.params["skin_tone"]
se = fit_res.bse["skin_tone"]
pval = fit_res.pvalues["skin_tone"]
odds_ratio = np.exp(coef)
ci_lower = np.exp(coef - 1.95996 * se)
ci_upper = np.exp(coef + 1.95996 * se)

# Output JSON
result = {
    "effect_size": float(odds_ratio),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(pval),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if pval < 0.05 else "no_significant_effect",
    "model_family": "logistic",
    "predictor_used": "average of rater1 and rater2",
    "covariates_included": ["log_games", "position", "leagueCountry"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "Excluded rows with missing rater1 or rater2"
}

print(json.dumps(result, indent=2))