import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

# 1. Load data
data_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_disguise_confirmatory_T0.0_r1/data.csv"
df = pd.read_csv(data_path)

# Predictor: average of alpha and beta risk scores (both on 0-1 scale)
df["risk_evaluator_score"] = (df["risk_evaluator_alpha_score"] + df["risk_evaluator_beta_score"]) / 2.0

# Outcome: loan_application_rejections (values 0, 1, 2; mean ~0.0125). Can treat as count or binary.
# The hypothesis asks if applicants with higher risk evaluation scores are rejected significantly more often.
# Let's check Poisson count model or Logistic regression.
# The prompt says: "the ratio effect of the risk evaluator score on loan_application_rejections (an odds ratio for a binary outcome, or an incidence rate ratio for a count model; set effect_type accordingly), for the full change from 0 to 1."
# Since loan_application_rejections has values 0, 1, 2, Poisson model with clustered SEs at applicant_id level is highly natural, or binary logistic regression (rejection > 0).
# Given it's a count (0, 1, 2), Poisson regression yields IRR for full change from 0 to 1.
# Alternatively, binary indicator rejection_any = (loan_application_rejections > 0).astype(int) with logistic regression.
# Let's use Poisson regression (IRR) on loan_application_rejections count, or logistic. Notice "loan_application_rejections" is a count of rejections.
# Let's include key applicant-level covariates: credit_score_index, annual_income_bracket, total_applications_reviewed.

covariates = ["credit_score_index", "annual_income_bracket", "total_applications_reviewed"]
analysis_cols = ["loan_application_rejections", "risk_evaluator_score", "applicant_id"] + covariates

df_subset = df[analysis_cols].dropna().copy()

X = df_subset[["risk_evaluator_score"] + covariates]
X = sm.add_constant(X)
y = df_subset["loan_application_rejections"]

# Fit Poisson model with robust / clustered standard errors by applicant_id
model = sm.GLM(y, X, family=sm.families.Poisson())
# Clustering on applicant_id
fit_res = model.fit(cov_type='cluster', cov_kwds={'groups': df_subset['applicant_id']})

coef = fit_res.params["risk_evaluator_score"]
se = fit_res.bse["risk_evaluator_score"]
irr = float(np.exp(coef))

# Delta method / exponentiated CI
ci_low = float(np.exp(fit_res.conf_int().loc["risk_evaluator_score", 0]))
ci_high = float(np.exp(fit_res.conf_int().loc["risk_evaluator_score", 1]))
p_val = float(fit_res.pvalues["risk_evaluator_score"])

# Standard error of IRR via delta method: SE(IRR) = IRR * SE(beta)
irr_se = float(irr * se)

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
    "effect_size": irr,
    "effect_type": "irr",
    "standard_error": irr_se,
    "p_value": p_val,
    "ci_lower": ci_low,
    "ci_upper": ci_high,
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "average of risk_evaluator_alpha_score and risk_evaluator_beta_score",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "dropped rows with missing risk scores or covariates"
}

print(json.dumps(output))