import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

# File path
data_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_soccer_skeptical_T1.0_r4/data.csv"

# Load data
df = pd.read_csv(data_path)

# Drop missing values in key variables
# Predictor: skin tone average of rater1 and rater2
df = df.dropna(subset=["rater1", "rater2", "redCards", "games", "playerShort"])

# Construct predictor: average of rater1 and rater2 (continuous 0 to 1)
df["skin_tone"] = (df["rater1"] + df["rater2"]) / 2.0

# Outcome is count of red cards with exposure = games
# We fit a Poisson regression with log(games) as offset
# Cluster standard errors on playerShort (or refNum, player is natural since skin tone is player-level)
df["log_games"] = np.log(df["games"])

# Covariates: position (impute missing as 'Unknown' to avoid losing 12% of data), leagueCountry
df["position_clean"] = df["position"].fillna("Unknown")

# Create design matrix
# Red cards count model (Poisson GLM with offset log_games)
X = pd.get_dummies(df[["skin_tone", "position_clean", "leagueCountry"]], drop_first=True, dtype=float)
X = sm.add_constant(X)
y = df["redCards"]

# Fit Poisson GLM with offset and clustered robust SE on player
model = sm.GLM(y, X, family=sm.families.Poisson(), offset=df["log_games"])
# Fit using cluster-robust standard errors
result = model.fit(cov_type="cluster", cov_kwds={"groups": df["playerShort"]})

# Extract skin_tone coefficient and statistics
coef = result.params["skin_tone"]
se = result.bse["skin_tone"]
p_val = result.pvalues["skin_tone"]
ci_low_log = result.conf_int().loc["skin_tone", 0]
ci_upp_log = result.conf_int().loc["skin_tone", 1]

# Primary estimand: Incidence Rate Ratio (IRR) for full change from 0 to 1
irr = float(np.exp(coef))
ci_lower = float(np.exp(ci_low_log))
ci_upper = float(np.exp(ci_upp_log))
# Delta method for SE of exp(coef) = exp(coef) * se
irr_se = float(irr * se)

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
    "effect_size": irr,
    "effect_type": "irr",
    "standard_error": irr_se,
    "p_value": float(p_val),
    "ci_lower": ci_lower,
    "ci_upper": ci_upper,
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "average of rater1 and rater2",
    "covariates_included": ["position_clean", "leagueCountry"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "dropped rows missing rater1 or rater2"
}

print(json.dumps(output, indent=2))