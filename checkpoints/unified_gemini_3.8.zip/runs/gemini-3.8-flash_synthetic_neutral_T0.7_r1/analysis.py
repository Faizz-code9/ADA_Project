import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

file_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_synthetic_neutral_T0.7_r1/data.csv"
df = pd.read_csv(file_path)

# Handle missing data
initial_len = len(df)
df_clean = df.dropna(subset=["skin_tone", "redCards", "games"]).copy()
exclusions = f"Removed {initial_len - len(df_clean)} rows with missing skin_tone"

# Filter out rows where games <= 0 if any (offset log(games) requires games > 0)
df_clean = df_clean[df_clean["games"] > 0].copy()

# Fit a Poisson or Negative Binomial regression with exposure/offset = log(games)
# Clustered standard errors at playerID level since multiple dyads per player
formula = "redCards ~ skin_tone + height + weight + C(position) + C(leagueCountry)"

# Fit Poisson GLM with offset = np.log(games)
poisson_model = smf.glm(
    formula=formula,
    data=df_clean,
    family=sm.families.Poisson(),
    offset=np.log(df_clean["games"])
)

# Cluster standard errors by playerID
res = poisson_model.fit(cov_type="cluster", cov_kwds={"groups": df_clean["playerID"]})

# Extract skin_tone parameter
coef = res.params["skin_tone"]
se = res.bse["skin_tone"]
pval = res.pvalues["skin_tone"]
ci_low_coef, ci_upp_coef = res.conf_int().loc["skin_tone"]

# Compute IRR (ratio effect for full change 0 to 1)
irr = float(np.exp(coef))
ci_lower = float(np.exp(ci_low_coef))
ci_upper = float(np.exp(ci_upp_coef))
# SE of IRR using delta method: SE(exp(beta)) = exp(beta) * SE(beta)
se_irr = float(irr * se)

conclusion = "significant_effect" if pval < 0.05 else "no_significant_effect"

covariates = ["height", "weight", "position", "leagueCountry", "games (exposure)"]

output = {
    "effect_size": irr,
    "effect_type": "irr",
    "standard_error": se_irr,
    "p_value": float(pval),
    "ci_lower": ci_lower,
    "ci_upper": ci_upper,
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "skin_tone",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": exclusions
}

print(json.dumps(output, indent=2))