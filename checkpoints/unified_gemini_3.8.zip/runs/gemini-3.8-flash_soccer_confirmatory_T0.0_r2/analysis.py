import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
data_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_soccer_confirmatory_T0.0_r2/data.csv"
df = pd.read_csv(data_path)

# 2. Data preparation
# Filter rows where skin tone rating is available
df_clean = df.dropna(subset=['rater1', 'rater2', 'games', 'redCards']).copy()

# Average skin tone rating across both raters (continuous 0 to 1)
df_clean['skin_tone'] = (df_clean['rater1'] + df_clean['rater2']) / 2.0

# Position: fill missing with 'Unknown' to avoid dropping 12% of data
df_clean['position'] = df_clean['position'].fillna('Unknown')

# Ensure games > 0 for offset
df_clean = df_clean[df_clean['games'] > 0].copy()
df_clean['log_games'] = np.log(df_clean['games'])

# Fill missing height and weight with median
df_clean['height'] = df_clean['height'].fillna(df_clean['height'].median())
df_clean['weight'] = df_clean['weight'].fillna(df_clean['weight'].median())

# Model formula: Poisson regression with offset(log_games)
# Controlling for position, height, weight, and leagueCountry
formula = "redCards ~ skin_tone + height + weight + C(leagueCountry) + C(position)"

# Fit Poisson model with cluster-robust standard errors clustered at player level
model = smf.poisson(formula, data=df_clean, offset=df_clean['log_games'])
res = model.fit(cov_type='cluster', cov_kwds={'groups': df_clean['playerShort']}, disp=False)

# Extract effect size for skin_tone (Incidence Rate Ratio for 0 to 1 change)
log_irr = res.params['skin_tone']
se_log_irr = res.bse['skin_tone']
irr = np.exp(log_irr)
ci_lower = np.exp(log_irr - 1.95996 * se_log_irr)
ci_upper = np.exp(log_irr + 1.95996 * se_log_irr)
p_val = res.pvalues['skin_tone']

output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se_log_irr),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "poisson",
    "predictor_used": "average of rater1 and rater2 (skin_tone)",
    "covariates_included": ["height", "weight", "leagueCountry", "position", "offset(log(games))"],
    "missing_data_strategy": "listwise_deletion for ratings, median imputation for height/weight, category for position",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "dropped rows missing skin tone ratings (rater1, rater2) or games <= 0"
}

print(json.dumps(output, indent=2))