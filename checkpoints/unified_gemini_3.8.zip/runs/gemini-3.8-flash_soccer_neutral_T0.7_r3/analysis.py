import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
data_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_soccer_neutral_T0.7_r3/data.csv"
df = pd.read_csv(data_path)

# 2. Clean and prepare data
# Construct skin tone rating as the mean of rater1 and rater2
df["skin_tone"] = (df["rater1"] + df["rater2"]) / 2.0

# Define columns needed
cols_needed = ["redCards", "skin_tone", "games", "position", "height", "weight", "playerShort"]
df_clean = df.dropna(subset=["skin_tone", "redCards", "games", "playerShort"]).copy()

# Fill missing position as 'Unknown'
df_clean["position"] = df_clean["position"].fillna("Unknown")

# Handle missing height and weight with median imputation if used, or just include key confounding
# Standard soccer crowd-sourcing dataset analysis: Poisson / Negative Binomial or Logistic regression
# Using Poisson regression with exposure = games (log(games) offset), clustered on playerShort
# Filter games > 0 (all games >= 1 based on dict)
df_clean = df_clean[df_clean["games"] > 0]
df_clean["log_games"] = np.log(df_clean["games"])

# Fit Poisson GLM with cluster-robust standard errors (clustered by player)
formula = "redCards ~ skin_tone + C(position)"
# Using smf.glm with family sm.families.Poisson()
model = smf.glm(
    formula=formula,
    data=df_clean,
    family=sm.families.Poisson(),
    offset=df_clean["log_games"]
)

# Clustered standard errors by player
fit_res = model.fit(cov_type="cluster", cov_kwds={"groups": df_clean["playerShort"]})

# Extract skin_tone effect
param_name = "skin_tone"
beta = fit_res.params[param_name]
se_beta = fit_res.bse[param_name]
p_val = fit_res.pvalues[param_name]

# Primary estimand: Incidence Rate Ratio (IRR) for full change from 0 to 1
irr = float(np.exp(beta))
ci_low = float(np.exp(beta - 1.95996 * se_beta))
ci_high = float(np.exp(beta + 1.95996 * se_beta))
# Standard error for IRR via delta method: se(exp(beta)) = exp(beta) * se_beta
se_irr = float(irr * se_beta)

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

out = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se_irr),
    "p_value": float(p_val),
    "ci_lower": float(ci_low),
    "ci_upper": float(ci_high),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "mean of rater1 and rater2 (continuous 0 to 1)",
    "covariates_included": ["position"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "Excluded rows with missing skin tone ratings (rater1, rater2)"
}

print(json.dumps(out, indent=2))