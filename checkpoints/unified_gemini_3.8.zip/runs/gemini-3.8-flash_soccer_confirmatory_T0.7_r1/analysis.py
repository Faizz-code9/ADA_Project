import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

# 1. Load data
data_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_soccer_confirmatory_T0.7_r1/data.csv"
df = pd.read_csv(data_path)

# 2. Exclusions & Cleaning
# Drop observations missing skin tone ratings
df = df.dropna(subset=['rater1', 'rater2', 'games', 'redCards']).copy()

# Exclude any cases where games <= 0 (exposure must be positive)
df = df[df['games'] > 0].copy()

# Average skin tone rating
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2.0

# 3. Model Fitting
# We model redCards count with Poisson regression, using log(games) as offset.
# Player-referee pairs are grouped within players; cluster SE by playerShort.
df['offset'] = np.log(df['games'])
X = sm.add_constant(df[['skin_tone']])
y = df['redCards']

# Fit GLM with Poisson family
poisson_model = sm.GLM(
    y, 
    X, 
    family=sm.families.Poisson(), 
    offset=df['offset']
)

# Robust standard errors clustered on player
results = poisson_model.fit(cov_type='cluster', cov_kwds={'groups': df['playerShort']})

# 4. Estimand computation
# Primary estimand: Incidence Rate Ratio (IRR) for full change from 0 to 1
beta = results.params['skin_tone']
se_beta = results.bse['skin_tone']
p_value = results.pvalues['skin_tone']

irr = np.exp(beta)
ci_lower = np.exp(beta - 1.959964 * se_beta)
ci_upper = np.exp(beta + 1.959964 * se_beta)

conclusion = "significant_effect" if p_value < 0.05 else "no_significant_effect"

output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se_beta),
    "p_value": float(p_value),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "average of rater1 and rater2 (skin_tone)",
    "covariates_included": ["log(games) [offset]"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "dropped rows missing rater1 or rater2 (or games <= 0)"
}

print(json.dumps(output, indent=2))