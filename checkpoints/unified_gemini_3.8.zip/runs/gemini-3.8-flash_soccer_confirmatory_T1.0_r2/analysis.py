import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

# File path
data_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_soccer_confirmatory_T1.0_r2/data.csv"

# Load data
df = pd.read_csv(data_path)

# Drop missing raters (primary predictor)
df = df.dropna(subset=["rater1", "rater2"]).copy()

# Compute mean skin tone
df["skin_tone"] = (df["rater1"] + df["rater2"]) / 2.0

# Ensure games > 0 for offset
df = df[df["games"] > 0].copy()

# Fit a Poisson regression for redCards with offset log(games)
# Clustered standard errors on playerShort
formula = "redCards ~ skin_tone"
df["log_games"] = np.log(df["games"])

# Using sm.GLM with Poisson family and offset
model = sm.GLM(
    endog=df["redCards"],
    exog=sm.add_constant(df["skin_tone"]),
    family=sm.families.Poisson(),
    offset=df["log_games"],
)

# Fit with cluster robust SEs by playerShort
# groups for clustering
player_groups = df["playerShort"].astype("category").cat.codes
res = model.fit(cov_type="cluster", cov_kwds={"groups": player_groups})

beta = res.params["skin_tone"]
se_beta = res.bse["skin_tone"]
p_val = res.pvalues["skin_tone"]
ci_lower_beta, ci_upper_beta = res.conf_int().loc["skin_tone"]

# Estimand: IRR (full change from 0 to 1)
irr = float(np.exp(beta))
irr_ci_lower = float(np.exp(ci_lower_beta))
irr_ci_upper = float(np.exp(ci_upper_beta))
# Standard error of IRR via delta method: se(exp(beta)) = exp(beta) * se_beta
irr_se = float(irr * se_beta)

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
    "effect_size": round(irr, 4),
    "effect_type": "irr",
    "standard_error": round(irr_se, 4),
    "p_value": round(float(p_val), 6),
    "ci_lower": round(irr_ci_lower, 4),
    "ci_upper": round(irr_ci_upper, 4),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "average of rater1 and rater2",
    "covariates_included": ["log(games) offset"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "Excluded rows with missing skin tone ratings (rater1/rater2) or non-positive games",
}

print(json.dumps(output, indent=2))