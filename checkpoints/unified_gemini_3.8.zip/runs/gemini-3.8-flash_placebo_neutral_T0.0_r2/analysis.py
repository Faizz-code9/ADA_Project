import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

# File path
data_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_placebo_neutral_T0.0_r2/data.csv"

# Load data
df = pd.read_csv(data_path)

# Drop missing values in key variables
cols_needed = ["redCards", "games", "rater1", "rater2", "playerShort"]
df = df.dropna(subset=["rater1", "rater2", "redCards", "games", "playerShort"]).copy()

# Filter games > 0
df = df[df["games"] > 0].copy()

# Predictor: average of rater1 and rater2
df["skin_tone"] = (df["rater1"] + df["rater2"]) / 2.0

# Aggregate to player level to avoid independence issues or fit count model
# Given player-referee pairs, aggregate total redCards and total games per player,
# or fit a Poisson/Negative Binomial model clustered by player / referee.
# Aggregating to player level is clean and directly answers player-level skin tone bias.
player_df = (
    df.groupby("playerShort")
    .agg(
        {
            "redCards": "sum",
            "games": "sum",
            "skin_tone": "first",
            "height": "first",
            "weight": "first",
        }
    )
    .reset_index()
)

# Impute median for height/weight if included, or use games as offset
player_df["log_games"] = np.log(player_df["games"])

# Fit Poisson regression with offset log(games)
X = sm.add_constant(player_df[["skin_tone"]])
poisson_mod = sm.GLM(
    player_df["redCards"],
    X,
    family=sm.families.Poisson(),
    offset=player_df["log_games"],
)
# Robust SE / Quasi-poisson (HC0) to account for overdispersion
res = poisson_mod.fit(cov_type="HC0")

beta = res.params["skin_tone"]
se = res.bse["skin_tone"]
p_val = res.pvalues["skin_tone"]
ci_lower_beta = beta - 1.95996 * se
ci_upper_beta = beta + 1.95996 * se

# Primary estimand: IRR for full change from 0 to 1
irr = float(np.exp(beta))
ci_lower = float(np.exp(ci_lower_beta))
ci_upper = float(np.exp(ci_upper_beta))
standard_error = float(se * irr)  # delta method SE for IRR or reporting log-scale se

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

out = {
    "effect_size": irr,
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": ci_lower,
    "ci_upper": ci_upper,
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "average of rater1 and rater2",
    "covariates_included": ["offset: log(games)"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "dropped rows with missing skin tone ratings (rater1, rater2) or games <= 0",
}

print(json.dumps(out))