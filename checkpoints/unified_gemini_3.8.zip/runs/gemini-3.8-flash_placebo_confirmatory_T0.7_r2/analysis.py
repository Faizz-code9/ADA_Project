import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

file_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_placebo_confirmatory_T0.7_r2/data.csv"
df = pd.read_csv(file_path)

# Drop missing skin tone ratings
df = df.dropna(subset=["rater1", "rater2"]).copy()

# Average skin tone rating
df["skin_tone"] = (df["rater1"] + df["rater2"]) / 2.0

# Ensure games is valid for offset
df = df[df["games"] > 0].copy()

# Clean covariates
# Impute missing position with 'Unknown'
df["position"] = df["position"].fillna("Unknown")

# Keep relevant columns and drop rows with missing covariates if any
covariates = ["position", "leagueCountry"]
df = df.dropna(subset=["skin_tone", "redCards", "games"] + covariates).copy()

# Prepare Poisson regression with log(games) offset
# Cluster-robust standard errors at the player level (playerShort)
y = df["redCards"]
offset = np.log(df["games"])

X = pd.get_dummies(df[["skin_tone"] + covariates], drop_first=True, dtype=float)
X = sm.add_constant(X)

model = sm.GLM(y, X, family=sm.families.Poisson(), offset=offset)
result = model.fit(cov_type="cluster", cov_kwds={"groups": df["playerShort"]})

# Extract skin_tone coefficient (IRR)
coef = result.params["skin_tone"]
se = result.bse["skin_tone"]
pval = result.pvalues["skin_tone"]

irr = float(np.exp(coef))
ci_lower = float(np.exp(coef - 1.959964 * se))
ci_upper = float(np.exp(coef + 1.959964 * se))

out = {
    "effect_size": irr,
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(pval),
    "ci_lower": ci_lower,
    "ci_upper": ci_upper,
    "conclusion": "significant_effect" if pval < 0.05 else "no_significant_effect",
    "model_family": "poisson",
    "predictor_used": "mean of rater1 and rater2",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "dropped rows missing rater1 or rater2",
}

print(json.dumps(out))