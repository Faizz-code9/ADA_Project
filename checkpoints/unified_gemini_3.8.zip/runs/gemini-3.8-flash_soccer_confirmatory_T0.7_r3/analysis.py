import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

# File path
data_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_soccer_confirmatory_T0.7_r3/data.csv"

# Load data
df = pd.read_csv(data_path)

# Drop missing skin tone ratings
df = df.dropna(subset=["rater1", "rater2"]).copy()

# Compute average skin tone
df["skintone"] = (df["rater1"] + df["rater2"]) / 2.0

# Prepare covariates and outcome
# Games is exposure (log games as offset in count model)
df = df[df["games"] > 0].copy()
df["log_games"] = np.log(df["games"])

# Handle missing values in height and weight using median or drop
covariates = ["height", "weight"]
df = df.dropna(subset=["skintone", "redCards", "games", "playerShort"] + covariates).copy()

# Fit Poisson regression with log(games) as offset and cluster-robust standard errors on player
X = df[["skintone"] + covariates]
X = sm.add_constant(X)
y = df["redCards"]
offset = df["log_games"]

# Fit Poisson GLM
poisson_model = sm.GLM(y, X, family=sm.families.Poisson(), offset=offset)
poisson_res = poisson_model.fit(cov_type="cluster", cov_kwds={"groups": df["playerShort"]})

# Extract results for skintone
coef = poisson_res.params["skintone"]
se = poisson_res.bse["skintone"]
p_val = poisson_res.pvalues["skintone"]
ci_lower_log = poisson_res.conf_int().loc["skintone", 0]
ci_upper_log = poisson_res.conf_int().loc["skintone", 1]

# Primary estimand: IRR for full change from 0 to 1
irr = float(np.exp(coef))
ci_lower = float(np.exp(ci_lower_log))
ci_upper = float(np.exp(ci_upper_log))
irr_se = float(irr * se)  # delta method SE: exp(b) * se(b)

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
    "effect_size": round(irr, 4),
    "effect_type": "irr",
    "standard_error": round(irr_se, 4),
    "p_value": round(float(p_val), 5),
    "ci_lower": round(ci_lower, 4),
    "ci_upper": round(ci_upper, 4),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "average of rater1 and rater2",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "dropped rows with missing skin tone ratings or physical covariates",
}

print(json.dumps(output, indent=2))