import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

# File path
data_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_soccer_skeptical_T1.0_r2/data.csv"

# Load data
df = pd.read_csv(data_path)

# Predictor: average of rater1 and rater2
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2.0

# Prepare required variables
# redCards is the count of red cards; games is exposure (log(games) as offset)
# Relevant covariates: position, height, weight, leagueCountry
required_cols = ['redCards', 'games', 'skin_tone', 'position', 'height', 'weight', 'leagueCountry', 'playerShort']
df_clean = df.dropna(subset=['skin_tone', 'redCards', 'games']).copy()

# Fill missing position as 'Unknown'
df_clean['position'] = df_clean['position'].fillna('Unknown')
# Impute median height and weight if missing
df_clean['height'] = df_clean['height'].fillna(df_clean['height'].median())
df_clean['weight'] = df_clean['weight'].fillna(df_clean['weight'].median())

# Create log exposure
df_clean['log_games'] = np.log(df_clean['games'])

# Model formula / design matrix:
# redCards ~ skin_tone + height + weight + C(position) + C(leagueCountry)
covariates = ['height', 'weight', 'position', 'leagueCountry']
X_df = pd.get_dummies(df_clean[['skin_tone'] + covariates], drop_first=True, dtype=float)
X = sm.add_constant(X_df)
y = df_clean['redCards']
offset = df_clean['log_games']

# Poisson regression with cluster-robust SEs at player level
# Player level clustering accounts for repeated player observations across referees
poisson_mod = sm.GLM(y, X, family=sm.families.Poisson(), offset=offset)
res = poisson_mod.fit(cov_type='cluster', cov_kwds={'groups': df_clean['playerShort']})

beta = res.params['skin_tone']
se_beta = res.bse['skin_tone']
p_val = res.pvalues['skin_tone']

# Incidence Rate Ratio (IRR) for a 0 to 1 change
irr = np.exp(beta)
ci_lower = np.exp(beta - 1.959964 * se_beta)
ci_upper = np.exp(beta + 1.959964 * se_beta)
se_irr = irr * se_beta  # Delta method approximation for IRR SE

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
    "effect_size": float(round(irr, 4)),
    "effect_type": "irr",
    "standard_error": float(round(se_irr, 4)),
    "p_value": float(round(p_val, 4)),
    "ci_lower": float(round(ci_lower, 4)),
    "ci_upper": float(round(ci_upper, 4)),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "average of rater1 and rater2",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "dropped rows missing skin tone (rater1/rater2)"
}

print(json.dumps(output, indent=2))