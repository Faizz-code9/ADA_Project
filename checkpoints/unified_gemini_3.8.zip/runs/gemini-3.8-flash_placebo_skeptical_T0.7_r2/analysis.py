import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

file_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_placebo_skeptical_T0.7_r2/data.csv"
df = pd.read_csv(file_path)

# Drop missing skin-tone ratings
df = df.dropna(subset=["rater1", "rater2"]).copy()

# Average skin tone rating
df["skin_tone"] = (df["rater1"] + df["rater2"]) / 2.0

# Exposure offset: games played
# games is always >= 1
df["log_games"] = np.log(df["games"])

# Fit Poisson regression for redCards with offset log(games) and cluster-robust standard errors
# Cluster on player to account for repeated observations across referees
formula = "redCards ~ skin_tone"
# We fit Poisson GLM
X = sm.add_constant(df["skin_tone"])
y = df["redCards"]
exposure = df["games"]

model = sm.GLM(
    y,
    X,
    family=sm.families.Poisson(),
    exposure=exposure
)

# Fit with robust standard errors clustered at player level
results = model.fit(cov_type="cluster", cov_kwds={"groups": df["playerShort"]})

beta = results.params["skin_tone"]
se = results.bse["skin_tone"]
pval = results.pvalues["skin_tone"]
ci_low_beta, ci_high_beta = results.conf_int().loc["skin_tone"]

irr = np.exp(beta)
ci_lower_irr = np.exp(ci_low_beta)
ci_upper_irr = np.exp(ci_high_beta)
# Standard error of IRR via delta method: SE(IRR) = IRR * SE(beta)
irr_se = irr * se

conclusion = "significant_effect" if pval < 0.05 else "no_significant_effect"

output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(irr_se),
    "p_value": float(pval),
    "ci_lower": float(ci_lower_irr),
    "ci_upper": float(ci_upper_irr),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "average of rater1 and rater2",
    "covariates_included": [],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "dropped rows with missing skin tone ratings (rater1, rater2)"
}

print(json.dumps(output, indent=2))