import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

# 1. Load data
data_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_placebo_neutral_T0.7_r2/data.csv"
df = pd.read_csv(data_path)

# 2. Exclusions and cleaning
# Drop rows with missing skin tone ratings
df = df.dropna(subset=['rater1', 'rater2', 'games', 'redCards']).copy()

# Average skin tone rating (0 to 1 scale)
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2.0

# Aggregate to player level to avoid independence violation and match player-level exposure
# Or analyze at dyad level using Poisson / negative binomial with offset log(games) and clustered SEs
# Clustering at player level is standard for this dataset (Silberzahn et al., 2018).
# Dyad-level Poisson regression with log(games) offset and cluster-robust standard errors by player:

# Filter out non-positive games just in case
df = df[df['games'] > 0].copy()
df['log_games'] = np.log(df['games'])

# Model: Poisson GLM on redCards ~ skin_tone with offset=log_games
# Clustered on playerShort
X = sm.add_constant(df[['skin_tone']])
y = df['redCards']
offset = df['log_games']

poisson_model = sm.GLM(
    y, 
    X, 
    family=sm.families.Poisson(), 
    offset=offset
)
res = poisson_model.fit(cov_type='cluster', cov_kwds={'groups': df['playerShort']})

beta = res.params['skin_tone']
se_beta = res.bse['skin_tone']
p_val = res.pvalues['skin_tone']
ci_lower_beta, ci_upper_beta = res.conf_int().loc['skin_tone']

# Primary estimand: Incidence Rate Ratio (IRR) for full change (0 to 1)
irr = float(np.exp(beta))
ci_lower = float(np.exp(ci_lower_beta))
ci_upper = float(np.exp(ci_upper_beta))

# Delta method SE for IRR: SE(exp(beta)) approx exp(beta) * SE(beta)
se_irr = float(irr * se_beta)

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
    "effect_size": irr,
    "effect_type": "irr",
    "standard_error": se_irr,
    "p_value": float(p_val),
    "ci_lower": ci_lower,
    "ci_upper": ci_upper,
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "mean of rater1 and rater2 (0-1 continuous)",
    "covariates_included": [],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "dropped rows missing rater1 or rater2 (n=21,407)"
}

print(json.dumps(output, indent=2))