import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

# File path
DATA_PATH = "/kaggle/working/outputs/runs/gemini-3.8-flash_soccer_neutral_T1.0_r5/data.csv"

# Load data
df = pd.read_csv(DATA_PATH)

# Drop missing skin tone ratings
df = df.dropna(subset=["rater1", "rater2"]).copy()

# Compute skin tone as the average of rater1 and rater2 (range 0 to 1)
df["skin_tone"] = (df["rater1"] + df["rater2"]) / 2.0

# Relevant covariates: games (exposure/log), position, height, weight
# Handle position missingness by categorizing as 'Unknown'
df["position"] = df["position"].fillna("Unknown")

# Handle missing height and weight by imputation with median or dropping if very few
df = df.dropna(subset=["height", "weight"]).copy()

# Add log of games played as an offset/exposure term
df["log_games"] = np.log(df["games"])

# Fit Poisson GLM for redCards with offset log(games) and clustered SE on player
# Model covariates: skin_tone, height, weight, C(position), C(leagueCountry)
df = df[df["games"] > 0].copy()

# Prepare design matrix
formula = "redCards ~ skin_tone + height + weight + C(position) + C(leagueCountry)"
from patsy import dmatrices
y, X = dmatrices(formula, data=df, return_type="dataframe")

# Fit Poisson model with offset and cluster-robust standard errors on player
offset = df.loc[X.index, "log_games"]
groups = df.loc[X.index, "playerShort"]

model = sm.GLM(y, X, family=sm.families.Poisson(), offset=offset)
result = model.fit(cov_type="cluster", cov_kwds={"groups": groups})

# Extract skin_tone coefficient (full change from 0 to 1)
beta = result.params["skin_tone"]
se_beta = result.bse["skin_tone"]
p_val = result.pvalues["skin_tone"]

irr = float(np.exp(beta))
ci_low = float(np.exp(beta - 1.96 * se_beta))
ci_high = float(np.exp(beta + 1.96 * se_beta))

output = {
    "effect_size": round(irr, 4),
    "effect_type": "irr",
    "standard_error": round(float(se_beta), 4),
    "p_value": round(float(p_val), 4),
    "ci_lower": round(ci_low, 4),
    "ci_upper": round(ci_high, 4),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "poisson",
    "predictor_used": "mean of rater1 and rater2",
    "covariates_included": ["height", "weight", "position", "leagueCountry", "log(games) offset"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "dropped rows with missing skin tone ratings (rater1, rater2) or missing height/weight"
}

print(json.dumps(output, indent=2))