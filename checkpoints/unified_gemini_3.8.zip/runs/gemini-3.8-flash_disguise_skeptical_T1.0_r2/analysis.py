import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

# File path
data_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_disguise_skeptical_T1.0_r2/data.csv"

# Load data
df = pd.read_csv(data_path)

# Predictor: average of risk evaluator alpha and beta scores
# Check missingness in predictor and outcome
# Outcome: loan_application_rejections (count: 0, 1, 2)
# We can model this as Poisson/Negative Binomial (or binary logistic if dichotomized, but IRR is requested for count)
# The prompt: "an odds ratio for a binary outcome, or an incidence rate ratio for a count model; set effect_type accordingly, for the full change from 0 to 1. Use a continuous 0-1 score (alpha, beta or their average; say which in predictor_used)."
# Since loan_application_rejections is a count (0, 1, 2) with mean 0.01256, Poisson / Negative Binomial is very natural.
# Alternatively, binary logistic regression if rejections > 0. Let's see: Poisson model provides IRR directly.

df['risk_score_mean'] = (df['risk_evaluator_alpha_score'] + df['risk_evaluator_beta_score']) / 2.0

covariates = [
    'credit_score_index',
    'annual_income_bracket',
    'total_applications_reviewed',
    'prior_approved_loans',
    'prior_conditional_loans',
    'prior_denied_loans',
    'repayment_performance_score',
    'formal_inquiry_notices',
    'elevated_risk_warnings'
]

model_cols = ['loan_application_rejections', 'risk_score_mean', 'loan_officer_id'] + covariates
df_clean = df.dropna(subset=model_cols).copy()

# Fit Poisson regression with clustered standard errors on loan_officer_id (or applicant_id)
# Clustering on applicant_id or loan_officer_id: pairing is applicant-loan officer.
# Loan officers make the decision, applicant is also clustered. Let's cluster by loan_officer_id.
formula_covs = " + ".join(covariates)
formula = f"loan_application_rejections ~ risk_score_mean + {formula_covs}"

import statsmodels.formula.api as smf

model = smf.poisson(formula, data=df_clean)
res = model.fit(cov_type='cluster', cov_kwds={'groups': df_clean['loan_officer_id']}, disp=False)

# Extract IRR for risk_score_mean (full change from 0 to 1)
coef = res.params['risk_score_mean']
se = res.bse['risk_score_mean']
p_val = res.pvalues['risk_score_mean']

irr = np.exp(coef)
# 95% CI on log scale, exponentiated
ci_lower = np.exp(coef - 1.959964 * se)
ci_upper = np.exp(coef + 1.959964 * se)
# SE of IRR using delta method: SE(exp(beta)) = exp(beta) * SE(beta)
se_irr = irr * se

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

out = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se_irr),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "average of risk_evaluator_alpha_score and risk_evaluator_beta_score",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "none"
}

print(json.dumps(out))