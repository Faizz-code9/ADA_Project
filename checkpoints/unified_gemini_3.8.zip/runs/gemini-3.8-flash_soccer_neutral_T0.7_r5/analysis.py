import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
data_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_soccer_neutral_T0.7_r5/data.csv"
df = pd.read_csv(data_path)

# 2. Exclusions & Variable Preparation
# We need skin tone predictor. We use the average of rater1 and rater2.
# Drop rows with missing rater1 or rater2
df = df.dropna(subset=["rater1", "rater2", "games", "redCards"]).copy()
df["skin_tone"] = (df["rater1"] + df["rater2"]) / 2.0

# Red cards is count per dyad, games is exposure
# Model: Poisson or Negative Binomial regression with offset log(games)
# Or logistic / count regression. Since redCards is count (0, 1, 2) and games is exposure,
# a Poisson / Negative Binomial model with offset log(games) is standard.
# Account for clustering at player level (or player and ref).
# Clustering on player accounts for repeated observations of the same player.
df["log_games"] = np.log(df["games"])

# Covariates: position, leagueCountry (if available/complete) or keep minimal and robust
# Let's check missingness on potential covariates: leagueCountry, height, weight
# Height and weight have missing values, let's include leagueCountry which has 0 missing.
# Let's fit a Poisson regression with cluster-robust standard errors on playerShort.
formula = "redCards ~ skin_tone + C(leagueCountry)"
model = smf.poisson(formula, data=df, offset=df["log_games"])
res = model.fit(
    cov_type="cluster", cov_kwds={"groups": df["playerShort"]}, disp=False
)

# Extract effect of skin tone (IRR = exp(beta))
coef = res.params["skin_tone"]
se = res.bse["skin_tone"]
pval = res.pvalues["skin_tone"]
ci_lower_beta = coef - 1.96 * se
ci_upper_beta = coef + 1.96 * se

irr = float(np.exp(coef))
irr_ci_lower = float(np.exp(ci_lower_beta))
irr_ci_upper = float(np.exp(ci_upper_beta))
# Standard error of IRR via delta method: SE(exp(beta)) = exp(beta) * SE(beta)
irr_se = float(irr * se)

output = {
    "effect_size": irr,
    "effect_type": "irr",
    "standard_error": irr_se,
    "p_value": float(pval),
    "ci_lower": irr_ci_lower,
    "ci_upper": irr_ci_upper,
    "conclusion": "significant_effect"
    if pval < 0.05
    else "no_significant_effect",
    "model_family": "poisson",
    "predictor_used": "mean of rater1 and rater2",
    "covariates_included": ["leagueCountry"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "Dropped rows missing rater1 or rater2",
}

print(json.dumps(output, indent=2))