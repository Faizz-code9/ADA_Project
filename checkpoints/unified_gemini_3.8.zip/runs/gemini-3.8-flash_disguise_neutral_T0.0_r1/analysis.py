import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

# File path
data_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_disguise_neutral_T0.0_r1/data.csv"

# Load data
df = pd.read_csv(data_path)

# Predictor: average of risk_evaluator_alpha_score and risk_evaluator_beta_score
# Outcome: loan_application_rejections (values 0, 1, 2; mean 0.01256)
# Model: Poisson or Negative Binomial regression for count outcome (or Logistic if binarized, but count model gives IRR)
# Primary estimand asks for: "the ratio effect of the risk evaluator score on loan_application_rejections (an odds ratio for a binary outcome, or an incidence rate ratio for a count model; set effect_type accordingly), for the full change from 0 to 1."

# Construct average score
df["risk_evaluator_score"] = (
    df["risk_evaluator_alpha_score"] + df["risk_evaluator_beta_score"]
) / 2.0

# Relevant covariates: credit_score_index, annual_income_bracket, total_applications_reviewed,
# prior_approved_loans, prior_conditional_loans, prior_denied_loans, repayment_performance_score,
# formal_inquiry_notices, elevated_risk_warnings
covariates = [
    "credit_score_index",
    "annual_income_bracket",
    "total_applications_reviewed",
    "prior_approved_loans",
    "prior_conditional_loans",
    "prior_denied_loans",
    "repayment_performance_score",
    "formal_inquiry_notices",
    "elevated_risk_warnings",
]

model_cols = [
    "loan_application_rejections",
    "risk_evaluator_score",
    "loan_officer_id",
] + covariates
df_clean = df.dropna(subset=model_cols).copy()

# Fit Poisson GLM with cluster-robust standard errors clustered at loan_officer_id (or applicant_id)
# Clustering at loan_officer_id
X = df_clean[["risk_evaluator_score"] + covariates]
X = sm.add_constant(X)
y = df_clean["loan_application_rejections"]

model = sm.GLM(y, X, family=sm.families.Poisson())
res = model.fit(
    cov_type="cluster", cov_kwds={"groups": df_clean["loan_officer_id"]}
)

# Extract effect for risk_evaluator_score (change from 0 to 1)
coef = res.params["risk_evaluator_score"]
se = res.bse["risk_evaluator_score"]
p_val = res.pvalues["risk_evaluator_score"]

irr = float(np.exp(coef))
ci_lower = float(np.exp(coef - 1.959964 * se))
ci_upper = float(np.exp(coef + 1.959964 * se))

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
    "effect_size": irr,
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": ci_lower,
    "ci_upper": ci_upper,
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "average_risk_evaluator_score",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "dropped rows with missing risk scores or covariates",
}

print(json.dumps(output, indent=2))