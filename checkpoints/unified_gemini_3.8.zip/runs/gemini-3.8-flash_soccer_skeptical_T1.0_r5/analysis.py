import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
data_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_soccer_skeptical_T1.0_r5/data.csv"
df = pd.read_csv(data_path)

# 2. Exclusions & variable construction
# Require non-missing rater1 and rater2
df = df.dropna(subset=["rater1", "rater2"]).copy()

# Construct continuous skin tone predictor (average of rater1 and rater2)
df["skin_tone"] = (df["rater1"] + df["rater2"]) / 2.0

# Aggregate red cards / games
# Poisson regression model for redCards with log(games) offset
# Filter games > 0 (all are >= 1 according to dictionary)
df = df[df["games"] > 0].copy()

# Listwise deletion for key covariates: height, weight, position
# To avoid dropping ~12% on position, we fill missing position with 'Unknown'
df["position"] = df["position"].fillna("Unknown")
df = df.dropna(subset=["height", "weight"]).copy()

# 3. Fit model
# Using Poisson regression with exposure/offset log(games) and clustered SE on player
# Model controls for position, height, weight, leagueCountry
formula = "redCards ~ skin_tone + height + weight + C(position) + C(leagueCountry)"

poisson_mod = smf.poisson(formula, data=df, offset=np.log(df["games"]))
# Cluster on player to account for non-independence of observations per player
res = poisson_mod.fit(cov_type="cluster", cov_kwds={"groups": df["playerShort"]}, disp=False)

# 4. Compute primary estimand: Incidence Rate Ratio (IRR) for full change from 0 to 1
beta = res.params["skin_tone"]
se_beta = res.bse["skin_tone"]
irr = float(np.exp(beta))
p_value = float(res.pvalues["skin_tone"])

# Delta method or exponentiated CI
ci_lower = float(np.exp(beta - 1.96 * se_beta))
ci_upper = float(np.exp(beta + 1.96 * se_beta))
se_irr = float(irr * se_beta)

conclusion = "significant_effect" if p_value < 0.05 else "no_significant_effect"

output = {
    "effect_size": irr,
    "effect_type": "irr",
    "standard_error": se_irr,
    "p_value": p_value,
    "ci_lower": ci_lower,
    "ci_upper": ci_upper,
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "mean of rater1 and rater2 (skin_tone, continuous 0 to 1)",
    "covariates_included": ["height", "weight", "position", "leagueCountry", "log(games) [offset]"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "Dropped rows missing rater1, rater2, height, or weight; missing positions coded as 'Unknown'"
}

print(json.dumps(output, indent=2))