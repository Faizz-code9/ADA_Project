import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

# 1. Load data
data_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_placebo_skeptical_T1.0_r1/data.csv"
df = pd.read_csv(data_path)

# 2. Data Cleaning & Variable Construction
# Predictor: average of rater1 and rater2 (continuous 0-1)
# Exclude rows missing rater1 or rater2
df = df.dropna(subset=['rater1', 'rater2', 'games', 'redCards', 'playerShort', 'refNum']).copy()
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2.0

# Optional covariates: position, height, weight, leagueCountry
# Let's adjust for position, height, weight, leagueCountry with listwise deletion
covars = ['height', 'weight', 'position', 'leagueCountry']
df_clean = df.dropna(subset=['skin_tone'] + covars).copy()

# Fit Poisson regression with games as exposure (log(games) as offset)
# or Negative Binomial / Poisson with clustered SEs on player
# The hypothesis asks for ratio effect of skin tone on red cards (IRR).
df_clean['log_games'] = np.log(df_clean['games'])

# Model formula / design matrix
formula = "redCards ~ skin_tone + height + weight + C(leagueCountry) + C(position)"
y = df_clean['redCards']
X = pd.get_dummies(df_clean[['skin_tone', 'height', 'weight', 'leagueCountry', 'position']], 
                   columns=['leagueCountry', 'position'], drop_first=True, dtype=float)
X = sm.add_constant(X)

# Fit Poisson model with cluster-robust standard errors on player (playerShort)
poisson_mod = sm.GLM(
    y, 
    X, 
    family=sm.families.Poisson(), 
    offset=df_clean['log_games']
)

# Cluster standard errors by playerShort
# playerShort groups
groups = df_clean['playerShort']
res = poisson_mod.fit(cov_type='cluster', cov_kwds={'groups': groups})

# Extract skin_tone effect
param = res.params['skin_tone']
se = res.bse['skin_tone']
p_val = res.pvalues['skin_tone']
ci_lower_log = res.conf_int().loc['skin_tone', 0]
ci_upper_log = res.conf_int().loc['skin_tone', 1]

# Primary estimand: IRR for full 0 to 1 change
irr = np.exp(param)
irr_ci_lower = np.exp(ci_lower_log)
irr_ci_upper = np.exp(ci_upper_log)
# Delta method SE for IRR: se(exp(b)) ~ exp(b) * se(b)
irr_se = irr * se

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

out = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(irr_se),
    "p_value": float(p_val),
    "ci_lower": float(irr_ci_lower),
    "ci_upper": float(irr_ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "average of rater1 and rater2",
    "covariates_included": ["height", "weight", "position", "leagueCountry"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "dropped rows missing skin tone ratings or covariates (height, weight, position)"
}

print(json.dumps(out))