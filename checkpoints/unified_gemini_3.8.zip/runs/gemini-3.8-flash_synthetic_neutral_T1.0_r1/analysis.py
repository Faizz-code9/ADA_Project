import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load the data
file_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_synthetic_neutral_T1.0_r1/data.csv"
df = pd.read_csv(file_path)

# 2. Data Cleaning / Preparation
# Missing values on skin_tone (8%)
initial_len = len(df)
df = df.dropna(subset=["skin_tone", "redCards", "games"]).copy()
exclusions = f"Dropped {initial_len - len(df)} rows with missing values (primarily skin_tone)"

# Ensure games > 0 (exposure)
df = df[df["games"] > 0].copy()

# 3. Model Fitting
# Outcome: redCards is a count outcome (0, 1, 2, 3), with exposure = games.
# Primary estimand: ratio effect of skin_tone on redCards (IRR for count model) for full change from 0 to 1.
# Fit Poisson or Negative Binomial regression with exposure=games, clustered by playerID (or refereeID/both).
# A Negative Binomial or Poisson model with clustered SE by playerID is standard for repeated observations per player.
formula = "redCards ~ skin_tone + C(position) + height + weight + C(leagueCountry)"

# Fit Negative Binomial model with log(games) as offset
df["log_games"] = np.log(df["games"])

# Using smf.glm with Poisson or NegativeBinomial family
# Clustered standard errors at playerID level
model = smf.glm(
    formula=formula,
    data=df,
    family=sm.families.NegativeBinomial(alpha=1.0),
    offset=df["log_games"]
)

# Fit with robust/clustered standard errors
try:
    res = model.fit(cov_type="cluster", cov_kwds={"groups": df["playerID"]})
    clustering = "clustered_se"
except Exception:
    res = model.fit()
    clustering = "none"

# 4. Compute estimand: IRR = exp(coef)
coef = res.params["skin_tone"]
se = res.bse["skin_tone"]
p_val = res.pvalues["skin_tone"]
ci_low_log, ci_upp_log = res.conf_int().loc["skin_tone"]

irr = np.exp(coef)
irr_ci_low = np.exp(ci_low_log)
irr_ci_upp = np.exp(ci_upp_log)
# Standard error for IRR using delta method: SE(IRR) = IRR * SE(coef)
irr_se = irr * se

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(irr_se),
    "p_value": float(p_val),
    "ci_lower": float(irr_ci_low),
    "ci_upper": float(irr_ci_upp),
    "conclusion": conclusion,
    "model_family": "negative_binomial",
    "predictor_used": "skin_tone",
    "covariates_included": ["position", "height", "weight", "leagueCountry", "games"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": clustering,
    "exclusions_applied": exclusions
}

print(json.dumps(output, indent=2))