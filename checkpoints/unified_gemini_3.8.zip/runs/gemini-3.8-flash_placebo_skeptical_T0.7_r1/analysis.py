import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

# File path
data_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_placebo_skeptical_T0.7_r1/data.csv"

# Load data
df = pd.read_csv(data_path)

# Drop rows missing skin tone ratings
df = df.dropna(subset=['rater1', 'rater2'])

# Predictor: average skin tone of rater1 and rater2
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2.0

# Prepare covariates
# Height, weight, position, and leagueCountry are standard confounders
# Missing positions can be coded as 'Unknown'
df['position'] = df['position'].fillna('Unknown')
df['height'] = df['height'].fillna(df['height'].median())
df['weight'] = df['weight'].fillna(df['weight'].median())

# Binary outcome: redCards > 0 vs = 0, or count model with offset = log(games)
# Poisson regression with exposure/offset log(games) is standard for redCards count
# Ensure games > 0
df = df[df['games'] > 0].copy()
df['log_games'] = np.log(df['games'])

covariates = ['height', 'weight']
cat_cols = ['position', 'leagueCountry']

# Create design matrix
X = pd.get_dummies(df[['skin_tone'] + covariates + cat_cols], drop_first=True, dtype=float)
X = sm.add_constant(X)
y = df['redCards']
offset = df['log_games']

# Fit Poisson model with cluster-robust standard errors clustered at player level
# Clustering on player accounts for repeated observations per player
poisson_model = sm.GLM(
    y,
    X,
    family=sm.families.Poisson(),
    offset=offset
)
res = poisson_model.fit(cov_type='cluster', cov_kwds={'groups': df['playerShort']})

# Extract results for skin_tone
coef = res.params['skin_tone']
se = res.bse['skin_tone']
p_val = res.pvalues['skin_tone']
ci_low_coef, ci_upp_coef = res.conf_int().loc['skin_tone']

# Estimand is Incidence Rate Ratio (IRR) for full change 0 to 1
irr = float(np.exp(coef))
ci_lower = float(np.exp(ci_low_coef))
ci_upper = float(np.exp(ci_upp_coef))
irr_se = float(irr * se)  # delta method SE approx

output = {
    "effect_size": round(irr, 4),
    "effect_type": "irr",
    "standard_error": round(irr_se, 4),
    "p_value": round(float(p_val), 4),
    "ci_lower": round(ci_lower, 4),
    "ci_upper": round(ci_upper, 4),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "poisson",
    "predictor_used": "mean(rater1, rater2)",
    "covariates_included": covariates + ["position", "leagueCountry", "log(games)_offset"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "removed rows missing rater1/rater2 ratings or games <= 0"
}

print(json.dumps(output, indent=2))