import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
data_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_synthetic_skeptical_T0.0_r2/data.csv"
df = pd.read_csv(data_path)

# 2. Clean and prepare data
# Missing values in skin_tone (8%)
initial_len = len(df)
df_clean = df.dropna(subset=["skin_tone", "redCards", "games"]).copy()

# Exposure offset: log(games)
df_clean["log_games"] = np.log(df_clean["games"])

# Fit Poisson or Negative Binomial regression with cluster-robust standard errors
# Cluster by refereeID or playerID (referee clustering is standard for referee bias)
formula = "redCards ~ skin_tone + C(position) + height + weight + C(leagueCountry) + yellowCards"

# Using Poisson regression with offset log(games) and clustered SE on refereeID
model = smf.poisson(formula, data=df_clean, offset=df_clean["log_games"])
res = model.fit(cov_type="cluster", cov_kwds={"groups": df_clean["refereeID"]}, disp=False)

# Extract skin_tone parameter
beta = res.params["skin_tone"]
se = res.bse["skin_tone"]
p_val = res.pvalues["skin_tone"]
ci_lower_beta, ci_upper_beta = res.conf_int().loc["skin_tone"]

# Compute incidence rate ratio (IRR)
irr = float(np.exp(beta))
irr_ci_lower = float(np.exp(ci_lower_beta))
irr_ci_upper = float(np.exp(ci_upper_beta))

# Standard error of IRR via delta method: se(exp(beta)) = exp(beta) * se(beta)
irr_se = float(irr * se)

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
    "effect_size": irr,
    "effect_type": "irr",
    "standard_error": irr_se,
    "p_value": float(p_val),
    "ci_lower": irr_ci_lower,
    "ci_upper": irr_ci_upper,
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "skin_tone",
    "covariates_included": ["position", "height", "weight", "leagueCountry", "yellowCards", "games"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "none" if len(df_clean) == initial_len else "dropped rows with missing skin_tone"
}

print(json.dumps(output))