import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

# File path
file_path = (
    "/kaggle/working/outputs/runs/gemini-3.8-flash_placebo_neutral_T1.0_r2/data.csv"
)

# Load data
df = pd.read_csv(file_path)

# Drop missing values for skin tone raters
df = df.dropna(subset=["rater1", "rater2"]).copy()

# Average skin tone rating across rater1 and rater2
df["skin_tone"] = (df["rater1"] + df["rater2"]) / 2.0

# Outcome: redCards
# Predictor: skin_tone
# Offset / exposure: games (log(games))
# Using Poisson regression with exposure = games, clustering by player (or ref)
# Many analysts in the Silberzahn et al. (2018) crowd-sourced project used Poisson / NegBin with log(games) offset
# and clustered standard errors at player or referee level.
# We also include available relevant player covariates (height, weight) if desired, or position,
# but keeping it robust and minimizing listwise deletion while adjusting for games exposure.

df = df[df["games"] > 0].copy()
df["log_games"] = np.log(df["games"])

# Fit Poisson regression using GLM
# Predictor: skin_tone
# Control for games using offset
model_formula = "redCards ~ skin_tone"
# Using sm.GLM with exposure / offset
X = sm.add_constant(df[["skin_tone"]])
y = df["redCards"]
offset = df["log_games"]

# Fit GLM Poisson with clustered standard errors on playerShort
glm_poisson = sm.GLM(y, X, offset=offset, family=sm.families.Poisson())
res = glm_poisson.fit(
    cov_type="cluster", cov_kwds={"groups": df["playerShort"]}
)

coef = res.params["skin_tone"]
se_coef = res.bse["skin_tone"]
p_val = res.pvalues["skin_tone"]
ci_lower_coef = res.conf_int().loc["skin_tone", 0]
ci_upper_coef = res.conf_int().loc["skin_tone", 1]

# Primary estimand: ratio effect (Incidence Rate Ratio for Poisson)
irr = float(np.exp(coef))
irr_ci_lower = float(np.exp(ci_lower_coef))
irr_ci_upper = float(np.exp(ci_upper_coef))

# Delta method SE for IRR: SE(exp(beta)) ~ exp(beta) * SE(beta)
irr_se = float(irr * se_coef)

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
    "effect_size": irr,
    "effect_type": "irr",
    "standard_error": irr_se,
    "p_value": float(p_val),
    "ci_lower": irr_ci_lower,
    "ci_upper": irr_ci_upper,
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "average of rater1 and rater2 (skin_tone)",
    "covariates_included": ["log(games) (offset)"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "removed rows with missing skin tone ratings (rater1, rater2) or games <= 0",
}

print(json.dumps(output, indent=2))