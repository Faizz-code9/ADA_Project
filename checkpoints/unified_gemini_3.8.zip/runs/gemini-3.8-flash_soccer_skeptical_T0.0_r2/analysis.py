import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

file_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_soccer_skeptical_T0.0_r2/data.csv"
df = pd.read_csv(file_path)

# Prepare skin tone: average of rater1 and rater2
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2.0

# Exclude missing values on skin tone, games, and position/league covariates
covars = ['leagueCountry', 'position']
analysis_cols = ['redCards', 'games', 'skin_tone', 'playerShort', 'refNum'] + covars
df_clean = df.dropna(subset=['skin_tone', 'games', 'redCards', 'playerShort']).copy()

# Fill or drop missing positions: create 'Unknown' category to retain data, or drop missing
df_clean['position'] = df_clean['position'].fillna('Unknown')

# Red cards count model with games as offset / exposure
# Using Poisson regression with robust standard errors clustered by player (or refNum)
# Primary estimand: IRR for full change from 0 to 1 in skin tone
df_clean['log_games'] = np.log(df_clean['games'])

# Dummy coding for league and position
X = pd.get_dummies(df_clean[covars], drop_first=True, dtype=float)
X['skin_tone'] = df_clean['skin_tone']
X = sm.add_constant(X)

y = df_clean['redCards']
exposure = df_clean['games']
clusters = df_clean['playerShort']

poisson_mod = sm.GLM(y, X, family=sm.families.Poisson(), exposure=exposure)
# Fit model and use robust cluster standard errors on player level
res = poisson_mod.fit(cov_type='cluster', cov_kwds={'groups': clusters})

beta = res.params['skin_tone']
se_beta = res.bse['skin_tone']
irr = float(np.exp(beta))
p_val = float(res.pvalues['skin_tone'])
ci_lower = float(np.exp(res.conf_int().loc['skin_tone', 0]))
ci_upper = float(np.exp(res.conf_int().loc['skin_tone', 1]))
irr_se = float(irr * se_beta)

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

out = {
    "effect_size": irr,
    "effect_type": "irr",
    "standard_error": irr_se,
    "p_value": p_val,
    "ci_lower": ci_lower,
    "ci_upper": ci_upper,
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "average of rater1 and rater2",
    "covariates_included": covars + ['games (offset)'],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "dropped rows with missing skin tone ratings (rater1, rater2)"
}

print(json.dumps(out))