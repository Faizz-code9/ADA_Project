import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_soccer_confirmatory_T0.0_r3/data.csv"
df = pd.read_csv(file_path)

# 2. Exclusions & variable construction
# Need rater1 and rater2 to form skin_tone
df = df.dropna(subset=["rater1", "rater2"]).copy()
df["skin_tone"] = (df["rater1"] + df["rater2"]) / 2.0

# Outcome and exposure (games played)
# We model redCards using Poisson regression with games as exposure (log(games) as offset)
# Filter games > 0 (all are >= 1 per dictionary)
df = df[df["games"] > 0].copy()

# Add position / league controls or standard covariates, handling missing position by filling as 'Unknown'
df["position"] = df["position"].fillna("Unknown")

# Fit Poisson GLM with offset = np.log(games) and cluster-robust standard errors on player
# Using statsmodels GLM
# Predictors: skin_tone, height, weight
# For missing height and weight, let's drop or keep listwise
model_data = df[["redCards", "skin_tone", "games", "playerShort"]].dropna().copy()
model_data["offset"] = np.log(model_data["games"])

X = sm.add_constant(model_data[["skin_tone"]])
y = model_data["redCards"]

poisson_mod = sm.GLM(
    y,
    X,
    family=sm.families.Poisson(),
    offset=model_data["offset"],
)

# Cluster standard errors by player
res = poisson_mod.fit(cov_type="cluster", cov_kwds={"groups": model_data["playerShort"]})

beta = res.params["skin_tone"]
se = res.bse["skin_tone"]
irr = np.exp(beta)
ci_low = np.exp(beta - 1.96 * se)
ci_high = np.exp(beta + 1.96 * se)
pval = res.pvalues["skin_tone"]

output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(pval),
    "ci_lower": float(ci_low),
    "ci_upper": float(ci_high),
    "conclusion": "significant_effect" if pval < 0.05 else "no_significant_effect",
    "model_family": "poisson",
    "predictor_used": "average of rater1 and rater2",
    "covariates_included": ["offset: log(games)"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "Excluded rows with missing rater1 or rater2",
}

print(json.dumps(output))