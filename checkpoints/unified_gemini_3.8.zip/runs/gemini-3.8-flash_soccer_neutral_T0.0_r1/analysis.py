import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_soccer_neutral_T0.0_r1/data.csv"
df = pd.read_csv(file_path)

# 2. Data preparation
# Filter rows with non-missing skin tone ratings and games > 0
valid_mask = df["rater1"].notna() & df["rater2"].notna() & (df["games"] > 0)
df_clean = df[valid_mask].copy()

# Skin tone predictor: average of rater1 and rater2 (ranges from 0 to 1)
df_clean["skintone"] = (df_clean["rater1"] + df_clean["rater2"]) / 2.0

# Red cards count & games (exposure / offset)
df_clean = df_clean.dropna(subset=["skintone", "redCards", "games", "leagueCountry"])
df_clean["log_games"] = np.log(df_clean["games"])

# Add league dummies as key covariate
league_dummies = pd.get_dummies(df_clean["leagueCountry"], drop_first=True, dtype=float)
X = pd.concat([df_clean[["skintone"]], league_dummies], axis=1)
X = sm.add_constant(X)
y = df_clean["redCards"]

# 3. Fit Poisson GLM with offset log(games) and cluster-robust standard errors on player
# Poisson regression model for red card incidence rate
model = sm.GLM(y, X, family=sm.families.Poisson(), offset=df_clean["log_games"])
# Clustered standard errors at player level
results = model.fit(cov_type="cluster", cov_kwds={"groups": df_clean["playerShort"]})

# 4. Compute estimand: Incidence Rate Ratio (IRR) for full change from 0 to 1
beta = results.params["skintone"]
se_beta = results.bse["skintone"]
irr = np.exp(beta)
p_val = results.pvalues["skintone"]

# 95% Confidence Interval for IRR
ci_lower_beta = beta - 1.959964 * se_beta
ci_upper_beta = beta + 1.959964 * se_beta
ci_lower = np.exp(ci_lower_beta)
ci_upper = np.exp(ci_upper_beta)

# Delta method standard error for IRR: SE(exp(beta)) ≈ exp(beta) * SE(beta)
se_irr = irr * se_beta

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se_irr),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "average of rater1 and rater2 (skintone)",
    "covariates_included": list(league_dummies.columns) + ["log(games) [offset]"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "dropped rows with missing skin tone ratings (rater1, rater2) or zero games",
}

print(json.dumps(output, indent=2))