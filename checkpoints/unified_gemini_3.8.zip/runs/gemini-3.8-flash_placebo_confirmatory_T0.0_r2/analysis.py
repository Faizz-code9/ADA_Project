import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

# 1. Load Data
df = pd.read_csv('/kaggle/working/outputs/runs/gemini-3.8-flash_placebo_confirmatory_T0.0_r2/data.csv')

# 2. Data Cleaning and Preparation
# Target: redCards (count, with exposure = games)
# Predictor: continuous 0-1 skin-tone score (mean of rater1 and rater2)
df = df.dropna(subset=['rater1', 'rater2', 'games', 'redCards', 'playerShort']).copy()
df = df[df['games'] > 0].copy()

df['skin_tone'] = (df['rater1'] + df['rater2']) / 2.0

# Aggregate to player level to properly handle clustering / repeated observations per player
# and fit a Poisson/Negative Binomial regression with log(games) exposure offset
agg_df = df.groupby('playerShort').agg({
    'redCards': 'sum',
    'yellowCards': 'sum',
    'games': 'sum',
    'skin_tone': 'mean',
    'height': 'mean',
    'weight': 'mean'
}).reset_index()

agg_df = agg_df.dropna(subset=['skin_tone', 'games', 'redCards', 'height', 'weight']).copy()
agg_df['log_games'] = np.log(agg_df['games'])

# Covariates: height, weight (standardized or raw)
X = agg_df[['skin_tone', 'height', 'weight']]
X = sm.add_constant(X)
y = agg_df['redCards']
offset = agg_df['log_games']

# Fit Negative Binomial model to handle overdispersion in count data
try:
    model = sm.GLM(
        y, 
        X, 
        family=sm.families.NegativeBinomial(alpha=1.0), 
        offset=offset
    ).fit(cov_type='HC1')
    model_family = 'negative_binomial'
except Exception:
    model = sm.GLM(
        y, 
        X, 
        family=sm.families.Poisson(), 
        offset=offset
    ).fit(cov_type='HC1')
    model_family = 'poisson'

beta = model.params['skin_tone']
se_beta = model.bse['skin_tone']
p_val = model.pvalues['skin_tone']

# Estimand: Incidence Rate Ratio (IRR) for full change from 0 to 1
irr = float(np.exp(beta))
ci_low_irr = float(np.exp(beta - 1.96 * se_beta))
ci_upp_irr = float(np.exp(beta + 1.96 * se_beta))

# Standard error of IRR via delta method: SE(IRR) = IRR * SE(beta)
se_irr = float(irr * se_beta)

conclusion = 'significant_effect' if p_val < 0.05 else 'no_significant_effect'

output = {
    "effect_size": round(irr, 4),
    "effect_type": "irr",
    "standard_error": round(se_irr, 4),
    "p_value": round(float(p_val), 4),
    "ci_lower": round(ci_low_irr, 4),
    "ci_upper": round(ci_upp_irr, 4),
    "conclusion": conclusion,
    "model_family": model_family,
    "predictor_used": "mean of rater1 and rater2",
    "covariates_included": ["height", "weight"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "Excluded rows with missing skin tone ratings or covariates; aggregated to player level"
}

print(json.dumps(output))