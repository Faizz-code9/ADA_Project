import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

def main():
    file_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_synthetic_confirmatory_T0.0_r1/data.csv"
    df = pd.read_csv(file_path)

    # Missing data strategy: listwise deletion for missing skin_tone
    initial_len = len(df)
    df_clean = df.dropna(subset=['skin_tone']).copy()
    exclusions = f"Removed {initial_len - len(df_clean)} rows with missing skin_tone"

    # Outcome is count of red cards, offset is log(games)
    # Accounting for clustering at the player level (since each player is observed multiple times across referees)
    # Fit Poisson or Negative Binomial regression with exposure / offset = np.log(games)
    # Using statsmodels GLM with Poisson family and robust / clustered standard errors (cluster by playerID)
    covariates = ['position', 'height', 'weight', 'leagueCountry', 'yellowCards']
    formula = "redCards ~ skin_tone + C(position) + height + weight + C(leagueCountry) + yellowCards"

    # GLM with Poisson family and offset
    model = smf.glm(
        formula=formula,
        data=df_clean,
        family=sm.families.Poisson(),
        offset=np.log(df_clean['games'])
    )
    # Cluster-robust standard errors by playerID
    fit_res = model.fit(cov_type='cluster', cov_kwds={'groups': df_clean['playerID']})

    coef = fit_res.params['skin_tone']
    se_coef = fit_res.bse['skin_tone']
    pval = fit_res.pvalues['skin_tone']

    # Incidence rate ratio (IRR) for full change from 0 to 1
    irr = float(np.exp(coef))
    ci_lower = float(np.exp(coef - 1.959964 * se_coef))
    ci_upper = float(np.exp(coef + 1.959964 * se_coef))
    # Delta method for SE of IRR: SE(exp(b)) approx exp(b) * SE(b)
    se_irr = float(irr * se_coef)

    conclusion = "significant_effect" if pval < 0.05 else "no_significant_effect"

    output = {
        "effect_size": irr,
        "effect_type": "irr",
        "standard_error": se_irr,
        "p_value": float(pval),
        "ci_lower": ci_lower,
        "ci_upper": ci_upper,
        "conclusion": conclusion,
        "model_family": "poisson",
        "predictor_used": "skin_tone",
        "covariates_included": covariates,
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "clustered_se",
        "exclusions_applied": exclusions
    }

    print(json.dumps(output, indent=2))

if __name__ == "__main__":
    main()