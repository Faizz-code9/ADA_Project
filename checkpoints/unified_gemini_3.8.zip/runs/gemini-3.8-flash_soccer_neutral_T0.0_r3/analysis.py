import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

file_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_soccer_neutral_T0.0_r3/data.csv"
df = pd.read_csv(file_path)

# Drop missing skin tone values
df = df.dropna(subset=["rater1", "rater2"]).copy()

# Compute mean skin tone (0 to 1)
df["skin_tone"] = (df["rater1"] + df["rater2"]) / 2.0

# Prepare covariates: games played (offset or log_games), position, leagueCountry
# Handle missing position
df["position"] = df["position"].fillna("Unknown")

# Filter rows where games > 0
df = df[df["games"] > 0].copy()
df["log_games"] = np.log(df["games"])

# Prepare model formula / design matrix
# Poisson regression with offset log(games) or log(games) as covariate, clustered SE by player
covariates = ["skin_tone", "position", "leagueCountry"]
df_reg = df[["redCards", "skin_tone", "position", "leagueCountry", "log_games", "playerShort"]].dropna()

X = pd.get_dummies(df_reg[["skin_tone", "position", "leagueCountry"]], drop_first=True, dtype=float)
X = sm.add_constant(X)
y = df_reg["redCards"]
offset = df_reg["log_games"]

# Poisson regression with cluster-robust standard errors at the player level
poisson_mod = sm.GLM(y, X, family=sm.families.Poisson(), offset=offset)
res = poisson_mod.fit(cov_type="cluster", cov_kwds={"groups": df_reg["playerShort"]})

beta = res.params["skin_tone"]
se = res.bse["skin_tone"]
irr = np.exp(beta)

# 95% CI on IRR scale
ci_low_beta = res.conf_int().loc["skin_tone", 0]
ci_high_beta = res.conf_int().loc["skin_tone", 1]
ci_lower = np.exp(ci_low_beta)
ci_upper = np.exp(ci_high_beta)

# Delta method standard error for IRR = exp(beta) * se(beta)
irr_se = irr * se
p_val = res.pvalues["skin_tone"]

output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(irr_se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "poisson",
    "predictor_used": "average of rater1 and rater2",
    "covariates_included": ["position", "leagueCountry", "log(games) [offset]"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "Excluded rows with missing rater1/rater2 (players without photo ratings) or games <= 0"
}

print(json.dumps(output))