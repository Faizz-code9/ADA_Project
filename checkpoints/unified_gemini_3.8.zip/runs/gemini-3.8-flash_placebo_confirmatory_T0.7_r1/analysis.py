import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

file_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_placebo_confirmatory_T0.7_r1/data.csv"

# Load data
df = pd.read_csv(file_path)

# Drop missing values for key analysis variables
# rater1 and rater2 are missing for ~14.7%
df = df.dropna(subset=['rater1', 'rater2', 'games', 'redCards', 'playerShort']).copy()

# Construct continuous skin tone predictor (mean of rater1 and rater2)
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2.0

# Optional covariates: position (handle missing as 'Unknown')
df['position'] = df['position'].fillna('Unknown')

# Prepare Poisson regression with log(games) exposure / offset
# Outcome is redCards, offset is log(games)
df['log_games'] = np.log(df['games'])

# Model: redCards ~ skin_tone with clustered standard errors at player level
# Using statsmodels GLM with Poisson family and offset
X = sm.add_constant(df[['skin_tone']])

model = sm.GLM(
    df['redCards'],
    X,
    family=sm.families.Poisson(),
    offset=df['log_games']
)

# Fit model with clustered covariance at the player level (playerShort)
fit_res = model.fit(cov_type='cluster', cov_kwds={'groups': df['playerShort']})

# Estimand: IRR for full change from 0 to 1
beta = fit_res.params['skin_tone']
se_beta = fit_res.bse['skin_tone']
irr = float(np.exp(beta))
p_value = float(fit_res.pvalues['skin_tone'])
ci_lower_beta, ci_upper_beta = fit_res.conf_int().loc['skin_tone']
ci_lower = float(np.exp(ci_lower_beta))
ci_upper = float(np.exp(ci_upper_beta))

# Standard error of IRR via delta method: se(IRR) = IRR * se(beta)
irr_se = float(irr * se_beta)

conclusion = "significant_effect" if p_value < 0.05 else "no_significant_effect"

output = {
    "effect_size": irr,
    "effect_type": "irr",
    "standard_error": irr_se,
    "p_value": p_value,
    "ci_lower": ci_lower,
    "ci_upper": ci_upper,
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "average of rater1 and rater2",
    "covariates_included": [],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "dropped rows with missing skin tone ratings (rater1 or rater2)"
}

print(json.dumps(output, indent=2))