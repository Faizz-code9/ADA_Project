import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

def main():
    file_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_synthetic_skeptical_T0.7_r2/data.csv"
    df = pd.read_csv(file_path)

    # Missing data handling
    # skin_tone has 8% missing values, drop rows with missing skin_tone
    initial_len = len(df)
    df_clean = df.dropna(subset=['skin_tone']).copy()
    exclusions = f"Removed {initial_len - len(df_clean)} rows with missing skin_tone"

    # Outcome is redCards (count: 0 to 3), offset is log(games)
    # Using Poisson regression with robust/clustered standard errors (clustered on playerID)
    # Covariates: position, leagueCountry, height, weight, yellowCards
    df_clean['log_games'] = np.log(df_clean['games'])

    formula = "redCards ~ skin_tone + C(position) + C(leagueCountry) + height + weight + yellowCards"

    # Fit Poisson model with offset
    poisson_model = smf.poisson(formula, data=df_clean, offset=df_clean['log_games'])
    
    # Cluster on playerID to account for repeated player observations
    res = poisson_model.fit(cov_type='cluster', cov_kwds={'groups': df_clean['playerID']}, disp=False)

    coef = res.params['skin_tone']
    se_coef = res.bse['skin_tone']
    pval = res.pvalues['skin_tone']
    ci_lower_coef, ci_upper_coef = res.conf_int().loc['skin_tone']

    # Primary estimand: ratio effect (IRR for Poisson model) for the full change from 0 to 1
    irr = float(np.exp(coef))
    ci_lower_irr = float(np.exp(ci_lower_coef))
    ci_upper_irr = float(np.exp(ci_upper_coef))
    # Standard error of IRR via delta method: se(IRR) = IRR * se(beta)
    se_irr = float(irr * se_coef)

    conclusion = "significant_effect" if pval < 0.05 else "no_significant_effect"

    output = {
        "effect_size": irr,
        "effect_type": "irr",
        "standard_error": se_irr,
        "p_value": float(pval),
        "ci_lower": ci_lower_irr,
        "ci_upper": ci_upper_irr,
        "conclusion": conclusion,
        "model_family": "poisson",
        "predictor_used": "skin_tone",
        "covariates_included": ["position", "leagueCountry", "height", "weight", "yellowCards", "log(games)_offset"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "clustered_se",
        "exclusions_applied": exclusions
    }

    print(json.dumps(output, indent=2))

if __name__ == '__main__':
    main()