import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

# File path
file_path = (
    "/kaggle/working/outputs/runs/gemini-3.8-flash_disguise_skeptical_T0.7_r2/data.csv"
)

# Load data
df = pd.read_csv(file_path)

# Outcome: loan_application_rejections (values 0, 1, 2; mostly 0/1, count or binary)
# Primary estimand: the ratio effect of the risk evaluator score on loan_application_rejections
# (an odds ratio for a binary outcome, or an incidence rate ratio for a count model)
# Use a continuous 0-1 score (alpha, beta, or their average)
# Let's check average or alpha: "mean of risk_evaluator_alpha_score and risk_evaluator_beta_score"
df["risk_score_avg"] = (
    df["risk_evaluator_alpha_score"] + df["risk_evaluator_beta_score"]
) / 2.0

# Relevant columns
# Potential confounders: credit_score_index, annual_income_bracket, total_applications_reviewed,
# prior_approved_loans, prior_conditional_loans, prior_denied_loans, repayment_performance_score, formal_inquiry_notices
covariates = [
    "credit_score_index",
    "annual_income_bracket",
    "total_applications_reviewed",
    "prior_approved_loans",
    "prior_conditional_loans",
    "prior_denied_loans",
    "repayment_performance_score",
    "formal_inquiry_notices",
]

cols_needed = (
    ["loan_application_rejections", "risk_score_avg", "applicant_id"]
    + covariates
)
df_clean = df.dropna(subset=cols_needed).copy()

# Fit Poisson regression for count model to obtain IRR, clustering on applicant_id (since repeated applicants exist)
# loan_application_rejections has values 0, 1, 2 -> Poisson / negative binomial count model with IRR
X = sm.add_constant(df_clean[["risk_score_avg"] + covariates])
y = df_clean["loan_application_rejections"]

# Fit GLM Poisson with robust / clustered standard errors or standard Poisson
# Using sm.GLM with family Poisson
poisson_model = sm.GLM(y, X, family=sm.families.Poisson()).fit(
    cov_type="cluster", cov_kwds={"groups": df_clean["applicant_id"]}
)

# Coefficient for risk_score_avg
beta = poisson_model.params["risk_score_avg"]
se_beta = poisson_model.bse["risk_score_avg"]
p_val = poisson_model.pvalues["risk_score_avg"]
ci_lower_beta, ci_upper_beta = poisson_model.conf_int().loc["risk_score_avg"]

# Incidence Rate Ratio (IRR) for full change from 0 to 1
irr = float(np.exp(beta))
irr_ci_lower = float(np.exp(ci_lower_beta))
irr_ci_upper = float(np.exp(ci_upper_beta))
# SE of IRR via delta method: SE(IRR) = IRR * SE(beta)
irr_se = float(irr * se_beta)

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
    "effect_size": irr,
    "effect_type": "irr",
    "standard_error": irr_se,
    "p_value": float(p_val),
    "ci_lower": irr_ci_lower,
    "ci_upper": irr_ci_upper,
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "risk_score_avg (average of alpha and beta scores)",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "Dropped rows with missing values in risk evaluator scores or covariates",
}

print(json.dumps(output, indent=2))