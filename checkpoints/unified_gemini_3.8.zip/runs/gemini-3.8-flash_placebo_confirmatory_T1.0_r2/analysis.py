import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

# File path
data_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_placebo_confirmatory_T1.0_r2/data.csv"

# Load data
df = pd.read_csv(data_path)

# Drop missing skin tone ratings
df = df.dropna(subset=["rater1", "rater2"]).copy()

# Compute mean skin tone
df["skin_tone"] = (df["rater1"] + df["rater2"]) / 2.0

# Outcome is count of red cards with exposure = games
# We use a Poisson GLM with log link, offset = log(games), clustering SE on player
# Check missing values on essential covariates: games, redCards, skin_tone
df = df[df["games"] > 0].copy()

# Add log games as offset
df["log_games"] = np.log(df["games"])

# Fit Poisson GLM with clustered standard errors at the player level (playerShort)
# Model: redCards ~ skin_tone + offset(log_games)
X = sm.add_constant(df[["skin_tone"]])
y = df["redCards"]
exposure = df["games"]

poisson_model = sm.GLM(
    y,
    X,
    family=sm.families.Poisson(),
    exposure=exposure
)

# Fit with robust clustered SE on playerShort
fit_res = poisson_model.fit(cov_type="cluster", cov_kwds={"groups": df["playerShort"]})

beta = fit_res.params["skin_tone"]
se = fit_res.bse["skin_tone"]
p_val = fit_res.pvalues["skin_tone"]
ci_low_beta, ci_high_beta = fit_res.conf_int().loc["skin_tone"]

irr = float(np.exp(beta))
ci_low = float(np.exp(ci_low_beta))
ci_high = float(np.exp(ci_high_beta))

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
    "effect_size": round(irr, 4),
    "effect_type": "irr",
    "standard_error": round(float(se), 4),
    "p_value": round(float(p_val), 4),
    "ci_lower": round(ci_low, 4),
    "ci_upper": round(ci_high, 4),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "average of rater1 and rater2",
    "covariates_included": ["offset: log(games)"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "dropped rows with missing skin tone ratings or games <= 0"
}

print(json.dumps(output))