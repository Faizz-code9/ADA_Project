import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

# 1. Load data
data_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_disguise_neutral_T0.0_r2/data.csv"
df = pd.read_csv(data_path)

# Predictor: average of risk_evaluator_alpha_score and risk_evaluator_beta_score
# Both scores range from 0 to 1
df["risk_evaluator_avg_score"] = (df["risk_evaluator_alpha_score"] + df["risk_evaluator_beta_score"]) / 2.0

# Outcome: loan_application_rejections (binary / count, unique values 0, 1, 2)
# Since values are 0, 1, 2, we can either use logistic regression (rejections > 0) or Poisson/Negative Binomial
# Let's inspect: "ratio effect of the risk evaluator score on loan_application_rejections (an odds ratio for a binary outcome, or an incidence rate ratio for a count model; set effect_type accordingly), for the full change from 0 to 1"
# A logistic regression on binary outcome (loan_application_rejections >= 1) or Poisson/Log-linear model
# Given repeated loan officer or applicant clustering: applicants appear multiple times with different officers.
# Let's check covariates to include:
# credit_score_index, annual_income_bracket, total_applications_reviewed, prior_approved_loans,
# prior_conditional_loans, prior_denied_loans, repayment_performance_score, formal_inquiry_notices, elevated_risk_warnings

covariates = [
    "credit_score_index",
    "annual_income_bracket",
    "total_applications_reviewed",
    "prior_approved_loans",
    "prior_conditional_loans",
    "prior_denied_loans",
    "repayment_performance_score",
    "formal_inquiry_notices",
    "elevated_risk_warnings"
]

predictor = "risk_evaluator_avg_score"
outcome = "loan_application_rejections"

# Define binary outcome for logistic regression
df["rejection_binary"] = (df[outcome] > 0).astype(int)

# Subset and drop missing
cols_needed = [predictor, "rejection_binary", outcome, "applicant_id"] + covariates
model_df = df.dropna(subset=[predictor] + covariates).copy()

# Fit Logistic Regression with clustered standard errors on applicant_id (or loan_officer_id)
# Institutional loan approval officers exhibit bias against applicants based on scores
X = sm.add_constant(model_df[[predictor] + covariates])
y = model_df["rejection_binary"]

# Fit GLM Binomial (Logistic) with clustered SE at applicant_id level
# statsmodels GLM with cov_type='cluster'
model = sm.Logit(y, X).fit(cov_type="cluster", cov_kwds={"groups": model_df["applicant_id"]}, disp=False)

# Extract effect size (Odds Ratio)
beta = model.params[predictor]
se = model.bse[predictor]
pval = model.pvalues[predictor]
ci_low_beta, ci_upp_beta = model.conf_int().loc[predictor]

or_val = float(np.exp(beta))
ci_lower = float(np.exp(ci_low_beta))
ci_upper = float(np.exp(ci_upp_beta))

result = {
    "effect_size": float(or_val),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(pval),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if pval < 0.05 else "no_significant_effect",
    "model_family": "logistic",
    "predictor_used": "risk_evaluator_avg_score",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "dropped rows with missing risk scores or covariates"
}

print(json.dumps(result, indent=2))