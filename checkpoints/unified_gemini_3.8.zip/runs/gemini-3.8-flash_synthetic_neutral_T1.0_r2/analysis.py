import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
data_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_synthetic_neutral_T1.0_r2/data.csv"
df = pd.read_csv(data_path)

# 2. Data preparation / exclusions
# Exclude rows with missing skin_tone
df_clean = df.dropna(subset=["skin_tone"]).copy()

# Outcome is count of redCards, with exposure 'games'
# Fit Negative Binomial or Poisson regression with log(games) as offset
# Given dyadic structure (player-referee pair), cluster SE at player level (or referee level). Player clustering accounts for repeated player observations.
# Model covariates: position, height, weight, leagueCountry, yellowCards
covariates = ["position", "height", "weight", "leagueCountry", "yellowCards"]
formula = "redCards ~ skin_tone + C(position) + height + weight + C(leagueCountry) + yellowCards"

# Using Poisson model with offset np.log(games) and cluster-robust standard errors on playerID
poisson_model = smf.poisson(
    formula, data=df_clean, offset=np.log(df_clean["games"])
)
# Cluster standard errors by playerID
results = poisson_model.fit(
    cov_type="cluster", cov_kwds={"groups": df_clean["playerID"]}, disp=False
)

# Extract estimand: incidence rate ratio (IRR) for full change in skin_tone (0 to 1)
coef = results.params["skin_tone"]
se = results.bse["skin_tone"]
p_val = results.pvalues["skin_tone"]
ci_lower_coef, ci_upper_coef = results.conf_int().loc["skin_tone"]

irr = np.exp(coef)
irr_ci_lower = np.exp(ci_lower_coef)
irr_ci_upper = np.exp(ci_upper_coef)
# Standard error for IRR via Delta Method: SE(exp(beta)) = exp(beta) * SE(beta)
irr_se = irr * se

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(irr_se),
    "p_value": float(p_val),
    "ci_lower": float(irr_ci_lower),
    "ci_upper": float(irr_ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "skin_tone",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "dropped rows with missing skin_tone",
}

print(json.dumps(output, indent=2))