import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

# 1. Load data
data_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_placebo_neutral_T0.0_r1/data.csv"
df = pd.read_csv(data_path)

# 2. Exclusions & variable preparation
# Drop missing skin tone ratings
df_clean = df.dropna(subset=["rater1", "rater2"]).copy()

# Predictor: average skin tone
df_clean["skintone"] = (df_clean["rater1"] + df_clean["rater2"]) / 2.0

# Position categorical: impute missing with 'Unknown' to avoid dropping data
df_clean["position"] = df_clean["position"].fillna("Unknown")

# Handle missing height and weight via median imputation
df_clean["height"] = df_clean["height"].fillna(df_clean["height"].median())
df_clean["weight"] = df_clean["weight"].fillna(df_clean["weight"].median())

# Exposure: games played (offset = log(games))
df_clean = df_clean[df_clean["games"] > 0].copy()
df_clean["log_games"] = np.log(df_clean["games"])

# Covariates: position, leagueCountry, height, weight
covariates = ["height", "weight", "leagueCountry", "position"]

# Prepare design matrix
X = pd.get_dummies(
    df_clean[["skintone", "height", "weight", "leagueCountry", "position"]],
    columns=["leagueCountry", "position"],
    drop_first=True,
    dtype=float,
)
X = sm.add_constant(X)
y = df_clean["redCards"]
offset = df_clean["log_games"]

# 3. Fit Poisson model with cluster-robust standard errors at player level
# Red cards are count data; exposure is games
model = sm.GLM(y, X, family=sm.families.Poisson(), offset=offset)
# Cluster on playerShort
fit_res = model.fit(
    cov_type="cluster", cov_kwds={"groups": df_clean["playerShort"]}
)

# 4. Extract estimand (Incidence Rate Ratio for 0 to 1 change in skintone)
beta = fit_res.params["skintone"]
se_beta = fit_res.bse["skintone"]
irr = np.exp(beta)

ci_lower_beta = fit_res.conf_int().loc["skintone", 0]
ci_upper_beta = fit_res.conf_int().loc["skintone", 1]
ci_lower = np.exp(ci_lower_beta)
ci_upper = np.exp(ci_upper_beta)
p_val = fit_res.pvalues["skintone"]

# SE of IRR using delta method: SE(exp(beta)) = exp(beta) * SE(beta)
se_irr = float(irr * se_beta)

output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": se_irr,
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": (
        "significant_effect" if p_val < 0.05 else "no_significant_effect"
    ),
    "model_family": "poisson",
    "predictor_used": "average of rater1 and rater2",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion for ratings, median imputation for height and weight, missing category for position",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "dropped rows missing skin tone ratings (rater1, rater2) or games <= 0",
}

print(json.dumps(output, indent=2))