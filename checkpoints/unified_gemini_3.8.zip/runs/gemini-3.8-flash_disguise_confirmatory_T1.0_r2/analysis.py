import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

file_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_disguise_confirmatory_T1.0_r2/data.csv"
df = pd.read_csv(file_path)

# Predictor: average of risk_evaluator_alpha_score and risk_evaluator_beta_score
# Both are continuous 0-1 scores
df["risk_evaluator_mean_score"] = (
    df["risk_evaluator_alpha_score"] + df["risk_evaluator_beta_score"]
) / 2.0

# Outcome: loan_application_rejections (binary indicator 0 vs >0, or count)
# Mean is 0.01256, unique values are 3 (0, 1, 2).
# Let's check if binary logistic regression on rejection (>0) is standard, or logistic regression where y = (rejections > 0).
# The prompt: "the ratio effect of the risk evaluator score on loan_application_rejections (an odds ratio for a binary outcome, or an incidence rate ratio for a count model; set effect_type accordingly), for the full change from 0 to 1."
# Let's treat it as binary outcome: rejected (>=1) vs not rejected (0), and use logistic regression.
df["rejected"] = (df["loan_application_rejections"] > 0).astype(int)

# Covariates to control for confounding
covariates = [
    "credit_score_index",
    "annual_income_bracket",
    "total_applications_reviewed",
    "prior_approved_loans",
    "prior_conditional_loans",
    "prior_denied_loans",
    "repayment_performance_score",
    "formal_inquiry_notices",
    "elevated_risk_warnings",
]

model_cols = (
    ["rejected", "risk_evaluator_mean_score", "applicant_id"] + covariates
)
clean_df = df[model_cols].dropna().copy()

# Add constant
X = sm.add_constant(clean_df[["risk_evaluator_mean_score"] + covariates])
y = clean_df["rejected"]

# Fit logistic regression with clustering at applicant_id level (repeated applicant observations)
logit_mod = sm.Logit(y, X)
res = logit_mod.fit(
    cov_type="cluster",
    cov_kwds={"groups": clean_df["applicant_id"]},
    disp=False,
)

beta = res.params["risk_evaluator_mean_score"]
se = res.bse["risk_evaluator_mean_score"]
p_val = res.pvalues["risk_evaluator_mean_score"]

# Odds ratio for full change from 0 to 1: exp(beta)
or_effect = np.exp(beta)
# 95% CI on odds ratio scale via delta method / exponentiating CI of beta
ci_low = np.exp(beta - 1.959964 * se)
ci_high = np.exp(beta + 1.959964 * se)
# SE of the odds ratio via delta method: SE(exp(beta)) = exp(beta) * SE(beta)
se_or = or_effect * se

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
    "effect_size": float(or_effect),
    "effect_type": "odds_ratio",
    "standard_error": float(se_or),
    "p_value": float(p_val),
    "ci_lower": float(ci_low),
    "ci_upper": float(ci_high),
    "conclusion": conclusion,
    "model_family": "logistic",
    "predictor_used": "risk_evaluator_mean_score (average of alpha and beta scores)",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "dropped rows with missing evaluator scores or covariates",
}

print(json.dumps(output, indent=2))