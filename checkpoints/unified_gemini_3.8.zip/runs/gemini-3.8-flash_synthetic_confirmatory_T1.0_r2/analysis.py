import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

def main():
    file_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_synthetic_confirmatory_T1.0_r2/data.csv"
    df = pd.read_csv(file_path)

    # Missing data strategy: listwise deletion for missing skin_tone
    initial_len = len(df)
    df_clean = df.dropna(subset=['skin_tone']).copy()
    exclusions = f"Removed {initial_len - len(df_clean)} rows with missing skin_tone"

    # Outcome is count of red cards, with exposure 'games'
    # Fitting a Poisson regression model with exposure / offset = log(games)
    # Accounting for clustering at the player level using cluster-robust SEs
    # Include standard covariates: position, height, weight, leagueCountry
    df_clean['log_games'] = np.log(df_clean['games'])

    formula = "redCards ~ skin_tone + C(position) + height + weight + C(leagueCountry)"
    
    # Fit Poisson GLM
    model = smf.poisson(formula, data=df_clean, offset=df_clean['log_games'])
    res = model.fit(cov_type='cluster', cov_kwds={'groups': df_clean['playerID']}, disp=False)

    coef = res.params['skin_tone']
    se_coef = res.bse['skin_tone']
    pval = float(res.pvalues['skin_tone'])
    
    # Estimand: Incidence Rate Ratio (IRR) for full change 0 to 1
    irr = float(np.exp(coef))
    ci_lower_log = coef - 1.959964 * se_coef
    ci_upper_log = coef + 1.959964 * se_coef
    ci_lower = float(np.exp(ci_lower_log))
    ci_upper = float(np.exp(ci_upper_log))
    
    # Standard error of IRR via delta method: SE(IRR) = IRR * SE(coef)
    se_irr = float(irr * se_coef)

    conclusion = "significant_effect" if pval < 0.05 else "no_significant_effect"

    out = {
        "effect_size": irr,
        "effect_type": "irr",
        "standard_error": se_irr,
        "p_value": pval,
        "ci_lower": ci_lower,
        "ci_upper": ci_upper,
        "conclusion": conclusion,
        "model_family": "poisson",
        "predictor_used": "skin_tone",
        "covariates_included": ["position", "height", "weight", "leagueCountry", "games"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "clustered_se",
        "exclusions_applied": exclusions
    }

    print(json.dumps(out, indent=2))

if __name__ == "__main__":
    main()