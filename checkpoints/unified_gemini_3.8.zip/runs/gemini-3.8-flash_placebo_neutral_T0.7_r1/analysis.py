import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

# File path
data_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_placebo_neutral_T0.7_r1/data.csv"

# Load dataset
df = pd.read_csv(data_path)

# Drop missing values in key variables
cols_to_check = ["rater1", "rater2", "redCards", "games", "playerShort"]
df_clean = df.dropna(subset=cols_to_check).copy()

# Average skin tone rating
df_clean["skin_tone"] = (df_clean["rater1"] + df_clean["rater2"]) / 2.0

# Prepare variables for Poisson regression with log(games) exposure / offset
# Outcome: redCards (count of red cards in dyad)
# Offset: log(games)
df_clean["log_games"] = np.log(df_clean["games"])

# Fit Poisson model with cluster-robust standard errors at player level
# Model: redCards ~ skin_tone, offset=log(games)
exog = sm.add_constant(df_clean["skin_tone"])
poisson_model = sm.GLM(
    endog=df_clean["redCards"],
    exog=exog,
    offset=df_clean["log_games"],
    family=sm.families.Poisson(),
)

# Fit with cluster-robust standard errors clustered on player
res = poisson_model.fit(cov_type="cluster", cov_kwds={"groups": df_clean["playerShort"]})

# Extract coefficient for skin_tone (full 0 to 1 change)
coef = res.params["skin_tone"]
se = res.bse["skin_tone"]
pval = res.pvalues["skin_tone"]
irr = np.exp(coef)
ci_lower = np.exp(coef - 1.959964 * se)
ci_upper = np.exp(coef + 1.959964 * se)
# Standard error for IRR via delta method: SE(IRR) = IRR * SE(beta)
irr_se = irr * se

conclusion = "significant_effect" if pval < 0.05 else "no_significant_effect"

output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(irr_se),
    "p_value": float(pval),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "mean of rater1 and rater2",
    "covariates_included": ["offset: log(games)"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "Excluded rows with missing skin tone ratings (rater1/rater2)"
}

print(json.dumps(output, indent=2))