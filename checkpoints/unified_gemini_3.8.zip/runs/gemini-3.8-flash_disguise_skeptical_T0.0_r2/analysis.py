import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

# 1. Load data
data_path = (
    "/kaggle/working/outputs/runs/gemini-3.8-flash_disguise_skeptical_T0.0_r2/"
    "data.csv"
)
df = pd.read_csv(data_path)

# 2. Variable construction & preparation
# Primary estimand: ratio effect of risk evaluator score on loan_application_rejections
# Outcome: loan_application_rejections (count 0, 1, 2, mean 0.01256)
# Predictor: continuous 0-1 score (average of alpha and beta)
df["risk_evaluator_score"] = (
    df["risk_evaluator_alpha_score"] + df["risk_evaluator_beta_score"]
) / 2.0

# Relevant covariates
covars = [
    "credit_score_index",
    "annual_income_bracket",
    "total_applications_reviewed",
    "prior_approved_loans",
    "prior_conditional_loans",
    "prior_denied_loans",
    "repayment_performance_score",
    "formal_inquiry_notices",
    "elevated_risk_warnings",
]

all_vars = [
    "loan_application_rejections",
    "risk_evaluator_score",
    "applicant_id",
] + covars
df_clean = df.dropna(subset=all_vars).copy()

# 3. Model Fitting
# Poisson regression model for count outcome, clustered on applicant_id (or robust SE)
# Since loan_application_rejections is count (0, 1, 2)
X = df_clean[["risk_evaluator_score"] + covars]
X = sm.add_constant(X)
y = df_clean["loan_application_rejections"]

model = sm.GLM(y, X, family=sm.families.Poisson())
res = model.fit(
    cov_type="cluster", cov_kwds={"groups": df_clean["applicant_id"]}
)

# Extract effect for risk_evaluator_score
# Primary estimand is IRR (full change from 0 to 1 -> exp(coef))
coef = res.params["risk_evaluator_score"]
se_coef = res.bse["risk_evaluator_score"]
irr = float(np.exp(coef))

# Delta method or CI on log scale then exponentiated
ci_lower_log, ci_upper_log = res.conf_int().loc["risk_evaluator_score"]
ci_lower = float(np.exp(ci_lower_log))
ci_upper = float(np.exp(ci_upper_log))
# SE of IRR via delta method: exp(coef) * se_coef
se_irr = float(irr * se_coef)
pval = float(res.pvalues["risk_evaluator_score"])

conclusion = "significant_effect" if pval < 0.05 else "no_significant_effect"

out = {
    "effect_size": round(irr, 4),
    "effect_type": "irr",
    "standard_error": round(se_irr, 4),
    "p_value": round(pval, 6),
    "ci_lower": round(ci_lower, 4),
    "ci_upper": round(ci_upper, 4),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "average of risk_evaluator_alpha_score and risk_evaluator_beta_score",
    "covariates_included": covars,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "dropped rows with missing values in outcome, predictor, or covariates",
}

print(json.dumps(out))