import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

def run_analysis():
    df = pd.read_csv('/kaggle/working/outputs/runs/gemini-3.8-flash_placebo_skeptical_T1.0_r2/data.csv')
    
    # Exclude rows missing skin-tone ratings
    initial_len = len(df)
    df = df.dropna(subset=['rater1', 'rater2', 'games']).copy()
    
    # Construct average skin tone predictor
    df['skin_tone'] = (df['rater1'] + df['rater2']) / 2.0
    
    # Keep rows where games > 0
    df = df[df['games'] > 0].copy()
    
    # Model: Poisson regression with offset log(games), clustering standard errors on playerShort
    # redCards ~ skin_tone + C(leagueCountry) + C(position)
    # Handle position missingness by treating as 'Unknown'
    df['position'] = df['position'].fillna('Unknown')
    
    # Fit Poisson model with offset=log(games)
    formula = 'redCards ~ skin_tone + C(leagueCountry) + C(position)'
    
    # Use GLM with exposure=games or offset=np.log(games)
    # statsmodels GLM with clustered SE
    mod = smf.glm(
        formula=formula,
        data=df,
        family=sm.families.Poisson(),
        offset=np.log(df['games'])
    )
    
    # Cluster on playerShort (or refNum; clustering on player is standard in Silberzahn et al.)
    res = mod.fit(cov_type='cluster', cov_kwds={'groups': df['playerShort']})
    
    coef = res.params['skin_tone']
    se = res.bse['skin_tone']
    p_val = res.pvalues['skin_tone']
    ci_low_coef, ci_high_coef = res.conf_int().loc['skin_tone']
    
    # Incidence Rate Ratio (IRR) for full 0 to 1 change
    irr = float(np.exp(coef))
    ci_lower = float(np.exp(ci_low_coef))
    ci_upper = float(np.exp(ci_high_coef))
    
    # Standard error for IRR via delta method: se(exp(b)) = exp(b) * se(b)
    irr_se = float(irr * se)
    
    conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"
    
    covariates = ['leagueCountry', 'position']
    
    output = {
        "effect_size": float(irr),
        "effect_type": "irr",
        "standard_error": irr_se,
        "p_value": float(p_val),
        "ci_lower": ci_lower,
        "ci_upper": ci_upper,
        "conclusion": conclusion,
        "model_family": "poisson",
        "predictor_used": "mean of rater1 and rater2",
        "covariates_included": covariates,
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "clustered_se",
        "exclusions_applied": "dropped rows missing rater1 or rater2 (n=21,407) and games <= 0"
    }
    
    print(json.dumps(output))

if __name__ == '__main__':
    run_analysis()