import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
data_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_soccer_skeptical_T0.7_r3/data.csv"
df = pd.read_csv(data_path)

# 2. Data Preparation
# Exclude rows where skin tone rating is missing
df = df.dropna(subset=["rater1", "rater2"]).copy()

# Compute mean skin tone rating (continuous 0 to 1)
df["skin_tone"] = (df["rater1"] + df["rater2"]) / 2.0

# Prepare outcome and exposure:
# Poisson or Negative Binomial regression on count of red cards, with log(games) offset
# Filter games > 0 (all games >= 1 in data dictionary)
df = df[df["games"] > 0].copy()
df["log_games"] = np.log(df["games"])

# Handle covariates: position, height, weight, leagueCountry
# Fill missing position as 'Unknown'
df["position"] = df["position"].fillna("Unknown")
# Drop rows with missing height/weight if any, or fill median
df["height"] = df["height"].fillna(df["height"].median())
df["weight"] = df["weight"].fillna(df["weight"].median())

# 3. Fit Model
# Negative Binomial model or Poisson with clustered SEs.
# Clustered standard errors at player level (or ref level; player level captures repeated measures across refs)
formula = "redCards ~ skin_tone + height + weight + C(position) + C(leagueCountry)"

poisson_mod = smf.poisson(formula, data=df, offset=df["log_games"])
# Red cards are clustered by playerShort (or refNum)
# Standard practice in many-analysts project: cluster by player
res = poisson_mod.fit(cov_type="cluster", cov_kwds={"groups": df["playerShort"]}, disp=False)

# Primary estimand: Incidence Rate Ratio (IRR) for full change from 0 to 1
beta = res.params["skin_tone"]
se_beta = res.bse["skin_tone"]
p_val = res.pvalues["skin_tone"]
ci_low_beta, ci_upp_beta = res.conf_int().loc["skin_tone"]

irr = np.exp(beta)
ci_lower = np.exp(ci_low_beta)
ci_upper = np.exp(ci_upp_beta)

# Delta method standard error for IRR = exp(beta) * se_beta
se_irr = irr * se_beta

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

out = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se_irr),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "average of rater1 and rater2",
    "covariates_included": ["height", "weight", "position", "leagueCountry", "log(games) offset"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "dropped rows missing rater1 or rater2"
}

print(json.dumps(out, indent=2))