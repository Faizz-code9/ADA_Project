import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

def run_analysis():
    data_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_disguise_confirmatory_T0.7_r2/data.csv"
    df = pd.read_csv(data_path)
    
    # Primary estimand: ratio effect of risk evaluator score on loan_application_rejections
    # loan_application_rejections has values 0, 1, 2 (count of rejections).
    # Predictor: average of alpha and beta scores (continuous 0-1 score)
    df['risk_score_mean'] = (df['risk_evaluator_alpha_score'] + df['risk_evaluator_beta_score']) / 2.0
    
    # Model: Poisson regression (or negative binomial) for count outcome, clustered on applicant_id or loan_officer_id
    # Covariates: credit_score_index, annual_income_bracket, total_applications_reviewed
    model_vars = ['loan_application_rejections', 'risk_score_mean', 'credit_score_index', 
                  'annual_income_bracket', 'total_applications_reviewed', 'applicant_id']
    
    df_clean = df.dropna(subset=model_vars).copy()
    
    X = df_clean[['risk_score_mean', 'credit_score_index', 'annual_income_bracket', 'total_applications_reviewed']]
    X = sm.add_constant(X)
    y = df_clean['loan_application_rejections']
    
    # Poisson model with robust / clustered standard errors by applicant_id
    poisson_model = sm.GLM(y, X, family=sm.families.Poisson())
    fit_res = poisson_model.fit(cov_type='cluster', cov_kwds={'groups': df_clean['applicant_id']})
    
    # Predictor of interest: risk_score_mean
    coef = fit_res.params['risk_score_mean']
    se = fit_res.bse['risk_score_mean']
    p_val = fit_res.pvalues['risk_score_mean']
    ci_low_coef, ci_high_coef = fit_res.conf_int().loc['risk_score_mean']
    
    # Ratio effect (Incidence Rate Ratio for full change 0 to 1)
    irr = float(np.exp(coef))
    # Delta method or exponentiated CI for IRR:
    ci_lower = float(np.exp(ci_low_coef))
    ci_upper = float(np.exp(ci_high_coef))
    # Standard error of IRR via delta method: SE(IRR) = IRR * SE(coef)
    irr_se = float(irr * se)
    
    conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"
    
    result = {
        "effect_size": irr,
        "effect_type": "irr",
        "standard_error": irr_se,
        "p_value": float(p_val),
        "ci_lower": ci_lower,
        "ci_upper": ci_upper,
        "conclusion": conclusion,
        "model_family": "poisson",
        "predictor_used": "average of risk_evaluator_alpha_score and risk_evaluator_beta_score",
        "covariates_included": ["credit_score_index", "annual_income_bracket", "total_applications_reviewed"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "clustered_se",
        "exclusions_applied": "dropped rows with missing risk scores, credit score index, or income bracket"
    }
    
    print(json.dumps(result, indent=2))

if __name__ == "__main__":
    run_analysis()