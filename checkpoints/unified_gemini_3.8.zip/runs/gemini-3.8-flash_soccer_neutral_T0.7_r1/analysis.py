import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

# 1. Load data
data_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_soccer_neutral_T0.7_r1/data.csv"
df = pd.read_csv(data_path)

# 2. Data Preparation
# Predictor: average of rater1 and rater2
df = df.dropna(subset=['rater1', 'rater2', 'redCards', 'games']).copy()
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2.0

# Aggregate by player to study player-level red cards offset by total games, or model directly with offset
# Modeling directly at dyad level with games as offset / exposure:
# Poisson regression: redCards ~ skin_tone with exposure = games
# Clustering standard errors at the player level (since skin_tone is assigned at player level)
# We also include position and leagueCountry as basic covariates if available, or keep minimal/robust dyad-level GLM
df['has_red'] = (df['redCards'] > 0).astype(int)

# Filter out zero games if any (games min is 1 according to dictionary)
df = df[df['games'] > 0].copy()

# Fit Poisson GLM with offset = log(games) and robust standard errors clustered on playerShort
# Outcome: redCards
df['log_games'] = np.log(df['games'])

# Model specification: Poisson model with player-clustered standard errors
X = sm.add_constant(df[['skin_tone']])
y = df['redCards']
exposure = df['games']

model = sm.GLM(
    y, 
    X, 
    family=sm.families.Poisson(), 
    offset=df['log_games']
)

# Cluster standard errors by playerShort
groups = df['playerShort']
fit = model.fit(cov_type='cluster', cov_kwds={'groups': groups})

# Extract results for skin_tone (full 0 to 1 change)
beta = fit.params['skin_tone']
se_beta = fit.bse['skin_tone']
pval = fit.pvalues['skin_tone']

# Incidence Rate Ratio (IRR) = exp(beta)
irr = float(np.exp(beta))
ci_low_beta, ci_high_beta = fit.conf_int().loc['skin_tone']
ci_lower = float(np.exp(ci_low_beta))
ci_upper = float(np.exp(ci_high_beta))

# Standard error of IRR via delta method: se(IRR) = IRR * se(beta)
irr_se = float(irr * se_beta)

conclusion = "significant_effect" if pval < 0.05 else "no_significant_effect"

output = {
    "effect_size": round(irr, 4),
    "effect_type": "irr",
    "standard_error": round(irr_se, 4),
    "p_value": round(float(pval), 5),
    "ci_lower": round(ci_lower, 4),
    "ci_upper": round(ci_upper, 4),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "average of rater1 and rater2 (skin_tone)",
    "covariates_included": [],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "dropped rows with missing skin tone ratings (rater1, rater2)"
}

print(json.dumps(output, indent=2))