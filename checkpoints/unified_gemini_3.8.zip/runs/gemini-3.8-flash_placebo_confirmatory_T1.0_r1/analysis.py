import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

file_path = (
    "/kaggle/working/outputs/runs/gemini-3.8-flash_placebo_confirmatory_T1.0_r1/data.csv"
)

# Load data
df = pd.read_csv(file_path)

# Drop missing skin tone ratings
df_clean = df.dropna(subset=["rater1", "rater2", "games", "redCards"]).copy()

# Average skin tone rating
df_clean["skin_tone"] = (df_clean["rater1"] + df_clean["rater2"]) / 2.0

# Ensure games > 0 for offset
df_clean = df_clean[df_clean["games"] > 0].copy()

# Aggregate or fit directly: Poisson regression with offset log(games)
# Red cards is count outcome, games is exposure.
# Cluster robust standard errors by player (playerShort)
y = df_clean["redCards"].astype(int)
X = sm.add_constant(df_clean[["skin_tone"]])
exposure = df_clean["games"]

# Fit Poisson GLM with robust clustered standard errors
poisson_model = sm.GLM(
    y,
    X,
    family=sm.families.Poisson(),
    offset=np.log(exposure),
)
res = poisson_model.fit(cov_type="cluster", cov_kwds={"groups": df_clean["playerShort"]})

# Extract results for skin_tone (full 0 to 1 change)
log_irr = res.params["skin_tone"]
se_log_irr = res.bse["skin_tone"]
p_val = float(res.pvalues["skin_tone"])

# Confidence interval on log scale, exponentiate for IRR
ci_lower_log, ci_upper_log = res.conf_int().loc["skin_tone"]

irr = float(np.exp(log_irr))
irr_ci_lower = float(np.exp(ci_lower_log))
irr_ci_upper = float(np.exp(ci_upper_log))
# Standard error of IRR via delta method: se(IRR) = IRR * se(beta)
irr_se = float(irr * se_log_irr)

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
    "effect_size": round(irr, 4),
    "effect_type": "irr",
    "standard_error": round(irr_se, 4),
    "p_value": round(p_val, 5),
    "ci_lower": round(irr_ci_lower, 4),
    "ci_upper": round(irr_ci_upper, 4),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "mean of rater1 and rater2",
    "covariates_included": [],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "removed rows with missing skin tone ratings (rater1, rater2) or games <= 0"
}

print(json.dumps(output))