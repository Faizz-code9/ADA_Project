import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

file_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_placebo_confirmatory_T0.0_r1/data.csv"
df = pd.read_csv(file_path)

# Drop rows missing rater scores
df = df.dropna(subset=["rater1", "rater2"]).copy()

# Skin tone predictor: mean of rater1 and rater2 (continuous 0 to 1)
df["skin_tone"] = (df["rater1"] + df["rater2"]) / 2.0

# Aggregating to player level or modeling at dyad level with offset:
# Each dyad has games (exposure) and redCards (count).
# Modeling redCards using negative binomial or Poisson regression with log(games) offset.
# Player-level clustering or player aggregation is standard.
# Let's aggregate by player: each player has total redCards, total games, position, height, weight, leagueCountry.
# Note that skin tone is fixed per player! So aggregating to player level avoids referee-level pseudoreplication
# and preserves exact counts.
agg_dict = {
    "redCards": "sum",
    "games": "sum",
    "skin_tone": "first",
    "height": "first",
    "weight": "first",
    "position": lambda x: x.dropna().iloc[0] if len(x.dropna()) > 0 else np.nan,
    "leagueCountry": "first",
}
player_df = df.groupby("playerShort").agg(agg_dict).reset_index()

# Clean missing values in covariates
player_df = player_df.dropna(subset=["skin_tone", "games", "redCards", "height", "weight", "position"]).copy()
player_df = player_df[player_df["games"] > 0].copy()

# Fit negative binomial / Poisson regression with log(games) as exposure
player_df["log_games"] = np.log(player_df["games"])

# Create formula / design matrix
X_df = pd.get_dummies(player_df[["skin_tone", "height", "weight", "position", "leagueCountry"]], drop_first=True, dtype=float)
X = sm.add_constant(X_df)
y = player_df["redCards"]
exposure = player_df["log_games"]

# Poisson / Negative binomial GLM
model = sm.GLM(y, X, family=sm.families.NegativeBinomial(alpha=1.0), offset=exposure)
try:
    res = model.fit()
except Exception:
    # Fallback to Poisson with robust SE
    model = sm.GLM(y, X, family=sm.families.Poisson(), offset=exposure)
    res = model.fit(cov_type="HC1")

# Extract effect of skin_tone
coef = res.params["skin_tone"]
se = res.bse["skin_tone"]
pval = res.pvalues["skin_tone"]
ci_lower_log = res.conf_int().loc["skin_tone", 0]
ci_upper_log = res.conf_int().loc["skin_tone", 1]

# Primary estimand: incidence rate ratio for full change 0 to 1
irr = float(np.exp(coef))
ci_lower = float(np.exp(ci_lower_log))
ci_upper = float(np.exp(ci_upper_log))
se_irr = float(irr * se)  # delta method approximation for IRR SE

output = {
    "effect_size": round(irr, 4),
    "effect_type": "irr",
    "standard_error": round(se_irr, 4),
    "p_value": round(float(pval), 5),
    "ci_lower": round(ci_lower, 4),
    "ci_upper": round(ci_upper, 4),
    "conclusion": "significant_effect" if pval < 0.05 else "no_significant_effect",
    "model_family": "negative_binomial",
    "predictor_used": "average of rater1 and rater2",
    "covariates_included": ["height", "weight", "position", "leagueCountry"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "aggregated to player level; dropped players with missing skin tone, height, weight, or position"
}

print(json.dumps(output, indent=2))