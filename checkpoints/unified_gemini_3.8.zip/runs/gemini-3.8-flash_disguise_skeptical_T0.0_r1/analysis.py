import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

file_path = (
    "/kaggle/working/outputs/runs/gemini-3.8-flash_disguise_skeptical_T0.0_r1/data.csv"
)
df = pd.read_csv(file_path)

# Predictor: average of risk_evaluator_alpha_score and risk_evaluator_beta_score
# Let's check missingness and compute predictor
df["risk_evaluator_score"] = (
    df["risk_evaluator_alpha_score"] + df["risk_evaluator_beta_score"]
) / 2.0

# Outcome is loan_application_rejections (count 0, 1, 2)
# The prompt mentions:
# "the ratio effect of the risk evaluator score on loan_application_rejections (an odds ratio for a binary outcome, or an incidence rate ratio for a count model; set effect_type accordingly), for the full change from 0 to 1. Use a continuous 0-1 score (alpha, beta or their average; say which in predictor_used)."
# Since loan_application_rejections has values 0, 1, 2, a Poisson regression (or logistic if binarized, but Poisson is standard for count of rejections with total_applications_reviewed as potential exposure or covariate) is appropriate.
# Let's check if Poisson GLM or negative binomial or logistic (e.g. any rejection vs none, or count directly).
# Using Poisson GLM for count with log link gives IRR = exp(beta) for full change 0 to 1.
# Key covariates: credit_score_index, annual_income_bracket, total_applications_reviewed, prior_approved_loans, prior_conditional_loans, prior_denied_loans.
# Let's cluster SE on loan_officer_id or applicant_id. Since pairings are applicant x loan_officer, applicant_id or loan_officer_id.
# Let's include standard covariates and use listwise deletion for missing values.

covariates = [
    "credit_score_index",
    "annual_income_bracket",
    "total_applications_reviewed",
    "prior_approved_loans",
    "prior_conditional_loans",
    "prior_denied_loans",
]

cols_needed = (
    ["loan_application_rejections", "risk_evaluator_score", "loan_officer_id"]
    + covariates
)
df_clean = df.dropna(subset=cols_needed).copy()

X = df_clean[["risk_evaluator_score"] + covariates]
X = sm.add_constant(X)
y = df_clean["loan_application_rejections"]

# Fit Poisson GLM
model = sm.GLM(
    y,
    X,
    family=sm.families.Poisson(),
)
res = model.fit(
    cov_type="cluster", cov_kwds={"groups": df_clean["loan_officer_id"]}
)

coef = res.params["risk_evaluator_score"]
se = res.bse["risk_evaluator_score"]
p_val = res.pvalues["risk_evaluator_score"]

irr = np.exp(coef)
ci_lower = np.exp(coef - 1.95996 * se)
ci_upper = np.exp(coef + 1.95996 * se)
irr_se = irr * se

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(irr_se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "average of risk_evaluator_alpha_score and risk_evaluator_beta_score",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "none",
}

print(json.dumps(output))