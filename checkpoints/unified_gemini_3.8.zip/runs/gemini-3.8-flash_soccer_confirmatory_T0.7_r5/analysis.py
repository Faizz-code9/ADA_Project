import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

# 1. Load data
data_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_soccer_confirmatory_T0.7_r5/data.csv"
df = pd.read_csv(data_path)

# 2. Data Cleaning & Preparation
# Drop rows missing skin tone ratings
df = df.dropna(subset=['rater1', 'rater2', 'games', 'redCards']).copy()

# Average skin tone rating across raters (continuous 0 to 1)
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2.0

# Aggregate to player level to avoid player-referee clustering issues and handle exposure properly
# Each player's total red cards and total games played
player_df = df.groupby('playerShort').agg({
    'redCards': 'sum',
    'games': 'sum',
    'skin_tone': 'first',
    'height': 'first',
    'weight': 'first',
    'leagueCountry': 'first',
    'position': 'first'
}).reset_index()

# Listwise deletion for key covariates if missing, or use minimal clean covariates
# To maximize sample and statistical power, adjust for leagueCountry and position (filling missing position as 'Unknown')
player_df['position'] = player_df['position'].fillna('Unknown')
player_df = player_df[player_df['games'] > 0].copy()

# 3. Fit Poisson regression with log(games) offset (Incidence Rate Model)
# Outcome: redCards count; Exposure: games
y = player_df['redCards']
X = pd.get_dummies(player_df[['skin_tone', 'leagueCountry', 'position']], drop_first=True, dtype=float)
X = sm.add_constant(X)
offset = np.log(player_df['games'])

# Use Poisson model with robust (HC1/sandwich) standard errors to account for potential overdispersion
poisson_mod = sm.GLM(y, X, family=sm.families.Poisson(), offset=offset)
res = poisson_mod.fit(cov_type='HC1')

# 4. Extract Primary Estimand (IRR for full 0 to 1 change in skin tone)
beta = res.params['skin_tone']
se_beta = res.bse['skin_tone']
p_val = res.pvalues['skin_tone']

irr = float(np.exp(beta))
ci_lower = float(np.exp(beta - 1.95996 * se_beta))
ci_upper = float(np.exp(beta + 1.95996 * se_beta))

# Standard error of IRR via delta method: SE(exp(beta)) = exp(beta) * SE(beta)
se_irr = float(irr * se_beta)

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
    "effect_size": round(irr, 4),
    "effect_type": "irr",
    "standard_error": round(se_irr, 4),
    "p_value": round(float(p_val), 4),
    "ci_lower": round(ci_lower, 4),
    "ci_upper": round(ci_upper, 4),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "average of rater1 and rater2 (skin_tone)",
    "covariates_included": ["leagueCountry", "position"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "dropped rows with missing skin tone ratings (rater1, rater2); aggregated to player level"
}

print(json.dumps(output, indent=2))