import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

# File path
data_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_soccer_skeptical_T1.0_r3/data.csv"

# Load data
df = pd.read_csv(data_path)

# Drop missing skin tone ratings
df = df.dropna(subset=["rater1", "rater2"]).copy()

# Predictor: average of rater1 and rater2 (scale 0 to 1)
df["skin_tone"] = (df["rater1"] + df["rater2"]) / 2.0

# Outcome: redCards (count model using Poisson / Negative Binomial with exposure=games)
# Also consider games offset: redCards per game
df = df[df["games"] > 0].copy()

# Add log(games) as offset
df["log_games"] = np.log(df["games"])

# Model: Poisson regression with clustered standard errors at player level
# Controlling for leagueCountry, position (handling NaNs as 'Unknown')
df["position"] = df["position"].fillna("Unknown")

# Construct design matrix
# Select covariates: position, leagueCountry
X = pd.get_dummies(df[["position", "leagueCountry"]], drop_first=True, dtype=float)
X.insert(0, "skin_tone", df["skin_tone"])
X = sm.add_constant(X)

y = df["redCards"]

# Fit Poisson GLM with exposure / offset
model = sm.GLM(
    y,
    X,
    family=sm.families.Poisson(),
    offset=df["log_games"]
)

# Fit with cluster-robust standard errors on playerShort
# Statsmodels GLM supports cov_type='cluster' with cov_kwds={'groups': ...}
res = model.fit(cov_type="cluster", cov_kwds={"groups": df["playerShort"]})

# Extract results for skin_tone (continuous 0 to 1)
coef = res.params["skin_tone"]
se = res.bse["skin_tone"]
ci_lower_coef, ci_upper_coef = res.conf_int().loc["skin_tone"]
p_val = res.pvalues["skin_tone"]

# Primary estimand: Incidence Rate Ratio (IRR) for full 0 to 1 change
irr = np.exp(coef)
irr_ci_lower = np.exp(ci_lower_coef)
irr_ci_upper = np.exp(ci_upper_coef)
# SE of IRR using delta method: se(IRR) = IRR * se(coef)
se_irr = irr * se

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se_irr),
    "p_value": float(p_val),
    "ci_lower": float(irr_ci_lower),
    "ci_upper": float(irr_ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "average of rater1 and rater2",
    "covariates_included": ["position", "leagueCountry"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "Dropped rows missing rater1 or rater2 (no photo/rating) and games == 0"
}

print(json.dumps(output, indent=2))