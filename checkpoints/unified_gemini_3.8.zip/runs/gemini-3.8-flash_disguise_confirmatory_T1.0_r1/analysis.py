import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

# 1. Load data
data_path = (
    "/kaggle/working/outputs/runs/gemini-3.8-flash_disguise_confirmatory_T1.0_r1/data.csv"
)
df = pd.read_csv(data_path)

# 2. Variable construction & Cleaning
# Predictor: average of alpha and beta scores, or alpha score if both identical/either used
# Let's check missingness. Both have missing in 21,407 rows.
# Predictor: mean of risk_evaluator_alpha_score and risk_evaluator_beta_score
df["risk_evaluator_score"] = (
    df["risk_evaluator_alpha_score"] + df["risk_evaluator_beta_score"]
) / 2.0

# Outcome: loan_application_rejections (0, 1, 2) - mean is 0.01256. Highly rare binary/count.
# As primary estimand specifies: "the ratio effect of the risk evaluator score on loan_application_rejections (an odds ratio for a binary outcome, or an incidence rate ratio for a count model; set effect_type accordingly)"
# Let's treat it as binary indicator (loan_application_rejections > 0) with logistic regression OR Poisson count model.
# Since loan_application_rejections takes values 0, 1, 2, binary or Poisson is standard.
# Let's use logistic regression for binary rejection (or Poisson for count). Poisson with log link gives IRR directly.
# Let's use Poisson regression (GLM with Poisson family and log link) or Logistic regression.
# If logistic: binary outcome: df['rejected'] = (df['loan_application_rejections'] > 0).astype(int).
# Given the instructions "an odds ratio for a binary outcome, or an incidence rate ratio for a count model", both are acceptable.
# Let's check logistic regression:
df["rejected_binary"] = (df["loan_application_rejections"] > 0).astype(int)

# Covariates: credit_score_index, annual_income_bracket, total_applications_reviewed, prior_approved_loans, prior_denied_loans
covariates = [
    "credit_score_index",
    "annual_income_bracket",
    "total_applications_reviewed",
]
model_vars = (
    ["rejected_binary", "risk_evaluator_score", "applicant_id"] + covariates
)

# Missing data strategy: listwise deletion on model variables
df_model = df.dropna(subset=model_vars).copy()

# Fit Logistic regression with clustered SE by applicant_id (panel / repeated applicant pairings)
X = df_model[["risk_evaluator_score"] + covariates]
X = sm.add_constant(X)
y = df_model["rejected_binary"]

logit_mod = sm.Logit(y, X)
fit_res = logit_mod.fit(
    cov_type="cluster",
    cov_kwds={"groups": df_model["applicant_id"]},
    disp=False,
)

# Estimand: Odds Ratio for full change from 0 to 1 of risk_evaluator_score
coef = fit_res.params["risk_evaluator_score"]
se = fit_res.bse["risk_evaluator_score"]
pval = fit_res.pvalues["risk_evaluator_score"]
ci_lower_coef, ci_upper_coef = fit_res.conf_int().loc["risk_evaluator_score"]

or_est = float(np.exp(coef))
ci_lower = float(np.exp(ci_lower_coef))
ci_upper = float(np.exp(ci_upper_coef))

# Delta method for SE of odds ratio: SE(OR) approx OR * SE(beta)
or_se = float(or_est * se)

conclusion = "significant_effect" if pval < 0.05 else "no_significant_effect"

output = {
    "effect_size": or_est,
    "effect_type": "odds_ratio",
    "standard_error": or_se,
    "p_value": float(pval),
    "ci_lower": ci_lower,
    "ci_upper": ci_upper,
    "conclusion": conclusion,
    "model_family": "logistic",
    "predictor_used": "average of risk_evaluator_alpha_score and risk_evaluator_beta_score",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "dropped rows with missing values in model variables",
}

print(json.dumps(output, indent=2))