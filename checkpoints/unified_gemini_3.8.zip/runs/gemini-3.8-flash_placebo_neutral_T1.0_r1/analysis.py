import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

# 1. Load the data
file_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_placebo_neutral_T1.0_r1/data.csv"
df = pd.read_csv(file_path)

# 2. Data Preparation & Cleaning
# Exclude rows where skin tone rating is missing
df_clean = df.dropna(subset=["rater1", "rater2"]).copy()

# Average skin tone rating (continuous 0-1)
df_clean["skin_tone"] = (df_clean["rater1"] + df_clean["rater2"]) / 2.0

# Red cards is count outcome, games is exposure/offset
df_clean = df_clean[df_clean["games"] > 0].copy()
df_clean["log_games"] = np.log(df_clean["games"])

# Position: fill missing with 'Unknown'
df_clean["position"] = df_clean["position"].fillna("Unknown")

# Handle any missing height/weight if included, but minimal set of key covariates is clean
# Create dummies for position and leagueCountry
pos_dummies = pd.get_dummies(df_clean["position"], prefix="pos", drop_first=True, dtype=float)
league_dummies = pd.get_dummies(df_clean["leagueCountry"], prefix="league", drop_first=True, dtype=float)

X = pd.concat([df_clean[["skin_tone"]], pos_dummies, league_dummies], axis=1)
X = sm.add_constant(X)
y = df_clean["redCards"]

# Fit Poisson regression with cluster-robust standard errors on player (playerShort)
# Exposure = games (via offset)
model = sm.GLM(
    y,
    X,
    family=sm.families.Poisson(),
    offset=df_clean["log_games"]
)
res = model.fit(cov_type="cluster", cov_kwds={"groups": df_clean["playerShort"]})

# Extract estimand: Incidence Rate Ratio (IRR) for full change from 0 to 1
beta = res.params["skin_tone"]
se = res.bse["skin_tone"]
p_val = res.pvalues["skin_tone"]
ci_low_beta, ci_high_beta = res.conf_int().loc["skin_tone"]

irr = np.exp(beta)
irr_ci_low = np.exp(ci_low_beta)
irr_ci_high = np.exp(ci_high_beta)
# Delta method SE for exp(beta): SE(irr) = exp(beta) * SE(beta)
irr_se = irr * se

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(irr_se),
    "p_value": float(p_val),
    "ci_lower": float(irr_ci_low),
    "ci_upper": float(irr_ci_high),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "average of rater1 and rater2",
    "covariates_included": ["position", "leagueCountry"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "Excluded rows with missing skin tone ratings (rater1, rater2) and games <= 0"
}

print(json.dumps(output))