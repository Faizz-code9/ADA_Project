import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

# File path
data_path = "/kaggle/working/outputs/runs/gemini-3.8-flash_soccer_neutral_T1.0_r1/data.csv"

# Load data
df = pd.read_csv(data_path)

# Predictor: skin tone average of rater1 and rater2
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2.0

# Outcome: redCards (count)
# Offset: log(games) because redCards are aggregated over dyadic player-referee games
# Exclude rows where skin_tone is missing or games <= 0
initial_len = len(df)
df = df.dropna(subset=['skin_tone', 'redCards', 'games', 'playerShort', 'refNum'])
df = df[df['games'] > 0].copy()

# Add covariates: position, leagueCountry, height, weight
# Handle missing positions as 'Unknown'
df['position'] = df['position'].fillna('Unknown')
# Impute or drop missing height/weight if any
df['height'] = df['height'].fillna(df['height'].median())
df['weight'] = df['weight'].fillna(df['weight'].median())

# Poisson regression with log(games) offset, robust/clustered standard errors on playerShort
# Formula: redCards ~ skin_tone + height + weight + C(leagueCountry) + C(position)
covariates = ['height', 'weight', 'C(leagueCountry)', 'C(position)']
formula = 'redCards ~ skin_tone + height + weight + C(leagueCountry) + C(position)'

import statsmodels.formula.api as smf

model = smf.glm(
    formula=formula,
    data=df,
    family=sm.families.Poisson(),
    offset=np.log(df['games'])
)

# Fit with cluster-robust standard errors at the player level (playerShort)
fit_res = model.fit(cov_type='cluster', cov_kwds={'groups': df['playerShort']})

# Extract results for skin_tone
coef = fit_res.params['skin_tone']
bse = fit_res.bse['skin_tone']
p_val = fit_res.pvalues['skin_tone']

# Estimand: IRR for full change 0 to 1
irr = float(np.exp(coef))
ci_low = float(np.exp(coef - 1.95996 * bse))
ci_high = float(np.exp(coef + 1.95996 * bse))
irr_se = float(irr * bse) # delta method standard error for IRR

output = {
    "effect_size": round(irr, 4),
    "effect_type": "irr",
    "standard_error": round(irr_se, 4),
    "p_value": round(float(p_val), 5),
    "ci_lower": round(ci_low, 4),
    "ci_upper": round(ci_high, 4),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "poisson",
    "predictor_used": "mean(rater1, rater2)",
    "covariates_included": ["height", "weight", "leagueCountry", "position", "offset(log(games))"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "Excluded rows with missing skin tone ratings (rater1/rater2) or games <= 0"
}

print(json.dumps(output, indent=2))