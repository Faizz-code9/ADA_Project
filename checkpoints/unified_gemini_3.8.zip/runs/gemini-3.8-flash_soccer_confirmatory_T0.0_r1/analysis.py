import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

def run_analysis():
    filepath = "/kaggle/working/outputs/runs/gemini-3.8-flash_soccer_confirmatory_T0.0_r1/data.csv"
    df = pd.read_csv(filepath)

    # Exclude rows where skin tone ratings are missing
    df = df.dropna(subset=['rater1', 'rater2', 'games']).copy()

    # Predictor: average of rater1 and rater2 (scale 0 to 1)
    df['skintone'] = (df['rater1'] + df['rater2']) / 2.0

    # Ensure games > 0 for offset
    df = df[df['games'] > 0].copy()

    # Model: Poisson GLM for red card counts with log(games) offset
    # Adjusting for position and leagueCountry where available
    covariates = ['leagueCountry', 'position']
    df_model = df.dropna(subset=['redCards', 'skintone'] + covariates).copy()

    # Create dummies
    X = pd.get_dummies(df_model[['skintone'] + covariates], drop_first=True, dtype=float)
    X = sm.add_constant(X)
    y = df_model['redCards']
    offset = np.log(df_model['games'])

    # Fit Poisson GLM with cluster-robust standard errors at player level
    groups = df_model['playerShort']
    model = sm.GLM(y, X, family=sm.families.Poisson(), offset=offset)
    res = model.fit(cov_type='cluster', cov_kwds={'groups': groups})

    # Estimand: IRR for full change from 0 to 1 in skintone
    beta = res.params['skintone']
    se_beta = res.bse['skintone']
    irr = np.exp(beta)

    # 95% CI for IRR
    ci_lower_beta = beta - 1.95996 * se_beta
    ci_upper_beta = beta + 1.95996 * se_beta
    ci_lower = np.exp(ci_lower_beta)
    ci_upper = np.exp(ci_upper_beta)
    
    # Delta method SE for IRR: se(exp(beta)) = exp(beta) * se(beta)
    se_irr = irr * se_beta
    p_value = res.pvalues['skintone']

    conclusion = "significant_effect" if p_value < 0.05 else "no_significant_effect"

    output = {
        "effect_size": float(irr),
        "effect_type": "irr",
        "standard_error": float(se_irr),
        "p_value": float(p_value),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": conclusion,
        "model_family": "poisson",
        "predictor_used": "average of rater1 and rater2",
        "covariates_included": covariates,
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "clustered_se",
        "exclusions_applied": "dropped rows missing rater1, rater2, games <= 0, or missing position"
    }

    print(json.dumps(output))

if __name__ == '__main__':
    run_analysis()