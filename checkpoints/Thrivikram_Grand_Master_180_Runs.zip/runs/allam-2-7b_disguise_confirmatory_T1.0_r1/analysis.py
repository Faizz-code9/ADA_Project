import pandas as pd
import numpy as np
import json
import statsmodels.api as sm
from scipy import stats

# Load data
df = pd.read_csv('/kaggle/working/outputs/runs/allam-2-7b_disguise_confirmatory_T1.0_r1/data.csv')

# Define covariates and predictor
predictor_col = 'risk_evaluator_alpha_score'
covariates = ['credit_score_index', 'annual_income_bracket', 'prior_denied_loans', 'total_applications_reviewed']

# Select relevant columns
cols_needed = [predictor_col] + covariates + ['loan_application_rejections']
df_subset = df[cols_needed].copy()

# Handle missing values via listwise deletion (drop rows with NaN in any required column)
df_subset = df_subset.dropna()

# Construct model matrix
X = sm.add_constant(df_subset[covariates + [predictor_col]])
y = df_subset['loan_application_rejections'].astype(float)

# Since the outcome is count data (mostly 0s), use Poisson GLM
# The hypothesis is about rejections, and the outcome is a count variable despite low mean.
model = sm.GLM(y, X, family=sm.families.Poisson())
result = model.fit()

# Extract primary estimand: coefficient for the predictor
pred_coeff = result.params.get(predictor_col)
if pred_coeff is np.nan:
    # Fallback if variable name change
    for p in result.params:
        if predictor_col in p:
            pred_coeff = result.params[p]
            break

pred_se = result.bse.get(predictor_col)
if pred_se is np.nan:
    for b in result.bse:
        if predictor_col in b:
            pred_se = result.bse[b]
            break

# Two-sided p-value
p_val = 2 * (1 - stats.norm.cdf(abs(pred_coeff / pred_se)))

# 95% CI
ci_lower_log = pred_coeff - 1.96 * pred_se
ci_upper_log = pred_coeff + 1.96 * pred_se

# Convert to IRR (Incidence Rate Ratio)
irr = np.exp(pred_coeff)
ci_lower_irr = np.exp(ci_lower_log)
ci_upper_irr = np.exp(ci_upper_log)

# Determine conclusion
conclusion = 'significant_effect' if p_val < 0.05 else 'no_significant_effect'

# Exclusions description
exclusion_count = len(df) - len(df_subset)
exclusions_desc = f"Dropped {exclusion_count} rows with missing predictor or covariates" if exclusion_count > 0 else "none"

output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(pred_se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower_irr),
    "ci_upper": float(ci_upper_irr),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "risk_evaluator_alpha_score",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": exclusions_desc
}

print(json.dumps(output))