import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

def main():
    file_path = '/kaggle/working/outputs/runs/gemini-2.5-flash-lite_placebo_skeptical_T1.0_r1/data.csv'
    df = pd.read_csv(file_path)

    # Data Preparation
    # Target is redCards (count data, but hypothesis asks for ratio effect of continuous predictor)
    # Using Poisson regression is appropriate for count data (red cards).
    # Predictor: skin tone (mean of rater1 and rater2)
    
    # Drop rows where rater values are missing (these are the primary predictors)
    df_clean = df.dropna(subset=['rater1', 'rater2', 'redCards']).copy()
    
    # Construct the continuous skin tone predictor
    df_clean['skin_tone_avg'] = df_clean[['rater1', 'rater2']].mean(axis=1)
    
    # Exclude rows where skin_tone_avg might be invalid or non-numeric
    df_clean = df_clean[(df_clean['skin_tone_avg'] >= 0) & (df_clean['skin_tone_avg'] <= 1)]

    # Fit Poisson model
    # Since redCards is a count (0, 1, 2), Poisson is the standard for modeling the rate/intensity.
    # The coefficient in a Poisson model represents the log of the Incident Rate Ratio (IRR).
    # To get the IRR (ratio effect), we exponentiate the coefficient.
    
    model = smf.poisson('redCards ~ skin_tone_avg + games + yellowCards', data=df_clean).fit(disp=False)
    
    # Extract stats for the skin_tone_avg coefficient
    coeff = model.params['skin_tone_avg']
    std_err = model.bse['skin_tone_avg']
    p_val = model.pvalues['skin_tone_avg']
    
    # Calculate IRR (Incidence Rate Ratio) and its CI
    # IRR = exp(coeff)
    irr = np.exp(coeff)
    ci_lower = np.exp(model.conf_int().loc['skin_tone_avg'][0])
    ci_upper = np.exp(model.conf_int().loc['skin_tone_avg'][1])
    
    # Standard Error for the ratio (using delta method approximation: SE(exp(x)) \approx exp(x) * SE(x))
    se_irr = irr * std_err

    output = {
        "effect_size": float(irr),
        "effect_type": "irr",
        "standard_error": float(se_irr),
        "p_value": float(p_val),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
        "model_family": "poisson",
        "predictor_used": "mean of rater1 and rater2",
        "covariates_included": ["games", "yellowCards"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "none",
        "exclusions_applied": f"Removed {len(df) - len(df_clean)} rows due to missingness or invalid skin tone values"
    }

    print(json.dumps(output, indent=2))

if __name__ == "__main__":
    main()