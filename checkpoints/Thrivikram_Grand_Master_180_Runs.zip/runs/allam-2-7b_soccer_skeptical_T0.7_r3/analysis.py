import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

# Load data
df = pd.read_csv('/kaggle/working/outputs/runs/allam-2-7b_soccer_skeptical_T0.7_r3/data.csv')

# Create skin tone variable (average of rater1 and rater2)
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2

# Exclude rows where skin tone is missing
df = df.dropna(subset=['skin_tone'])

# Define outcome: redCards (count of red cards)
# Use Poisson regression since redCards is a count variable
# Expose = games (number of games played) as offset

# Prepare data
X = df[['skin_tone']]
X = sm.add_constant(X)
y = df['redCards']
offset = np.log(df['games'])  # offset for exposure

# Fit Poisson model with offset
model = sm.GLM(y, X, family=sm.families.Poisson(), offset=offset)
result = model.fit()

# Extract coefficient for skin_tone
coef = result.params['skin_tone']
se = result.bse['skin_tone']
p_val = result.pvalues['skin_tone']

# Effect size: IRR = exp(coef)
irr = np.exp(coef)
irr_se = irr * se  # Delta method approximation

# CI in log scale
ci_lower_log = coef - 1.96 * se
ci_upper_log = coef + 1.96 * se
ci_lower = np.exp(ci_lower_log)
ci_upper = np.exp(ci_upper_log)

# Conclusion
conclusion = 'significant_effect' if p_val < 0.05 else 'no_significant_effect'

# Build output
output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(irr_se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "skin_tone (average of rater1 and rater2)",
    "covariates_included": [],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "rows with missing skin tone (rater1 or rater2)"
}

print(json.dumps(output))