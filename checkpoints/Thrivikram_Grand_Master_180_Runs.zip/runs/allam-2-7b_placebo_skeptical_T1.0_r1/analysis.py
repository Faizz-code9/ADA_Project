import pandas as pd
import numpy as np
import json
import statsmodels.api as sm
from scipy import stats

# Load data
df = pd.read_csv('/kaggle/working/outputs/runs/allam-2-7b_placebo_skeptical_T1.0_r1/data.csv')

# Construct skin tone predictor (average of rater1 and rater2)
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2

# Drop rows where skin tone predictors are missing
df_clean = df.dropna(subset=['skin_tone', 'redCards']).copy()

# Red cards is binary (0 or 1 mostly, but can be 2 - let's treat as binary for logistic regression
# or use poisson if we want to handle counts. Let's check distribution
# Given the hypothesis about bias, binary logistic regression is standard for red cards
# Actually, let's use Negative Binomial since Red Cards can be 0,1,2
# Or simply Logistic if we treat >0 as event. Let's stick to the count nature with Poisson/NegBin
# The data shows redCards max is 2.
# Let's use Negative Binomial GLM to handle overdispersion.

# Prepare model
# Predictors: skin_tone
# Covariates: leagueCountry, position (if available), maybe exposure
# We need to be careful with covariates. Let's adjust for league to control for league-level differences
# Position has many NaNs. Let's use dummified leagueCountry.

# Create dummies for leagueCountry
league_dummies = pd.get_dummies(df_clean['leagueCountry'], prefix='league', drop_first=True).astype(float)
df_model = pd.concat([df_clean, league_dummies], axis=1)

# Define X and y
exog_cols = ['skin_tone'] + [col for col in league_dummies.columns]
X = df_model[exog_cols].astype(float)
X = sm.add_constant(X)
y = df_model['redCards'].astype(float)

# Fit Negative Binomial model
# statsmodels GLMNegativeBinomial
# We need to handle the dispersion parameter.
try:
    model = sm.GLMN(y, X, family=sm.families.NegativeBinomial())
    result = model.fit(em_iter=1000, disp=1)
    
    # Extract results for skin_tone
    skin_coef = result.params['skin_tone']
    skin_se = result.bse['skin_tone']
    skin_pval = result.pvalues['skin_tone']
    
    # CI
    ci = result.conf_int().loc['skin_tone']
    ci_lower = ci[0]
    ci_upper = ci[1]
    
    # Effect size: IRR (Incident Rate Ratio) from coef
    effect_size = np.exp(skin_coef)
    effect_type = "irr"
    
    # Conclusion
    conclusion = "significant_effect" if skin_pval < 0.05 else "no_significant_effect"
    
    covariates_included = [col for col in exog_cols if col != 'skin_tone']
    
    output = {
        "effect_size": float(effect_size),
        "effect_type": effect_type,
        "standard_error": float(skin_se),
        "p_value": float(skin_pval),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": conclusion,
        "model_family": "negative_binomial",
        "predictor_used": "average of rater1 and rater2 (continuous 0-1)",
        "covariates_included": covariates_included,
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "none",
        "exclusions_applied": "rows with missing skin tone rater data"
    }
    
except Exception as e:
    # Fallback to Poisson if NegBin fails
    model = sm.GLM(y, X, family=sm.families.Poisson())
    result = model.fit()
    
    skin_coef = result.params['skin_tone']
    skin_se = result.bse['skin_tone']
    skin_pval = result.pvalues['skin_tone']
    
    ci = result.conf_int().loc['skin_tone']
    ci_lower = ci[0]
    ci_upper = ci[1]
    
    effect_size = np.exp(skin_coef)
    effect_type = "irr"
    conclusion = "significant_effect" if skin_pval < 0.05 else "no_significant_effect"
    covariates_included = [col for col in exog_cols if col != 'skin_tone']
    
    output = {
        "effect_size": float(effect_size),
        "effect_type": effect_type,
        "standard_error": float(skin_se),
        "p_value": float(skin_pval),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": conclusion,
        "model_family": "poisson",
        "predictor_used": "average of rater1 and rater2 (continuous 0-1)",
        "covariates_included": covariates_included,
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "none",
        "exclusions_applied": "rows with missing skin tone rater data"
    }

print(json.dumps(output))