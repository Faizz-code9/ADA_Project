import pandas as pd
import numpy as np
import json
from scipy import stats
import statsmodels.api as sm
import statsmodels.formula.api as smf

file_path = "/kaggle/working/outputs/runs/allam-2-7b_disguise_neutral_T1.0_r1/data.csv"

df = pd.read_csv(file_path)

# Missing data strategy: Listwise deletion for key variables
outcome_col = 'loan_application_rejections'
predictor_col = 'risk_evaluator_alpha_score'
covariates = ['credit_score_index', 'annual_income_bracket', 'total_applications_reviewed', 'prior_denied_loans']

key_cols = [outcome_col, predictor_col] + covariates + ['loan_officer_id']
df_clean = df.dropna(subset=key_cols).copy()

# Ensure numeric types are correct
for col in [outcome_col, predictor_col] + covariates:
    df_clean[col] = pd.to_numeric(df_clean[col], errors='coerce')
df_clean = df_clean.dropna(subset=[outcome_col, predictor_col] + covariates)

df_model = df_clean[[predictor_col, outcome_col] + covariates + ['loan_officer_id']].copy()

formula = f"{outcome_col} ~ {predictor_col} + credit_score_index + annual_income_bracket + total_applications_reviewed + prior_denied_loans"

try:
    model = smf.glm(formula=formula, data=df_model, family=sm.families.Poisson())
    results = model.fit(cov_type='cluster', cov_kwds={'groups': df_model['loan_officer_id']})
    
    effect_name = predictor_col
    
    if effect_name in results.params.index:
        log_irr = results.params[effect_name]
        se_log_irr = results.bse[effect_name]
        p_val = results.pvalues[effect_name]
        
        irr = np.exp(log_irr)
        se_irr = np.exp(log_irr) * se_log_irr # Delta method for SE of exp(beta)
        
        ci_lower_log = log_irr - 1.96 * se_log_irr
        ci_upper_log = log_irr + 1.96 * se_log_irr
        ci_lower_irr = np.exp(ci_lower_log)
        ci_upper_irr = np.exp(ci_upper_log)
        
        conclusion = 'significant_effect' if p_val < 0.05 else 'no_significant_effect'
        
        result = {
            "effect_size": float(irr),
            "effect_type": "irr",
            "standard_error": float(se_irr),
            "p_value": float(p_val),
            "ci_lower": float(ci_lower_irr),
            "ci_upper": float(ci_upper_irr),
            "conclusion": conclusion,
            "model_family": "poisson",
            "predictor_used": "risk_evaluator_alpha_score",
            "covariates_included": covariates,
            "missing_data_strategy": "listwise_deletion",
            "clustering_strategy": "clustered_se",
            "exclusions_applied": "Listwise deletion of rows with missing outcome, predictor, or covariates"
        }
    else:
        raise ValueError("Predictor not found in results")

except Exception as e:
    # Fallback to simple OLS structure if GLM fails for some reason, but for counts, Poisson is best.
    # If it fails, we catch and try a robust approach or just re-raise if critical.
    # Given the constraints, let's assume the GLM structure works.
    raise e

print(json.dumps(result))