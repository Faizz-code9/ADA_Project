import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

# Load data
df = pd.read_csv('/kaggle/working/outputs/runs/allam-2-7b_soccer_neutral_T0.0_r1/data.csv')

# Construct skin tone variable (average of rater1 and rater2)
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2

# Drop rows with missing skin tone, position, height, weight
df = df.dropna(subset=['skin_tone', 'position', 'height', 'weight'])

# Define outcome
y = df['redCards']

# One-hot encode position and leagueCountry
pos_dummies = pd.get_dummies(df['position'], prefix='pos', drop_first=True)
league_dummies = pd.get_dummies(df['leagueCountry'], prefix='league', drop_first=True)

# Combine all predictors
X = pd.concat([df[['skin_tone', 'height', 'weight']], pos_dummies, league_dummies], axis=1)

# Add constant
X_const = sm.add_constant(X)

# Fit Poisson regression
model = sm.GLM(y, X_const, family=sm.families.Poisson())
result = model.fit()

# Extract coefficient for skin_tone
coef = result.params['skin_tone']
se = result.bse['skin_tone']
p_val = result.pvalues['skin_tone']

# Compute IRR (Incident Rate Ratio)
irr = np.exp(coef)
irr_se = se * irr  # Delta method approximation
irr_ci_lower = np.exp(coef - 1.96 * se)
irr_ci_upper = np.exp(coef + 1.96 * se)

# Conclusion
conclusion = 'significant_effect' if p_val < 0.05 else 'no_significant_effect'

# Build JSON output
output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(irr_se),
    "p_value": float(p_val),
    "ci_lower": float(irr_ci_lower),
    "ci_upper": float(irr_ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "skin_tone (average of rater1 and rater2)",
    "covariates_included": ["height", "weight", "position", "leagueCountry"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "Rows with missing skin_tone, position, height, or weight"
}

print(json.dumps(output))