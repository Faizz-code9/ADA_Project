import pandas as pd
import numpy as np
import statsmodels.api as sm
import json
import warnings

warnings.filterwarnings('ignore')

# 1. Load Data
df = pd.read_csv('/kaggle/working/outputs/runs/allam-2-7b_placebo_confirmatory_T1.0_r2/data.csv')

# 2. Cleaning & Variable Construction
# Check missing skin tone
df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)

# Listwise deletion for rows without skin tone
df_clean = df.dropna(subset=['skin_tone']).copy()

# Outcome: Binary (Did the player receive at least one red card this season?)
df_clean['red_card_event'] = (df_clean['redCards'] > 0).astype(int)

# Construct explanatory variables
# Keep club and league country as covariates
# Drop rows if club or league is missing (should be none based on dict)
df_model = df_clean.dropna(subset=['club', 'leagueCountry'])

# Create dummies for club (drop one to avoid perfect multicollinearity with intercept)
club_dummies = pd.get_dummies(df_model['club'], prefix='club', drop_first=True, dtype=float)
league_dummies = pd.get_dummies(df_model['leagueCountry'], prefix='league', drop_first=True, dtype=float)

X = pd.concat([df_model[['skin_tone']], club_dummies, league_dummies], axis=1)
X = sm.add_constant(X)
y = df_model['red_card_event']

# 3. Fit Model
# Logistic Regression
model = sm.Logit(y, X)
result = model.fit(disp=False)

# 4. Extract Results for 'skin_tone'
# The coefficient for skin_tone represents the change in log-odds.
# We need the OR.
beta = result.params['skin_tone']
bse = result.bse['skin_tone']
p_val = result.pvalues['skin_tone']

# To get CI for the OR, we calculate CI for beta then exponentiate
ci_lower_beta = beta - 1.959964 * bse
ci_upper_beta = beta + 1.959964 * bse

odds_ratio = np.exp(beta)
or_ci_lower = np.exp(ci_lower_beta)
or_ci_upper = np.exp(ci_upper_beta)

# Standard error of the OR? 
# The prompt asks for "standard_error" corresponding to the "effect_size".
# Usually, for OR, the SE is of the log-OR (beta). However, if effect_type is odds_ratio,
# does it want SE of the OR (Delta method) or the SE of the log OR?
# Convention in many JSON outputs for this task: "standard_error" refers to the SE of the parameter on the scale of the effect_size.
# If effect_size is OR, the SE is typically the SE of the log(OR) which is bse.
# But strictly, the "standard error of the odds ratio" is exp(beta) * bse (approx delta method) or binom.deviation.
# Let's look at the keys: "effect_size", "standard_error".
# If effect_size is 1.2, standard_error should likely be the uncertainty of 1.2.
# SE(OR) = OR * SE(log(OR)).
se_or = odds_ratio * bse

conclusion = 'significant_effect' if p_val < 0.05 else 'no_significant_effect'

# Covariates included (summative list)
covariates = ['club (fixed effects)', 'leagueCountry (fixed effects)']

output = {
    "effect_size": float(odds_ratio),
    "effect_type": "odds_ratio",
    "standard_error": float(se_or),
    "p_value": float(p_val),
    "ci_lower": float(or_ci_lower),
    "ci_upper": float(or_ci_upper),
    "conclusion": conclusion,
    "model_family": "logistic",
    "predictor_used": "skin_tone (average of rater1 and rater2)",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "Rows missing skin tone ratings (rater1/rater2) removed"
}

print(json.dumps(output))