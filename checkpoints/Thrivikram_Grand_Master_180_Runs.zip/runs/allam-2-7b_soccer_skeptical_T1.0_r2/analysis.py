import pandas as pd
import numpy as np
import statsmodels.api as sm
import json
from scipy import stats

# Load data
df = pd.read_csv('/kaggle/working/outputs/runs/allam-2-7b_soccer_skeptical_T1.0_r2/data.csv')

# Construct continuous skin tone predictor (0-1)
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2.0

# Drop rows with missing skin tone or key variables
mask = df['skin_tone'].notna() & df['redCards'].notna() & df['games'].notna()
df = df[mask].copy()

# Define outcome and predictors
# Outcome: redCards (count)
# Main predictor: skin_tone (continuous 0-1)
# Covariates: games (exposure), leagueCountry
# Use Negative Binomial regression due to overdispersion typical in count data

# Prepare data for modeling
# Use log(games) as offset if games > 0, else exclude
df_valid_games = df[df['games'] > 0].copy()
df_valid_games['log_games'] = np.log(df_valid_games['games'])

X = sm.add_constant(pd.DataFrame({
    'skin_tone': df_valid_games['skin_tone'],
    'leagueCountry': df_valid_games['leagueCountry'].astype('category').cat.codes
}))
# Handle multiple league categories properly
league_cats = pd.get_dummies(df_valid_games['leagueCountry'], prefix='league', drop_first=True, dtype=float)
X = sm.add_constant(pd.concat([X[['const', 'skin_tone']], league_cats], axis=1))
y = df_valid_games['redCards']

# Fit Negative Binomial model
try:
    model = sm.GLM(y, X, family=sm.families.NegativeBinomial())
    result = model.fit()
    
    if not result.converged:
        # Fallback to Poisson if NB doesn't converge
        model = sm.GLM(y, X, family=sm.families.Poisson())
        result = model.fit()
        model_family = 'poisson'
    else:
        model_family = 'negative_binomial'
    
    # Extract coefficient for skin_tone
    coef = result.params['skin_tone']
    se = result.bse['skin_tone']
    
    # For negative binomial/poisson, the coefficient is log rate ratio
    # Exp(coef) gives the IRR (Incident Rate Ratio)
    irr = np.exp(coef)
    irr_se = se * irr  # Delta method approximation
    log_ci_lower = coef - 1.96 * se
    log_ci_upper = coef + 1.96 * se
    ci_lower = np.exp(log_ci_lower)
    ci_upper = np.exp(log_ci_upper)
    
    # P-value
    p_value = result.pvalues['skin_tone']
    
    # Conclusion
    conclusion = 'significant_effect' if p_value < 0.05 else 'no_significant_effect'
    
    covariates = sorted([c for c in X.columns if c != 'const' and c != 'skin_tone'])
    
    output = {
        "effect_size": float(irr),
        "effect_type": "irr",
        "standard_error": float(irr_se),
        "p_value": float(p_value),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": conclusion,
        "model_family": model_family,
        "predictor_used": "skin_tone ((rater1 + rater2) / 2, continuous 0-1)",
        "covariates_included": covariates,
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "none",
        "exclusions_applied": "rows with missing skin_tone, redCards, or games<=0"
    }
    
    print(json.dumps(output))
    
except Exception as e:
    # Fallback: simpler model
    X_simple = sm.add_constant(df_valid_games[['skin_tone']])
    model = sm.GLM(df_valid_games['redCards'], X_simple, family=sm.families.Poisson(), offset=np.log(df_valid_games['games']))
    result = model.fit()
    
    coef = result.params['skin_tone']
    se = result.bse['skin_tone']
    irr = np.exp(coef)
    irr_se = se * irr
    log_ci_lower = coef - 1.96 * se
    log_ci_upper = coef + 1.96 * se
    ci_lower = np.exp(log_ci_lower)
    ci_upper = np.exp(log_ci_upper)
    p_value = result.pvalues['skin_tone']
    conclusion = 'significant_effect' if p_value < 0.05 else 'no_significant_effect'
    
    output = {
        "effect_size": float(irr),
        "effect_type": "irr",
        "standard_error": float(irr_se),
        "p_value": float(p_value),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": conclusion,
        "model_family": "poisson",
        "predictor_used": "skin_tone ((rater1 + rater2) / 2, continuous 0-1)",
        "covariates_included": [],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "none",
        "exclusions_applied": "rows with missing skin_tone, redCards, or games<=0"
    }
    
    print(json.dumps(output))