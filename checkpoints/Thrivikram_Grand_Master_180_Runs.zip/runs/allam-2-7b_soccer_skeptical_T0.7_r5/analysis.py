import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

# Load data
df = pd.read_csv('/kaggle/working/outputs/runs/allam-2-7b_soccer_skeptical_T0.7_r5/data.csv')

# Construct skin tone predictor (average of rater1 and rater2)
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2.0

# Drop rows where skin tone is missing (listwise deletion for this variable)
df = df.dropna(subset=['skin_tone'])

# Outcome: redCards (count, rare)
# Use Poisson regression for count outcome
# Covariates: height, weight, position (categorical), leagueCountry, games
# Keep numeric covariates for simplicity; one-hot encode leagueCountry and position

covariates = ['height', 'weight', 'games']
# One-hot encode leagueCountry
league_dummies = pd.get_dummies(df['leagueCountry'], prefix='league', drop_first=True, dtype=float)
# One-hot encode position (handle NaN by filling with 'Unknown')
df['position_filled'] = df['position'].fillna('Unknown')
pos_dummies = pd.get_dummies(df['position_filled'], prefix='pos', drop_first=True, dtype=float)

X = pd.concat([df[covariates], league_dummies, pos_dummies], axis=1).astype(float)
X = sm.add_constant(X)
y = df['redCards'].astype(float)

# Fit Poisson model
model = sm.GLM(y, X, family=sm.families.Poisson())
result = model.fit()

# Extract coefficient for skin_tone
# Find the column index for skin_tone in X
skin_tone_idx = list(X.columns).index('skin_tone')
coef = result.params[skin_tone_idx]
se = result.bse[skin_tone_idx]
p_val = result.pvalues[skin_tone_idx]

# 95% CI
ci = result.conf_int(alpha=0.05)
ci_lower = ci.iloc[skin_tone_idx, 0]
ci_upper = ci.iloc[skin_tone_idx, 1]

# Effect type: for Poisson, exp(coef) is IRR (Incident Rate Ratio)
irr = np.exp(coef)
irr_se = se * np.exp(coef)
irr_ci_lower = np.exp(ci_lower)
irr_ci_upper = np.exp(ci_upper)

conclusion = 'significant_effect' if p_val < 0.05 else 'no_significant_effect'

output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(irr_se),
    "p_value": float(p_val),
    "ci_lower": float(irr_ci_lower),
    "ci_upper": float(irr_ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "skin_tone (mean of rater1 and rater2, continuous 0-1)",
    "covariates_included": covariates + ['leagueCountry', 'position'],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "rows missing rater1 or rater2 (skin tone)"
}

print(json.dumps(output))