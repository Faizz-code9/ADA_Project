import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

# Load data
df = pd.read_csv('/kaggle/working/outputs/runs/allam-2-7b_soccer_neutral_T0.0_r2/data.csv')

# Construct skin tone variable (average of rater1 and rater2)
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2

# Drop rows with missing skin tone
df = df.dropna(subset=['skin_tone'])

# Define outcome and predictor
y = df['redCards']
X = df[['skin_tone']]

# Add covariates: position (one-hot), leagueCountry (one-hot), height, weight
# Handle missing position and height/weight with listwise deletion for simplicity
df_model = df.dropna(subset=['position', 'height', 'weight'])

# One-hot encode position and leagueCountry
pos_dummies = pd.get_dummies(df_model['position'], prefix='pos', drop_first=True)
league_dummies = pd.get_dummies(df_model['leagueCountry'], prefix='league', drop_first=True)

# Build design matrix
X_model = pd.concat([df_model[['skin_tone', 'height', 'weight']], pos_dummies, league_dummies], axis=1)
X_model = sm.add_constant(X_model)

# Fit Poisson regression (red cards are count data, low mean)
model = sm.GLM(df_model['redCards'], X_model, family=sm.families.Poisson())
result = model.fit()

# Extract coefficient for skin_tone
coef = result.params['skin_tone']
se = result.bse['skin_tone']
p_val = result.pvalues['skin_tone']
ci = result.conf_int().loc['skin_tone']

# Effect size: IRR (Incident Rate Ratio) = exp(coef)
effect_size = np.exp(coef)
ci_lower = np.exp(ci[0])
ci_upper = np.exp(ci[1])

# Conclusion
conclusion = 'significant_effect' if p_val < 0.05 else 'no_significant_effect'

# Covariates included
covariates = ['height', 'weight'] + list(pos_dummies.columns) + list(league_dummies.columns)

# Output JSON
output = {
    "effect_size": float(effect_size),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "skin_tone (average of rater1 and rater2)",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "rows with missing skin_tone, position, height, or weight"
}

print(json.dumps(output))