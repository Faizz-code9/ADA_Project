import pandas as pd
import numpy as np
import json
import statsmodels.api as sm
from scipy import stats

# Load data
df = pd.read_csv('/kaggle/working/outputs/runs/allam-2-7b_soccer_confirmatory_T0.7_r4/data.csv')

# Construct skin tone variable: average of rater1 and rater2
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2.0

# Drop rows with missing skin tone
df = df.dropna(subset=['skin_tone'])

# Prepare variables
y = df['redCards']
X = df[['skin_tone']]

# Add covariates
covariates = ['games', 'height', 'weight']
# Drop rows with missing covariates
df = df.dropna(subset=covariates)
y = df['redCards']
X = df[['skin_tone'] + covariates]

# Add constant
X = sm.add_constant(X)

# Fit Poisson regression (red cards are count data, low frequency)
model = sm.GLM(y, X, family=sm.families.Poisson())
result = model.fit()

# Extract coefficients
coef = result.params['skin_tone']
se = result.bse['skin_tone']
p_val = result.pvalues['skin_tone']
ci = result.conf_int().loc['skin_tone']

# Convert log coefficient to IRR
irr = np.exp(coef)
irr_se = se * irr
irr_ci_lower = np.exp(ci[0])
irr_ci_upper = np.exp(ci[1])

conclusion = 'significant_effect' if p_val < 0.05 else 'no_significant_effect'

output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(irr_se),
    "p_value": float(p_val),
    "ci_lower": float(irr_ci_lower),
    "ci_upper": float(irr_ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "skin_tone (average of rater1 and rater2)",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "rows with missing skin tone or covariates (games, height, weight)"
}

print(json.dumps(output))