import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

def run_analysis():
    file_path = '/kaggle/working/outputs/runs/gemini-2.5-flash-lite_disguise_neutral_T0.7_r2/data.csv'
    
    try:
        df = pd.read_csv(file_path)
    except Exception:
        return

    # Cleaning and Preparation
    # The target is 'loan_application_rejections' (count-like/ratio effect requested)
    # The predictor is 'risk_evaluator_alpha_score' or 'beta_score'. 
    # Given 'risk evaluator scores' (plural) and 'continuous risk evaluator score (0-1)', 
    # we will use the mean of alpha and beta scores as the composite risk score.
    
    # Drop rows where target or predictor is missing
    # Note: identification_dossier_id missingness is tied to risk scores in the dictionary.
    df['risk_score'] = df[['risk_evaluator_alpha_score', 'risk_evaluator_beta_score']].mean(axis=1)
    
    # Filter for valid rows
    initial_count = len(df)
    df_clean = df.dropna(subset=['loan_application_rejections', 'risk_score', 'credit_score_index', 'annual_income_bracket']).copy()
    
    # The primary estimand asks for "ratio effect of continuous risk evaluator score on loan_application_rejections".
    # Since loan_application_rejections is a count (0, 1, 2), a Poisson model or Negative Binomial is appropriate.
    # However, "ratio effect" in the context of a count model usually implies the Incident Rate Ratio (IRR).
    
    # Model: Poisson Regression to find the rate ratio (IRR)
    # We include credit_score_index and annual_income_bracket as covariates to control for standard financial metrics.
    
    X = df_clean[['risk_score', 'credit_score_index', 'annual_income_bracket']]
    X = sm.add_constant(X)
    y = df_clean['loan_application_rejections']
    
    model = sm.GLM(y, X, family=sm.families.Poisson()).fit()
    
    # Extract coefficients for IRR
    # IRR = exp(coefficient)
    risk_coef = model.params['risk_score']
    risk_stderr = model.bse['risk_score']
    
    irr = np.exp(risk_coef)
    # Standard error of IRR: SE(exp(b)) = exp(b) * SE(b)
    irr_se = irr * risk_stderr
    
    # Confidence Interval for IRR
    ci_lower_log = model.conf_int().loc['risk_score', 0]
    ci_upper_log = model.conf_int().loc['risk_score', 1]
    ci_lower = np.exp(ci_lower_log)
    ci_upper = np.exp(ci_upper_log)
    
    p_val = model.pvalues['risk_score']
    
    result = {
        "effect_size": float(irr),
        "effect_type": "irr",
        "standard_error": float(irr_se),
        "p_value": float(p_val),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
        "model_family": "poisson",
        "predictor_used": "mean(risk_evaluator_alpha_score, risk_evaluator_beta_score)",
        "covariates_included": ["credit_score_index", "annual_income_bracket"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "none",
        "exclusions_applied": f"Removed {initial_count - len(df_clean)} rows with missing values"
    }
    
    print(json.dumps(result))

if __name__ == "__main__":
    run_analysis()