import pandas as pd
import numpy as np
import statsmodels.formula.api as smf
import json

# Load data
df = pd.read_csv("/kaggle/working/outputs/runs/allam-2-7b_soccer_neutral_T1.0_r4/data.csv")

# Construct skin tone variable: average of rater1 and rater2
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2.0

# Keep only rows with valid skin tone
df = df.dropna(subset=['skin_tone'])

# Outcome: redCards (0, 1, 2) - treat as binary (any red card) for logistic regression
df['red_card_binary'] = (df['redCards'] > 0).astype(int)

# Covariates to include for adjustment
covariates = []
if 'position' in df.columns:
    df = df.dropna(subset=['position'])
    covariates.append('position')

# Fit logistic regression model
formula = "red_card_binary ~ skin_tone"
if covariates:
    formula += " + " + " + ".join(covariates)

model = smf.logit(formula, data=df).fit()

# Extract results for skin_tone
coef = model.params['skin_tone']
se = model.bse['skin_tone']
p_val = model.pvalues['skin_tone']

# Odds ratio
odds_ratio = np.exp(coef)
# CI for log odds
ci_low_logit = coef - 1.96 * se
ci_high_logit = coef + 1.96 * se
ci_lower = np.exp(ci_low_logit)
ci_upper = np.exp(ci_high_logit)

conclusion = 'significant_effect' if p_val < 0.05 else 'no_significant_effect'

result = {
    "effect_size": float(odds_ratio),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "logistic",
    "predictor_used": "skin_tone (average of rater1 and rater2, 0-1 scale)",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "Rows with missing rater1/rater2 or position excluded"
}

print(json.dumps(result))