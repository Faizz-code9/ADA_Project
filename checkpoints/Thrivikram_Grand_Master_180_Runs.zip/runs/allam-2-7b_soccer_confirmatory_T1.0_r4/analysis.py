import pandas as pd
import numpy as np
import json
import statsmodels.api as sm

# Load data
df = pd.read_csv('/kaggle/working/outputs/runs/allam-2-7b_soccer_confirmatory_T1.0_r4/data.csv')

# Primary predictor: average skin tone rating (continuous 0-1)
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2

# Outcome: total red cards (direct + second yellow)
df['total_red_cards'] = df['redCards'] + df['yellowReds']

# Exclusions: require skin tone data
df_clean = df.dropna(subset=['skin_tone']).copy()

# Covariates: construct from available data
# Age from birthday
def parse_age(bday):
    try:
        if isinstance(bday, str):
            parts = bday.split('.')
            year = int(parts[2])
            return 2024 - year
    except:
        return np.nan
    return np.nan

df_clean['age'] = df_clean['birthday'].apply(parse_age)

# One-hot encode position (safe with NaN)
pos_dummies = pd.get_dummies(df_clean['position'], prefix='pos', drop_first=True, dtype=int)
pos_dummies = pos_dummies.fillna(0)
df_clean = pd.concat([df_clean, pos_dummies], axis=1)

# Impute missing continuous covariates with median
for col in ['age', 'height', 'weight']:
    if col in df_clean.columns:
        df_clean[col] = df_clean[col].fillna(df_clean[col].median())
    else:
        df_clean[col] = 0.0

# Define model variables
X_cols = ['skin_tone', 'age', 'height', 'weight'] + [c for c in pos_dummies.columns]
X = df_clean[X_cols].astype(float)
X = sm.add_constant(X)
y = df_clean['total_red_cards'].astype(float)

# Fit Poisson GLM (appropriate for count outcome)
model = sm.GLM(y, X, family=sm.families.Poisson())
result = model.fit(cov_type='HC1')

# Extract results for skin_tone
skin_tone_coeff = result.params['skin_tone']
skin_tone_se_log = result.bse['skin_tone']
skin_tone_pval = result.pvalues['skin_tone']
skin_tone_ci_log = result.conf_int().loc['skin_tone'].values.tolist()

# Convert to IRR (Incidence Rate Ratio)
irr = float(np.exp(skin_tone_coeff))
se_irr = float(irr * skin_tone_se_log)  # Delta method approximation
ci_lower = float(np.exp(skin_tone_ci_log[0]))
ci_upper = float(np.exp(skin_tone_ci_log[1]))

p_value = float(skin_tone_pval)
conclusion = 'significant_effect' if p_value < 0.05 else 'no_significant_effect'

covariates_list = [c for c in X_cols if c != 'skin_tone']

output = {
    "effect_size": irr,
    "effect_type": "irr",
    "standard_error": se_irr,
    "p_value": p_value,
    "ci_lower": ci_lower,
    "ci_upper": ci_upper,
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "average of rater1 and rater2 skin tone scores",
    "covariates_included": covariates_list,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "rows with missing skin tone ratings (rater1 or rater2)"
}

print(json.dumps(output))