import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json
import warnings
warnings.filterwarnings('ignore')

# Load data
df = pd.read_csv('/kaggle/working/outputs/runs/allam-2-7b_soccer_skeptical_T1.0_r3/data.csv')

# Create skin tone variable: average of rater1 and rater2
df['skintone'] = (df['rater1'] + df['rater2']) / 2

# Remove rows with missing key variables
df_clean = df.dropna(subset=['skintone', 'redCards', 'leagueCountry', 'position']).copy()

# Simplify position grouping
pos_map = {'Goalkeeper': 'GK', 'Center Back': 'DEF', 'Left Back': 'DEF', 'Right Back': 'DEF',
           'Defensive midfielder': 'MID', 'Attacking midfielder': 'MID', 'Left Midfielder': 'MID',
           'Right Midfielder': 'MID', 'Center Forward': 'FWD', 'Left Forward': 'FWD', 'Right Forward': 'FWD'}
df_clean['pos_grp'] = df_clean['position'].map(pos_map)
df_clean = df_clean.dropna(subset=['pos_grp'])

# Fit GEE Poisson model, clustered by referee (refNum)
# Use formula API which handles dummies automatically
try:
    model = smf.gee('redCards ~ skintone + height + weight + C(leagueCountry) + C(pos_grp)',
                    data=df_clean, groups=df_clean['refNum'],
                    family=sm.families.Poisson(link=sm.families.links.Log()),
                    time=None,
                    cov_type='exchangeable')
    result = model.fit()
    effect_size = float(result.params['skintone'])
    se = float(result.bse['skintone'])
    p_value = float(result.pvalues['skintone'])
    conf = result.conf_int().loc['skintone']
    ci_lower = float(conf[0])
    ci_upper = float(conf[1])
    effect_type = 'izr'  # rate ratio on log scale
    model_family = 'gee'
except Exception:
    # Fallback: OLS
    result = smf.ols('redCards ~ skintone + height + weight + C(leagueCountry) + C(pos_grp)', data=df_clean).fit()
    effect_size = float(result.params['skintone'])
    se = float(result.bse['skintone'])
    p_value = float(result.pvalues['skintone'])
    conf = result.conf_int().loc['skintone']
    ci_lower = float(conf[0])
    ci_upper = float(conf[1])
    effect_type = 'log_odds'
    model_family = 'ols'

conclusion = 'significant_effect' if p_value < 0.05 else 'no_significant_effect'

covariates = []
mcols = [c for c in result.params.index if c != 'Const' and c != 'skintone']
for c in mcols:
    base = c.split('_')[0]
    if base not in covariates:
        covariates.append(base)

out = {
    "effect_size": effect_size,
    "effect_type": effect_type,
    "standard_error": se,
    "p_value": p_value,
    "ci_lower": ci_lower,
    "ci_upper": ci_upper,
    "conclusion": conclusion,
    "model_family": model_family,
    "predictor_used": "skintone (mean of rater1 & rater2)",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "gee" if model_family == 'gee' else "none",
    "exclusions_applied": "rows missing skintone, redCards, leagueCountry, position, or unmapable position"
}
print(json.dumps(out))