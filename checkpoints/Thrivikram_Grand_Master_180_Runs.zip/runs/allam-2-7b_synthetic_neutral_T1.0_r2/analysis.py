import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
from statsmodels.stats.contrast import ContrastResults

# Load data
df = pd.read_csv('/kaggle/working/outputs/runs/allam-2-7b_synthetic_neutral_T1.0_r2/data.csv')

# Clean data: handle missing skin_tone using median imputation (common for ordered/ranked scales)
median_skin_tone = df['skin_tone'].median()
df['skin_tone'] = df['skin_tone'].fillna(median_skin_tone)

# Prepare features
# Outcome: redCards
# Predictor: skin_tone (continuous, 0-1)
# Covariates: games (exposure), yellowCards, position, leagueCountry
# We will model redCards as a Poisson process, accounting for exposure (games played)
# Since redCards is a count, Poisson regression is appropriate.
# Log-link function is standard for Poisson, so the coefficient for skin_tone will be the log of the rate ratio.
# IRR (Incident Rate Ratio) = exp(coefficient)

# Create dummy variables for categorical covariates
pos_dummies = pd.get_dummies(df['position'], prefix='pos', drop_first=True)
country_dummies = pd.get_dummies(df['leagueCountry'], prefix='country', drop_first=True)

# Combine features
X = pd.concat([df[['skin_tone', 'yellowCards']].copy(), pos_dummies, country_dummies], axis=1)
offset = np.log(df['games'].astype(float))  # Offset for exposure
y = df['redCards']

# Fit Poisson regression with offset
# statsmodels' Poisson GLM handles offset via the 'offset' parameter
model = sm.GLM(y, X, family=sm.families.Poisson())
res = model.fit(offset=offset.values)

# Extract results for skin_tone
coef_name = 'skin_tone'
effect_log = res.params[coef_name]
se_log = res.bse[coef_name]
p_val = res.pvalues[coef_name]
conf_low_log = res.conf_int().loc[coef_name, 0]
conf_high_log = res.conf_int().loc[coef_name, 1]

# Transform to IRR (Incident Rate Ratio)
effect_size = np.exp(effect_log)
ci_lower = np.exp(conf_low_log)
ci_upper = np.exp(conf_high_log)
se_irr = se_log * effect_size  # Approximate SE of IRR via delta method

# Determine conclusion
conclusion = 'significant_effect' if p_val < 0.05 else 'no_significant_effect'

# Extract covariate names
covariates = list(X.columns)
covariates.remove(coef_name)

# Build JSON output
result = {
    "effect_size": float(effect_size),
    "effect_type": "irr",
    "standard_error": float(se_irr),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "skin_tone",
    "covariates_included": covariates,
    "missing_data_strategy": "other",  # Median imputation for skin_tone
    "clustering_strategy": "none",
    "exclusions_applied": "none"
}

print(json.dumps(result))