import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

# Load data
df = pd.read_csv('/kaggle/working/outputs/runs/allam-2-7b_disguise_neutral_T0.0_r1/data.csv')

# Clean data: drop rows where risk_evaluator_alpha_score is missing (14.7% missing)
df = df.dropna(subset=['risk_evaluator_alpha_score'])

# Construct predictor: continuous risk evaluator score (0-1)
# Use risk_evaluator_alpha_score as the main predictor
df['risk_score'] = df['risk_evaluator_alpha_score']

# Outcome: loan_application_rejections (count variable, 0-2)
# Use Poisson regression for count outcome

# Covariates to adjust for
covariates = ['credit_score_index', 'annual_income_bracket', 'total_applications_reviewed',
              'prior_approved_loans', 'prior_denied_loans', 'financial_jurisdiction']

# Handle missing values in covariates with listwise deletion
df = df.dropna(subset=covariates)

# Create dummy variables for financial_jurisdiction
df = pd.get_dummies(df, columns=['financial_jurisdiction'], drop_first=True, dtype=float)

# Update covariates list after creating dummies
jurisdiction_dummies = [c for c in df.columns if c.startswith('financial_jurisdiction_')]
covariates_final = ['credit_score_index', 'annual_income_bracket', 'total_applications_reviewed',
                    'prior_approved_loans', 'prior_denied_loans'] + jurisdiction_dummies

# Prepare design matrix
X = df[covariates_final + ['risk_score']]
X = sm.add_constant(X)
y = df['loan_application_rejections']

# Fit Poisson regression
model = sm.GLM(y, X, family=sm.families.Poisson())
result = model.fit()

# Extract coefficient for risk_score
coef_name = 'risk_score'
effect_size = np.exp(result.params[coef_name])  # IRR
se = result.bse[coef_name]
p_value = result.pvalues[coef_name]

# Confidence interval for IRR
ci_lower = np.exp(result.conf_int().loc[coef_name, 0])
ci_upper = np.exp(result.conf_int().loc[coef_name, 1])

# Conclusion
conclusion = 'significant_effect' if p_value < 0.05 else 'no_significant_effect'

# Build JSON output
output = {
    "effect_size": float(effect_size),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_value),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "risk_evaluator_alpha_score (continuous, 0-1)",
    "covariates_included": covariates_final,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "Rows with missing risk_evaluator_alpha_score or covariates removed"
}

print(json.dumps(output))