import pandas as pd
import numpy as np
import json
import statsmodels.api as sm
from scipy import stats

# Load the data
file_path = '/kaggle/working/outputs/runs/allam-2-7b_synthetic_neutral_T1.0_r1/data.csv'
df = pd.read_csv(file_path)

# Clean and prepare data
# Drop rows with missing skin_tone
df_clean = df.dropna(subset=['skin_tone']).copy()

# Define outcome and predictors
y = df_clean['redCards']
X = df_clean[['skin_tone', 'games', 'yellowCards']].copy()

# Add constant
X = sm.add_constant(X)

# Use Poisson regression for count data (redCards)
# redCards has many zeros, mean ~0.12, so Poisson is appropriate
model = sm.GLM(y, X, family=sm.families.Poisson())
result = model.fit()

# Extract coefficient for skin_tone
effect_size_log = result.params['skin_tone']
se_log = result.bse['skin_tone']
p_value = result.pvalues['skin_tone']

# Convert to IRR (Incidence Rate Ratio) by exponentiating
effect_size = np.exp(effect_size_log)
ci_lower = np.exp(result.conf_int().loc['skin_tone', 0])
ci_upper = np.exp(result.conf_int().loc['skin_tone', 1])

# Conclusion
conclusion = 'significant_effect' if p_value < 0.05 else 'no_significant_effect'

# Build result JSON
result_json = {
    "effect_size": float(effect_size),
    "effect_type": "irr",
    "standard_error": float(se_log),  # SE on log scale
    "p_value": float(p_value),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "skin_tone (continuous, 0-1)",
    "covariates_included": ["games", "yellowCards"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "Dropped rows with missing skin_tone"
}

print(json.dumps(result_json))