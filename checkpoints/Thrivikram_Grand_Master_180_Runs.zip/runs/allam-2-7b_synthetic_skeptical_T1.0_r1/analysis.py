import pandas as pd
import numpy as np
import json
import statsmodels.api as sm
from scipy import stats

# Load data
df = pd.read_csv('/kaggle/working/outputs/runs/allam-2-7b_synthetic_skeptical_T1.0_r1/data.csv')

# Handle missing skin_tone and construct a ratio-scale predictor
# Drop rows where skin_tone is missing
df = df.dropna(subset=['skin_tone'])
exclusions = 'Rows with missing skin_tone removed'

# Ensure skin_tone is numeric and 0-1
df['skin_tone'] = df['skin_tone'].astype(float)

# Build ratio of redCards to games (rate), or use redCards directly with exposure offset
# Since redCards can be 0 and sparse, use Poisson regression with log(games) as offset
# Check games are all > 0 (they are, min=1)
df['log_games'] = np.log(df['games'])

# Fit Poisson GLM: redCards ~ skin_tone + offset(log_games) + covariates
# Covariates: position (dummy), leagueCountry (dummy)
pos_dummies = pd.get_dummies(df['position'], prefix='pos', drop_first=True, dtype=float)
league_dummies = pd.get_dummies(df['leagueCountry'], prefix='lec', drop_first=True, dtype=float)

X = pd.concat([
    sm.add_constant(df[['skin_tone']].astype(float)),
    pos_dummies,
    league_dummies
], axis=1)

y = df['redCards'].astype(float)
offset = np.log(df['games'].astype(float))

# Fit Poisson with offset
model = sm.GLM(y, X, family=sm.families.Poisson(), offset=offset)
result = model.fit()

# Extract coefficient for skin_tone
coef = result.params['skin_tone']
se = result.bse['skin_tone']
pval = result.pvalues['skin_tone']

# IRR (Incidence Rate Ratio) for continuous skin_tone
irr = np.exp(coef)
# CI on IRR scale
ci_lower = np.exp(coef - 1.96 * se)
ci_upper = np.exp(coef + 1.96 * se)

covariates = ['position', 'leagueCountry']
if 'pos_Midfielder' in X.columns: covariates = ['position', 'leagueCountry']

conclusion = 'significant_effect' if pval < 0.05 else 'no_significant_effect'

output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(pval),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "skin_tone (continuous 0-1)",
    "covariates_included": ['position', 'leagueCountry'],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "288 rows with missing skin_tone"
}

print(json.dumps(output))