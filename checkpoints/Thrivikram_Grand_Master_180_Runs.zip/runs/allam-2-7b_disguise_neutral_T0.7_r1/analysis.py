import pandas as pd
import numpy as np
import statsmodels.api as sm
import json
from scipy import stats

# Load data
df = pd.read_csv('/kaggle/working/outputs/runs/allam-2-7b_disguise_neutral_T0.7_r1/data.csv')

# Construct the main predictor: average of alpha and beta scores
df['risk_score'] = (df['risk_evaluator_alpha_score'] + df['risk_evaluator_beta_score']) / 2.0

# Define outcome and predictor
outcome = 'loan_application_rejections'
predictor = 'risk_score'

# Define covariates
covariates = ['credit_score_index', 'annual_income_bracket', 'total_applications_reviewed',
              'prior_approved_loans', 'prior_conditional_loans', 'prior_denied_loans',
              'repayment_performance_score', 'formal_inquiry_notices', 'elevated_risk_warnings']

# Filter to rows where outcome and predictor are present
df_clean = df.dropna(subset=[outcome, predictor])

# Drop rows with missing covariates (listwise deletion)
all_cols = [outcome, predictor] + covariates + ['loan_officer_id']
df_clean = df_clean[all_cols].dropna()

# Prepare X and y
X = df_clean[[predictor] + covariates].copy()
X['const'] = 1.0
y = df_clean[outcome].astype(float)

# Fit Negative Binomial GLM
model = sm.GLM(y, X, family=sm.families.NegativeBinomial())
result = model.fit(cov_type='cluster', cov_kwds={'groups': df_clean['loan_officer_id']})

# Extract primary estimand
effect_size = float(result.params[predictor])
std_err = float(result.bse[predictor])
p_val = float(result.pvalues[predictor])

# 95% CI
ci_lower = effect_size - 1.96 * std_err
ci_upper = effect_size + 1.96 * std_err

# Conclusion
conclusion = 'significant_effect' if p_val < 0.05 else 'no_significant_effect'

result_dict = {
    "effect_size": effect_size,
    "effect_type": "coefficient",
    "standard_error": std_err,
    "p_value": p_val,
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "negative_binomial",
    "predictor_used": "risk_score (mean of risk_evaluator_alpha_score and risk_evaluator_beta_score)",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "rows with missing risk scores, outcome, or any covariate"
}

print(json.dumps(result_dict))