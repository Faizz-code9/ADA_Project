import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

def run_analysis():
    file_path = '/kaggle/working/outputs/runs/gemini-2.5-flash-lite_disguise_confirmatory_T0.0_r2/data.csv'
    
    try:
        df = pd.read_csv(file_path)
    except Exception as e:
        return

    # The hypothesis asks for the effect of risk evaluator scores on rejections.
    # The primary estimand is the ratio effect of continuous risk evaluator score (0-1).
    # Since 'loan_application_rejections' is a count (0, 1, 2), and we want a ratio effect,
    # a Poisson regression or Negative Binomial is appropriate. 
    # However, the prompt asks for "ratio effect" which in the context of counts 
    # usually implies an Incidence Rate Ratio (IRR).
    
    # Data Cleaning
    # We need to handle missing values in the predictor and outcome.
    # risk_evaluator_alpha_score and risk_evaluator_beta_score have 14.7% missing.
    # The prompt implies a single continuous score. I will use the average of alpha and beta 
    # or choose one. Given the prompt says "risk evaluator score (0-1)", 
    # and both alpha and beta are 0-1, I'll use alpha as the primary predictor.
    
    df['risk_score'] = df['risk_evaluator_alpha_score']
    
    # Target: loan_application_rejections
    # Predictor: risk_score
    # Covariates: credit_score_index, annual_income_bracket, prior_denied_loans
    
    cols_to_use = ['loan_application_rejections', 'risk_score', 'credit_score_index', 
                   'annual_income_bracket', 'prior_denied_loans']
    
    # Listwise deletion for the model
    clean_df = df[cols_to_use].dropna().copy()
    
    # Ensure target is integer for Poisson
    clean_df['loan_application_rejections'] = clean_df['loan_application_rejections'].astype(int)
    
    X = clean_df[['risk_score', 'credit_score_index', 'annual_income_bracket', 'prior_denied_loans']]
    X = sm.add_constant(X)
    y = clean_df['loan_application_rejections']
    
    # Fit Poisson model to get IRR
    model = sm.GLM(y, X, family=sm.families.Poisson()).fit()
    
    # Extract coefficient for risk_score
    # The coefficient in Poisson is log(IRR). IRR = exp(coef)
    coef = model.params['risk_score']
    se = model.bse['risk_score']
    p_val = model.pvalues['risk_score']
    
    irr = np.exp(coef)
    ci_lower = np.exp(model.conf_int().loc['risk_score', 0])
    ci_upper = np.exp(model.conf_int().loc['risk_score', 1])
    
    results = {
        "effect_size": float(irr),
        "effect_type": "irr",
        "standard_error": float(se), # SE of the coefficient is standard, but for IRR we usually report SE of log(IRR)
        "p_value": float(p_val),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
        "model_family": "poisson",
        "predictor_used": "risk_evaluator_alpha_score",
        "covariates_included": ["credit_score_index", "annual_income_bracket", "prior_denied_loans"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "none",
        "exclusions_applied": f"Removed rows with missing values in {cols_to_use}"
    }
    
    print(json.dumps(results))

if __name__ == "__main__":
    run_analysis()