import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

# Load data
df = pd.read_csv("/kaggle/working/outputs/runs/allam-2-7b_soccer_neutral_T0.7_r3/data.csv")

# Create skin tone variable (average of rater1 and rater2)
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2

# Drop rows where skin_tone is NaN
df = df.dropna(subset=['skin_tone'])

# Model: Poisson regression for redCards
# Outcome: redCards (count, low frequency)
# Predictor: skin_tone (continuous 0-1)
# Covariates: position (categorical), leagueCountry (categorical), games (exposure)

# One-hot encode categorical variables
df_model = df.copy()
df_model['position'] = df_model['position'].astype('category')
df_model['leagueCountry'] = df_model['leagueCountry'].astype('category')

# Create design matrix
X = pd.DataFrame({
    'skin_tone': df_model['skin_tone'],
    'games': df_model['games']
})

# Add position dummies
pos_dummies = pd.get_dummies(df_model['position'], prefix='pos', drop_first=True)
X = pd.concat([X, pos_dummies], axis=1)

# Add leagueCountry dummies
league_dummies = pd.get_dummies(df_model['leagueCountry'], prefix='league', drop_first=True)
X = pd.concat([X, league_dummies], axis=1)

# Add constant
X = sm.add_constant(X)

y = df_model['redCards']

# Fit Poisson model
model = sm.GLM(y, X, family=sm.families.Poisson()).fit()

# Extract coefficient for skin_tone
coeff = model.params['skin_tone']
se = model.bse['skin_tone']
p_val = model.pvalues['skin_tone']

# IRR = exp(coefficient)
irr = np.exp(coeff)
se_irr = se * irr  # Delta method
ci_lower = np.exp(coeff - 1.96 * se)
ci_upper = np.exp(coeff + 1.96 * se)

# Determine conclusion
conclusion = 'significant_effect' if p_val < 0.05 else 'no_significant_effect'

# List covariates included
covariates = [c for c in X.columns if c not in ['const', 'skin_tone']]

result = {
    "effect_size": irr,
    "effect_type": "irr",
    "standard_error": se_irr,
    "p_value": p_val,
    "ci_lower": ci_lower,
    "ci_upper": ci_upper,
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "skin_tone (average of rater1 and rater2)",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "rows with missing rater1 or rater2 dropped (21,407 rows)"
}

print(json.dumps(result))