import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

# Load data
df = pd.read_csv('/kaggle/working/outputs/runs/allam-2-7b_placebo_confirmatory_T0.0_r1/data.csv')

# Construct skin tone predictor (average of rater1 and rater2)
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2.0

# Exclude rows with missing skin tone
df = df.dropna(subset=['skin_tone'])

# Prepare outcome: redCards (count)
# Use Poisson regression with offset log(games)
# Covariates: height, weight, position, leagueCountry

# Fill missing position with 'Unknown'
df['position'] = df['position'].fillna('Unknown')

# Create dummy variables for position and leagueCountry
pos_dummies = pd.get_dummies(df['position'], prefix='pos', drop_first=True, dtype=float)
league_dummies = pd.get_dummies(df['leagueCountry'], prefix='league', drop_first=True, dtype=float)

# Build design matrix
X = pd.concat([
    df[['skin_tone', 'height', 'weight']],
    pos_dummies,
    league_dummies
], axis=1)

# Add constant
X = sm.add_constant(X)

# Use log(games) as offset for Poisson
df['log_games'] = np.log(df['games'])

# Drop rows with any NaN in X or offset
valid_mask = X.notna().all(axis=1) & df['log_games'].notna()
X = X[valid_mask]
y = df.loc[valid_mask, 'redCards']
offset = df.loc[valid_mask, 'log_games']

# Fit Poisson model
model = sm.GLM(y, X, family=sm.families.Poisson(), offset=offset)
result = model.fit()

# Get coefficient for skin_tone
coef = result.params['skin_tone']
se = result.bse['skin_tone']
p_val = result.pvalues['skin_tone']
ci = result.conf_int().loc['skin_tone']

# Convert to IRR (Incidence Rate Ratio)
irr = np.exp(coef)
irr_se = irr * se  # Delta method approximation
irr_ci_lower = np.exp(ci[0])
irr_ci_upper = np.exp(ci[1])

# Determine conclusion
conclusion = 'significant_effect' if p_val < 0.05 else 'no_significant_effect'

# Covariates included
covariates = ['height', 'weight'] + list(pos_dummies.columns) + list(league_dummies.columns)

# Build JSON output
output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(irr_se),
    "p_value": float(p_val),
    "ci_lower": float(irr_ci_lower),
    "ci_upper": float(irr_ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "skin_tone (average of rater1 and rater2)",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "rows with missing rater1/rater2 or height/weight"
}

print(json.dumps(output))