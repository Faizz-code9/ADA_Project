import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

def main():
    df = pd.read_csv("/kaggle/working/outputs/runs/allam-2-7b_soccer_neutral_T1.0_r3/data.csv")
    
    # Clean data: remove rows where skin tone is missing
    df = df.dropna(subset=["rater1", "rater2"])
    
    # Construct skin tone predictor: average of two raters
    df["skin_tone"] = (df["rater1"] + df["rater2"]) / 2.0
    
    # Remove any rows where skin_tone is still NaN
    df = df.dropna(subset=["skin_tone"])
    
    # Exclusions: only players with meaningful data
    df = df[df["redCards"] >= 0]
    
    # Covariates to adjust for
    covariates = ["height", "weight", "games", "yellowCards"]
    
    # Handle missing values in covariates via listwise deletion
    df = df.dropna(subset=covariates)
    
    # Ensure outcome and predictor exist
    assert "redCards" in df.columns and "skin_tone" in df.columns, "Missing columns"
    
    # Use Poisson regression since red cards are counts and rare
    y = df["redCards"].values
    X_vars = ["skin_tone"] + covariates
    X = df[X_vars].values
    
    # Add constant
    X = sm.add_constant(X)
    
    # Fit Poisson GLM
    model = sm.GLM(y, X, family=sm.families.Poisson())
    results = model.fit()
    
    # Extract coefficient for skin_tone
    skin_tone_idx = 1  # index of skin_tone in X (after constant)
    coef = results.params[skin_tone_idx]
    se = results.bse[skin_tone_idx]
    pval = results.pvalues[skin_tone_idx]
    ci = results.conf_int()[skin_tone_idx]
    
    # Convert to IRР (Incident Rate Ratio)
    irr = np.exp(coef)
    ci_lower = np.exp(ci[0])
    ci_upper = np.exp(ci[1])
    
    # Conclusion
    conclusion = "significant_effect" if pval < 0.05 else "no_significant_effect"
    
    result = {
        "effect_size": float(irr),
        "effect_type": "irr",
        "standard_error": float(se),
        "p_value": float(pval),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": conclusion,
        "model_family": "poisson",
        "predictor_used": "skin_tone",
        "covariates_included": covariates,
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "none",
        "exclusions_applied": "Removed rows with missing rater1, rater2, or covariates (height, weight, games, yellowCards)"
    }
    
    print(json.dumps(result))

if __name__ == "__main__":
    main()