import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

# Load data
df = pd.read_csv('/kaggle/working/outputs/runs/allam-2-7b_placebo_neutral_T1.0_r2/data.csv')

# Construct the main predictor: mean of rater1 and rater2
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2.0

# We need rows where both raters are available (i.e., not missing)
df = df.dropna(subset=['rater1', 'rater2'])

# Define outcome variable
df['outcome'] = (df['redCards'] > 0).astype(int)

# Define covariates
# Adjust for position (one of the most important confounders in this context), height, weight, games, leagueCountry
# Use one-hot encoding for position (drop first) and leagueCountry (drop first)
pos_dummies = pd.get_dummies(df['position'], prefix='pos', drop_first=True)
# Filter out any non-numeric columns if they appear (shouldn't, but safe)
pos_dummies = pos_dummies.select_dtypes(include=[np.number])

league_dummies = pd.get_dummies(df['leagueCountry'], prefix='league', drop_first=True)
league_dummies = league_dummies.select_dtypes(include=[np.number])

# Combine
X_df = pd.concat([df[['skin_tone', 'height', 'weight', 'games']], pos_dummies, league_dummies], axis=1)

# Handle missing values in covariates (height, weight, games, position, league)
# Use listwise deletion to ensure valid model fitting without complex imputation
X_df = X_df.dropna()
df_final = df.loc[X_df.index]

# Final check: ensure no NaN in outcome or X
mask = df_final['outcome'].notna() & X_df.notna().all(axis=1)
X = X_df[mask]
y = df_final.loc[mask, 'outcome'].values

# Add constant
X = sm.add_constant(X)

# Fit logistic regression
model = sm.Logit(y, X).fit(disp=0)

# Extract coefficients for 'skin_tone'
coef_name = 'skin_tone'
if coef_name in model.params:
    coef = model.params[coef_name]
    se = model.bse[coef_name]
    p_val = model.pvalues[coef_name]
    conf_int = model.conf_int().loc[coef_name, :]
    ci_lower = conf_int[0]
    ci_upper = conf_int[1]
else:
    coef, se, p_val, ci_lower, ci_upper = 0, 0, 1, 0, 0

# Calculate Odds Ratio
delta_beta = coef
se_ratio = delta_beta * se  # Delta method: SE of log(IRR) is SE of beta
z_val = delta_beta / se if se != 0 else 0
p_value = 2 * (1 - 0.5 * (1 + np.sin(np.pi * (abs(z_val) / 2))))  # Approximation if needed, but model has pvalue
# Actually, model.pvalues is correct for the coefficient, which corresponds to OR via delta method logic for the exponentiated value's p-value?
# No, p-value for the log-odds is the same as p-value for the odds ratio.
p_value = model.pvalues[coef_name]

# Odds Ratio
odds_ratio = np.exp(delta_beta)
# CI for Odds Ratio
or_ci_lower = np.exp(ci_lower)
or_ci_upper = np.exp(ci_upper)
# SE for Odds Ratio using Delta Method
or_se = odds_ratio * se

# Determine conclusion
conclusion = 'significant_effect' if p_value < 0.05 else 'no_significant_effect'

# Identify covariates included
covariates = [c for c in X.columns if c not in ['const', 'skin_tone']]

result = {
    "effect_size": float(odds_ratio),
    "effect_type": "odds_ratio",
    "standard_error": float(or_se),
    "p_value": float(p_value),
    "ci_lower": float(or_ci_lower),
    "ci_upper": float(or_ci_upper),
    "conclusion": conclusion,
    "model_family": "logistic",
    "predictor_used": "mean_skin_tone_rater1_rater2",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "rows with missing rater1/rater2/covariates removed"
}

print(json.dumps(result))