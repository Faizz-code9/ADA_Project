import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

# Load data
df = pd.read_csv('/kaggle/working/outputs/runs/allam-2-7b_placebo_neutral_T0.0_r1/data.csv')

# Construct skin tone variable (average of rater1 and rater2)
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2.0

# Drop rows where skin_tone is NaN (i.e., both raters missing)
df = df.dropna(subset=['skin_tone'])

# Define outcome and predictor
y = df['redCards']
X = df[['skin_tone']]

# Add covariates: position (one-hot), leagueCountry (one-hot), height, weight
# Use listwise deletion for missing covariates
covariates = ['position', 'leagueCountry', 'height', 'weight']
df_model = df.dropna(subset=covariates).copy()

# One-hot encode categorical variables
df_model = pd.get_dummies(df_model, columns=['position', 'leagueCountry'], drop_first=True, dtype=float)

# Build design matrix
X_cols = ['skin_tone'] + [c for c in df_model.columns if c.startswith('position_') or c.startswith('leagueCountry_')] + ['height', 'weight']
X = df_model[X_cols]
y = df_model['redCards']

# Fit Poisson regression (red cards are count data, low mean)
X_const = sm.add_constant(X)
model = sm.GLM(y, X_const, family=sm.families.Poisson())
result = model.fit()

# Extract coefficient for skin_tone
coef = result.params['skin_tone']
se = result.bse['skin_tone']
p_val = result.pvalues['skin_tone']
ci = result.conf_int().loc['skin_tone']

# Effect size: IRR (Incident Rate Ratio) = exp(coef)
effect_size = np.exp(coef)
ci_lower = np.exp(ci[0])
ci_upper = np.exp(ci[1])

# Conclusion
conclusion = 'significant_effect' if p_val < 0.05 else 'no_significant_effect'

# Build JSON output
output = {
    "effect_size": float(effect_size),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "skin_tone (average of rater1 and rater2)",
    "covariates_included": ["position", "leagueCountry", "height", "weight"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "Rows with missing skin_tone (rater1/rater2) or missing covariates (position, leagueCountry, height, weight) were removed"
}

print(json.dumps(output))