import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

# Load data
df = pd.read_csv('/kaggle/working/outputs/runs/allam-2-7b_placebo_neutral_T0.7_r1/data.csv')

# Construct skin tone predictor as mean of rater1 and rater2
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2

# Exclude rows where skin_tone is missing
df = df.dropna(subset=['skin_tone'])

# Exclude rows where redCards is missing
df = df.dropna(subset=['redCards'])

# Create binary outcome: red card received (1 if redCards > 0, else 0)
df['red_card'] = (df['redCards'] > 0).astype(int)

# Define covariates for adjustment
covariates = ['height', 'weight', 'games', 'yellowCards', 'leagueCountry', 'position']

# Handle missing covariates: use listwise deletion
df = df.dropna(subset=covariates)

# Encode categorical variables
df = pd.get_dummies(df, columns=['leagueCountry', 'position'], prefix=['lc', 'pos'], drop_first=True, dtype=float)

# Prepare design matrix
X = df[['skin_tone', 'height', 'weight', 'games', 'yellowCards'] + 
       [c for c in df.columns if c.startswith('lc_') or c.startswith('pos_')]]
X = sm.add_constant(X)

y = df['red_card']

# Fit logistic regression
model = sm.Logit(y, X).fit(disp=0)

# Extract coefficient for skin_tone
coef_name = 'skin_tone'
beta = model.params[coef_name]
se = model.bse[coef_name]
p_val = model.pvalues[coef_name]

# Compute odds ratio
odds_ratio = np.exp(beta)
ci_lower = np.exp(beta - 1.96 * se)
ci_upper = np.exp(beta + 1.96 * se)

# Conclusion
conclusion = 'significant_effect' if p_val < 0.05 else 'no_significant_effect'

# Identify covariates included
covariates_included = [c for c in model.params.index if c not in ['const', 'skin_tone']]

# Build JSON output
result = {
    "effect_size": float(odds_ratio),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "logistic",
    "predictor_used": "skin_tone (mean of rater1 and rater2, continuous 0-1)",
    "covariates_included": covariates_included,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "rows with missing rater1, rater2, redCards, height, weight, games, yellowCards, leagueCountry, or position removed"
}

print(json.dumps(result))