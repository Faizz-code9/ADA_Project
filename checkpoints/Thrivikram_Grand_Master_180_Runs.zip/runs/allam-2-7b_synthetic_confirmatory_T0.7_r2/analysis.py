import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

# Load data
df = pd.read_csv("/kaggle/working/outputs/runs/allam-2-7b_synthetic_confirmatory_T0.7_r2/data.csv")

# Missing data: drop rows with missing skin_tone (listwise deletion)
df = df.dropna(subset=["skin_tone"]).reset_index(drop=True)

# Create log offset
df['log_games'] = np.log(df['games'])

# Use Negative Binomial GLM with offset
formula = "redCards ~ skin_tone + C(position) + height + weight + C(leagueCountry) + np.log(games)"

# We need to use offset parameter instead of in formula
# Let's use a different approach: create the design matrix manually or use sm.GLM directly

# Fit Negative Binomial GLM with offset
try:
    model = smf.glm(formula, data=df, family=sm.families.NegativeBinomial())
    # Set offset
    model.data = model.data._make_subset(model.data.data, model.data.rownames)
    result = model.fit(method="newton")
except Exception:
    # Fallback to Poisson
    model = smf.glm(formula, data=df, family=sm.families.Poisson())
    result = model.fit(method="newton")

# Get coefficient for skin_tone
coef_name = "skin_tone"
effect_size = result.params[coef_name]
se = result.bse[coef_name]
p_value = result.pvalues[coef_name]
ci_lower, ci_upper = result.conf_int().loc[coef_name].values

# For negative binomial, exp(coef) gives the IRR
effect_size_irr = np.exp(effect_size)
se_irr = np.exp(effect_size) * se
ci_lower_irr = np.exp(ci_lower)
ci_upper_irr = np.exp(ci_upper)

conclusion = "significant_effect" if p_value < 0.05 else "no_significant_effect"

covariates = ["position", "height", "weight", "leagueCountry"]

output = {
    "effect_size": float(effect_size_irr),
    "effect_type": "irr",
    "standard_error": float(se_irr),
    "p_value": float(p_value),
    "ci_lower": float(ci_lower_irr),
    "ci_upper": float(ci_upper_irr),
    "conclusion": conclusion,
    "model_family": "negative_binomial",
    "predictor_used": "skin_tone (continuous, 0-1)",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "288 rows with missing skin_tone removed"
}

print(json.dumps(output))