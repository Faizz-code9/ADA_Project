import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

# Load data
df = pd.read_csv('/kaggle/working/outputs/runs/allam-2-7b_soccer_skeptical_T0.0_r1/data.csv')

# Construct skin tone predictor (average of rater1 and rater2)
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2.0

# Exclude rows where skin tone is missing
df = df.dropna(subset=['skin_tone'])

# Outcome: redCards (count data, low mean ~0.0126)
# Use Poisson regression with clustered standard errors by refNum
# Covariates: leagueCountry, position (if available), height, weight, games

# Prepare covariates
covariates = ['leagueCountry', 'height', 'weight', 'games']

# One-hot encode leagueCountry
df_encoded = pd.get_dummies(df, columns=['leagueCountry'], prefix='lc', drop_first=True, dtype=float)

# Handle missing position: create dummy for missing
df_encoded['position_missing'] = df['position'].isna().astype(int)

# Select covariate columns
cov_cols = [c for c in df_encoded.columns if c.startswith('lc_')] + ['height', 'weight', 'games', 'position_missing']

# Drop rows with missing covariates (listwise deletion)
df_model = df_encoded.dropna(subset=cov_cols)

# Build design matrix
X = df_model[cov_cols].copy()
X['skin_tone'] = df_model['skin_tone']
X = sm.add_constant(X)

y = df_model['redCards']

# Fit Poisson model
model = sm.GLM(y, X, family=sm.families.Poisson())
result = model.fit()

# Get coefficient for skin_tone
coef = result.params['skin_tone']
se = result.bse['skin_tone']
p_val = result.pvalues['skin_tone']

# Compute IRR (Incident Rate Ratio)
irr = np.exp(coef)
irr_se = se * irr  # Delta method approximation
irr_ci_lower = np.exp(coef - 1.96 * se)
irr_ci_upper = np.exp(coef + 1.96 * se)

# Clustered SE by refNum
# Use statsmodels with cov_type='cluster'
result_clustered = model.fit(cov_type='cluster', cov_kwds={'groups': df_model['refNum']})
se_clustered = result_clustered.bse['skin_tone']
p_val_clustered = result_clustered.pvalues['skin_tone']
irr_se_clustered = se_clustered * irr
irr_ci_lower_clustered = np.exp(coef - 1.96 * se_clustered)
irr_ci_upper_clustered = np.exp(coef + 1.96 * se_clustered)

# Use clustered SE for final output
effect_size = irr
standard_error = irr_se_clustered
p_value = p_val_clustered
ci_lower = irr_ci_lower_clustered
ci_upper = irr_ci_upper_clustered

conclusion = 'significant_effect' if p_value < 0.05 else 'no_significant_effect'

output = {
    "effect_size": float(effect_size),
    "effect_type": "irr",
    "standard_error": float(standard_error),
    "p_value": float(p_value),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "skin_tone (average of rater1 and rater2)",
    "covariates_included": cov_cols,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "rows with missing skin tone or covariates removed"
}

print(json.dumps(output))