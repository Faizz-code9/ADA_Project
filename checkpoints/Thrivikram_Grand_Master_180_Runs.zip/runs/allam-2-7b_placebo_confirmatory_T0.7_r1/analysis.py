import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

# Load data
df = pd.read_csv('/kaggle/working/outputs/runs/allam-2-7b_placebo_confirmatory_T0.7_r1/data.csv')

# Create composite skin tone score (mean of rater1 and rater2 where both available)
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2

# Drop rows with missing skin_tone
df = df.dropna(subset=['skin_tone'])

# Exclude goalkeepers (they don't get red cards in the same way and are not subject to the same tactical pressures)
df = df[df['position'] != 'Goalkeeper']

# Prepare model
# Outcome: redCards (count, but very sparse - mostly 0)
# Use Poisson regression with offset for games played (rate of red cards per game)
# Actually, redCards is the count. Let's use Poisson with log(games) as offset to model rate.
# But redCards max is 2, so it's a count.
# Given the sparsity, a Poisson model is appropriate.

# Covariates: leagueCountry (categorical), position (categorical), height, weight
# We need to handle missing position and weight/height
# For missing position, we'll create a dummy for missing
df['position_missing'] = df['position'].isna().astype(int)
df['position'] = df['position'].fillna('Unknown')

# One-hot encode position and leagueCountry
pos_dummies = pd.get_dummies(df['position'], prefix='pos', drop_first=True, dtype=float)
league_dummies = pd.get_dummies(df['leagueCountry'], prefix='league', drop_first=True, dtype=float)

# Drop rows with missing height or weight for simplicity (listwise deletion)
df = df.dropna(subset=['height', 'weight'])
pos_dummies = pos_dummies.loc[df.index]
league_dummies = league_dummies.loc[df.index]

# Construct design matrix
X = pd.concat([
    df[['skin_tone', 'height', 'weight', 'position_missing']],
    pos_dummies,
    league_dummies,
    df[['games']].apply(np.log)  # offset: log(games)
], axis=1)

X = sm.add_constant(X)

y = df['redCards']

# Fit Poisson model
model = sm.GLM(y, X, family=sm.families.Poisson())
result = model.fit()

# Extract coefficient for skin_tone
coef = result.params['skin_tone']
se = result.bse['skin_tone']
p_val = result.pvalues['skin_tone']

# Effect size: Incidence Rate Ratio (IRR) for skin_tone
irr = np.exp(coef)
irr_se = irr * se  # Delta method approximation
ci_lower = np.exp(coef - 1.96 * se)
ci_upper = np.exp(coef + 1.96 * se)

# Determine significance
conclusion = 'significant_effect' if p_val < 0.05 else 'no_significant_effect'

# Build JSON output
covariates = ['height', 'weight', 'position_missing'] + \
             [c for c in pos_dummies.columns] + \
             [c for c in league_dummies.columns] + ['log_games_offset']

output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "skin_tone (mean of rater1 and rater2)",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "Excluded goalkeepers and rows with missing skin tone, height, or weight"
}

print(json.dumps(output))