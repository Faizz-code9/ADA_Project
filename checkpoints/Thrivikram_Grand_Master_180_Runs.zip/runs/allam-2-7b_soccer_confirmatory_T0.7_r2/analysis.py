import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

# Load data
df = pd.read_csv('/kaggle/working/outputs/runs/allam-2-7b_soccer_confirmatory_T0.7_r2/data.csv')

# Construct skin tone variable (average of raters)
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2.0

# Exclude rows with missing skin tone or key variables
df = df.dropna(subset=['skin_tone', 'redCards', 'games', 'height', 'weight'])

# One-hot encode categorical variables
pos_dummies = pd.get_dummies(df['position'], prefix='pos', drop_first=True, dtype=float)
league_dummies = pd.get_dummies(df['leagueCountry'], prefix='league', drop_first=True, dtype=float)

df = pd.concat([df, pos_dummies, league_dummies], axis=1)

# Define numeric and dummy columns to use in the model
numeric_cols = ['skin_tone', 'height', 'weight', 'games']
pos_cols = [c for c in pos_dummies.columns]
league_cols = [c for c in league_dummies.columns]

X_vars = numeric_cols + pos_cols + league_cols

# Ensure all X variables are numeric
X = df[X_vars].astype(float)
X = sm.add_constant(X)
y = df['redCards'].astype(float)

# Offset for rate modeling
offset = np.log(df['games'])

# Fit Poisson model
try:
    model = sm.GLM(y, X, offset=offset, family=sm.families.Poisson())
    res = model.fit()
    
    param_name = 'skin_tone'
    coef = res.params[param_name]
    se = res.bse[param_name]
    p_val = res.pvalues[param_name]
    ci = res.conf_int().loc[param_name]
    
    effect_size = float(np.exp(coef))
    ci_lower = float(np.exp(ci[0]))
    ci_upper = float(np.exp(ci[1]))
    
    effect_type = 'irr'
    conclusion = 'significant_effect' if p_val < 0.05 else 'no_significant_effect'
    model_family = 'poisson'

except Exception:
    # Fallback to logistic if Poisson fails
    y_bin = (df['redCards'] > 0).astype(int)
    model = sm.GLM(y_bin, X, family=sm.families.Binomial())
    res = model.fit()
    
    param_name = 'skin_tone'
    coef = res.params[param_name]
    se = res.bse[param_name]
    p_val = res.pvalues[param_name]
    ci = res.conf_int().loc[param_name]
    
    effect_size = float(np.exp(coef))
    ci_lower = float(np.exp(ci[0]))
    ci_upper = float(np.exp(ci[1]))
    
    effect_type = 'odds_ratio'
    conclusion = 'significant_effect' if p_val < 0.05 else 'no_significant_effect'
    model_family = 'logistic'

output = {
    "effect_size": effect_size,
    "effect_type": effect_type,
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": ci_lower,
    "ci_upper": ci_upper,
    "conclusion": conclusion,
    "model_family": model_family,
    "predictor_used": "skin_tone (average of rater1 and rater2)",
    "covariates_included": [c for c in X_vars if c != 'skin_tone'],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "rows with missing skin tone, height, weight, or games"
}

print(json.dumps(output))