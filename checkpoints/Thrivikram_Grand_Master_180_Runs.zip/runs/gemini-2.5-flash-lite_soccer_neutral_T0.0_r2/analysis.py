import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json
import os

def solve():
    # The user provided a specific path. I will use it.
    file_path = '/kaggle/working/outputs/runs/gemini-2.5-flash-lite_soccer_neutral_T0.0_r2/data.csv'
    
    if not os.path.exists(file_path):
        # If the path is wrong in the environment, we cannot proceed. 
        # However, I must provide the script that *would* work.
        return

    df = pd.read_csv(file_path)

    # 1. Data Cleaning and Preparation
    # Primary estimand: ratio effect (IRR) of continuous skin tone on red cards.
    # Skin tone is rater1 and rater2. We use the mean.
    # redCards is the outcome (count).
    
    # Drop rows where outcome or predictor is missing
    df_clean = df.dropna(subset=['redCards', 'rater1', 'rater2']).copy()
    
    # Construct continuous skin tone predictor
    df_clean['skin_tone'] = df_clean[['rater1', 'rater2']].mean(axis=1)
    
    # Poisson regression is appropriate for count data (redCards).
    # To get the "ratio effect" (IRR), we use the log link.
    # We use 'games' as an offset to account for exposure (number of games played).
    # We must ensure games > 0 for the log offset.
    df_clean = df_clean[df_clean['games'] > 0]
    
    # Include covariates to control for player characteristics
    # We use listwise deletion for missing values in covariates
    covariates = ['height', 'weight', 'yellowCards']
    df_clean = df_clean.dropna(subset=covariates)
    
    initial_len = len(df)
    final_len = len(df_clean)
    exclusions = f"Removed {initial_len - final_len} rows due to missing values or games=0"

    # 2. Statistical Modeling
    # Model: Poisson regression
    # Formula: redCards ~ skin_tone + height + weight + yellowCards
    # Offset: log(games)
    
    try:
        model = smf.poisson('redCards ~ skin_tone + height + weight + yellowCards', 
                            offset=np.log(df_clean['games']), 
                            data=df_clean)
        results = model.fit(disp=False)

        # 3. Extract Estimands
        # The coefficient for skin_tone in Poisson is log(IRR).
        # IRR = exp(coefficient)
        coef = results.params['skin_tone']
        se_log_irr = results.bse['skin_tone']
        p_val = results.pvalues['skin_tone']
        
        irr = np.exp(coef)
        # CI for IRR is exp(CI for log-coefficient)
        ci_log = results.conf_int().loc['skin_tone']
        ci_lower = np.exp(ci_log[0])
        ci_upper = np.exp(ci_log[1])

        conclusion = 'significant_effect' if p_val < 0.05 else 'no_significant_effect'

        # 4. Construct JSON Output
        output = {
            "effect_size": float(irr),
            "effect_type": "irr",
            "standard_error": float(se_log_irr),
            "p_value": float(p_val),
            "ci_lower": float(ci_lower),
            "ci_upper": float(ci_upper),
            "conclusion": conclusion,
            "model_family": "poisson",
            "predictor_used": "mean(rater1, rater2)",
            "covariates_included": covariates,
            "missing_data_strategy": "listwise_deletion",
            "clustering_strategy": "none",
            "exclusions_applied": exclusions
        }

        print(json.dumps(output))
        
    except Exception as e:
        # In case of convergence issues or other errors
        pass

if __name__ == "__main__":
    solve()