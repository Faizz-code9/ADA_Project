import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

def run_analysis():
    # 1. Load Data
    file_path = '/kaggle/working/outputs/runs/gemini-2.5-flash-lite_soccer_confirmatory_T1.0_r1/data.csv'
    df = pd.read_csv(file_path)

    # 2. Data Cleaning & Preparation
    # The hypothesis asks for the effect of continuous skin tone on red cards.
    # Skin tone is provided via rater1 and rater2. We'll take their mean as the continuous variable.
    # Red cards is the count outcome.
    
    # Define skin tone as the average of rater1 and rater2
    df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)
    
    # We are predicting redCards (count). 
    # Note: redCards is count data, usually modeled with Poisson or Negative Binomial.
    # Given the sparsity (most are 0), Poisson is a standard starting point.
    
    # Select relevant columns and drop rows with missing predictor or outcome
    # Target: redCards. Predictor: skin_tone.
    # Covariates: games (exposure/intensity), yellowCards (control for aggressive behavior).
    cols_to_keep = ['redCards', 'skin_tone', 'games', 'yellowCards']
    df_clean = df.dropna(subset=['redCards', 'skin_tone', 'games', 'yellowCards']).copy()
    
    initial_count = len(df)
    df_clean = df_clean[df_clean['redCards'] >= 0] # Ensure non-negative
    exclusions = f"Dropped {initial_count - len(df_clean)} rows due to NaNs in outcome/predictors/covariates"

    # 3. Statistical Modeling
    # Since redCards is a count, and we want a 'ratio effect', we use a Poisson Regression.
    # The exponentiated coefficient of a Poisson model is the Incidence Rate Ratio (IRR).
    
    X = df_clean[['skin_tone', 'games', 'yellowCards']]
    X = sm.add_constant(X)
    y = df_clean['redCards']
    
    try:
        # Using Poisson to get IRR (ratio effect)
        model = sm.GLM(y, X, family=sm.families.Poisson()).fit()
        
        # Extracting coefficient for skin_tone
        # coefficient in log scale, IRR is exp(coeff)
        coeff = model.params['skin_tone']
        irr = np.exp(coeff)
        std_err_log = model.bse['skin_tone']
        std_err_irr = irr * std_err_log # Delta method approximation for error propagation
        
        p_val = model.pvalues['skin_tone']
        ci_log = model.conf_int().loc['skin_tone']
        ci_lower = np.exp(ci_log[0])
        ci_upper = np.exp(ci_log[1])
        
        conclusion = 'significant_effect' if p_val < 0.05 else 'no_significant_effect'
        
    except Exception as e:
        # Fallback for robust execution
        return {"error": str(e)}

    # 4. Construct Result
    result = {
        "effect_size": float(irr),
        "effect_type": "irr",
        "standard_error": float(std_err_irr),
        "p_value": float(p_val),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": conclusion,
        "model_family": "poisson",
        "predictor_used": "mean(rater1, rater2)",
        "covariates_included": ["games", "yellowCards"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "none",
        "exclusions_applied": exclusions
    }
    
    print(json.dumps(result, indent=2))

if __name__ == "__main__":
    run_analysis()