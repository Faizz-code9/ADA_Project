import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_synthetic_confirmatory_T0.0_r2/data.csv"
df = pd.read_csv(file_path)

# 2. Clean and prepare data
initial_len = len(df)
df = df.dropna(subset=['skin_tone']).copy()
exclusions_applied = f"Dropped {initial_len - len(df)} rows due to missing skin_tone"

df['log_games'] = np.log(df['games'])

# 3. Fit statistical model (Poisson regression with GEE for clustering by playerID)
model = smf.gee(
    "redCards ~ skin_tone + yellowCards + log_games",
    data=df,
    groups=df["playerID"],
    family=sm.families.Poisson(),
    cov_struct=sm.cov_struct.Exchangeable()
)
results = model.fit()

# 4. Extract primary estimand (IRR for skin_tone)
beta = results.params["skin_tone"]
se = results.bse["skin_tone"]
p_val = results.pvalues["skin_tone"]
ci = results.conf_int().loc["skin_tone"]

irr = np.exp(beta)
ci_lower = np.exp(ci[0])
ci_upper = np.exp(ci[1])

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "gee",
    "predictor_used": "skin_tone",
    "covariates_included": ["yellowCards", "log_games"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "gee",
    "exclusions_applied": exclusions_applied
}

print(json.dumps(output))