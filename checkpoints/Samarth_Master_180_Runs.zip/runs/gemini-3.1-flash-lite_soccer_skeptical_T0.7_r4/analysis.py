import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json
import sys

def run_analysis():
    # 1. Load data
    file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_soccer_skeptical_T0.7_r4/data.csv'
    df = pd.read_csv(file_path)

    # 2. Preparation
    # Exclude rows where skin tone data is missing
    df = df.dropna(subset=['rater1', 'rater2'])
    
    # Create skinTone variable as average of two raters
    df['skinTone'] = (df['rater1'] + df['rater2']) / 2.0
    
    # Add constant for intercept
    df['intercept'] = 1.0

    # 3. Model Fitting
    # We use a Poisson regression as redCards are count data (often 0, 1, or 2)
    # Clustering by refNum (referee) to account for correlation within referee decisions
    # Covariates: games (exposure), leagueCountry, position (one-hot encoded)
    formula = 'redCards ~ skinTone + games + C(leagueCountry) + C(position)'
    
    # Using GEE to handle clustering
    model = smf.gee(
        formula, 
        groups='refNum', 
        data=df, 
        family=sm.families.Poisson(),
        cov_struct=sm.cov_struct.Exchangeable()
    )
    result = model.fit()

    # 4. Extract metrics
    # The effect size is the coefficient of skinTone
    coef = result.params['skinTone']
    se = result.bse['skinTone']
    p_val = result.pvalues['skinTone']
    conf = result.conf_int().loc['skinTone']
    
    # Conclusion
    significant = p_val < 0.05
    
    # 5. Output
    output = {
        "effect_size": float(coef),
        "effect_type": "coefficient",
        "standard_error": float(se),
        "p_value": float(p_val),
        "ci_lower": float(conf[0]),
        "ci_upper": float(conf[1]),
        "conclusion": "significant_effect" if significant else "no_significant_effect",
        "model_family": "gee",
        "predictor_used": "average of rater1 and rater2 (0-1 scale)",
        "covariates_included": ["games", "leagueCountry", "position"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "gee",
        "exclusions_applied": "removed rows where rater1 or rater2 is missing"
    }
    
    print(json.dumps(output))

if __name__ == "__main__":
    run_analysis()