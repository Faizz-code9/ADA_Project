import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load dataset
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_soccer_skeptical_T0.7_r5/data.csv"
df = pd.read_csv(file_path)

# 2. Prepare data and variables
# Compute average skin tone from rater1 and rater2
df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)

# Drop rows with missing values in key variables
subset_cols = ['redCards', 'skin_tone', 'games', 'yellowCards']
df_clean = df.dropna(subset=subset_cols).copy()

# Ensure redCards is integer and exposure (games) is valid
df_clean = df_clean[df_clean['games'] > 0]

# 3. Fit Poisson regression model (using log(games) as exposure)
formula = 'redCards ~ skin_tone + yellowCards + np.log(games)'
model = smf.poisson(formula, data=df_clean)
result = model.fit(disp=False)

# 4. Extract primary estimand (skin_tone coefficient)
coef = result.params['skin_tone']
se = result.bse['skin_tone']
pval = result.pvalues['skin_tone']
ci = result.conf_int().loc['skin_tone']
irr = np.exp(coef)
irr_ci_lower = np.exp(ci[0])
irr_ci_upper = np.exp(ci[1])

conclusion = 'significant_effect' if pval < 0.05 else 'no_significant_effect'

output = {
  "effect_size": float(irr),
  "effect_type": "irr",
  "standard_error": float(se),
  "p_value": float(pval),
  "ci_lower": float(irr_ci_lower),
  "ci_upper": float(irr_ci_upper),
  "conclusion": conclusion,
  "model_family": "poisson",
  "predictor_used": "skin_tone",
  "covariates_included": ["yellowCards", "games"],
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "none",
  "exclusions_applied": "Dropped rows missing rater scores, red cards, or games."
}

print(json.dumps(output))