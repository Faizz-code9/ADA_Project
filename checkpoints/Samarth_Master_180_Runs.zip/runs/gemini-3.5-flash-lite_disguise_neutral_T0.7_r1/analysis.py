import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_disguise_neutral_T0.7_r1/data.csv"
df = pd.read_csv(file_path)

# 2. Data preparation
# Define predictor: average of risk_evaluator_alpha_score and risk_evaluator_beta_score
df['risk_evaluator_score'] = df[['risk_evaluator_alpha_score', 'risk_evaluator_beta_score']].mean(axis=1)

# Ensure binary outcome (loan_application_rejections > 0 or exact values; usually 0/1, let's treat >0 as 1 if multi-class)
df['loan_application_rejection_binary'] = (df['loan_application_rejections'] > 0).astype(int)

# Filter out rows missing core variables
model_vars = ['loan_application_rejection_binary', 'risk_evaluator_score', 'credit_score_index', 'annual_income_bracket']
df_clean = df.dropna(subset=model_vars).copy()

# 3. Model fitting
# Logistic regression to get odds ratios for the continuous risk score
formula = 'loan_application_rejection_binary ~ risk_evaluator_score + credit_score_index + annual_income_bracket'
model = smf.logit(formula=formula, data=df_clean)
result = model.fit(disp=False)

# 4. Extract metrics for primary estimand (risk_evaluator_score)
coef = result.params['risk_evaluator_score']
se = result.bse['risk_evaluator_score']
p_val = result.pvalues['risk_evaluator_score']
conf_int = result.conf_int().loc['risk_evaluator_score']

odds_ratio = np.exp(coef)
ci_lower = np.exp(conf_int[0])
ci_upper = np.exp(conf_int[1])

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
  "effect_size": float(odds_ratio),
  "effect_type": "odds_ratio",
  "standard_error": float(se),
  "p_value": float(p_val),
  "ci_lower": float(ci_lower),
  "ci_upper": float(ci_upper),
  "conclusion": conclusion,
  "model_family": "logistic",
  "predictor_used": "risk_evaluator_score",
  "covariates_included": ["credit_score_index", "annual_income_bracket"],
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "none",
  "exclusions_applied": "Dropped rows with missing values in risk evaluator scores, credit score, or income."
}

print(json.dumps(output))