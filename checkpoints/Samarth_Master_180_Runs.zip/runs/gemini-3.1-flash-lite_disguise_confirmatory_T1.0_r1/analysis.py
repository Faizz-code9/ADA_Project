import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

def run_analysis():
    # 1. Load data
    file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_disguise_confirmatory_T1.0_r1/data.csv'
    df = pd.read_csv(file_path)

    # 2. Preparation
    # Construct primary predictor: average of alpha and beta scores
    df['risk_eval_score'] = df[['risk_evaluator_alpha_score', 'risk_evaluator_beta_score']].mean(axis=1)
    
    # Exclusions: drop rows where risk scores are missing (14.7% per dict)
    df_clean = df.dropna(subset=['risk_eval_score', 'credit_score_index', 'annual_income_bracket']).copy()
    
    # 3. Fit model
    # Hypothesis: higher risk evaluation scores lead to higher rejection (logit)
    # Adjust for credit_score_index and annual_income_bracket as confounders
    # Use random intercepts for loan_officer_id as applicants are nested within loan officers
    model = smf.mixedlm(
        "loan_application_rejections ~ risk_eval_score + credit_score_index + annual_income_bracket",
        data=df_clean,
        groups=df_clean["loan_officer_id"]
    )
    result = model.fit()

    # 4. Compute primary estimand (coefficient for risk_eval_score)
    coef = result.params['risk_eval_score']
    se = result.bse['risk_eval_score']
    p_val = result.pvalues['risk_eval_score']
    ci_lower = result.conf_int().loc['risk_eval_score', 0]
    ci_upper = result.conf_int().loc['risk_eval_score', 1]

    # 5. Format Output
    output = {
        "effect_size": float(coef),
        "effect_type": "coefficient",
        "standard_error": float(se),
        "p_value": float(p_val),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
        "model_family": "mixed_effects",
        "predictor_used": "mean of risk_evaluator_alpha_score and risk_evaluator_beta_score",
        "covariates_included": ["credit_score_index", "annual_income_bracket"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "random_intercepts",
        "exclusions_applied": "dropped rows with missing risk_eval_score, credit_score_index, or annual_income_bracket"
    }

    print(json.dumps(output))

if __name__ == "__main__":
    run_analysis()