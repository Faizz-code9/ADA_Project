import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_soccer_neutral_T1.0_r1/data.csv"
df = pd.read_csv(file_path)

# 2. Prepare data
# Construct skin tone predictor as the average of rater1 and rater2
df['skinTone'] = (df['rater1'] + df['rater2']) / 2.0

# Exclude rows with missing values in key variables for listwise deletion consistency
# Primary estimand uses redCards as outcome and skinTone as predictor.
# Let's also control for basic confounders like games played or yellowCards if appropriate, 
# but a clean Poisson/Logistic model on redCards vs skinTone with exposure/games is standard.
# Let's use listwise deletion on redCards, skinTone, and games.
analysis_df = df.dropna(subset=['redCards', 'skinTone', 'games']).copy()

# Ensure games is at least 1
analysis_df = analysis_df[analysis_df['games'] > 0]

# 3. Model Fitting
# Using Poisson regression with log(games) as exposure to model rate of red cards
# Alternatively, standard logistic regression or Poisson with robust SEs / GEE. 
# Since observations are player-referee dyads over games, let's use Poisson with robust standard errors (HC1) or GLM Poisson.
formula = 'redCards ~ skinTone + np.log(games)'

model = smf.glm(
    formula=formula, 
    data=analysis_df, 
    family=sm.families.Poisson()
).fit(cov_type='HC1')

# 4. Extract Primary Estimand (skinTone effect)
# Effect type: 'irr' (incidence rate ratio) since it's a Poisson model
coef = model.params['skinTone']
se = model.bse['skinTone']
p_val = model.pvalues['skinTone']
conf_int = model.conf_int().loc['skinTone']

irr = np.exp(coef)
ci_lower = np.exp(conf_int[0])
ci_upper = np.exp(conf_int[1])

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
  "effect_size": float(irr),
  "effect_type": "irr",
  "standard_error": float(se),
  "p_value": float(p_val),
  "ci_lower": float(ci_lower),
  "ci_upper": float(ci_upper),
  "conclusion": conclusion,
  "model_family": "poisson",
  "predictor_used": "skinTone (average of rater1 and rater2)",
  "covariates_included": ["games (offset/log-exposure)"],
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "clustered_se", # HC1 robust SEs used
  "exclusions_applied": "Removed rows with missing skinTone, redCards, or games <= 0."
}

print(json.dumps(output))