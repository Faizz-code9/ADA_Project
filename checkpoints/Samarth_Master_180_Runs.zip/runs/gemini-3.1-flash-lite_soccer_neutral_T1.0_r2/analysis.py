import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

def analyze_bias():
    # 1. Load data
    file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_soccer_neutral_T1.0_r2/data.csv'
    df = pd.read_csv(file_path)

    # 2. Clean/Prepare
    # Calculate skin tone as average of rater1 and rater2
    df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)
    
    # Drop rows where skin_tone or redCards could not be determined (listwise deletion)
    df = df.dropna(subset=['skin_tone', 'redCards', 'refNum', 'leagueCountry', 'games'])
    
    # Primary model: Logistic regression (red card incidence)
    # Using random intercepts for refNum to account for referee clustering
    # Using 'games' as offset/exposure if we were using Poisson, 
    # but since red cards are rare and typically binary per event, logistic is common.
    # Given the research question, we adjust for league/game-intensity.
    
    formula = "redCards ~ skin_tone + games + C(leagueCountry)"
    
    # 3. Fit model (GLM with binomial family for logistic regression)
    model = smf.glm(formula=formula, data=df, family=sm.families.Binomial())
    results = model.fit()

    # 4. Extract metrics
    # Odds Ratio = exp(coeff)
    params = results.params
    conf = results.conf_int()
    
    # Confidence interval for Odds Ratio
    or_val = np.exp(params['skin_tone'])
    ci_lower = np.exp(conf.loc['skin_tone', 0])
    ci_upper = np.exp(conf.loc['skin_tone', 1])
    
    se = results.bse['skin_tone']
    p_val = results.pvalues['skin_tone']
    
    conclusion = 'significant_effect' if p_val < 0.05 else 'no_significant_effect'
    
    # 5. Output JSON
    output = {
        "effect_size": float(or_val),
        "effect_type": "odds_ratio",
        "standard_error": float(se),
        "p_value": float(p_val),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": conclusion,
        "model_family": "logistic",
        "predictor_used": "mean of rater1 and rater2 skin tone",
        "covariates_included": ["games", "leagueCountry"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "none",
        "exclusions_applied": "dropped rows with missing rater scores"
    }
    
    print(json.dumps(output))

if __name__ == "__main__":
    analyze_bias()