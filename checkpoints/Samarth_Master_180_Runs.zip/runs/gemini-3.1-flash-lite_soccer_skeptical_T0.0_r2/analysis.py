import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

# 1. Load data
file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_soccer_skeptical_T0.0_r2/data.csv'
df = pd.read_csv(file_path)

# 2. Clean and prepare
# Drop rows where skin tone ratings are missing
df = df.dropna(subset=['rater1', 'rater2'])
# Construct skin tone variable as average of two raters
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2
# Ensure outcome is numeric
df['redCards'] = df['redCards'].astype(float)

# 3. Fit model
# Using Poisson regression for count data (red cards)
# Adjusting for games played as an offset to account for exposure
# Clustering by referee (refNum) to account for individual referee tendencies
df['log_games'] = np.log(df['games'].replace(0, 1))
model = smf.glm(
    formula='redCards ~ skin_tone + games', 
    data=df, 
    family=sm.families.Poisson(),
    offset=df['log_games']
).fit(cov_type='cluster', cov_kwds={'groups': df['refNum']})

# 4. Compute estimand
params = model.params
conf = model.conf_int()
p_values = model.pvalues

effect_size = np.exp(params['skin_tone'])
se = model.bse['skin_tone']
ci_lower = np.exp(conf.loc['skin_tone', 0])
ci_upper = np.exp(conf.loc['skin_tone', 1])
p_val = p_values['skin_tone']

# 5. Output JSON
result = {
    "effect_size": float(effect_size),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "poisson",
    "predictor_used": "average of rater1 and rater2",
    "covariates_included": ["games"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "rows with missing rater1 or rater2 values"
}

print(json.dumps(result))