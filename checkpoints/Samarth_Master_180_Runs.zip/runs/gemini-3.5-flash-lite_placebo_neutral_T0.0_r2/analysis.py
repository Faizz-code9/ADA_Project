import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_placebo_neutral_T0.0_r2/data.csv"
df = pd.read_csv(file_path)

# 2. Prepare data
# Create average skin tone from rater1 and rater2
df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)

# Drop missing values for key variables (listwise deletion)
subset_cols = ['redCards', 'skin_tone', 'games', 'yellowCards', 'meanIAT']
df_clean = df.dropna(subset=subset_cols).copy()

# 3. Fit model
# Using a Poisson regression model for count data (redCards)
# Controlling for games played, yellow cards, and mean IAT
formula = 'redCards ~ skin_tone + games + yellowCards + meanIAT'
model = smf.poisson(formula, data=df_clean)
result = model.fit(disp=False)

# 4. Extract primary estimand (skin_tone coefficient, IRR)
coef = result.params['skin_tone']
se = result.bse['skin_tone']
p_val = result.pvalues['skin_tone']
conf_int = result.conf_int().loc['skin_tone']

irr = np.exp(coef)
ci_lower = np.exp(conf_int[0])
ci_upper = np.exp(conf_int[1])

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
  "effect_size": float(irr),
  "effect_type": "irr",
  "standard_error": float(se),
  "p_value": float(p_val),
  "ci_lower": float(ci_lower),
  "ci_upper": float(ci_upper),
  "conclusion": conclusion,
  "model_family": "poisson",
  "predictor_used": "skin_tone",
  "covariates_included": ["games", "yellowCards", "meanIAT"],
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "none",
  "exclusions_applied": "Dropped rows with missing values in redCards, rater1/rater2, games, yellowCards, or meanIAT."
}

print(json.dumps(output))