import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/PILOT_gemini-3.5-flash-lite_synthetic_T0.0_1/data.csv"
df = pd.read_csv(file_path)

# 2. Clean and prepare data
# Missing data strategy: listwise deletion on variables of interest
df_clean = df.dropna(subset=['skin_tone', 'redCards', 'games', 'yellowCards', 'position', 'leagueCountry']).copy()

# Since players and referees appear multiple times, we use Poisson regression with exposure (games)
# and robust clustered standard errors at the player level (or mixed effects).
# Let's use statsmodels GEE with clustering by playerID for robust SEs.

df_clean['log_games'] = np.log(df_clean['games'])

# Model formula: redCards ~ skin_tone + yellowCards + height + weight + C(position) + C(leagueCountry)
# Offset for exposure: log_games
formula = 'redCards ~ skin_tone + yellowCards + height + weight + C(position) + C(leagueCountry)'

model = smf.gee(
    formula,
    data=df_clean,
    groups=df_clean['playerID'],
    family=sm.families.Poisson(link=sm.families.links.Log()),
    exposure=df_clean['games']
)

result = model.fit()

# 3. Extract primary estimand (skin_tone)
effect_size = float(np.exp(result.params['skin_tone']))  # IRR
std_err = float(result.bse['skin_tone'])  # SE of log scale or approx. Wait, delta method for IRR: SE(IRR) = IRR * SE(log(IRR))
# Actually, let's report the log_odds/coefficient or IRR properly. effect_type is 'irr', so standard_error should correspond to IRR standard error via delta method or log scale. Let's provide log scale SE or IRR SE. Standard practice for IRR is SE of log(IRR) or delta method. Let's use delta method: SE_IRR = IRR * SE_log_IRR.
irr_se = float(effect_size * result.bse['skin_tone'])

p_value = float(result.pvalues['skin_tone'])
ci_lower = float(np.exp(result.conf_int().loc['skin_tone', 0]))
ci_upper = float(np.exp(result.conf_int().loc['skin_tone', 1]))

conclusion = "significant_effect" if p_value < 0.05 else "no_significant_effect"

output = {
  "effect_size": effect_size,
  "effect_type": "irr",
  "standard_error": irr_se,
  "p_value": p_value,
  "ci_lower": ci_lower,
  "ci_upper": ci_upper,
  "conclusion": conclusion,
  "model_family": "gee",
  "predictor_used": "skin_tone",
  "covariates_included": ["yellowCards", "height", "weight", "position", "leagueCountry", "games"],
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "gee",
  "exclusions_applied": "Dropped rows with missing skin_tone (288 rows)"
}

print(json.dumps(output))