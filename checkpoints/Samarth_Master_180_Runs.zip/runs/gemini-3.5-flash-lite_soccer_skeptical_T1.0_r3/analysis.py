import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_soccer_skeptical_T1.0_r3/data.csv"
df = pd.read_csv(file_path)

# 2. Prepare data and variables
# Skin tone predictor: average of rater1 and rater2
df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)

# Drop missing values for skin_tone and redCards (listwise deletion)
subset_cols = ['redCards', 'skin_tone', 'games', 'yellowCards']
df_clean = df.dropna(subset=subset_cols).copy()

# 3. Fit model
# Poisson regression for count outcome (redCards), exposure via log(games)
formula = 'redCards ~ skin_tone + yellowCards'
model = smf.poisson(formula, data=df_clean, offset=np.log(df_clean['games'])).fit(disp=False)

# 4. Extract estimates
params = model.params
conf = model.conf_int()
pvalues = model.pvalues
bse = model.bse

# Predictor of interest: skin_tone
effect_log_irr = params['skin_tone']
irr = np.exp(effect_log_irr)
se_irr = bse['skin_tone'] * irr  # Delta method approximate for IRR SE
p_val = pvalues['skin_tone']
ci_lower = np.exp(conf.loc['skin_tone', 0])
ci_upper = np.exp(conf.loc['skin_tone', 1])

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

# 5. Output JSON
result = {
  "effect_size": float(irr),
  "effect_type": "irr",
  "standard_error": float(se_irr),
  "p_value": float(p_val),
  "ci_lower": float(ci_lower),
  "ci_upper": float(ci_upper),
  "conclusion": conclusion,
  "model_family": "poisson",
  "predictor_used": "skin_tone (mean of rater1 and rater2)",
  "covariates_included": ["yellowCards", "games (offset)"],
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "none",
  "exclusions_applied": "Rows with missing rater1/rater2 or redCards removed"
}

print(json.dumps(result))