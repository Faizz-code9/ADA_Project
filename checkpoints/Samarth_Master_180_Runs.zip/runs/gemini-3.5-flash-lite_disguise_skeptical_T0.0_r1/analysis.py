import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load dataset
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_disguise_skeptical_T0.0_r1/data.csv"
df = pd.read_csv(file_path)

# 2. Data Preparation & Construction
# Predictor: continuous risk evaluator score (average of alpha and beta if available, or just alpha/beta). Let's use risk_evaluator_alpha_score.
# Primary estimand: ratio effect (odds ratio) of continuous risk evaluator score on loan_application_rejections.
df['risk_score'] = df['risk_evaluator_alpha_score']

# Subset data for complete cases on key variables to avoid missing data drop issues
analysis_df = df[['loan_application_rejections', 'risk_score', 'credit_score_index', 'annual_income_bracket']].dropna().copy()

# Ensure binary or count outcome for logistic regression. loan_application_rejections has max 2, let's treat >=1 as rejection or use Poisson/Negative Binomial, or Logistic if binary. 
# The prompt mentions "loan_application_rejections" and ratio effect (odds_ratio or irr). Let's check unique values of loan_application_rejections.
# It has unique values 3 (0, 1, 2). Let's treat it as a binary indicator for any rejection (>0) to use logistic regression for odds ratio, or Poisson for IRR.
# Let's create a binary rejection indicator:
analysis_df['rejection_binary'] = (analysis_df['loan_application_rejections'] > 0).astype(int)

# 3. Model Fitting (Logistic Regression for Odds Ratio)
model = smf.logit("rejection_binary ~ risk_score + credit_score_index + annual_income_bracket", data=analysis_df)
result = model.fit(disp=False)

# 4. Extract Estimates
coef = result.params['risk_score']
se = result.bse['risk_score']
p_val = result.pvalues['risk_score']
ci = result.conf_int().loc['risk_score']

effect_size = float(np.exp(coef))
ci_lower = float(np.exp(ci[0]))
ci_upper = float(np.exp(ci[1]))

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
  "effect_size": effect_size,
  "effect_type": "odds_ratio",
  "standard_error": float(se),
  "p_value": float(p_val),
  "ci_lower": ci_lower,
  "ci_upper": ci_upper,
  "conclusion": conclusion,
  "model_family": "logistic",
  "predictor_used": "risk_evaluator_alpha_score",
  "covariates_included": ["credit_score_index", "annual_income_bracket"],
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "none",
  "exclusions_applied": "dropped rows with missing values in analysis variables"
}

print(json.dumps(output))