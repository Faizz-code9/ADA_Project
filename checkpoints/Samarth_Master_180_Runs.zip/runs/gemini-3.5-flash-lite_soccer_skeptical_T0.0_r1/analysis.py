import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
df = pd.read_csv('/kaggle/working/outputs/runs/gemini-3.5-flash-lite_soccer_skeptical_T0.0_r1/data.csv')

# 2. Clean and prepare data
# Construct skin tone as mean of rater1 and rater2
df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)

# Drop rows where skin_tone or redCards is missing
df_clean = df.dropna(subset=['skin_tone', 'redCards']).copy()

# Fit Poisson GLM using statsmodels formula api 'poisson'
model = smf.poisson(
    'redCards ~ skin_tone + games + yellowCards',
    data=df_clean
).fit(cov_type='HC1', disp=False)

# Extract parameters
effect_size = np.exp(model.params['skin_tone'])
conf = model.conf_int()
ci_lower = np.exp(conf.loc['skin_tone', 0])
ci_upper = np.exp(conf.loc['skin_tone', 1])
p_value = model.pvalues['skin_tone']
std_err = model.bse['skin_tone'] * effect_size  # delta method approximation for IRR SE

conclusion = 'significant_effect' if p_value < 0.05 else 'no_significant_effect'

output = {
  "effect_size": float(effect_size),
  "effect_type": "irr",
  "standard_error": float(std_err),
  "p_value": float(p_value),
  "ci_lower": float(ci_lower),
  "ci_upper": float(ci_upper),
  "conclusion": conclusion,
  "model_family": "poisson",
  "predictor_used": "skin_tone",
  "covariates_included": ["games", "yellowCards"],
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "none",
  "exclusions_applied": "dropped rows missing rater1/rater2 skin tone ratings"
}

print(json.dumps(output))