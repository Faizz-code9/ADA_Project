import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

def analyze_referee_bias():
    # 1. Load data
    file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_soccer_skeptical_T1.0_r2/data.csv'
    df = pd.read_csv(file_path)

    # 2. Cleaning and Preparation
    # Drop missing rater values
    df = df.dropna(subset=['rater1', 'rater2'])
    # Construct mean skin tone
    df['skin_tone'] = (df['rater1'] + df['rater2']) / 2.0
    
    # Ensuring refNum is categorical for robust clustering
    df['refNum'] = df['refNum'].astype(int)
    
    # 3. Model Fitting
    # Using Poisson regression. Standard statsmodels GLM with clustered SE 
    # often fails if the design matrix is not fully compatible with bincount.
    # We use GLM, but define cluster grouping using a stable approach.
    formula = "redCards ~ skin_tone + meanIAT + games"
    
    # Using 'gee' with an exchangeable correlation structure is more stable
    # for clustered counts (referee-level dependency) than GLM+clustered_se
    model = smf.gee(formula, 
                    groups=df['refNum'], 
                    data=df, 
                    family=sm.families.Poisson(),
                    cov_struct=sm.cov_struct.Exchangeable())
    
    results_fit = model.fit()

    # 4. Extracting Estimands
    # GEE coefficients are log-link, so exp(coef) gives IRR
    params = results_fit.params
    bse = results_fit.bse
    conf = results_fit.conf_int()
    
    effect_size = np.exp(params['skin_tone'])
    std_err = bse['skin_tone']
    p_val = results_fit.pvalues['skin_tone']
    ci_lower = np.exp(conf.loc['skin_tone', 0])
    ci_upper = np.exp(conf.loc['skin_tone', 1])

    # 5. Output Result
    output = {
        "effect_size": float(effect_size),
        "effect_type": "irr",
        "standard_error": float(std_err),
        "p_value": float(p_val),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
        "model_family": "gee",
        "predictor_used": "average of rater1 and rater2",
        "covariates_included": ["meanIAT", "games"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "gee",
        "exclusions_applied": "dropped rows with missing skin tone data"
    }

    print(json.dumps(output))

if __name__ == "__main__":
    analyze_referee_bias()