import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

def analyze_bias():
    # 1. Load data
    file_path = "/kaggle/working/outputs/runs/gemini-3.1-flash-lite_placebo_confirmatory_T1.0_r1/data.csv"
    df = pd.read_csv(file_path)

    # 2. Preparation
    # Exclude missing skin tone (rater1/rater2) and compute mean skin tone
    df = df.dropna(subset=['rater1', 'rater2'])
    df['skin_tone'] = (df['rater1'] + df['rater2']) / 2.0
    
    # Target: redCards (count)
    # Using Poisson regression as it is a standard for count data in this domain
    # Adjust for covariates as recommended by research: position, league, etc.
    df['position'] = df['position'].fillna('Unknown')
    
    # 3. Model
    # Cluster standard errors by referee to account for systematic adjudicator bias
    # Formula: redCards ~ skin_tone + position + leagueCountry
    model = smf.glm(
        formula="redCards ~ skin_tone + C(position) + C(leagueCountry)",
        data=df,
        family=sm.families.Poisson()
    )
    result = model.fit(cov_type='cluster', cov_kwds={'groups': df['refNum']})

    # 4. Extract metrics
    params = result.params
    bse = result.bse
    conf = result.conf_int()
    
    coef = params['skin_tone']
    se = bse['skin_tone']
    p_val = result.pvalues['skin_tone']
    ci_lower = conf.loc['skin_tone', 0]
    ci_upper = conf.loc['skin_tone', 1]
    
    # 5. Output
    output = {
        "effect_size": np.exp(coef),
        "effect_type": "irr",
        "standard_error": se,
        "p_value": p_val,
        "ci_lower": np.exp(ci_lower),
        "ci_upper": np.exp(ci_upper),
        "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
        "model_family": "poisson",
        "predictor_used": "mean(rater1, rater2)",
        "covariates_included": ["position", "leagueCountry"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "clustered_se",
        "exclusions_applied": "rows missing skin tone data"
    }
    
    print(json.dumps(output))

if __name__ == "__main__":
    analyze_bias()