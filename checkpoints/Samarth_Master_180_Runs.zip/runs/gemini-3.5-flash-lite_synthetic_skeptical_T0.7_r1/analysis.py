import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_synthetic_skeptical_T0.7_r1/data.csv"
df = pd.read_csv(file_path)

# 2. Clean and prepare data
# Missing data strategy: listwise deletion for skin_tone (the predictor)
df_clean = df.dropna(subset=['skin_tone']).copy()

# Since outcome is count data (redCards) over exposure (games), we use Poisson/Negative Binomial regression with log(games) offset.
# To avoid log(0), ensure games > 0 (data shows min games is 1).
df_clean['log_games'] = np.log(df_clean['games'])

# 3. Fit model (Poisson regression with robust/cluster SEs for refereeID or playerID, let's use Poisson GLM with robust cov)
# Primary estimand: ratio effect of continuous skin_tone on redCards -> incidence rate ratio (IRR).
formula = "redCards ~ skin_tone + height + weight + yellowCards + C(position) + C(leagueCountry)"

# Fit Poisson model
model = smf.glm(
    formula=formula,
    data=df_clean,
    family=sm.families.Poisson(link=sm.families.links.Log()),
    offset=df_clean['log_games']
).fit(cov_type='HC1')

# 4. Extract primary estimand statistics for skin_tone
coef = model.params['skin_tone']
se = model.bse['skin_tone']
p_val = model.pvalues['skin_tone']
ci = model.conf_int().loc['skin_tone']

irr = float(np.exp(coef))
ci_lower = float(np.exp(ci[0]))
ci_upper = float(np.exp(ci[1]))
effect_size = irr
standard_error = float(se * irr)  # Delta method for standard error of IRR

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
  "effect_size": effect_size,
  "effect_type": "irr",
  "standard_error": standard_error,
  "p_value": float(p_val),
  "ci_lower": ci_lower,
  "ci_upper": ci_upper,
  "conclusion": conclusion,
  "model_family": "poisson",
  "predictor_used": "skin_tone",
  "covariates_included": ["height", "weight", "yellowCards", "position", "leagueCountry", "games (offset)"],
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "none",
  "exclusions_applied": "288 rows dropped due to missing skin_tone"
}

print(json.dumps(output))