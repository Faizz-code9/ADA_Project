import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.1-flash-lite_disguise_skeptical_T0.7_r1/data.csv"
df = pd.read_csv(file_path)

# 2. Prepare data
# Construct risk score as average of alpha and beta
df['risk_score'] = df[['risk_evaluator_alpha_score', 'risk_evaluator_beta_score']].mean(axis=1)

# Drop missing values for primary variables
df_clean = df.dropna(subset=['risk_score', 'loan_application_rejections', 'credit_score_index', 'annual_income_bracket']).copy()

# Treat outcome as binary for bias detection (rejection vs no rejection)
df_clean['rejected'] = (df_clean['loan_application_rejections'] > 0).astype(int)

# Use GEE to handle clustering by loan_officer_id without the massive overhead of thousands of dummy variables
# The prompt asks for clustered SE or GEE; GEE is efficient for this scale.
fam = sm.families.Binomial()
ind = sm.cov_struct.Exchangeable()
model = smf.gee("rejected ~ risk_score + credit_score_index + annual_income_bracket", 
                "loan_officer_id", 
                data=df_clean, 
                family=fam, 
                cov_struct=ind)
results = model.fit()

# Extract results
effect = results.params['risk_score']
se = results.bse['risk_score']
p_val = results.pvalues['risk_score']
ci = results.conf_int().loc['risk_score']

# 5. Construct JSON
output = {
    "effect_size": float(np.exp(effect)),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(np.exp(ci[0])),
    "ci_upper": float(np.exp(ci[1])),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "gee",
    "predictor_used": "average of risk_evaluator_alpha_score and risk_evaluator_beta_score",
    "covariates_included": ["credit_score_index", "annual_income_bracket"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "gee",
    "exclusions_applied": "rows with missing risk_score, credit_score_index, or annual_income_bracket"
}

print(json.dumps(output))