import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

def analyze():
    # 1. Load data
    file_path = "/kaggle/working/outputs/runs/gemini-3.1-flash-lite_soccer_neutral_T0.7_r3/data.csv"
    df = pd.read_csv(file_path)

    # 2. Prepare data
    # Drop rows where skin tone rating is missing
    df = df.dropna(subset=['rater1', 'rater2'])
    
    # Construct primary predictor: average of rater1 and rater2
    df['skin_tone'] = (df['rater1'] + df['rater2']) / 2.0
    
    # Target: Poisson regression for red cards count
    # Covariates: positions, league, games played (as offset or control)
    # Using log(games) as an offset to model rate of red cards per game
    df['log_games'] = np.log(df['games'] + 1e-9)
    
    # 3. Model Fit
    # Using GEE to account for clustering within refs (refNum)
    model = smf.gee("redCards ~ skin_tone + C(position) + C(leagueCountry)", 
                    groups=df['refNum'], 
                    data=df, 
                    family=sm.families.Poisson(),
                    offset=df['log_games'])
    result = model.fit()

    # 4. Extract metrics
    params = result.params
    bse = result.bse
    conf = result.conf_int()
    
    effect_size = np.exp(params['skin_tone'])
    # Delta method for SE of IRR
    se_irr = np.exp(params['skin_tone']) * bse['skin_tone']
    
    ci_lower = np.exp(conf.loc['skin_tone', 0])
    ci_upper = np.exp(conf.loc['skin_tone', 1])
    p_val = result.pvalues['skin_tone']
    
    conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

    # 5. Output JSON
    output = {
        "effect_size": float(effect_size),
        "effect_type": "irr",
        "standard_error": float(se_irr),
        "p_value": float(p_val),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": conclusion,
        "model_family": "gee",
        "predictor_used": "average of rater1 and rater2",
        "covariates_included": ["C(position)", "C(leagueCountry)"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "gee",
        "exclusions_applied": "rows with missing rater1 or rater2 values removed"
    }
    
    print(json.dumps(output))

if __name__ == "__main__":
    analyze()