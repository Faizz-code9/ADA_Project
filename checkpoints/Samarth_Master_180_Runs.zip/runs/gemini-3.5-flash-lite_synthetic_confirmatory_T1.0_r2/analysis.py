import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_synthetic_confirmatory_T1.0_r2/data.csv"
df = pd.read_csv(file_path)

# 2. Clean and prepare data
# Missing data strategy: listwise deletion for skin_tone
df_clean = df.dropna(subset=["skin_tone", "redCards", "games"]).copy()

# Exposure variable (offset) for rate model since games vary
df_clean["log_games"] = np.log(df_clean["games"])

# 3. Fit statistical model (Negative Binomial regression)
model = smf.negativebinomial(
    formula="redCards ~ skin_tone + height + weight + C(position) + C(leagueCountry)",
    data=df_clean,
    offset=df_clean["log_games"]
)
results = model.fit(disp=False)

# 4. Compute primary estimand (IRR for skin_tone)
coef = results.params["skin_tone"]
se = results.bse["skin_tone"]
p_val = results.pvalues["skin_tone"]
ci = results.conf_int().loc["skin_tone"]

irr = np.exp(coef)
ci_lower = np.exp(ci[0])
ci_upper = np.exp(ci[1])

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "negative_binomial",
    "predictor_used": "skin_tone",
    "covariates_included": ["height", "weight", "position", "leagueCountry", "log_games"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "Dropped 288 rows with missing skin_tone"
}

print(json.dumps(output))