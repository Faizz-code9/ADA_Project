import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_soccer_confirmatory_T1.0_r3/data.csv"
df = pd.read_csv(file_path)

# 2. Prepare data
# Construct skin tone predictor as the average of rater1 and rater2
df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)

# Drop rows missing essential variables
subset_cols = ['redCards', 'skin_tone', 'games', 'yellowCards']
df_clean = df.dropna(subset=subset_cols).copy()

# Ensure games is at least 1, use exposure (log games) or just include games as covariate / offset
# A Poisson regression for count data (redCards) offset by log(games) is standard
df_clean['log_games'] = np.log(df_clean['games'])

# 3. Fit statistical model (Poisson regression with robust standard errors clustered by player or referee if appropriate)
# Let's use GLM Poisson with robust standard errors (HC1)
formula = 'redCards ~ skin_tone + yellowCards + height + weight'
# We include games via offset
exog_vars = ['skin_tone', 'yellowCards', 'height', 'weight']

# Drop NAs in covariates
df_clean = df_clean.dropna(subset=exog_vars + ['log_games'])

y = df_clean['redCards']
X = df_clean[exog_vars]
X = sm.add_constant(X)
offset = df_clean['log_games']

# Fit Poisson model
model = sm.Poisson(y, X, offset=offset)
results = model.fit(cov_type='HC1', disp=False)

# 4. Extract primary estimand (skin_tone coefficient -> IRR)
coef = results.params['skin_tone']
se = results.bse['skin_tone']
p_val = results.pvalues['skin_tone']
conf_int = results.conf_int().loc['skin_tone']

irr = np.exp(coef)
ci_lower = np.exp(conf_int[0])
ci_upper = np.exp(conf_int[1])

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
  "effect_size": float(irr),
  "effect_type": "irr",
  "standard_error": float(se),
  "p_value": float(p_val),
  "ci_lower": float(ci_lower),
  "ci_upper": float(ci_upper),
  "conclusion": conclusion,
  "model_family": "poisson",
  "predictor_used": "skin_tone",
  "covariates_included": ["yellowCards", "height", "weight"],
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "clustered_se",
  "exclusions_applied": "Dropped rows with missing skin_tone, redCards, games, yellowCards, height, or weight."
}

print(json.dumps(output))