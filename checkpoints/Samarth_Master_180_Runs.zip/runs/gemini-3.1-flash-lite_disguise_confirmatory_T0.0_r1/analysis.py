import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

# 1. Load data
file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_disguise_confirmatory_T0.0_r1/data.csv'
df = pd.read_csv(file_path)

# 2. Clean and prepare
# The error indicates loan_application_rejections contains values > 1. 
# Based on the data dictionary, it has values 0, 1, 2. 
# We treat rejection as a binary outcome (1 if rejected, 0 otherwise).
df['rejection_binary'] = (df['loan_application_rejections'] > 0).astype(int)
df['risk_evaluator_score'] = df[['risk_evaluator_alpha_score', 'risk_evaluator_beta_score']].mean(axis=1)

# Exclusions: Drop rows where key variables are missing
df_clean = df.dropna(subset=['risk_evaluator_score', 'credit_score_index', 'annual_income_bracket']).copy()

# 3. Fit model
# Using Logistic Regression to model the probability of rejection (binary)
formula = 'rejection_binary ~ risk_evaluator_score + credit_score_index + annual_income_bracket + prior_denied_loans'
model = smf.logit(formula, data=df_clean).fit(disp=0)

# 4. Compute estimands
params = model.params
conf = model.conf_int()
se = model.bse
p_values = model.pvalues

effect_size = params['risk_evaluator_score']
se_val = se['risk_evaluator_score']
p_val = p_values['risk_evaluator_score']
ci_lower = conf.loc['risk_evaluator_score', 0]
ci_upper = conf.loc['risk_evaluator_score', 1]

# 5. Output JSON
result = {
    "effect_size": float(effect_size),
    "effect_type": "log_odds",
    "standard_error": float(se_val),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "logistic",
    "predictor_used": "mean of risk_evaluator_alpha_score and risk_evaluator_beta_score",
    "covariates_included": ["credit_score_index", "annual_income_bracket", "prior_denied_loans"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "rows with missing risk_evaluator_score, credit_score_index, or annual_income_bracket; outcome binarized"
}

print(json.dumps(result))