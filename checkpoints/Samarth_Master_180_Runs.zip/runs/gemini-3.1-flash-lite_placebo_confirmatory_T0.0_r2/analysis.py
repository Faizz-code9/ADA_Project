import pandas as pd
import numpy as np
import statsmodels.formula.api as smf
import json

# 1. Load data
file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_placebo_confirmatory_T0.0_r2/data.csv'
df = pd.read_csv(file_path)

# 2. Clean and prepare
# Exclude rows where skin tone ratings are missing
df = df.dropna(subset=['rater1', 'rater2', 'refNum'])
# Construct skin tone variable
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2
# Ensure outcome is binary
df['red_card_binary'] = (df['redCards'] > 0).astype(int)
# Ensure refNum is categorical for clustering
df['refNum'] = df['refNum'].astype(int)

# 3. Fit model
# The error in the previous attempt was likely due to index misalignment during clustering.
# We ensure the dataframe used for the model has a clean index.
df_model = df.dropna(subset=['skin_tone', 'games', 'meanIAT', 'red_card_binary', 'refNum']).copy()
df_model = df_model.reset_index(drop=True)

# Using Logistic Regression with clustered standard errors
# We use a formula that handles categorical variables internally
model = smf.logit(
    "red_card_binary ~ skin_tone + games + meanIAT + C(position)", 
    data=df_model
).fit(cov_type='cluster', cov_kwds={'groups': df_model['refNum']}, disp=0)

# 4. Compute estimand
params = model.params
conf = model.conf_int()
p_values = model.pvalues

effect_size = np.exp(params['skin_tone'])
se = model.bse['skin_tone']
ci_lower = np.exp(conf.loc['skin_tone', 0])
ci_upper = np.exp(conf.loc['skin_tone', 1])
p_val = p_values['skin_tone']

# 5. Output JSON
result = {
    "effect_size": float(effect_size),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "logistic",
    "predictor_used": "skin_tone (average of rater1 and rater2)",
    "covariates_included": ["games", "meanIAT", "position"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "rows with missing rater1, rater2, refNum, or covariates"
}

print(json.dumps(result))