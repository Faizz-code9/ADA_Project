import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

# 1. Load data
file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_placebo_skeptical_T0.0_r1/data.csv'
df = pd.read_csv(file_path)

# 2. Clean and prepare
# Drop rows where skin tone ratings are missing
df = df.dropna(subset=['rater1', 'rater2', 'position', 'meanIAT'])
# Construct skin tone variable
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2
# Log exposure for Poisson
df['log_games'] = np.log(df['games'])

# 3. Fit model
# Patsy does not support 'offset()' directly in formula strings for GEE in all versions.
# We use the 'offset' parameter in the fit method instead.
formula = 'redCards ~ skin_tone + meanIAT + C(leagueCountry) + C(position)'

# 4. Compute estimand
# Using GEE to account for clustering by referee (refNum)
model = smf.gee(
    formula, 
    data=df, 
    groups=df['refNum'], 
    family=sm.families.Poisson(),
    offset=df['log_games'],
    cov_struct=sm.cov_struct.Exchangeable()
)
result = model.fit()

# Extracting coefficient for skin_tone
coef = result.params['skin_tone']
se = result.bse['skin_tone']
p_val = result.pvalues['skin_tone']
conf_int = result.conf_int().loc['skin_tone']

# 5. Print JSON
output = {
    "effect_size": float(np.exp(coef)),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(np.exp(conf_int[0])),
    "ci_upper": float(np.exp(conf_int[1])),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "gee",
    "predictor_used": "average of rater1 and rater2",
    "covariates_included": ["meanIAT", "leagueCountry", "position"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "gee",
    "exclusions_applied": "rows with missing rater1, rater2, position, or meanIAT"
}

print(json.dumps(output))