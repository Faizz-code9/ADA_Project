import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

def analyze_bias():
    # 1. Load data
    file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_placebo_neutral_T1.0_r2/data.csv'
    df = pd.read_csv(file_path)

    # 2. Clean and Prepare
    # Drop rows missing rater values (required for predictor) and any NaN in covariates
    df = df.dropna(subset=['rater1', 'rater2', 'games', 'position', 'leagueCountry'])
    
    # Construct Skin Tone (average of the two raters)
    df['skin_tone'] = (df['rater1'] + df['rater2']) / 2.0
    
    # Ensure categorical variables are handled correctly for formula
    # statsmodels handles C() for categorical variables, but we must ensure no NaNs exist.
    
    # 3. Model Fitting
    # Using Poisson GLM. 
    # To avoid the ValueError in sandwich_covariance, we ensure the index matches the design matrix
    # and use the fit() method which supports clustering.
    formula = 'redCards ~ skin_tone + games + C(position) + C(leagueCountry)'
    model = smf.glm(
        formula=formula,
        data=df,
        family=sm.families.Poisson()
    )
    
    # Fit with robust standard errors (HC1) for clustering by referee (refNum)
    # The 'groups' array must be passed correctly based on the cleaned dataframe
    result = model.fit(
        cov_type='cluster', 
        cov_kwds={'groups': df['refNum']}
    )
    
    # 4. Extract quantities
    params = result.params
    bse = result.bse
    conf = result.conf_int()
    
    effect_size = params['skin_tone'] 
    irr = np.exp(effect_size)
    # Standard error of IRR via Delta Method: d(exp(x))/dx * SE = exp(x) * SE
    se_irr = irr * bse['skin_tone']
    
    # CI for IRR
    ci_lower = np.exp(conf.loc['skin_tone', 0])
    ci_upper = np.exp(conf.loc['skin_tone', 1])
    
    p_val = result.pvalues['skin_tone']
    
    # 5. Output
    output = {
        "effect_size": float(irr),
        "effect_type": "irr",
        "standard_error": float(se_irr),
        "p_value": float(p_val),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
        "model_family": "poisson",
        "predictor_used": "average of rater1 and rater2 skin tone ratings",
        "covariates_included": ["games", "position", "leagueCountry"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "clustered_se",
        "exclusions_applied": "rows with missing rater1, rater2, games, position, or leagueCountry"
    }
    
    print(json.dumps(output))

if __name__ == "__main__":
    analyze_bias()