import json
import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
df = pd.read_csv('/kaggle/working/outputs/runs/gemini-3.5-flash-lite_placebo_confirmatory_T0.7_r2/data.csv')

# 2. Clean and prepare data
# Construct skin tone predictor as the average of rater1 and rater2
df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)

# Drop rows with missing values in key variables for a clean analysis
vars_to_check = ['redCards', 'skin_tone', 'games', 'yellowCards']
initial_len = len(df)
df_clean = df.dropna(subset=vars_to_check).copy()
exclusions_applied = f"Dropped {initial_len - len(df_clean)} rows due to missing values in primary variables."

# Offset for exposure (games played) or include games as a covariate. 
# A Poisson regression with log(games) as offset or games as predictor is standard.
# Let's use Poisson regression modeling redCards count.
# Since redCards max is 2, Poisson or Negative Binomial is appropriate.

# 3. Fit model
# We model redCards ~ skin_tone + games + yellowCards
model = smf.poisson('redCards ~ skin_tone + games + yellowCards', data=df_clean).fit(disp=False)

# 4. Extract primary estimand (effect of skin_tone)
# The primary estimand is the ratio effect (incidence rate ratio, IRR).
coef = model.params['skin_tone']
se = model.bse['skin_tone']
pval = model.pvalues['skin_tone']
ci = model.conf_int().loc['skin_tone']
irr = np.exp(coef)
ci_lower = np.exp(ci[0])
ci_upper = np.exp(ci[1])

conclusion = "significant_effect" if pval < 0.05 else "no_significant_effect"

output = {
  "effect_size": float(irr),
  "effect_type": "irr",
  "standard_error": float(se),
  "p_value": float(pval),
  "ci_lower": float(ci_lower),
  "ci_upper": float(ci_upper),
  "conclusion": conclusion,
  "model_family": "poisson",
  "predictor_used": "skin_tone",
  "covariates_included": ["games", "yellowCards"],
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "none",
  "exclusions_applied": exclusions_applied
}

print(json.dumps(output))