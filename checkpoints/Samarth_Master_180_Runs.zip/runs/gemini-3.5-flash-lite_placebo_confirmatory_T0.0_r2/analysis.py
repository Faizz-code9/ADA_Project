import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_placebo_confirmatory_T0.0_r2/data.csv"
df = pd.read_csv(file_path)

# 2. Clean and prepare data
# Construct skin tone predictor as the average of rater1 and rater2
df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)

# Listwise deletion of missing values for necessary columns
analysis_cols = ['redCards', 'skin_tone', 'games', 'yellowCards']
df_clean = df.dropna(subset=analysis_cols).copy()

# 3. Model Fitting
# Using Poisson regression (or Negative Binomial) for count outcome 'redCards'
# Controlling for games played and yellow cards as exposure/covariates
model = smf.poisson('redCards ~ skin_tone + games + yellowCards', data=df_clean).fit(disp=False)

# 4. Extract primary estimand
# The primary estimand is the ratio effect (incidence rate ratio) of continuous skin tone
params = model.params
conf_int = model.conf_int()

effect_size = float(np.exp(params['skin_tone']))
std_err = float(model.bse['skin_tone'])
p_val = float(model.pvalues['skin_tone'])
ci_lower = float(np.exp(conf_int.loc['skin_tone', 0]))
ci_upper = float(np.exp(conf_int.loc['skin_tone', 1]))

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

# 5. Output JSON
result = {
  "effect_size": effect_size,
  "effect_type": "irr",
  "standard_error": std_err,
  "p_value": p_val,
  "ci_lower": ci_lower,
  "ci_upper": ci_upper,
  "conclusion": conclusion,
  "model_family": "poisson",
  "predictor_used": "skin_tone",
  "covariates_included": ["games", "yellowCards"],
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "none",
  "exclusions_applied": "Rows with missing skin_tone or redCards were dropped via listwise deletion."
}

print(json.dumps(result))