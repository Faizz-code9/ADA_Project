import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_synthetic_confirmatory_T0.7_r1/data.csv"
df = pd.read_csv(file_path)

# 2. Clean and prepare data
# Missing data strategy: listwise deletion for skin_tone (the primary predictor)
df = df.dropna(subset=["skin_tone"]).copy()

# Offset for exposure: games played (log(games) as offset for Poisson model)
df["log_games"] = np.log(df["games"])

# Covariates to adjust for: yellowCards, position, height, weight, leagueCountry
covariates = [
    "yellowCards",
    "position",
    "height",
    "weight",
    "leagueCountry",
]

# 3. Fit statistical model (Poisson regression with exposure offset)
formula = "redCards ~ skin_tone + yellowCards + C(position) + height + weight + C(leagueCountry)"
model = smf.poisson(
    formula=formula, data=df, offset=df["log_games"]
).fit(disp=False)

# 4. Extract primary estimand (skin_tone)
# Effect type for Poisson regression is IRR (Incidence Rate Ratio) = exp(coefficient)
coef = model.params["skin_tone"]
se = model.bse["skin_tone"]
p_val = model.pvalues["skin_tone"]
ci = model.conf_int().loc["skin_tone"]

irr = float(np.exp(coef))
ci_lower = float(np.exp(ci[0]))
ci_upper = float(np.exp(ci[1]))

conclusion = (
    "significant_effect" if p_val < 0.05 else "no_significant_effect"
)

# 5. Output JSON
result = {
    "effect_size": irr,
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": ci_lower,
    "ci_upper": ci_upper,
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "skin_tone",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "Dropped rows with missing skin_tone (288 rows).",
}

print(json.dumps(result))