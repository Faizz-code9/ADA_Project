import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_disguise_skeptical_T0.7_r1/data.csv"
df = pd.read_csv(file_path)

# 2. Clean and prepare data
# Construct primary predictor: average of risk_evaluator_alpha_score and risk_evaluator_beta_score
df['risk_score'] = df[['risk_evaluator_alpha_score', 'risk_evaluator_beta_score']].mean(axis=1)

# Ensure outcome is binary/count appropriate for logistic regression
# loan_application_rejections has values 0, 1, 2. Let's look at max: 2. We can treat as binary (0 vs >=1) or count.
# The prompt says: "ratio effect of continuous risk evaluator score (0-1) on loan_application_rejections"
# Given it's rejections, logistic regression on a binary indicator or Poisson is standard. Let's use logistic on rejection > 0.
df['rejected_binary'] = (df['loan_application_rejections'] > 0).astype(int)

# Covariates to include
covariates = ['credit_score_index', 'annual_income_bracket', 'prior_approved_loans', 'prior_denied_loans']

# Missing data strategy: listwise deletion on used columns
model_vars = ['rejected_binary', 'risk_score'] + covariates
df_clean = df.dropna(subset=model_vars).copy()

# 3. Fit statistical model (Logistic Regression)
formula = 'rejected_binary ~ risk_score + credit_score_index + annual_income_bracket + prior_approved_loans + prior_denied_loans'
model = smf.logit(formula, data=df_clean)
result = model.fit(disp=False)

# 4. Compute primary estimand (Odds Ratio for risk_score)
coef = result.params['risk_score']
se = result.bse['risk_score']
p_val = result.pvalues['risk_score']
ci = result.conf_int().loc['risk_score']

effect_size = np.exp(coef)
ci_lower = np.exp(ci[0])
ci_upper = np.exp(ci[1])

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
  "effect_size": float(effect_size),
  "effect_type": "odds_ratio",
  "standard_error": float(se),
  "p_value": float(p_val),
  "ci_lower": float(ci_lower),
  "ci_upper": float(ci_upper),
  "conclusion": conclusion,
  "model_family": "logistic",
  "predictor_used": "risk_score",
  "covariates_included": covariates,
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "none",
  "exclusions_applied": "dropped rows with missing values in model variables"
}

print(json.dumps(output))