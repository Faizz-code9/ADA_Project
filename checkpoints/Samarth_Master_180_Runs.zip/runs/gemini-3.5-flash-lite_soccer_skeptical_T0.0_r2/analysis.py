import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
df = pd.read_csv('/kaggle/working/outputs/runs/gemini-3.5-flash-lite_soccer_skeptical_T0.0_r2/data.csv')

# 2. Clean and prepare data
# Construct skin tone as the average of rater1 and rater2
df['skinTone'] = df[['rater1', 'rater2']].mean(axis=1)

# Drop rows missing essential variables
subset_cols = ['redCards', 'skinTone', 'games', 'yellowCards', 'meanIAT', 'leagueCountry']
df_clean = df.dropna(subset=subset_cols).copy()

# Offset for exposure (games played) in Poisson/Negative Binomial regression
# Or include log(games) as an offset
df_clean['log_games'] = np.log(df_clean['games'])

# 3. Fit statistical model (Poisson regression with robust standard errors or Negative Binomial)
# Using Poisson with robust SE (clustered by refNum or player) to account for overdispersion/clustering
formula = 'redCards ~ skinTone + yellowCards + meanIAT + C(leagueCountry)'
model = smf.glm(formula=formula, data=df_clean, family=sm.families.Poisson(), 
                exposure=df_clean['games']).fit(cov_type='HC1')

# 4. Extract primary estimand (skinTone effect)
effect_size = np.exp(model.params['skinTone'])
se_log = model.bse['skinTone']
# Delta method for SE of IRR
effect_se = effect_size * se_log
p_value = model.pvalues['skinTone']
ci_lower = np.exp(model.conf_int().loc['skinTone', 0])
ci_upper = np.exp(model.conf_int().loc['skinTone', 1])

conclusion = 'significant_effect' if p_value < 0.05 else 'no_significant_effect'

output = {
  "effect_size": float(effect_size),
  "effect_type": "irr",
  "standard_error": float(effect_se),
  "p_value": float(p_value),
  "ci_lower": float(ci_lower),
  "ci_upper": float(ci_upper),
  "conclusion": conclusion,
  "model_family": "poisson",
  "predictor_used": "skinTone",
  "covariates_included": ["yellowCards", "meanIAT", "leagueCountry"],
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "none",
  "exclusions_applied": "Dropped rows missing skinTone, redCards, games, yellowCards, meanIAT, or leagueCountry."
}

print(json.dumps(output))