import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load the CSV
df = pd.read_csv('/kaggle/working/outputs/runs/gemini-3.5-flash-lite_disguise_confirmatory_T0.7_r2/data.csv')

# 2. Data Preparation & Cleaning
# Construct a combined continuous risk evaluator score (e.g., mean of alpha and beta scores, or just alpha). 
# Let's use `risk_evaluator_alpha_score` as the primary continuous risk evaluator score (0-1), 
# or an average if both are available. Let's use `risk_evaluator_alpha_score`.
# Missing data strategy: listwise deletion for the variables used in the model.
model_vars = ['loan_application_rejections', 'risk_evaluator_alpha_score', 'credit_score_index', 'annual_income_bracket']
df_clean = df.dropna(subset=model_vars).copy()

# Ensure outcome is binary/count appropriate for logistic regression (rejections can be >0, let's binarize or use Poisson/Logistic)
# The outcome `loan_application_rejections` has min 0, max 2. Let's treat as binary (rejection vs no rejection) or use logistic.
df_clean['rejected_binary'] = (df_clean['loan_application_rejections'] > 0).astype(int)

# 3. Fit Model (Logistic Regression)
formula = 'rejected_binary ~ risk_evaluator_alpha_score + credit_score_index + annual_income_bracket'
model = smf.logit(formula, data=df_clean)
result = model.fit(disp=False)

# 4. Extract Estimates for Primary Estimand (risk_evaluator_alpha_score)
param_name = 'risk_evaluator_alpha_score'
coef = result.params[param_name]
se = result.bse[param_name]
pval = result.pvalues[param_name]
ci = result.conf_int().loc[param_name]

# Since it's logistic regression, ratio effect (odds ratio) is exp(coef)
effect_size = float(np.exp(coef))
ci_lower = float(np.exp(ci[0]))
ci_upper = float(np.exp(ci[1]))
standard_error = float(se) * effect_size  # Delta method approx for OR standard error, or report log_odds. 
# Wait, the prompt asks for effect_type: 'odds_ratio' or 'coefficient'. Let's provide 'odds_ratio' and its SE via delta method.

conclusion = 'significant_effect' if pval < 0.05 else 'no_significant_effect'

output = {
  "effect_size": effect_size,
  "effect_type": "odds_ratio",
  "standard_error": standard_error,
  "p_value": float(pval),
  "ci_lower": ci_lower,
  "ci_upper": ci_upper,
  "conclusion": conclusion,
  "model_family": "logistic",
  "predictor_used": "risk_evaluator_alpha_score",
  "covariates_included": ["credit_score_index", "annual_income_bracket"],
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "none",
  "exclusions_applied": "dropped rows with missing values in model variables"
}

print(json.dumps(output))