import json
import pandas as pd
import numpy as np
import statsmodels.api as sm

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_placebo_neutral_T0.0_r1/data.csv"
df = pd.read_csv(file_path)

# 2. Clean and prepare data
df['skinTone'] = df[['rater1', 'rater2']].mean(axis=1)
analysis_vars = ['redCards', 'skinTone', 'games', 'yellowCards', 'meanIAT', 'height', 'weight', 'refNum']
df_clean = df.dropna(subset=analysis_vars).copy()

df_clean['log_games'] = np.log(df_clean['games'])

# 3. Fit statistical model using statsmodels GLM instead of patsy formula to avoid offset parsing errors
features = ['skinTone', 'yellowCards', 'meanIAT', 'height', 'weight', 'log_games']
X = df_clean[features]
X = sm.add_constant(X)
y = df_clean['redCards']

# Fit Poisson regression
model = sm.GLM(y, X, family=sm.families.Poisson()).fit(
    cov_type='cluster', 
    cov_kwds={'groups': df_clean['refNum']}
)

# 4. Compute primary estimand (IRR for skinTone)
coef = model.params['skinTone']
se = model.bse['skinTone']
pval = model.pvalues['skinTone']
ci = model.conf_int().loc['skinTone']

irr = np.exp(coef)
ci_lower = np.exp(ci[0])
ci_upper = np.exp(ci[1])

conclusion = "significant_effect" if pval < 0.05 else "no_significant_effect"

output = {
  "effect_size": float(irr),
  "effect_type": "irr",
  "standard_error": float(se),
  "p_value": float(pval),
  "ci_lower": float(ci_lower),
  "ci_upper": float(ci_upper),
  "conclusion": conclusion,
  "model_family": "poisson",
  "predictor_used": "skinTone",
  "covariates_included": ["yellowCards", "meanIAT", "height", "weight", "log_games"],
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "clustered_se",
  "exclusions_applied": "Dropped rows with missing skinTone, redCards, games, yellowCards, meanIAT, height, weight, or refNum."
}

print(json.dumps(output))