import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_placebo_neutral_T0.7_r2/data.csv"
df = pd.read_csv(file_path)

# 2. Clean and prepare data
# Construct skin tone as average of rater1 and rater2
df['skinTone'] = df[['rater1', 'rater2']].mean(axis=1)

# Drop rows with missing values in key variables
subset_cols = ['redCards', 'skinTone', 'games', 'yellowCards', 'meanIAT']
df_clean = df.dropna(subset=subset_cols).copy()

# 3. Fit model
# Using Poisson regression for count outcome (redCards), controlling for games played, yellow cards, and mean IAT.
# Clustered standard errors by referee (refNum) to account for referee-level correlation.
formula = 'redCards ~ skinTone + games + yellowCards + meanIAT'
model = smf.poisson(formula, data=df_clean)
result = model.fit(cov_type='cluster', cov_kwds={'groups': df_clean['refNum']}, disp=False)

# 4. Compute primary estimand (IRR for skinTone)
beta = result.params['skinTone']
se = result.bse['skinTone']
p_val = result.pvalues['skinTone']
ci = result.conf_int().loc['skinTone']

irr = np.exp(beta)
ci_lower = np.exp(ci[0])
ci_upper = np.exp(ci[1])

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

# 5. Output JSON
output = {
  "effect_size": float(irr),
  "effect_type": "irr",
  "standard_error": float(se),
  "p_value": float(p_val),
  "ci_lower": float(ci_lower),
  "ci_upper": float(ci_upper),
  "conclusion": conclusion,
  "model_family": "poisson",
  "predictor_used": "skinTone (average of rater1 and rater2)",
  "covariates_included": ["games", "yellowCards", "meanIAT"],
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "clustered_se",
  "exclusions_applied": "Dropped rows with missing skinTone, redCards, games, yellowCards, or meanIAT"
}

print(json.dumps(output))