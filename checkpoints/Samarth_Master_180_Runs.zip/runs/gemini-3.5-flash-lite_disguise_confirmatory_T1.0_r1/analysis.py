import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_disguise_confirmatory_T1.0_r1/data.csv"
df = pd.read_csv(file_path)

# 2. Data Preparation & Cleaning
# Primary outcome: loan_application_rejections
# Primary predictor: risk_evaluator_alpha_score (or beta_score, let's use alpha_score as the continuous 0-1 risk score)
# Covariates: credit_score_index, annual_income_bracket, prior_denied_loans, prior_approved_loans

# Create a combined risk score or use one. The prompt says "continuous risk evaluator score (0-1)".
# Let's use `risk_evaluator_alpha_score` as the predictor.
predictor = "risk_evaluator_alpha_score"
outcome = "loan_application_rejections"

covariates = [
    "credit_score_index",
    "annual_income_bracket",
    "prior_denied_loans",
    "prior_approved_loans",
]

# Subset relevant columns for complete case analysis (listwise deletion)
model_vars = [outcome, predictor] + covariates
df_clean = df[model_vars].dropna().copy()

# Ensure outcome is binary/count. Rejections max is 2, but let's check. 
# We can use Poisson/Negative Binomial or Logistic regression. Since it's count/binary, 
# let's use a Generalized Linear Model (Poisson or Logistic). Let's use Logistic regression 
# for rejection (>=1 vs 0) or Poisson for the count. The prompt says "rejected significantly more often" 
# and "ratio effect", which points to IRR (Poisson/Negative Binomial) or Odds Ratio (Logistic).
# Let's treat loan_application_rejections as binary (rejection happened or not) via logistic, 
# or count via poisson. Given max is 2, logistic on (loan_application_rejections > 0) or Poisson on the count work.
# Let's use Poisson for rate/ratio effect (IRR), or Logistic for Odds Ratio. 
# "ratio effect of continuous risk evaluator score... loan_application_rejections" -> Poisson / Negative Binomial gives IRR.

df_clean["rejection_binary"] = (df_clean[outcome] > 0).astype(int)

# Let's fit a Poisson GLM or Logistic. Logistic gives odds ratio. Poisson gives IRR. 
# Let's use Poisson regression for IRR.
formula = f"{outcome} ~ {predictor} + credit_score_index + annual_income_bracket + prior_denied_loans + prior_approved_loans"

model = smf.glm(formula=formula, data=df_clean, family=sm.families.Poisson()).fit()

# Extract parameters
effect_coef = model.params[predictor]
effect_se = model.bse[predictor]
p_value = model.pvalues[predictor]
ci = model.conf_int()
ci_lower_log = ci.loc[predictor, 0]
ci_upper_log = ci.loc[predictor, 1]

# Convert to IRR (incidence rate ratio)
irr = np.exp(effect_coef)
ci_lower = np.exp(ci_lower_log)
ci_upper = np.exp(ci_upper_log)

conclusion = "significant_effect" if p_value < 0.05 else "no_significant_effect"

output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(effect_se),
    "p_value": float(p_value),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": predictor,
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "dropped rows with missing values in analysis variables (~14.7% missing mostly due to risk evaluator score)",
}

print(json.dumps(output))