import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
df = pd.read_csv(
    "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_soccer_confirmatory_T0.7_r2/data.csv"
)

# 2. Data preparation
# Average rater1 and rater2 to create a continuous skin tone predictor (0-1)
df["skin_tone"] = df[["rater1", "rater2"]].mean(axis=1)

# Drop rows missing the key predictor or outcome
subset_cols = ["redCards", "skin_tone", "games", "yellowCards"]
df_clean = df.dropna(subset=subset_cols).copy()

# 3. Model Fitting
# Using Poisson regression (or Negative Binomial if overdispersed) for count outcome 'redCards', 
# offsetting by log(games) to account for exposure time, controlling for yellowCards as a proxy for aggressiveness.
# Since observations can be clustered by player or referee, we use robust standard errors (HC1) or GEE.
# Let's use GLM with Poisson family and robust standard errors (cov_type='HC1').

formula = "redCards ~ skin_tone + yellowCards + np.log(games + 1)"

model = smf.glm(
    formula=formula,
    data=df_clean,
    family=sm.families.Poisson()
)
results = model.fit(cov_type="HC1")

# 4. Extract Primary Estimand (skin_tone effect -> Incidence Rate Ratio)
param_name = "skin_tone"
beta = results.params[param_name]
se = results.bse[param_name]
p_val = results.pvalues[param_name]
ci = results.conf_int()
ci_lower = np.exp(ci.loc[param_name, 0])
ci_upper = np.exp(ci.loc[param_name, 1])
irr = np.exp(beta)

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "skin_tone (average of rater1 and rater2)",
    "covariates_included": ["yellowCards", "log(games + 1)"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "Dropped rows with missing skin_tone or redCards",
}

print(json.dumps(output))