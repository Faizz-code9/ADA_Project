import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

# 1. Load data
file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_soccer_confirmatory_T0.0_r3/data.csv'
df = pd.read_csv(file_path)

# 2. Clean and prepare
# Exclude rows where skin tone ratings are missing
df = df.dropna(subset=['rater1', 'rater2'])
# Construct skin tone predictor as the average of the two raters
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2
# Ensure outcome is numeric
df['redCards'] = df['redCards'].astype(int)

# 3. Fit model
# Using Poisson regression for count data (red cards)
# Adjusting for games played (exposure) and league/referee effects
# We use clustered standard errors by referee to account for adjudication patterns
formula = 'redCards ~ skin_tone + games + C(leagueCountry)'
model = smf.glm(formula, data=df, family=sm.families.Poisson(), offset=np.log(df['games'] + 1))
result = model.fit(cov_type='cluster', cov_kwds={'groups': df['refNum']})

# 4. Compute estimand
params = result.params
conf_int = result.conf_int()
p_values = result.pvalues

effect_size = np.exp(params['skin_tone'])
ci_lower = np.exp(conf_int.loc['skin_tone', 0])
ci_upper = np.exp(conf_int.loc['skin_tone', 1])
p_val = p_values['skin_tone']

# 5. Output JSON
output = {
    "effect_size": float(effect_size),
    "effect_type": "irr",
    "standard_error": float(result.bse['skin_tone']),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "poisson",
    "predictor_used": "average of rater1 and rater2",
    "covariates_included": ["games", "leagueCountry"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "rows with missing rater1 or rater2 values"
}

print(json.dumps(output))