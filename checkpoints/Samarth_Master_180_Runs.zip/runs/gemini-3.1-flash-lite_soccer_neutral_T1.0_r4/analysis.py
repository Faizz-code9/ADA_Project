import pandas as pd
import numpy as np
import statsmodels.formula.api as smf
import statsmodels.api as sm
import json

# 1. Load data
df = pd.read_csv('/kaggle/working/outputs/runs/gemini-3.1-flash-lite_soccer_neutral_T1.0_r4/data.csv')

# 2. Clean and prepare data
# Remove missing skin tone data
df_clean = df.dropna(subset=['rater1', 'rater2']).copy()

# Average the rater scores as the skin tone index
df_clean['skin_tone'] = (df_clean['rater1'] + df_clean['rater2']) / 2

# Filter for positive games to use log-offset for Poisson regression
df_clean = df_clean[df_clean['games'] > 0].copy()
df_clean['log_games'] = np.log(df_clean['games'])

# 3. Fit Model
# Correcting imports: use sm.families for the Poisson distribution
# Formula API allows offset usage
model = smf.glm(
    formula='redCards ~ skin_tone + C(leagueCountry)',
    data=df_clean,
    family=sm.families.Poisson(),
    offset=df_clean['log_games']
).fit(cov_type='cluster', cov_kwds={'groups': df_clean['refNum']})

# 4. Compute primary estimand
coef = model.params['skin_tone']
# Using delta method for standard error of the exponentiated coefficient
# SE(exp(beta)) approx exp(beta) * SE(beta)
irr = np.exp(coef)
se_irr = irr * model.bse['skin_tone']
p_val = model.pvalues['skin_tone']

conf_int = model.conf_int().loc['skin_tone']
ci_lower = np.exp(conf_int[0])
ci_upper = np.exp(conf_int[1])

# 5. Output JSON
result = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se_irr),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "poisson",
    "predictor_used": "mean of rater1 and rater2 skin tone ratings",
    "covariates_included": ["leagueCountry"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "rows missing rater1 or rater2 or with zero games were removed"
}

print(json.dumps(result))