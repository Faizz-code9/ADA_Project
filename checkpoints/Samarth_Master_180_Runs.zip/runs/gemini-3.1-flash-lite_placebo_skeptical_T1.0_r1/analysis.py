import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

def analyze_referee_bias():
    # 1. Load data
    file_path = "/kaggle/working/outputs/runs/gemini-3.1-flash-lite_placebo_skeptical_T1.0_r1/data.csv"
    df = pd.read_csv(file_path)

    # 2. Preparation
    # Exclude rows where skin tone data is missing
    df = df.dropna(subset=['rater1', 'rater2'])
    # Construct continuous skin tone variable (average of rater1 and rater2)
    df['skin_tone'] = (df['rater1'] + df['rater2']) / 2
    
    # 3. Model: Poisson regression for count data (redCards)
    # Adjusting for leagueCountry and refNum (clustering)
    # Using Poisson as red cards are rare, non-negative counts.
    formula = "redCards ~ skin_tone + C(leagueCountry)"
    
    # Using Poisson model with GEE to account for clustering within refs
    # refNum is the unique identifier for the referee
    model = smf.gee(formula, "refNum", data=df, family=sm.families.Poisson())
    result = model.fit()

    # 4. Extract Estimates
    params = result.params
    conf_int = result.conf_int()
    bse = result.bse
    
    # Extract effect size for 'skin_tone'
    effect = params['skin_tone']
    se = bse['skin_tone']
    p_val = result.pvalues['skin_tone']
    ci_lower = conf_int.loc['skin_tone', 0]
    ci_upper = conf_int.loc['skin_tone', 1]
    
    # 5. Format Output
    output = {
        "effect_size": float(effect),
        "effect_type": "coefficient",
        "standard_error": float(se),
        "p_value": float(p_val),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
        "model_family": "gee",
        "predictor_used": "average of rater1 and rater2",
        "covariates_included": ["leagueCountry"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "gee",
        "exclusions_applied": "Removed rows where rater1 or rater2 were missing"
    }
    
    print(json.dumps(output))

if __name__ == "__main__":
    analyze_referee_bias()