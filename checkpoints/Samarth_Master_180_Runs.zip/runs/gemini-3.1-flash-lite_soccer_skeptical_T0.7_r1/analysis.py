import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

# 1. Load the data
file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_soccer_skeptical_T0.7_r1/data.csv'
df = pd.read_csv(file_path)

# 2. Prepare data
# Construct skin_tone as average of rater1 and rater2
df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)

# Exclude rows with missing skin tone or outcomes
df = df.dropna(subset=['skin_tone', 'redCards', 'games', 'yellowCards'])

# We model the rate of red cards per game (using Poisson regression)
# Adjusting for exposure (games) using offset
df['log_games'] = np.log(df['games'])

# 3. Fit model
# Poisson regression for count data
model = smf.glm(
    formula='redCards ~ skin_tone + yellowCards + C(leagueCountry)',
    data=df,
    offset=df['log_games'],
    family=sm.families.Poisson()
).fit(cov_type='cluster', cov_kwds={'groups': df['refNum']})

# 4. Extract results
params = model.params
bse = model.bse
pvalues = model.pvalues
conf = model.conf_int()

effect_size = np.exp(params['skin_tone'])
se_log = bse['skin_tone']
# Delta method for SE of IRR (exponentiated coefficient)
se_irr = se_log * effect_size
ci_lower = np.exp(conf.loc['skin_tone', 0])
ci_upper = np.exp(conf.loc['skin_tone', 1])

# 5. Output JSON
result = {
    "effect_size": float(effect_size),
    "effect_type": "irr",
    "standard_error": float(se_irr),
    "p_value": float(pvalues['skin_tone']),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if pvalues['skin_tone'] < 0.05 else "no_significant_effect",
    "model_family": "poisson",
    "predictor_used": "mean of rater1 and rater2",
    "covariates_included": ["yellowCards", "leagueCountry"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "rows with missing rater scores or card counts"
}

print(json.dumps(result))