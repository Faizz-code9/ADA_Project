import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

# 1. Load data
file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_soccer_confirmatory_T0.0_r2/data.csv'
df = pd.read_csv(file_path)

# 2. Clean and prepare
# Exclude rows where skin tone ratings are missing
df = df.dropna(subset=['rater1', 'rater2', 'position'])
# Construct skin tone variable
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2
# Log exposure for Poisson offset
df['log_games'] = np.log(df['games'])

# 3. Fit model
# Using GLM with Poisson family. 
# Note: statsmodels GLM does not support 'cluster' cov_type directly in the fit method.
# We use GEE (Generalized Estimating Equations) which is the standard for clustered count data.
model = smf.gee(
    formula='redCards ~ skin_tone + C(position) + C(leagueCountry)',
    data=df,
    groups=df['playerShort'],
    offset=df['log_games'],
    family=sm.families.Poisson(),
    cov_struct=sm.cov_struct.Exchangeable()
).fit()

# 4. Compute estimand
# GEE coefficients are log-rate ratios
params = model.params
conf = model.conf_int()
p_values = model.pvalues

effect_size = np.exp(params['skin_tone'])
se = model.bse['skin_tone']
ci_lower = np.exp(conf.loc['skin_tone', 0])
ci_upper = np.exp(conf.loc['skin_tone', 1])
p_val = p_values['skin_tone']

# 5. Output JSON
result = {
    "effect_size": float(effect_size),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "gee",
    "predictor_used": "mean of rater1 and rater2",
    "covariates_included": ["position", "leagueCountry"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "gee",
    "exclusions_applied": "rows with missing rater1, rater2, or position"
}

print(json.dumps(result))