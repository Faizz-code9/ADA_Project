import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_synthetic_skeptical_T1.0_r2/data.csv"
df = pd.read_csv(file_path)

# 2. Clean and prepare data
# Missing data strategy: listwise deletion for skin_tone
df_clean = df.dropna(subset=['skin_tone']).copy()

# Since outcome is redCards (count) and exposure varies (games), 
# a Poisson regression with offset log(games) is appropriate for rate/ratio effect.
df_clean['log_games'] = np.log(df_clean['games'])

# 3. Fit statistical model (Poisson regression with robust standard errors or GEE for clustering)
# Let's use Poisson GLM with robust standard errors clustered by refereeID or playerID if needed, 
# or standard Poisson. Let's use GEE with groups=refereeID or just robust standard errors (HC1).
# Given multiple players and referees, let's cluster by refereeID.
model = smf.gee(
    "redCards ~ skin_tone + yellowCards + height + weight + C(position) + C(leagueCountry)",
    groups="refereeID",
    data=df_clean,
    family=sm.families.Poisson(link=sm.families.links.Log()),
    time=None
)
result = model.fit()

# 4. Extract primary estimand (skin_tone)
# Effect type: irr (Incidence Rate Ratio) because it's a Poisson model with log link.
param_name = 'skin_tone'
coef = result.params[param_name]
se = result.bse[param_name]
p_val = result.pvalues[param_name]
ci = result.conf_int()
ci_lower_log = ci.loc[param_name, 0]
ci_upper_log = ci.loc[param_name, 1]

irr = np.exp(coef)
ci_lower = np.exp(ci_lower_log)
ci_upper = np.exp(ci_upper_log)

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "gee",
    "predictor_used": "skin_tone",
    "covariates_included": ["yellowCards", "height", "weight", "position", "leagueCountry"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "gee",
    "exclusions_applied": "dropped rows with missing skin_tone (288 rows)"
}

print(json.dumps(output))