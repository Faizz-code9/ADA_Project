import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

# 1. Load data
file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_soccer_neutral_T0.0_r1/data.csv'
df = pd.read_csv(file_path)

# 2. Clean and prepare
# Drop rows where skin tone ratings are missing
df = df.dropna(subset=['rater1', 'rater2'])
# Create skin tone variable as average of two raters
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2
# Ensure outcome is binary for logistic regression (redCards can be > 1, but usually treated as binary event)
df['red_card_binary'] = (df['redCards'] > 0).astype(int)

# 3. Fit model
# Using logistic regression with clustering by referee (refNum)
# Covariates: games, yellowCards (to control for disciplinary history/exposure)
model = smf.logit(
    "red_card_binary ~ skin_tone + games + yellowCards", 
    data=df
).fit(cov_type='cluster', cov_kwds={'groups': df['refNum']}, disp=0)

# 4. Compute estimand
params = model.params
conf = model.conf_int()
p_values = model.pvalues

effect_size = np.exp(params['skin_tone'])
ci_lower = np.exp(conf.loc['skin_tone', 0])
ci_upper = np.exp(conf.loc['skin_tone', 1])
se = model.bse['skin_tone']
p_val = p_values['skin_tone']

# 5. Output JSON
result = {
    "effect_size": float(effect_size),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "logistic",
    "predictor_used": "average of rater1 and rater2",
    "covariates_included": ["games", "yellowCards"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "rows with missing rater1 or rater2 values"
}

print(json.dumps(result))