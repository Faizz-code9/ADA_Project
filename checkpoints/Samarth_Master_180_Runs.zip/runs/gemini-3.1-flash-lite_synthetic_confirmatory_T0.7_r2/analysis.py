import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

def analyze_bias():
    # 1. Load data
    file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_synthetic_confirmatory_T0.7_r2/data.csv'
    df = pd.read_csv(file_path)

    # 2. Data Cleaning
    # Drop rows where skin_tone is missing (listwise deletion)
    df_clean = df.dropna(subset=['skin_tone']).copy()
    
    # 3. Fit Model
    # Since the outcome 'redCards' is count data with relatively low mean, 
    # we use Poisson regression. To account for varying exposure (games), 
    # we use an offset term log(games).
    # We use GEE to account for clustering at the referee level.
    fam = sm.families.Poisson()
    ind = sm.cov_struct.Exchangeable()
    
    formula = "redCards ~ skin_tone + height + weight + yellowCards + C(position) + C(leagueCountry)"
    
    # Add offset
    df_clean['log_games'] = np.log(df_clean['games'])
    
    model = smf.gee(formula, "refereeID", df_clean, family=fam, cov_struct=ind, offset=df_clean['log_games'])
    result = model.fit()

    # 4. Extract Estimand (IRR)
    params = result.params
    bse = result.bse
    
    coef = params['skin_tone']
    se = bse['skin_tone']
    irr = np.exp(coef)
    
    # Standard Error of IRR using Delta Method: se(exp(b)) = exp(b) * se(b)
    irr_se = irr * se
    
    # Confidence Interval for IRR
    ci_lower = np.exp(coef - 1.96 * se)
    ci_upper = np.exp(coef + 1.96 * se)
    
    # P-value
    p_val = result.pvalues['skin_tone']
    
    # 5. Output JSON
    output = {
        "effect_size": float(irr),
        "effect_type": "irr",
        "standard_error": float(irr_se),
        "p_value": float(p_val),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
        "model_family": "gee",
        "predictor_used": "skin_tone",
        "covariates_included": ["height", "weight", "yellowCards", "position", "leagueCountry"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "gee",
        "exclusions_applied": "rows with missing skin_tone dropped"
    }
    
    print(json.dumps(output))

if __name__ == "__main__":
    analyze_bias()