import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

def analyze_referee_bias():
    # 1. Load data
    file_path = "/kaggle/working/outputs/runs/gemini-3.1-flash-lite_soccer_skeptical_T1.0_r3/data.csv"
    df = pd.read_csv(file_path)

    # 2. Preparation
    # Drop rows without rater values (the target predictor)
    df = df.dropna(subset=['rater1', 'rater2'])
    
    # Create skinTone as the average of rater1 and rater2
    df['skinTone'] = (df['rater1'] + df['rater2']) / 2
    
    # Missing data: drop other minor missing values (height, weight, etc.)
    df = df.dropna(subset=['games', 'redCards', 'skinTone'])
    
    # 3. Model
    # Since redCards is a count variable that is sparse, Poisson is appropriate.
    # To account for varying playing time, use 'games' as an offset.
    df['log_games'] = np.log(df['games'])
    
    # Using statsmodels Poisson for the model
    # Model: redCards ~ skinTone + leagueCountry + offset(log_games)
    # We cluster by refNum to account for repeated decisions by the same referee.
    model = smf.gee("redCards ~ skinTone + C(leagueCountry)", 
                    groups=df["refNum"], 
                    data=df, 
                    offset=df["log_games"],
                    family=sm.families.Poisson(),
                    cov_struct=sm.cov_struct.Exchangeable())
    
    result = model.fit()

    # 4. Extract metrics
    # The coefficient represents the log(IRR) for skinTone
    coeff = result.params['skinTone']
    stderr = result.bse['skinTone']
    p_val = result.pvalues['skinTone']
    ci_lower = coeff - 1.96 * stderr
    ci_upper = coeff + 1.96 * stderr
    
    # 5. Output JSON
    output = {
        "effect_size": float(np.exp(coeff)),
        "effect_type": "irr",
        "standard_error": float(stderr),
        "p_value": float(p_val),
        "ci_lower": float(np.exp(ci_lower)),
        "ci_upper": float(np.exp(ci_upper)),
        "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
        "model_family": "gee",
        "predictor_used": "skinTone (mean of rater1, rater2)",
        "covariates_included": ["leagueCountry", "log(games) as offset"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "gee",
        "exclusions_applied": "Removed rows with missing rater values"
    }

    print(json.dumps(output))

if __name__ == "__main__":
    analyze_referee_bias()