import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

# 1. Load data
file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_soccer_confirmatory_T0.7_r4/data.csv'
df = pd.read_csv(file_path)

# 2. Prepare data
# Exclude rows where skin tone is missing
df = df.dropna(subset=['rater1', 'rater2'])
# Create aggregate skin tone (0-1)
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2
# Add a small constant to games to handle potential exposure offsets or use as control
# Using Poisson regression given the nature of redCards (count data)
# We cluster by refNum to account for referee-specific bias tendencies

# 3. Fit model
# We use Poisson regression as redCards is a count variable.
# We include games as an offset or covariate; typically in this literature, 
# 'games' acts as an exposure.
model = smf.glm(
    formula='redCards ~ skin_tone + games + C(leagueCountry)',
    data=df,
    family=sm.families.Poisson(),
    groups=df['refNum']
).fit(cov_type='cluster', cov_kwds={'groups': df['refNum']})

# 4. Extract results
params = model.params
conf_int = model.conf_int()

effect_size = np.exp(params['skin_tone'])
ci_lower = np.exp(conf_int.loc['skin_tone', 0])
ci_upper = np.exp(conf_int.loc['skin_tone', 1])
p_value = model.pvalues['skin_tone']

# 5. Output JSON
results = {
    "effect_size": float(effect_size),
    "effect_type": "irr",
    "standard_error": float(model.bse['skin_tone']),
    "p_value": float(p_value),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if p_value < 0.05 else "no_significant_effect",
    "model_family": "poisson",
    "predictor_used": "mean of rater1 and rater2",
    "covariates_included": ["games", "leagueCountry"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "rows with missing rater1/rater2"
}

print(json.dumps(results))