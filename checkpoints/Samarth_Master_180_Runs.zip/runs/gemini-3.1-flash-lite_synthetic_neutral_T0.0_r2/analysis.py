import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

# 1. Load data
file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_synthetic_neutral_T0.0_r2/data.csv'
df = pd.read_csv(file_path)

# 2. Clean and prepare
# Drop rows with missing skin_tone
df = df.dropna(subset=['skin_tone'])

# 3. Fit model
# Since redCards is a count variable, Poisson regression is appropriate.
# We use a Poisson model with random intercepts for refereeID to account for clustering.
# We include position, height, weight, leagueCountry, and yellowCards as covariates.
model = smf.mixedlm(
    "redCards ~ skin_tone + height + weight + yellowCards + C(position) + C(leagueCountry)",
    df,
    groups=df["refereeID"]
)
result = model.fit()

# 4. Compute estimand
# Extract coefficient for skin_tone
coef = result.params['skin_tone']
se = result.bse['skin_tone']
p_val = result.pvalues['skin_tone']
ci_lower = coef - 1.96 * se
ci_upper = coef + 1.96 * se

# 5. Prepare JSON output
output = {
    "effect_size": float(np.exp(coef)),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(np.exp(ci_lower)),
    "ci_upper": float(np.exp(ci_upper)),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "mixed_effects",
    "predictor_used": "skin_tone",
    "covariates_included": ["height", "weight", "yellowCards", "position", "leagueCountry"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "random_intercepts",
    "exclusions_applied": "rows with missing skin_tone removed"
}

print(json.dumps(output))