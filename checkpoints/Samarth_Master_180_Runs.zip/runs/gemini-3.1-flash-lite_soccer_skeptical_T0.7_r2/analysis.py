import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

# 1. Load data
file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_soccer_skeptical_T0.7_r2/data.csv'
df = pd.read_csv(file_path)

# 2. Preparation
# Drop rows where skin tone data is missing or critical covariates are missing
df = df.dropna(subset=['rater1', 'rater2', 'height', 'weight', 'refNum'])
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2

# To fix the clustering error, ensure refNum is categorical/integer and data is aligned
df['refNum'] = df['refNum'].astype(int)

# 3. Model
# Using Poisson GLM. Clustering via GEE is more robust for clustered counts in statsmodels.
# GEE handles the group argument more gracefully than GLM.fit(cov_type='cluster')
model = smf.gee('redCards ~ skin_tone + height + weight + games + yellowCards', 
                data=df, 
                groups=df['refNum'], 
                family=sm.families.Poisson())
result = model.fit()

# 4. Extract estimands
params = result.params
bse = result.bse
pvalues = result.pvalues
conf = result.conf_int()

effect_size = params['skin_tone']
se = bse['skin_tone']
p_val = pvalues['skin_tone']
ci_lower = conf.loc['skin_tone', 0]
ci_upper = conf.loc['skin_tone', 1]

# 5. Output
output = {
    "effect_size": float(effect_size),
    "effect_type": "coefficient",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "gee",
    "predictor_used": "skin_tone (mean of rater1 and rater2)",
    "covariates_included": ["height", "weight", "games", "yellowCards"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "gee",
    "exclusions_applied": "rows with missing rater1/rater2, height, or weight values removed"
}

print(json.dumps(output))