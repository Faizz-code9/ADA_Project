import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.1-flash-lite_disguise_confirmatory_T1.0_r2/data.csv"
df = pd.read_csv(file_path)

# 2. Prepare data
# Remove missing values for the primary predictor/outcome
df = df.dropna(subset=['risk_evaluator_alpha_score', 'risk_evaluator_beta_score', 'loan_application_rejections'])

# Create continuous risk score as average of available evaluator scores
df['risk_score'] = (df['risk_evaluator_alpha_score'] + df['risk_evaluator_beta_score']) / 2

# Exclusions: None explicitly required beyond dropping rows missing the primary variable
# Using logit model to handle binary loan rejections (0: approved/other, 1: rejected)
# Note: Outcome has values 0, 1, 2. Treating 0 as 'not rejected', 1 & 2 as 'rejected'.
df['is_rejected'] = (df['loan_application_rejections'] > 0).astype(int)

# Covariates to adjust for
covariates = ['credit_score_index', 'annual_income_bracket', 'total_applications_reviewed']
df = df.dropna(subset=covariates)

# 3. Model Fit
# Using Logistic Regression. Clustering by officer ID as per domain structure.
formula = 'is_rejected ~ risk_score + credit_score_index + annual_income_bracket + total_applications_reviewed'
model = smf.logit(formula, data=df)
res = model.fit(disp=0, cov_type='cluster', cov_kwds={'groups': df['loan_officer_id']})

# 4. Extract Estimands
params = res.params['risk_score']
se = res.bse['risk_score']
pval = res.pvalues['risk_score']
conf = res.conf_int().loc['risk_score']

# 5. Output
results = {
    "effect_size": float(np.exp(params)),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(pval),
    "ci_lower": float(np.exp(conf[0])),
    "ci_upper": float(np.exp(conf[1])),
    "conclusion": "significant_effect" if pval < 0.05 else "no_significant_effect",
    "model_family": "logistic",
    "predictor_used": "average of risk_evaluator_alpha_score and risk_evaluator_beta_score",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "dropped rows missing risk evaluator scores or primary covariates"
}

print(json.dumps(results))