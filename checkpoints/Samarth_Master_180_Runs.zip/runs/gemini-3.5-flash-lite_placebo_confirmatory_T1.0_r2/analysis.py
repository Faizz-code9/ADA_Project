import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_placebo_confirmatory_T1.0_r2/data.csv"
df = pd.read_csv(file_path)

# 2. Data Preparation & Variable Construction
df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)

# Missing data strategy: listwise_deletion for required variables
df_clean = df.dropna(subset=['skin_tone', 'redCards', 'games']).copy()

covariates = ['height', 'weight', 'yellowCards', 'goals']
for col in covariates:
    df_clean[col] = df_clean[col].fillna(df_clean[col].mean())

# 3. Fit Statistical Model using GEE with Independence structure (robust SEs clustered by player)
df_clean = df_clean.sort_values('playerShort')

formula = 'redCards ~ skin_tone + height + weight + yellowCards + goals'

model = smf.gee(
    formula,
    data=df_clean,
    groups=df_clean['playerShort'],
    family=sm.families.Poisson(),
    cov_struct=sm.cov_struct.Independence()
)
result = model.fit()

# 4. Extract Primary Estimand (IRR for skin_tone)
beta = result.params['skin_tone']
se = result.bse['skin_tone']
p_val = result.pvalues['skin_tone']
ci = result.conf_int().loc['skin_tone']

effect_size = float(np.exp(beta))
ci_lower = float(np.exp(ci[0]))
ci_upper = float(np.exp(ci[1]))

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
  "effect_size": effect_size,
  "effect_type": "irr",
  "standard_error": float(se),
  "p_value": float(p_val),
  "ci_lower": ci_lower,
  "ci_upper": ci_upper,
  "conclusion": conclusion,
  "model_family": "gee",
  "predictor_used": "skin_tone",
  "covariates_included": covariates,
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "gee",
  "exclusions_applied": "Dropped rows with missing skin_tone or redCards."
}

print(json.dumps(output))