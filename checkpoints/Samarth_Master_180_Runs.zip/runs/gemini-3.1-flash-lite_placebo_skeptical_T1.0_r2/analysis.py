import pandas as pd
import numpy as np
import statsmodels.api as sm
import json
import sys

def run_analysis():
    # 1. Load data
    file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_placebo_skeptical_T1.0_r2/data.csv'
    df = pd.read_csv(file_path)

    # 2. Preparation
    # Drop rows without skin tone data (rater1/rater2)
    df = df.dropna(subset=['rater1', 'rater2'])
    
    # Compute skin_tone (average of two raters)
    df['skin_tone'] = (df['rater1'] + df['rater2']) / 2.0
    
    # Define outcome: presence of red card (dichotomous for logistic)
    # The prompt requests the effect of continuous skin tone on red cards. 
    # Since redCards is count data, Logistic regression is standard for incidence.
    df['red_card_bin'] = (df['redCards'] > 0).astype(int)
    
    # Covariates to control for: league (fixed effect), games (exposure)
    # Using log(games) as an offset to account for differing playtime
    df['log_games'] = np.log(df['games'] + 1)
    
    # 3. Fit Model
    # Using Logit with clustering by refNum
    formula = "red_card_bin ~ skin_tone + log_games + C(leagueCountry)"
    model = sm.Logit.from_formula(formula, data=df)
    results = model.fit(cov_type='cluster', cov_kwds={'groups': df['refNum']}, disp=0)

    # 4. Extract Estimands
    params = results.params
    conf_int = results.conf_int()
    
    effect_val = np.exp(params['skin_tone'])
    se = results.bse['skin_tone']
    p_val = results.pvalues['skin_tone']
    ci_lower = np.exp(conf_int.loc['skin_tone', 0])
    ci_upper = np.exp(conf_int.loc['skin_tone', 1])

    # 5. Output JSON
    output = {
        "effect_size": float(effect_val),
        "effect_type": "odds_ratio",
        "standard_error": float(se),
        "p_value": float(p_val),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
        "model_family": "logistic",
        "predictor_used": "average of rater1 and rater2 skin tone ratings",
        "covariates_included": ["log_games", "leagueCountry"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "clustered_se",
        "exclusions_applied": "rows with missing rater1/rater2 values removed"
    }
    
    print(json.dumps(output))

if __name__ == "__main__":
    run_analysis()