import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

def run_analysis():
    # 1. Load data
    file_path = "/kaggle/working/outputs/runs/gemini-3.1-flash-lite_placebo_skeptical_T0.7_r1/data.csv"
    df = pd.read_csv(file_path)

    # 2. Preparation
    # Drop rows without rater info as per problem description
    df = df.dropna(subset=['rater1', 'rater2'])
    # Construct continuous skin tone variable (average of raters)
    df['skin_tone'] = (df['rater1'] + df['rater2']) / 2
    
    # We use Poisson regression as redCards are count data (0, 1, 2)
    # Adjust for games played to account for exposure
    df['log_games'] = np.log(df['games'].replace(0, 1))
    
    # 3. Model
    # Hypothesis: effect of skin tone on redCards, adjusting for games and basic demographics
    formula = "redCards ~ skin_tone + height + weight + C(leagueCountry)"
    model = smf.glm(formula, data=df, family=sm.families.Poisson(), offset=df['log_games']).fit()
    
    # 4. Extract Estimates
    params = model.params
    conf = model.conf_int()
    
    effect_size = np.exp(params['skin_tone'])
    se = model.bse['skin_tone']
    p_val = model.pvalues['skin_tone']
    ci_lower = np.exp(conf.loc['skin_tone', 0])
    ci_upper = np.exp(conf.loc['skin_tone', 1])
    
    # 5. JSON Output
    result = {
        "effect_size": float(effect_size),
        "effect_type": "irr",
        "standard_error": float(se),
        "p_value": float(p_val),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
        "model_family": "poisson",
        "predictor_used": "average of rater1 and rater2",
        "covariates_included": ["height", "weight", "leagueCountry"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "none",
        "exclusions_applied": "rows with missing rater data removed"
    }
    
    print(json.dumps(result))

if __name__ == "__main__":
    run_analysis()