import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

# 1. Load data
file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_soccer_confirmatory_T0.0_r1/data.csv'
df = pd.read_csv(file_path)

# 2. Clean and prepare
# Drop rows where skin tone ratings are missing
df = df.dropna(subset=['rater1', 'rater2'])
# Construct skin tone variable as the mean of the two raters
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2
# Ensure outcome is binary for logistic regression (redCards > 0)
df['red_card_binary'] = (df['redCards'] > 0).astype(int)

# 3. Fit model
# Using Logistic Regression with clustering by referee (refNum)
# Covariates: games (exposure), meanIAT (implicit bias), position (categorical)
# We use GEE to handle clustering by referee
model = smf.gee(
    "red_card_binary ~ skin_tone + games + meanIAT + C(position)",
    data=df,
    groups=df['refNum'],
    family=sm.families.Binomial(),
    cov_struct=sm.cov_struct.Exchangeable()
)
result = model.fit()

# 4. Extract estimands
params = result.params
conf_int = result.conf_int()
p_values = result.pvalues

# Extract for skin_tone
effect = params['skin_tone']
se = result.bse['skin_tone']
p_val = p_values['skin_tone']
ci_lower = conf_int.loc['skin_tone', 0]
ci_upper = conf_int.loc['skin_tone', 1]

# 5. Prepare JSON output
output = {
    "effect_size": float(np.exp(effect)),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(np.exp(ci_lower)),
    "ci_upper": float(np.exp(ci_upper)),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "gee",
    "predictor_used": "mean of rater1 and rater2 skin tone scores",
    "covariates_included": ["games", "meanIAT", "position"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "gee",
    "exclusions_applied": "rows with missing rater1 or rater2 values"
}

print(json.dumps(output))