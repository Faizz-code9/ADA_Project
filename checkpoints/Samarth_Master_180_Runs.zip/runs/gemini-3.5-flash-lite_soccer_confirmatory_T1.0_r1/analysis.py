import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load dataset
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_soccer_confirmatory_T1.0_r1/data.csv"
df = pd.read_csv(file_path)

# 2. Clean and prepare data
# Construct skin tone predictor as the average of rater1 and rater2
df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)

# Drop rows with missing skin tone or red cards
df = df.dropna(subset=['skin_tone', 'redCards'])

# Missing data strategy: listwise deletion for the variables used in the model
# Include basic covariates like height, weight, yellowCards (as proxy for aggressiveness)
covariates = ['height', 'weight', 'yellowCards']
df_model = df.dropna(subset=['skin_tone', 'redCards'] + covariates).copy()

# 3. Fit statistical model
# Since redCards is a count outcome, a Poisson regression (or Negative Binomial) is appropriate.
# We will use Poisson regression with robust standard errors (GLM with Poisson family).
formula = 'redCards ~ skin_tone + height + weight + yellowCards'
model = smf.glm(formula=formula, data=df_model, family=sm.families.Poisson())
results = model.fit(cov_type='HC1')

# 4. Extract primary estimand (effect of skin_tone)
# The primary estimand is the ratio effect (incidence rate ratio, IRR)
beta = results.params['skin_tone']
se = results.bse['skin_tone']
p_val = results.pvalues['skin_tone']
ci = results.conf_int().loc['skin_tone']

irr = np.exp(beta)
ci_lower = np.exp(ci[0])
ci_upper = np.exp(ci[1])

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
  "effect_size": float(irr),
  "effect_type": "irr",
  "standard_error": float(se),
  "p_value": float(p_val),
  "ci_lower": float(ci_lower),
  "ci_upper": float(ci_upper),
  "conclusion": conclusion,
  "model_family": "poisson",
  "predictor_used": "skin_tone",
  "covariates_included": covariates,
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "none",
  "exclusions_applied": "dropped rows with missing skin_tone or covariates"
}

print(json.dumps(output))