import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

# 1. Load data
file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_synthetic_skeptical_T0.0_r1/data.csv'
df = pd.read_csv(file_path)

# 2. Clean and prepare
# Drop missing skin_tone as it is the primary predictor
df = df.dropna(subset=['skin_tone'])

# 3. Fit model
# Since redCards is a count variable, Poisson regression is appropriate.
# We use Poisson regression with robust standard errors clustered by refereeID 
# to account for potential referee-specific bias patterns.
formula = 'redCards ~ skin_tone + height + weight + C(position) + C(leagueCountry) + yellowCards'
model = smf.poisson(formula, data=df)
results = model.fit(cov_type='cluster', cov_kwds={'groups': df['refereeID']}, disp=False)

# 4. Compute estimand
# Extract IRR (Incidence Rate Ratio)
params = results.params
conf = results.conf_int()

effect_size = np.exp(params['skin_tone'])
se = results.bse['skin_tone'] * effect_size # Delta method for IRR SE
p_val = results.pvalues['skin_tone']
ci_lower = np.exp(conf.loc['skin_tone', 0])
ci_upper = np.exp(conf.loc['skin_tone', 1])

# 5. Output JSON
output = {
    "effect_size": float(effect_size),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "poisson",
    "predictor_used": "skin_tone",
    "covariates_included": ["height", "weight", "position", "leagueCountry", "yellowCards"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "rows with missing skin_tone removed"
}

print(json.dumps(output))