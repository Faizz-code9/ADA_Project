import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

# 1. Load data
file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_placebo_confirmatory_T0.7_r2/data.csv'
df = pd.read_csv(file_path)

# 2. Prepare data
# Construct skin tone predictor
df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)

# Drop missing values for the model variables to ensure indices match
cols_to_use = ['redCards', 'skin_tone', 'height', 'weight', 'games', 'leagueCountry', 'refNum']
df_clean = df.dropna(subset=cols_to_use).copy()

# Ensure refNum is treated as categorical for grouping
# GLM with cluster-robust standard errors requires the group array to be consistent with the model fit
# We use GEE as a robust alternative for clustered count data if GLM cluster fails
model = smf.gee('redCards ~ skin_tone + height + weight + games + C(leagueCountry)', 
                data=df_clean, 
                groups=df_clean['refNum'], 
                family=sm.families.Poisson(),
                cov_struct=sm.cov_struct.Exchangeable()).fit()

# 4. Compute primary estimand
# IRR is the exponentiated coefficient
params = model.params
bse = model.bse
coef = params['skin_tone']
se = bse['skin_tone']
irr = np.exp(coef)

# Wald test for p-value and CI
z_score = coef / se
p_val = 2 * (1 - sm.stats.norm.cdf(abs(z_score)))
ci_lower = np.exp(coef - 1.96 * se)
ci_upper = np.exp(coef + 1.96 * se)

# 5. Output JSON
result = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "gee",
    "predictor_used": "mean of rater1 and rater2",
    "covariates_included": ["height", "weight", "games", "leagueCountry"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "gee",
    "exclusions_applied": "dropped rows with missing skin tone, height, weight, or refNum"
}

print(json.dumps(result))