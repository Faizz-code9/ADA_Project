import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

def analyze_referee_bias():
    # 1. Load data
    file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_soccer_skeptical_T0.7_r5/data.csv'
    df = pd.read_csv(file_path)

    # 2. Preparation
    # Drop rows where skin tone data (rater1/2) is missing
    df = df.dropna(subset=['rater1', 'rater2'])
    # Construct continuous skin tone measure (average of two raters)
    df['skin_tone'] = (df['rater1'] + df['rater2']) / 2
    
    # Exclusions: None explicitly required beyond missing data handling
    # We use a Poisson model for count data (redCards)
    # Adjusting for league and player position as standard controls in this literature
    df['position'] = df['position'].fillna('Unknown')
    
    # 3. Model Fitting
    # Using Poisson regression as redCards is a count variable. 
    # Clustered standard errors by referee (refNum) to account for referee-specific disciplinary patterns.
    model = smf.glm(
        formula='redCards ~ skin_tone + C(leagueCountry) + C(position) + games',
        data=df,
        family=sm.families.Poisson()
    )
    
    # Fit with robust covariance clustered by referee
    result = model.fit(cov_type='cluster', cov_kwds={'groups': df['refNum']})
    
    # 4. Extract Estimates
    params = result.params
    bse = result.bse
    pvals = result.pvalues
    conf_int = result.conf_int()
    
    # Effect size (coefficient for skin_tone)
    effect = params['skin_tone']
    se = bse['skin_tone']
    p_val = pvals['skin_tone']
    ci_lower = conf_int.loc['skin_tone', 0]
    ci_upper = conf_int.loc['skin_tone', 1]
    
    # 5. Output JSON
    output = {
        "effect_size": float(effect),
        "effect_type": "coefficient",
        "standard_error": float(se),
        "p_value": float(p_val),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
        "model_family": "poisson",
        "predictor_used": "mean of rater1 and rater2",
        "covariates_included": ["leagueCountry", "position", "games"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "clustered_se",
        "exclusions_applied": "dropped rows with missing rater1 or rater2 values"
    }
    
    print(json.dumps(output))

if __name__ == "__main__":
    analyze_referee_bias()