import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

# 1. Load the data
file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_disguise_neutral_T0.7_r1/data.csv'
df = pd.read_csv(file_path)

# 2. Clean and prepare data
# Create primary predictor: average of risk scores
df['risk_evaluator_score'] = df[['risk_evaluator_alpha_score', 'risk_evaluator_beta_score']].mean(axis=1)

# Exclusions: Drop rows where risk evaluator score is missing
df_clean = df.dropna(subset=['risk_evaluator_score', 'credit_score_index', 'annual_income_bracket'])

# 3. Model Fitting
# We use a Logistic regression as the outcome is binary (rejections).
# We cluster by loan_officer_id to account for individual officer bias.
formula = 'loan_application_rejections ~ risk_evaluator_score + credit_score_index + annual_income_bracket + prior_approved_loans + prior_denied_loans'
model = smf.gee(formula, 
                groups='loan_officer_id', 
                data=df_clean, 
                family=sm.families.Binomial())
result = model.fit()

# 4. Extract Estimates
params = result.params
bse = result.bse
pvalues = result.pvalues
conf_int = result.conf_int()

effect_size = np.exp(params['risk_evaluator_score'])
ci_lower = np.exp(conf_int.loc['risk_evaluator_score', 0])
ci_upper = np.exp(conf_int.loc['risk_evaluator_score', 1])
se = bse['risk_evaluator_score']
p_val = pvalues['risk_evaluator_score']

# 5. Prepare JSON output
output = {
    "effect_size": float(effect_size),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "gee",
    "predictor_used": "risk_evaluator_score (mean of alpha and beta)",
    "covariates_included": ["credit_score_index", "annual_income_bracket", "prior_approved_loans", "prior_denied_loans"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "gee",
    "exclusions_applied": "dropped rows with missing risk evaluator scores or core financial covariates"
}

print(json.dumps(output))