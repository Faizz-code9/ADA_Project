import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_disguise_confirmatory_T0.0_r1/data.csv"
df = pd.read_csv(file_path)

# 2. Data Preparation & Variable Construction
# Primary Predictor: continuous risk evaluator score (e.g., risk_evaluator_alpha_score)
# Primary Estimand: ratio effect (odds ratio) of continuous risk evaluator score on loan_application_rejections.
# We use logistic regression since loan_application_rejections is count/binary-like (values 0, 1, 2).
# Let's binarize rejections or treat as binary indicator of rejection (0 vs >=1) for standard logistic regression, 
# or use Poisson/Negative Binomial if count. Looking at mean 0.0125, max 2, it's mostly 0 and 1. 
# Let's create a binary rejection indicator:
df['rejection_binary'] = (df['loan_application_rejections'] > 0).astype(int)

# Use risk_evaluator_alpha_score as the predictor
predictor = 'risk_evaluator_alpha_score'

# Covariates to adjust for
covariates = ['credit_score_index', 'annual_income_bracket', 'prior_denied_loans', 'formal_inquiry_notices']

# Subset data for modeling
model_vars = ['rejection_binary', predictor] + covariates
df_model = df[model_vars].dropna()

# 3. Fit Statistical Model (Logistic Regression)
formula = 'rejection_binary ~ risk_evaluator_alpha_score + credit_score_index + annual_income_bracket + prior_denied_loans + formal_inquiry_notices'
model = smf.logit(formula, data=df_model).fit(disp=False)

# 4. Extract Estimates
coef = model.params[predictor]
se = model.bse[predictor]
pval = model.pvalues[predictor]
ci = model.conf_int().loc[predictor]

odds_ratio = np.exp(coef)
ci_lower = np.exp(ci[0])
ci_upper = np.exp(ci[1])

conclusion = "significant_effect" if pval < 0.05 else "no_significant_effect"

output = {
  "effect_size": float(odds_ratio),
  "effect_type": "odds_ratio",
  "standard_error": float(se),
  "p_value": float(pval),
  "ci_lower": float(ci_lower),
  "ci_upper": float(ci_upper),
  "conclusion": conclusion,
  "model_family": "logistic",
  "predictor_used": predictor,
  "covariates_included": covariates,
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "none",
  "exclusions_applied": "Dropped rows with missing values in regression variables (~14.7% due to risk evaluator score missingness)"
}

print(json.dumps(output))