import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

# 1. Load data
file_path = '/kaggle/working/outputs/runs/PILOT_gemini-3.1-flash-lite_synthetic_T0.0_1/data.csv'
df = pd.read_csv(file_path)

# 2. Clean and prepare
# Drop missing skin_tone
df = df.dropna(subset=['skin_tone'])
# Log-transform games to use as an exposure variable (offset) in a GLM framework
# Since MixedLM doesn't support offset, we use Poisson GEE which handles clustering and offsets
df['log_games'] = np.log(df['games'])

# 3. Fit model
# Using Poisson GEE to handle count data, clustering by referee, and exposure offset
fam = sm.families.Poisson()
ind = sm.cov_struct.Exchangeable()
model = smf.gee(
    "redCards ~ skin_tone + position + height + weight + leagueCountry + yellowCards",
    "refereeID",
    df,
    family=fam,
    cov_struct=ind,
    exposure=df['games']
)
result = model.fit()

# 4. Compute estimand
coef = result.params['skin_tone']
se = result.bse['skin_tone']
p_val = result.pvalues['skin_tone']
ci_lower = coef - 1.96 * se
ci_upper = coef + 1.96 * se

# 5. Output JSON
output = {
    "effect_size": float(np.exp(coef)),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(np.exp(ci_lower)),
    "ci_upper": float(np.exp(ci_upper)),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "gee",
    "predictor_used": "skin_tone",
    "covariates_included": ["position", "height", "weight", "leagueCountry", "yellowCards"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "gee",
    "exclusions_applied": "rows with missing skin_tone removed"
}

print(json.dumps(output))