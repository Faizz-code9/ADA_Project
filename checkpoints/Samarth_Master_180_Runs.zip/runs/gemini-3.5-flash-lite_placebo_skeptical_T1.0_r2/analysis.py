import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_placebo_skeptical_T1.0_r2/data.csv"
df = pd.read_csv(file_path)

# 2. Data preparation
# Construct continuous skin tone predictor as the average of rater1 and rater2
df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)

# Filter out rows missing the key variables
# Missing data strategy: listwise deletion for the variables used in the model
model_vars = ['redCards', 'skin_tone', 'games', 'yellowCards', 'meanIAT']
df_clean = df.dropna(subset=model_vars).copy()

# Exclusions applied description
exclusions = "Listwise deletion of rows with missing skin_tone, redCards, games, yellowCards, or meanIAT"

# 3. Fit statistical model
# Poisson regression for count outcome (redCards), offset by log(games) to account for exposure
formula = 'redCards ~ skin_tone + yellowCards + meanIAT + np.log(games)'
model = smf.poisson(formula, data=df_clean).fit(disp=False)

# 4. Compute primary estimand (incidence rate ratio for skin_tone)
effect_size = np.exp(model.params['skin_tone'])
conf = model.conf_int()
ci_lower = np.exp(conf.loc['skin_tone', 0])
ci_upper = np.exp(conf.loc['skin_tone', 1])
std_err = model.bse['skin_tone'] * effect_size  # Delta method for IRR SE roughly, or use coefficient SE for log scale.
# Actually, standard error on IRR scale via delta method: SE(IRR) = IRR * SE(coef)
p_value = model.pvalues['skin_tone']

conclusion = "significant_effect" if p_value < 0.05 else "no_significant_effect"

# 5. Output JSON
output = {
  "effect_size": float(effect_size),
  "effect_type": "irr",
  "standard_error": float(std_err),
  "p_value": float(p_value),
  "ci_lower": float(ci_lower),
  "ci_upper": float(ci_upper),
  "conclusion": conclusion,
  "model_family": "poisson",
  "predictor_used": "skin_tone",
  "covariates_included": ["yellowCards", "meanIAT", "games"],
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "none",
  "exclusions_applied": exclusions
}

print(json.dumps(output))