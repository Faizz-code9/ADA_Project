import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

# 1. Load data
file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_placebo_skeptical_T0.0_r2/data.csv'
df = pd.read_csv(file_path)

# 2. Clean and prepare
# Drop rows where skin tone ratings are missing
df = df.dropna(subset=['rater1', 'rater2'])
# Construct skin tone variable as the mean of the two raters
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2
# Ensure outcome is numeric
df['redCards'] = df['redCards'].astype(float)

# 3. Fit model
# Using Poisson regression as redCards is a count variable (often 0, 1, 2)
# Adjusting for games played as an exposure variable (log(games))
# Clustering by referee (refNum) to account for individual referee tendencies
df['log_games'] = np.log(df['games'])
model = smf.gee("redCards ~ skin_tone + log_games", 
                groups=df['refNum'], 
                data=df, 
                family=sm.families.Poisson(),
                cov_struct=sm.cov_struct.Exchangeable())
result = model.fit()

# 4. Compute estimand
# Extract coefficient for skin_tone
coef = result.params['skin_tone']
se = result.bse['skin_tone']
p_val = result.pvalues['skin_tone']
ci_lower = coef - 1.96 * se
ci_upper = coef + 1.96 * se

# 5. Print JSON
output = {
    "effect_size": float(np.exp(coef)),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(np.exp(ci_lower)),
    "ci_upper": float(np.exp(ci_upper)),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "gee",
    "predictor_used": "mean of rater1 and rater2",
    "covariates_included": ["log_games"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "gee",
    "exclusions_applied": "rows with missing rater1 or rater2 values"
}

print(json.dumps(output))