import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.1-flash-lite_soccer_skeptical_T1.0_r5/data.csv"
df = pd.read_csv(file_path)

# 2. Clean and Prepare
# Exclude rows where skin tone data is missing
df = df.dropna(subset=['rater1', 'rater2'])
# Create primary predictor: average of rater1 and rater2
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2
# Drop rows with missing position for formula stability
df = df.dropna(subset=['position'])

# 3. Fit Model
# Using GEE for clustered data (referees). Poisson family for red card counts.
# Predictor is continuous skin tone. 
formula = "redCards ~ skin_tone + C(leagueCountry) + C(position) + games"
model = smf.gee(formula, 
                groups=df['refNum'], 
                data=df, 
                cov_struct=sm.cov_struct.Exchangeable(),
                family=sm.families.Poisson())
result = model.fit()

# 4. Extract Metrics
# In statsmodels GEE, standard errors are accessed via .std_err (as a series)
effect_size = result.params['skin_tone']
std_err = result.std_err['skin_tone']
p_val = result.pvalues['skin_tone']
conf = result.conf_int()
ci_lower = conf.loc['skin_tone', 0]
ci_upper = conf.loc['skin_tone', 1]

# 5. Output JSON
output = {
    "effect_size": float(effect_size),
    "effect_type": "coefficient",
    "standard_error": float(std_err),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "gee",
    "predictor_used": "average of rater1 and rater2",
    "covariates_included": ["leagueCountry", "position", "games"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "gee",
    "exclusions_applied": "rows with missing rater1, rater2, or position values"
}

print(json.dumps(output))