import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_soccer_confirmatory_T0.0_r2/data.csv"
df = pd.read_csv(file_path)

# 2. Prepare data
# Construct skin tone predictor as the average of rater1 and rater2
df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)

# Drop rows with missing values in key variables
cols_to_check = ['skin_tone', 'redCards', 'games', 'yellowCards', 'meanIAT']
df_clean = df.dropna(subset=cols_to_check).copy()

# Exclusions tracked
exclusions_applied = f"listwise deletion of {len(df) - len(df_clean)} rows due to missing values in skin_tone or outcome/covariates"

# 3. Model fitting
# We use Poisson regression for count data (redCards) with exposure (log games)
# Including basic covariates: yellowCards, meanIAT, height, weight
formula = "redCards ~ skin_tone + yellowCards + meanIAT + height + weight + np.log(games)"

# Fit Poisson regression
model = smf.poisson(formula=formula, data=df_clean).fit(disp=False)

# 4. Extract primary estimand (skin_tone effect)
effect_size = np.exp(model.params['skin_tone'])  # IRR
std_err = model.bse['skin_tone']
p_val = model.pvalues['skin_tone']
ci = model.conf_int().loc['skin_tone']
ci_lower = np.exp(ci[0])
ci_upper = np.exp(ci[1])

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
    "effect_size": float(effect_size),
    "effect_type": "irr",
    "standard_error": float(std_err),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "skin_tone",
    "covariates_included": ["yellowCards", "meanIAT", "height", "weight", "games"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": exclusions_applied
}

print(json.dumps(output))