import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_soccer_neutral_T0.0_r3/data.csv"
df = pd.read_csv(file_path)

# 2. Prepare data
# Construct skin tone as average of rater1 and rater2
df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)

# Listwise deletion for regression variables
cols_to_use = ['redCards', 'skin_tone', 'games', 'yellowCards', 'meanIAT']
df_clean = df.dropna(subset=cols_to_use).copy()

# 3. Fit statistical model (Poisson regression with exposure/games offset, or standard OLS/Poisson)
# Since redCards is a count, and games acts as exposure, Poisson regression (or negative binomial) is appropriate.
# Let's use Poisson via GLM with log(games) as offset.
df_clean['log_games'] = np.log(df_clean['games'])

formula = 'redCards ~ skin_tone + yellowCards + meanIAT'
model = smf.glm(
    formula=formula, 
    data=df_clean, 
    offset=df_clean['log_games'],
    family=sm.families.Poisson()
)
results = model.fit()

# 4. Extract primary estimand (skin_tone effect)
# Effect type: IRR (incidence rate ratio) since it's Poisson
coef = results.params['skin_tone']
se = results.bse['skin_tone']
p_val = results.pvalues['skin_tone']
conf_int = results.conf_int().loc['skin_tone']

irr = np.exp(coef)
ci_lower = np.exp(conf_int[0])
ci_upper = np.exp(conf_int[1])

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
  "effect_size": float(irr),
  "effect_type": "irr",
  "standard_error": float(se),
  "p_value": float(p_val),
  "ci_lower": float(ci_lower),
  "ci_upper": float(ci_upper),
  "conclusion": conclusion,
  "model_family": "poisson",
  "predictor_used": "skin_tone",
  "covariates_included": ["yellowCards", "meanIAT"],
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "none",
  "exclusions_applied": "dropped rows with missing skin_tone, games, redCards, yellowCards, or meanIAT"
}

print(json.dumps(output))