import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

# 1. Load data
file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_placebo_neutral_T0.0_r2/data.csv'
df = pd.read_csv(file_path)

# 2. Clean and prepare
# Drop rows where skin tone ratings are missing
df = df.dropna(subset=['rater1', 'rater2', 'refNum'])
# Construct skin tone variable
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2
# Ensure refNum is categorical for clustering
df['refNum'] = df['refNum'].astype(int)

# 3. Fit model
# GLM with Poisson family. Using GEE for robust clustering as it handles 
# the grouping structure more reliably than GLM cluster kwds in some versions.
model = smf.gee(
    formula='redCards ~ skin_tone + C(position) + C(leagueCountry) + games',
    data=df,
    groups=df['refNum'],
    family=sm.families.Poisson(),
    cov_struct=sm.cov_struct.Exchangeable()
).fit()

# 4. Compute estimand
# Extract results for skin_tone
params = model.params
se = model.bse
p_values = model.pvalues
conf = model.conf_int()

effect_size = np.exp(params['skin_tone'])
# Delta method for SE of exponentiated coefficient
se_log = se['skin_tone']
se_irr = se_log * effect_size
ci_lower = np.exp(params['skin_tone'] - 1.96 * se_log)
ci_upper = np.exp(params['skin_tone'] + 1.96 * se_log)
p_val = p_values['skin_tone']

# 5. Output JSON
result = {
    "effect_size": float(effect_size),
    "effect_type": "irr",
    "standard_error": float(se_irr),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "gee",
    "predictor_used": "average of rater1 and rater2",
    "covariates_included": ["position", "leagueCountry", "games"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "gee",
    "exclusions_applied": "rows with missing rater1, rater2, or refNum"
}

print(json.dumps(result))