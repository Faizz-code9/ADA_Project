import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_soccer_skeptical_T0.7_r1/data.csv"
df = pd.read_csv(file_path)

# 2. Data preparation
# Average the two raters to get a continuous skin tone score (0-1)
df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)

# Drop rows missing key variables
subset_cols = ['redCards', 'skin_tone', 'games', 'yellowCards', 'height', 'weight']
df_clean = df.dropna(subset=subset_cols).copy()

# Listwise deletion strategy used for missing values in subset
missing_data_strategy = "listwise_deletion"
exclusions_applied = "Dropped rows with missing skin_tone, redCards, height, weight, or games."

# 3. Model Fitting
# Poisson regression for count outcome (redCards), offsetting by log(games) to account for exposure.
# Adjusting for yellowCards, height, weight as basic covariates.
formula = "redCards ~ skin_tone + yellowCards + height + weight + np.log(games)"

model = smf.poisson(formula, data=df_clean)
result = model.fit(disp=False)

# 4. Extract Estimates
effect_size = float(result.params['skin_tone'])
std_err = float(result.bse['skin_tone'])
p_val = float(result.pvalues['skin_tone'])
ci = result.conf_int().loc['skin_tone']
ci_lower = float(ci[0])
ci_upper = float(ci[1])

# Determine significance at alpha = 0.05
conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
    "effect_size": float(np.exp(effect_size)),  # IRR (incidence rate ratio)
    "effect_type": "irr",
    "standard_error": std_err,
    "p_value": p_val,
    "ci_lower": float(np.exp(ci_lower)),
    "ci_upper": float(np.exp(ci_upper)),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "skin_tone",
    "covariates_included": ["yellowCards", "height", "weight", "games"],
    "missing_data_strategy": missing_data_strategy,
    "clustering_strategy": "none",
    "exclusions_applied": exclusions_applied
}

print(json.dumps(output))