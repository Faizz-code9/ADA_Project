import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
df = pd.read_csv('/kaggle/working/outputs/runs/gemini-3.5-flash-lite_soccer_skeptical_T0.7_r4/data.csv')

# 2. Clean and prepare data
# Construct skin tone as average of rater1 and rater2
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2.0

# Drop rows missing essential variables
subset_cols = ['redCards', 'skin_tone', 'games', 'yellowCards', 'leagueCountry']
df_clean = df.dropna(subset=subset_cols).copy()

# 3. Fit statistical model (Poisson / Negative Binomial for count outcome redCards)
# Exposure: games played (using log(games) as offset)
df_clean['log_games'] = np.log(df_clean['games'])

formula = 'redCards ~ skin_tone + yellowCards + C(leagueCountry)'
model = smf.poisson(formula, data=df_clean, offset=df_clean['log_games'])
results = model.fit(disp=False)

# 4. Extract primary estimand (skin_tone effect)
param_name = 'skin_tone'
effect_size = float(np.exp(results.params[param_name]))
std_err = float(results.bse[param_name])
p_value = float(results.pvalues[param_name])
ci_lower = float(np.exp(results.conf_int().loc[param_name][0]))
ci_upper = float(np.exp(results.conf_int().loc[param_name][1]))

conclusion = 'significant_effect' if p_value < 0.05 else 'no_significant_effect'

output = {
  "effect_size": effect_size,
  "effect_type": "irr",
  "standard_error": std_err,
  "p_value": p_value,
  "ci_lower": ci_lower,
  "ci_upper": ci_upper,
  "conclusion": conclusion,
  "model_family": "poisson",
  "predictor_used": "skin_tone",
  "covariates_included": ["yellowCards", "leagueCountry", "log_games (offset)"],
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "none",
  "exclusions_applied": "Dropped rows with missing skin_tone, redCards, games, yellowCards, or leagueCountry."
}

print(json.dumps(output))