import pandas as pd
import numpy as np
import statsmodels.formula.api as smf
import statsmodels.api as sm
import json

# 1. Load the data
file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_disguise_neutral_T1.0_r2/data.csv'
df = pd.read_csv(file_path)

# 2. Clean and Prepare
# Primary Predictor: Combined risk score. Average of alpha and beta.
df['combined_risk_score'] = (df['risk_evaluator_alpha_score'] + df['risk_evaluator_beta_score']) / 2

# Exclusions: Rows with missing predictors or covariates
df_clean = df.dropna(subset=['combined_risk_score', 'credit_score_index', 'annual_income_bracket', 'loan_officer_id'])

# 3. Fit the model using GEE (Corrected import for families)
# statsmodels.genmod.families.family.Binomial is the standard way to call it
from statsmodels.genmod.families import Binomial
from statsmodels.genmod.cov_struct import Independence

formula = 'loan_application_rejections ~ combined_risk_score + credit_score_index + annual_income_bracket + prior_approved_loans + prior_denied_loans'

# GEE allows for clustered standard errors
model = smf.gee(formula, 
                data=df_clean, 
                groups=df_clean['loan_officer_id'], 
                family=Binomial(),
                cov_struct=Independence())
result = model.fit()

# 4. Extract results
coeff = result.params['combined_risk_score']
std_err = result.bse['combined_risk_score']
p_val = result.pvalues['combined_risk_score']
ci = result.conf_int().loc['combined_risk_score']

# 5. Output JSON
output = {
    "effect_size": float(np.exp(coeff)),  # Odds Ratio
    "effect_type": "odds_ratio",
    "standard_error": float(std_err),
    "p_value": float(p_val),
    "ci_lower": float(np.exp(ci[0])),
    "ci_upper": float(np.exp(ci[1])),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "gee",
    "predictor_used": "combined_risk_score (avg of alpha and beta scores)",
    "covariates_included": ["credit_score_index", "annual_income_bracket", "prior_approved_loans", "prior_denied_loans"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "gee",
    "exclusions_applied": "Removed rows with missing risk_evaluator_alpha/beta_score, credit_score_index, or annual_income_bracket"
}

print(json.dumps(output))