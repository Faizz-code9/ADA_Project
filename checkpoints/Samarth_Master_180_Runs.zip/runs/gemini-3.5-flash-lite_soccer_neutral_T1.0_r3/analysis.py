import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

# 1. Load dataset
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_soccer_neutral_T1.0_r3/data.csv"
df = pd.read_csv(file_path)

# 2. Data preparation
df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)
subset_cols = ['redCards', 'skin_tone', 'games', 'yellowCards']
df_clean = df.dropna(subset=subset_cols).copy()

df_clean['log_games'] = np.log(df_clean['games'])

# 3. Fit statistical model using statsmodels GLM directly to avoid patsy offset parsing issues
X = df_clean[['skin_tone', 'yellowCards']]
X = sm.add_constant(X)
y = df_clean['redCards']
exposure = df_clean['log_games']

model = sm.GLM(y, X, family=sm.families.Poisson(), offset=exposure)
results = model.fit()

# 4. Extract primary estimand (incidence rate ratio for skin_tone)
effect_size = np.exp(results.params['skin_tone'])
se_log = results.bse['skin_tone']
standard_error = effect_size * se_log
p_value = results.pvalues['skin_tone']

ci_log = results.conf_int().loc['skin_tone']
ci_lower = np.exp(ci_log[0])
ci_upper = np.exp(ci_log[1])

conclusion = 'significant_effect' if p_value < 0.05 else 'no_significant_effect'

output = {
  "effect_size": float(effect_size),
  "effect_type": "irr",
  "standard_error": float(standard_error),
  "p_value": float(p_value),
  "ci_lower": float(ci_lower),
  "ci_upper": float(ci_upper),
  "conclusion": conclusion,
  "model_family": "poisson",
  "predictor_used": "skin_tone",
  "covariates_included": ["yellowCards"],
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "none",
  "exclusions_applied": "Dropped rows with missing skin_tone, redCards, games, or yellowCards."
}

print(json.dumps(output))