import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load dataset
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_soccer_neutral_T0.7_r5/data.csv"
df = pd.read_csv(file_path)

# 2. Data preparation
# Average the two raters for skin tone
df["skin_tone"] = (df["rater1"] + df["rater2"]) / 2.0

# Drop missing values for key variables to perform listwise deletion
cols_to_check = ["redCards", "skin_tone", "meanIAT", "games", "yellowCards"]
df_clean = df.dropna(subset=cols_to_check).copy()

# Exclusions applied tracking
exclusions_applied = f"Dropped {len(df) - len(df_clean)} rows due to missing values in key variables."

# 3. Fit statistical model (Poisson regression using statsmodels GLM to properly handle exposure/offset)
df_clean["log_games"] = np.log(df_clean["games"].replace(0, 1))

formula = "redCards ~ skin_tone + meanIAT + yellowCards"

# Fit via GLM with Poisson family and log link, passing exposure/offset correctly
model = smf.glm(
    formula=formula,
    data=df_clean,
    family=sm.families.Poisson(link=sm.families.links.Log()),
    exposure=df_clean["games"]
)

# Fit with robust standard errors clustered by referee (refNum)
result = model.fit(cov_type="cluster", cov_kwds={"groups": df_clean["refNum"]})

# 4. Extract primary estimand (skin_tone effect)
coef = result.params["skin_tone"]
se = result.bse["skin_tone"]
p_val = result.pvalues["skin_tone"]
ci = result.conf_int().loc["skin_tone"]

irr = np.exp(coef)
ci_lower = np.exp(ci[0])
ci_upper = np.exp(ci[1])

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

# 5. Output JSON format
output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "skin_tone",
    "covariates_included": ["meanIAT", "yellowCards", "games"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": exclusions_applied,
}

print(json.dumps(output))