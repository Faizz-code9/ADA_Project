import json
import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_synthetic_neutral_T0.7_r1/data.csv"
df = pd.read_csv(file_path)

# 2. Cleaning and preparation
# Missing data strategy: listwise deletion for skin_tone
initial_len = len(df)
df = df.dropna(subset=['skin_tone', 'redCards', 'games', 'yellowCards'])
exclusions_applied = f"Dropped {initial_len - len(df)} rows due to missing skin_tone" if initial_len > len(df) else "none"

# Exposure term: log(games) to account for varying exposure time per player
df['log_games'] = np.log(df['games'])

# 3. Fit Poisson regression model (Ratio effect -> Incidence Rate Ratio)
# Adjusting for yellowCards, height, weight, position, leagueCountry as common confounders
formula = 'redCards ~ skin_tone + yellowCards + height + weight + C(position) + C(leagueCountry)'
model = smf.poisson(formula=formula, data=df, offset=df['log_games']).fit(disp=False)

# 4. Extract primary estimand (skin_tone coefficient -> IRR)
coef = model.params['skin_tone']
se = model.bse['skin_tone']
p_val = model.pvalues['skin_tone']
ci_lower_log, ci_upper_log = model.conf_int().loc['skin_tone']

effect_size = float(np.exp(coef))
ci_lower = float(np.exp(ci_lower_log))
ci_upper = float(np.exp(ci_upper_log))

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
  "effect_size": effect_size,
  "effect_type": "irr",
  "standard_error": float(se),
  "p_value": float(p_val),
  "ci_lower": ci_lower,
  "ci_upper": ci_upper,
  "conclusion": conclusion,
  "model_family": "poisson",
  "predictor_used": "skin_tone",
  "covariates_included": ["yellowCards", "height", "weight", "position", "leagueCountry", "log_games (offset)"],
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "none",
  "exclusions_applied": exclusions_applied
}

print(json.dumps(output))