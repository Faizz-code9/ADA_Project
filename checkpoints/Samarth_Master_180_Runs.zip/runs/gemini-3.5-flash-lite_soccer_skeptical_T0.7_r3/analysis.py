import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load dataset
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_soccer_skeptical_T0.7_r3/data.csv"
df = pd.read_csv(file_path)

# 2. Prepare data
# Construct skin tone predictor as the average of rater1 and rater2
df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)

# Drop rows with missing values in key variables
sub_df = df[['redCards', 'skin_tone', 'games']].dropna(subset=['redCards', 'skin_tone', 'games']).copy()

# Exclusions applied tracking
exclusions = f"Dropped {len(df) - len(sub_df)} rows due to missing values in skin_tone or outcome."

# Offset for exposure (games played)
sub_df['log_games'] = np.log(sub_df['games'])

# 3. Fit Poisson regression model for count outcome (red cards) with log(games) offset
# Using robust standard errors clustered by referee if refNum is available, else standard Poisson
if 'refNum' in df.columns:
    sub_df['refNum'] = df['refNum']
    # Fit GEE Poisson model to account for clustering by referee
    fam = sm.families.Poisson()
    ind = sm.cov_struct.Exchangeable()
    model = smf.gee("redCards ~ skin_tone", offset=np.log(sub_df['games']), 
                    data=sub_df, groups=sub_df['refNum'], family=fam, cov_struct=ind)
    result = model.fit()
    clustering_strategy = "gee"
    effect_type = "irr" # Incidence Rate Ratio
    
    effect_size = np.exp(result.params['skin_tone'])
    se = result.bse['skin_tone']
    p_val = result.pvalues['skin_tone']
    # CI for IRR via delta method / exponentiation of log bounds
    ci_lower = np.exp(result.params['skin_tone'] - 1.96 * se)
    ci_upper = np.exp(result.params['skin_tone'] + 1.96 * se)
else:
    model = smf.poisson("redCards ~ skin_tone + offset(log_games)", data=sub_df)
    result = model.fit(disp=False)
    clustering_strategy = "none"
    effect_type = "irr"
    effect_size = np.exp(result.params['skin_tone'])
    se = result.bse['skin_tone']
    p_val = result.pvalues['skin_tone']
    ci_lower = np.exp(result.params['skin_tone'] - 1.96 * se)
    ci_upper = np.exp(result.params['skin_tone'] + 1.96 * se)

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
  "effect_size": float(effect_size),
  "effect_type": effect_type,
  "standard_error": float(se),
  "p_value": float(p_val),
  "ci_lower": float(ci_lower),
  "ci_upper": float(ci_upper),
  "conclusion": conclusion,
  "model_family": "gee" if clustering_strategy == "gee" else "poisson",
  "predictor_used": "skin_tone (mean of rater1 and rater2)",
  "covariates_included": [],
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": clustering_strategy,
  "exclusions_applied": exclusions
}

print(json.dumps(output))