import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

# 1. Load the data
file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_soccer_confirmatory_T0.7_r1/data.csv'
df = pd.read_csv(file_path)

# 2. Clean and prepare data
# Calculate mean skin tone as the predictor
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2
# Exclude rows where skin tone data is missing
df = df.dropna(subset=['skin_tone'])
# The outcome is 'redCards'. Since it's count data with many zeros, Poisson or NegBinom is appropriate.
# We adjust for 'games' as an exposure variable to account for varying playing time.

# 3. Fit model
# Using Poisson regression with clustered standard errors by referee
# We include 'games' as an exposure variable (using log(games) as offset)
# Covariates: position (dummy), meanIAT (to control for regional bias)
df = df.dropna(subset=['meanIAT', 'position'])
model = smf.glm(
    formula='redCards ~ skin_tone + meanIAT + C(position)',
    data=df,
    family=sm.families.Poisson(),
    offset=np.log(df['games'])
).fit(cov_type='cluster', cov_kwds={'groups': df['refNum']})

# 4. Compute primary estimand
# The effect is the coefficient of skin_tone (log IRR)
beta = model.params['skin_tone']
se = model.bse['skin_tone']
p_val = model.pvalues['skin_tone']
conf = model.conf_int().loc['skin_tone']

# 5. Output JSON
result = {
    "effect_size": np.exp(beta),
    "effect_type": "irr",
    "standard_error": se,
    "p_value": p_val,
    "ci_lower": np.exp(conf[0]),
    "ci_upper": np.exp(conf[1]),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "poisson",
    "predictor_used": "average of rater1 and rater2",
    "covariates_included": ["meanIAT", "position"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "rows with missing skin tone, meanIAT, or position"
}

print(json.dumps(result))