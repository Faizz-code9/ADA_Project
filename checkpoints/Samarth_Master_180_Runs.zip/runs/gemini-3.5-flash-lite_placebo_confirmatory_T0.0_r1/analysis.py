import json
import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load dataset
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_placebo_confirmatory_T0.0_r1/data.csv"
df = pd.read_csv(file_path)

# 2. Prepare data
# Average rater1 and rater2 to get continuous skin tone (0-1)
df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)

# Drop rows missing skin_tone or redCards
df_clean = df.dropna(subset=['skin_tone', 'redCards', 'games']).copy()

# Poisson regression or Negative Binomial for count outcome (redCards), exposure is games (or log(games))
# Alternatively, since redCards can be modeled as count, use statsmodels GLM with Poisson family and log link.
# We include exposure log(games) since 'games' vary per player-referee row.
df_clean['log_games'] = np.log(df_clean['games'])

# Model specification: redCards ~ skin_tone with offset(log_games)
# Let's adjust for standard covariates if needed, or simple univariate/multivariate as appropriate.
# We can include yellowCards, meanIAT as common covariates in this dataset context.
covariates = ['yellowCards', 'meanIAT']
for c in covariates:
    df_clean[c] = df_clean[c].fillna(df_clean[c].mean())

# 3. Fit model (Poisson regression using GLM)
formula = 'redCards ~ skin_tone + yellowCards + meanIAT'
model = smf.glm(
    formula=formula,
    data=df_clean,
    family=sm.families.Poisson(),
    offset=df_clean['log_games']
).fit()

# 4. Extract parameters for primary estimand (skin_tone)
# The estimand is a ratio effect (IRR) of continuous skin tone on red cards.
coef = model.params['skin_tone']
se = model.bse['skin_tone']
p_val = model.pvalues['skin_tone']
ci = model.conf_int().loc['skin_tone']

irr = np.exp(coef)
ci_lower = np.exp(ci[0])
ci_upper = np.exp(ci[1])

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
  "effect_size": float(irr),
  "effect_type": "irr",
  "standard_error": float(se),
  "p_value": float(p_val),
  "ci_lower": float(ci_lower),
  "ci_upper": float(ci_upper),
  "conclusion": conclusion,
  "model_family": "poisson",
  "predictor_used": "skin_tone",
  "covariates_included": covariates,
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "none",
  "exclusions_applied": "Dropped rows missing rater1/rater2 or redCards"
}

print(json.dumps(output))