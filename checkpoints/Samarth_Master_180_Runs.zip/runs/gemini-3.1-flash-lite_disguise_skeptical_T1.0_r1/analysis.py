import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

def run_analysis():
    # 1. Load data
    file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_disguise_skeptical_T1.0_r1/data.csv'
    df = pd.read_csv(file_path)

    # 2. Data Preparation
    # The risk evaluator score is the mean of alpha and beta scores
    df['risk_score'] = df[['risk_evaluator_alpha_score', 'risk_evaluator_beta_score']].mean(axis=1)
    
    # Filter rows: must have risk_score, and keep relevant covariates
    # Loan application rejection is binary (0/1/2 -> 0/1 for logistic)
    df['rejection_bin'] = (df['loan_application_rejections'] > 0).astype(int)
    
    # Exclusions: Drop rows with missing values in key variables
    features = ['rejection_bin', 'risk_score', 'credit_score_index', 'annual_income_bracket', 
                'total_applications_reviewed', 'prior_approved_loans', 'loan_officer_id']
    df_clean = df.dropna(subset=features).copy()
    
    # 3. Fit Model
    # Using Logistic Regression. Clustering by loan_officer_id to handle institutional auditing variance
    # Formula: rejection ~ risk_score + covariates
    model = smf.gee("rejection_bin ~ risk_score + credit_score_index + annual_income_bracket + total_applications_reviewed + prior_approved_loans", 
                    groups=df_clean['loan_officer_id'], 
                    data=df_clean, 
                    family=sm.families.Binomial())
    results = model.fit()
    
    # 4. Extract Estimates
    params = results.params
    bse = results.bse
    conf = results.conf_int()
    p_val = results.pvalues
    
    effect_size = params['risk_score']
    se = bse['risk_score']
    p_val_score = p_val['risk_score']
    ci_lower = conf.loc['risk_score', 0]
    ci_upper = conf.loc['risk_score', 1]
    
    # 5. Output JSON
    output = {
        "effect_size": float(effect_size),
        "effect_type": "log_odds",
        "standard_error": float(se),
        "p_value": float(p_val_score),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": "significant_effect" if p_val_score < 0.05 else "no_significant_effect",
        "model_family": "gee",
        "predictor_used": "average of risk_evaluator_alpha_score and risk_evaluator_beta_score",
        "covariates_included": ["credit_score_index", "annual_income_bracket", "total_applications_reviewed", "prior_approved_loans"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "gee",
        "exclusions_applied": "rows missing risk scores or control variables removed"
    }
    
    print(json.dumps(output))

if __name__ == "__main__":
    run_analysis()