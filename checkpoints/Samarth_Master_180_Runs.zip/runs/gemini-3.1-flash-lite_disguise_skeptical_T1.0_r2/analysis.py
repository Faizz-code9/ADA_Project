import pandas as pd
import numpy as np
import statsmodels.api as sm
import json
import os

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.1-flash-lite_disguise_skeptical_T1.0_r2/data.csv"
df = pd.read_csv(file_path)

# 2. Clean and prepare data
# We treat risk_evaluator_alpha_score as the predictor. 
# Missing values are in rows where the score wasn't calculated (14.7%).
# We use listwise deletion as this is a standard approach for missing covariates in a model.
df = df.dropna(subset=['risk_evaluator_alpha_score', 'credit_score_index', 'annual_income_bracket'])

# Ensure outcome is binary for logistic regression
df['rejection_binary'] = (df['loan_application_rejections'] > 0).astype(int)

# 3. Fit model (Logistic Regression)
# Predictor: risk_evaluator_alpha_score (0-1)
# Covariates: credit_score_index, annual_income_bracket, prior_approved_loans, prior_denied_loans
X = df[['risk_evaluator_alpha_score', 'credit_score_index', 'annual_income_bracket', 
        'prior_approved_loans', 'prior_denied_loans']]
X = sm.add_constant(X)
y = df['rejection_binary']

# Using clustering by loan_officer_id to account for individual officer behavior
model = sm.GEE(y, X, groups=df['loan_officer_id'], family=sm.families.Binomial())
result = model.fit()

# 4. Extract quantities
params = result.params
stderr = result.bse
p_values = result.pvalues
conf = result.conf_int()

effect = params['risk_evaluator_alpha_score']
se = stderr['risk_evaluator_alpha_score']
p_val = p_values['risk_evaluator_alpha_score']
ci_lower = conf.loc['risk_evaluator_alpha_score', 0]
ci_upper = conf.loc['risk_evaluator_alpha_score', 1]

# 5. Output JSON
output = {
    "effect_size": float(np.exp(effect)),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(np.exp(ci_lower)),
    "ci_upper": float(np.exp(ci_upper)),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "gee",
    "predictor_used": "risk_evaluator_alpha_score",
    "covariates_included": ["credit_score_index", "annual_income_bracket", "prior_approved_loans", "prior_denied_loans"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "gee",
    "exclusions_applied": "Removed rows with missing risk_evaluator_alpha_score, credit_score_index, or annual_income_bracket"
}

print(json.dumps(output))