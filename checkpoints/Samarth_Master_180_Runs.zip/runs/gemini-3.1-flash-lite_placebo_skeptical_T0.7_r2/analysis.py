import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

# 1. Load data
file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_placebo_skeptical_T0.7_r2/data.csv'
df = pd.read_csv(file_path)

# 2. Preparation
# Create skin_tone as average of raters
df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)

# Listwise deletion for missing values needed for model
model_df = df.dropna(subset=['skin_tone', 'redCards', 'refNum', 'yellowCards', 'games']).copy()

# 3. Model
# Using Poisson regression for count data (redCards)
# We cluster by refNum to account for referee-level variations
formula = 'redCards ~ skin_tone + yellowCards + games + C(refNum)'
# Due to high number of referees, we use Generalized Estimating Equations (GEE)
# to handle clustering efficiently without fitting thousands of fixed effects
model = smf.gee(
    "redCards ~ skin_tone + yellowCards + games", 
    groups=model_df["refNum"], 
    data=model_df, 
    cov_struct=sm.cov_struct.Exchangeable(), 
    family=sm.families.Poisson()
)
result = model.fit()

# 4. Extract metrics
# Extracting coefficient for skin_tone
params = result.params
bse = result.bse
conf = result.conf_int()

effect_size = params['skin_tone']
se = bse['skin_tone']
ci_lower = conf.loc['skin_tone', 0]
ci_upper = conf.loc['skin_tone', 1]
p_val = result.pvalues['skin_tone']

# 5. Output JSON
output = {
    "effect_size": float(np.exp(effect_size)), # IRR interpretation
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(np.exp(ci_lower)),
    "ci_upper": float(np.exp(ci_upper)),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "gee",
    "predictor_used": "mean of rater1 and rater2",
    "covariates_included": ["yellowCards", "games"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "gee",
    "exclusions_applied": "dropped rows with missing skin tone, red cards, or referee ID"
}

print(json.dumps(output))