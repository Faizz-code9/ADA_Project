import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_placebo_neutral_T1.0_r1/data.csv"
df = pd.read_csv(file_path)

# 2. Data Preparation / Cleaning
# Average skin tone rating from rater1 and rater2
df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)

# Drop missing values for key variables used in the model
model_vars = ['redCards', 'skin_tone', 'games', 'yellowCards', 'meanIAT']
df_clean = df.dropna(subset=model_vars).copy()

# 3. Fit Model
# Using Poisson regression (or Negative Binomial) for count outcome (redCards), adjusting for games played, yellowCards, and meanIAT
formula = 'redCards ~ skin_tone + yellowCards + meanIAT + np.log(games)'
model = smf.poisson(formula, data=df_clean).fit(disp=False)

# 4. Extract Primary Estimand
effect_size = np.exp(model.params['skin_tone'])
conf_int = np.exp(model.conf_int().loc['skin_tone'])
p_value = model.pvalues['skin_tone']
std_err = model.bse['skin_tone'] * effect_size  # Delta method approx for IRR standard error

conclusion = "significant_effect" if p_value < 0.05 else "no_significant_effect"

# 5. Output JSON
result = {
  "effect_size": float(effect_size),
  "effect_type": "irr",
  "standard_error": float(std_err),
  "p_value": float(p_value),
  "ci_lower": float(conf_int[0]),
  "ci_upper": float(conf_int[1]),
  "conclusion": conclusion,
  "model_family": "poisson",
  "predictor_used": "skin_tone",
  "covariates_included": ["yellowCards", "meanIAT", "games"],
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "none",
  "exclusions_applied": "Dropped rows missing skin_tone, redCards, games, yellowCards, or meanIAT"
}

print(json.dumps(result))