import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_placebo_confirmatory_T0.7_r1/data.csv"
df = pd.read_csv(file_path)

# 2. Clean and prepare data
# Construct skin tone predictor as the average of rater1 and rater2
df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)

# Drop rows with missing values in key variables for a clean analysis
vars_to_check = ['redCards', 'skin_tone', 'games', 'yellowCards']
df_clean = df.dropna(subset=vars_to_check).copy()

# 3. Fit statistical model
# Using a Poisson regression model for count outcome (redCards), 
# adjusting for games played and yellow cards as exposure/covariates.
formula = 'redCards ~ skin_tone + yellowCards + games'

model = smf.poisson(formula, data=df_clean).fit(disp=False)

# 4. Compute primary estimand and statistics
# The estimand is the ratio effect (incidence rate ratio, IRR) of continuous skin tone
coef = model.params['skin_tone']
se = model.bse['skin_tone']
p_val = model.pvalues['skin_tone']
ci = model.conf_int().loc['skin_tone']

irr = np.exp(coef)
ci_lower = np.exp(ci[0])
ci_upper = np.exp(ci[1])

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

# 5. Output JSON result
result = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "skin_tone",
    "covariates_included": ["yellowCards", "games"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "Dropped rows with missing values in redCards, rater1/rater2, games, or yellowCards."
}

print(json.dumps(result))