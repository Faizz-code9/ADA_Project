import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

# 1. Load data
file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_synthetic_skeptical_T0.0_r2/data.csv'
df = pd.read_csv(file_path)

# 2. Clean and prepare
# Drop rows with missing skin_tone
df_clean = df.dropna(subset=['skin_tone']).copy()

# 3. Fit model
# Using Poisson regression for count data (redCards). 
# Adjusting for position, height, weight, leagueCountry, and yellowCards (exposure/confounder).
# Using random intercepts for refereeID to account for clustering.
model = smf.mixedlm(
    "redCards ~ skin_tone + C(position) + height + weight + C(leagueCountry) + yellowCards",
    df_clean,
    groups=df_clean["refereeID"]
)
result = model.fit()

# 4. Compute estimands
# Extract coefficient for skin_tone
coef = result.params['skin_tone']
se = result.bse['skin_tone']
p_val = result.pvalues['skin_tone']
ci_lower = coef - 1.96 * se
ci_upper = coef + 1.96 * se

# 5. Prepare JSON output
output = {
    "effect_size": float(coef),
    "effect_type": "coefficient",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "mixed_effects",
    "predictor_used": "skin_tone",
    "covariates_included": ["position", "height", "weight", "leagueCountry", "yellowCards"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "random_intercepts",
    "exclusions_applied": "rows with missing skin_tone removed"
}

print(json.dumps(output))