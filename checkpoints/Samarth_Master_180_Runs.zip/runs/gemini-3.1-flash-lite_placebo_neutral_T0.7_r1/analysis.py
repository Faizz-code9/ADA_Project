import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

def run_analysis():
    # 1. Load data
    file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_placebo_neutral_T0.7_r1/data.csv'
    df = pd.read_csv(file_path)

    # 2. Cleaning and preparation
    # Exclude rows where skin tone ratings are missing
    df = df.dropna(subset=['rater1', 'rater2'])
    
    # Construct primary predictor: average skin tone (0-1)
    df['skin_tone'] = (df['rater1'] + df['rater2']) / 2
    
    # Ensure outcome is binary/count-appropriate (redCards is 0, 1, or 2)
    # Using Logistic Regression as it is standard for binary disciplinary outcomes (Any red card vs none)
    df['red_card_any'] = (df['redCards'] > 0).astype(int)
    
    # 3. Model Fitting
    # Using Logistic Regression to estimate the effect of skin tone.
    # Clustering by referee (refNum) to account for referee-specific disciplinary thresholds.
    model = smf.logit(
        "red_card_any ~ skin_tone + games + yellowCards + yellowReds", 
        data=df
    )
    res = model.fit(cov_type='cluster', cov_kwds={'groups': df['refNum']}, disp=0)

    # 4. Extract results
    params = res.params
    conf = res.conf_int()
    
    # Odds ratio
    effect_size = np.exp(params['skin_tone'])
    ci_lower = np.exp(conf.loc['skin_tone', 0])
    ci_upper = np.exp(conf.loc['skin_tone', 1])
    
    # Standard Error (delta method for OR)
    se_log_or = res.bse['skin_tone']
    
    p_val = res.pvalues['skin_tone']
    
    # 5. Output JSON
    output = {
        "effect_size": float(effect_size),
        "effect_type": "odds_ratio",
        "standard_error": float(se_log_or),
        "p_value": float(p_val),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
        "model_family": "logistic",
        "predictor_used": "average of rater1 and rater2",
        "covariates_included": ["games", "yellowCards", "yellowReds"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "clustered_se",
        "exclusions_applied": "rows with missing rater1 or rater2 values"
    }
    
    print(json.dumps(output))

if __name__ == "__main__":
    run_analysis()