import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.1-flash-lite_soccer_skeptical_T0.7_r3/data.csv"
df = pd.read_csv(file_path)

# 2. Prepare data
# Construct predictor
df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)

# Clean: Drop missing values for required variables
# Ensure position is treated as a category (fill NA to avoid dropping)
df['position'] = df['position'].fillna('Unknown')
df = df.dropna(subset=['skin_tone', 'redCards', 'games', 'refNum', 'leagueCountry'])

# 3. Fit Model
# Using Poisson regression with robust standard errors clustered by referee.
# Standard Poisson regression is often more stable in statsmodels than GEE 
# for zero-inflated sparse data.
# Use log(games) as exposure to model the rate of red cards per game.
df['log_games'] = np.log(df['games'].replace(0, 1)) # replace 0 games with 1 to avoid -inf

# Using GLM with robust covariance
model = smf.glm(
    "redCards ~ skin_tone + C(position) + C(leagueCountry)",
    data=df,
    family=sm.families.Poisson(),
    offset=df['log_games']
)
# Fit with robust standard errors clustered by refNum
result = model.fit(cov_type='cluster', cov_kwds={'groups': df['refNum']})

# 4. Compute metrics
coef = result.params['skin_tone']
se = result.bse['skin_tone']
p_val = result.pvalues['skin_tone']
ci = result.conf_int().loc['skin_tone']

# 5. Output JSON
output = {
    "effect_size": float(np.exp(coef)),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(np.exp(ci[0])),
    "ci_upper": float(np.exp(ci[1])),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "poisson",
    "predictor_used": "average of rater1 and rater2",
    "covariates_included": ["position", "leagueCountry"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "rows with missing skin tone, redCards, or games"
}

print(json.dumps(output))