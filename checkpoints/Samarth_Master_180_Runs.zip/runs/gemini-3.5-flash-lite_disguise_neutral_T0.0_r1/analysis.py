import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_disguise_neutral_T0.0_r1/data.csv"
df = pd.read_csv(file_path)

# 2. Data preparation
# Define predictor: average of risk_evaluator_alpha_score and risk_evaluator_beta_score
df['risk_evaluator_score'] = df[['risk_evaluator_alpha_score', 'risk_evaluator_beta_score']].mean(axis=1)

# Ensure outcome is binary/count appropriate for logistic or Poisson. 
# loan_application_rejections has max value 2, so Poisson or Logistic. Let's use Logistic (0 vs >=1) or Poisson.
# The prompt says ratio effect of continuous risk evaluator score (0-1) on loan_application_rejections.
# Let's binarize rejections for logistic regression, or use Poisson for rate/count. Let's use logistic regression for binary rejection indicator.
df['rejection_binary'] = (df['loan_application_rejections'] > 0).astype(int)

# Drop missing values for the key variables
model_vars = ['rejection_binary', 'risk_evaluator_score', 'credit_score_index', 'annual_income_bracket']
df_clean = df.dropna(subset=model_vars).copy()

# 3. Fit model (Logistic Regression)
formula = 'rejection_binary ~ risk_evaluator_score + credit_score_index + annual_income_bracket'
model = smf.logit(formula, data=df_clean)
result = model.fit(disp=False)

# 4. Extract primary estimand (Odds Ratio for risk_evaluator_score)
coef = result.params['risk_evaluator_score']
se = result.bse['risk_evaluator_score']
pval = result.pvalues['risk_evaluator_score']
conf = result.conf_int().loc['risk_evaluator_score']

effect_size = np.exp(coef)
ci_lower = np.exp(conf[0])
ci_upper = np.exp(conf[1])

conclusion = "significant_effect" if pval < 0.05 else "no_significant_effect"

output = {
  "effect_size": float(effect_size),
  "effect_type": "odds_ratio",
  "standard_error": float(se),
  "p_value": float(pval),
  "ci_lower": float(ci_lower),
  "ci_upper": float(ci_upper),
  "conclusion": conclusion,
  "model_family": "logistic",
  "predictor_used": "risk_evaluator_score",
  "covariates_included": ["credit_score_index", "annual_income_bracket"],
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "none",
  "exclusions_applied": "Dropped rows with missing values in risk evaluator scores or covariates."
}

print(json.dumps(output))