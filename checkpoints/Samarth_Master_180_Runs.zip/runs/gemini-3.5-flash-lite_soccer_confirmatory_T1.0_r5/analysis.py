import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_soccer_confirmatory_T1.0_r5/data.csv"
df = pd.read_csv(file_path)

# 2. Data Preparation & Construction
# Average rater1 and rater2 to get continuous skin tone (0 to 1)
df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)

# Filter out rows with missing primary predictor or outcome
df = df.dropna(subset=['skin_tone', 'redCards'])

# Missing data strategy for covariates: listwise deletion on used variables
model_vars = ['redCards', 'skin_tone', 'yellowCards', 'games']
df_clean = df.dropna(subset=model_vars).copy()

# 3. Model Fitting
# Using Poisson regression (or Negative Binomial if overdispersed) for count outcome 'redCards'
# We include games as an exposure/offset or control, and yellowCards as a key control for aggressiveness.
# Clustering by refNum or player can be handled with GEE or robust SEs. Let's use Poisson with robust SEs clustered by refNum.
formula = 'redCards ~ skin_tone + yellowCards + games'

model = smf.glm(formula=formula, data=df_clean, family=sm.families.Poisson())
results = model.fit(cov_type='cluster', cov_kwds={'groups': df_clean['refNum']})

# 4. Extract Estimates
# The primary estimand is the ratio effect (incidence rate ratio, IRR) for skin tone
beta = results.params['skin_tone']
se = results.bse['skin_tone']
p_val = results.pvalues['skin_tone']
ci = results.conf_int().loc['skin_tone']

irr = np.exp(beta)
ci_lower = np.exp(ci[0])
ci_upper = np.exp(ci[1])

conclusion = 'significant_effect' if p_val < 0.05 else 'no_significant_effect'

output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "skin_tone",
    "covariates_included": ["yellowCards", "games"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "Dropped rows with missing skin_tone, redCards, yellowCards, or games"
}

print(json.dumps(output))