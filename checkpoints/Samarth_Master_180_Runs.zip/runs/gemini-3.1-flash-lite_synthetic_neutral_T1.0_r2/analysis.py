import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

# 1. Load data
file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_synthetic_neutral_T1.0_r2/data.csv'
df = pd.read_csv(file_path)

# 2. Clean and prepare data
df_clean = df.dropna(subset=['skin_tone']).copy()
# Ensure games is at least 1 to avoid log(0)
df_clean['log_games'] = np.log(df_clean['games'].clip(lower=1))

# 3. Fit model
# Using GLM with offset correctly handled via the 'offset' argument in the fit or included as a term.
# In statsmodels formula, adding the log-transformed exposure as an offset term works best 
# by passing it as the 'exposure' or 'offset' argument directly.
model = smf.glm(
    formula="redCards ~ skin_tone + height + weight + yellowCards + C(position) + C(leagueCountry)",
    data=df_clean,
    exposure=df_clean['games'],
    family=sm.families.Poisson()
).fit(cov_type='HC0')

# 4. Compute primary estimand
# Effect size is the IRR (exponentiated coefficient of skin_tone)
coef = model.params['skin_tone']
se = model.bse['skin_tone']
p_val = model.pvalues['skin_tone']
irr = np.exp(coef)
ci_lower = np.exp(coef - 1.96 * se)
ci_upper = np.exp(coef + 1.96 * se)

# 5. Format output
result = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "poisson",
    "predictor_used": "skin_tone",
    "covariates_included": ["height", "weight", "yellowCards", "position", "leagueCountry"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "rows with missing skin_tone (288 rows)"
}

print(json.dumps(result))