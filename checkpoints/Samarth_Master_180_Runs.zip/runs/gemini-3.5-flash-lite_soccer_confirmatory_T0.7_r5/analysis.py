import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_soccer_confirmatory_T0.7_r5/data.csv"
df = pd.read_csv(file_path)

# 2. Data preparation & cleaning
# Create skin tone predictor as the average of rater1 and rater2
df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)

# Drop rows missing essential variables for the model
cols_to_check = ['redCards', 'skin_tone', 'games', 'yellowCards', 'meanIAT']
df_clean = df.dropna(subset=cols_to_check).copy()

# 3. Model Fitting
# Using Poisson regression (or Negative Binomial if overdispersed) for count outcome 'redCards'
# Controlling for games played, yellow cards, and mean IAT as standard confounders
formula = 'redCards ~ skin_tone + yellowCards + games + meanIAT'

model = smf.poisson(formula, data=df_clean)
result = model.fit(disp=False)

# 4. Extract Estimates
effect_size = np.exp(result.params['skin_tone'])
conf = result.conf_int()
ci_lower = np.exp(conf.loc['skin_tone', 0])
ci_upper = np.exp(conf.loc['skin_tone', 1])
std_err = result.bse['skin_tone']
p_val = result.pvalues['skin_tone']

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
  "effect_size": float(effect_size),
  "effect_type": "irr",
  "standard_error": float(std_err),
  "p_value": float(p_val),
  "ci_lower": float(ci_lower),
  "ci_upper": float(ci_upper),
  "conclusion": conclusion,
  "model_family": "poisson",
  "predictor_used": "skin_tone",
  "covariates_included": ["yellowCards", "games", "meanIAT"],
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "none",
  "exclusions_applied": "Rows with missing values in redCards, skin_tone, games, yellowCards, or meanIAT were removed."
}

print(json.dumps(output))