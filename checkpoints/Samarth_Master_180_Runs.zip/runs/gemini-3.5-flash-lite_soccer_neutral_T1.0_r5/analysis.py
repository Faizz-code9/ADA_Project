import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_soccer_neutral_T1.0_r5/data.csv"
df = pd.read_csv(file_path)

# 2. Data preparation
df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)

# Drop missing values for key variables
df_clean = df.dropna(subset=['redCards', 'skin_tone', 'games', 'yellowCards', 'meanIAT', 'height', 'weight', 'playerShort']).copy()

# Ensure playerShort is treated as integer codes for statsmodels grouping if needed, 
# or use GEE / standard Poisson without cluster if bincount fails due to string identifiers.
# Converting playerShort to categorical codes solves the np.bincount length/index issue in statsmodels cluster covariance.
df_clean['player_code'] = df_clean['playerShort'].astype('category').cat.codes

# 3. Fit model using Poisson regression with clustered SEs on numeric group codes
formula = 'redCards ~ skin_tone + games + yellowCards + meanIAT + height + weight'
model = smf.poisson(formula, data=df_clean)
results = model.fit(cov_type='cluster', cov_kwds={'groups': df_clean['player_code']}, disp=False)

# 4. Extract primary estimand (skin_tone coefficient, IRR = exp(coef))
coef = results.params['skin_tone']
se = results.bse['skin_tone']
pval = results.pvalues['skin_tone']
ci = results.conf_int().loc['skin_tone']

irr = np.exp(coef)
ci_lower = np.exp(ci[0])
ci_upper = np.exp(ci[1])

conclusion = "significant_effect" if pval < 0.05 else "no_significant_effect"

output = {
  "effect_size": float(irr),
  "effect_type": "irr",
  "standard_error": float(se),
  "p_value": float(pval),
  "ci_lower": float(ci_lower),
  "ci_upper": float(ci_upper),
  "conclusion": conclusion,
  "model_family": "poisson",
  "predictor_used": "skin_tone",
  "covariates_included": ["games", "yellowCards", "meanIAT", "height", "weight"],
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "clustered_se",
  "exclusions_applied": "dropped rows with missing skin_tone, redCards, games, yellowCards, meanIAT, height, weight, or playerShort"
}

print(json.dumps(output))