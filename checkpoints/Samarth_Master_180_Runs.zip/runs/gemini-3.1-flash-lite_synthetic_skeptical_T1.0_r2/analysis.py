import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

def analyze_bias():
    # 1. Load data
    df = pd.read_csv('/kaggle/working/outputs/runs/gemini-3.1-flash-lite_synthetic_skeptical_T1.0_r2/data.csv')

    # 2. Preparation: Listwise deletion for skin_tone (as per requirements)
    df = df.dropna(subset=['skin_tone'])
    
    # We use a Poisson model to handle count data (redCards) 
    # and include an offset for log(games) to model the rate.
    # Clustering by refereeID accounts for potential differences in card-giving tendencies.
    df['log_games'] = np.log(df['games'].replace(0, 1))
    
    # 3. Model: Poisson regression with clustered standard errors
    model = smf.glm(
        formula='redCards ~ skin_tone + height + weight + C(position) + C(leagueCountry)',
        data=df,
        offset=df['log_games'],
        family=sm.families.Poisson()
    )
    
    # Use robust standard errors clustered by refereeID
    result = model.fit(cov_type='cluster', cov_kwds={'groups': df['refereeID']})
    
    # 4. Extract Estimates
    params = result.params
    bse = result.bse
    pvalues = result.pvalues
    conf_int = result.conf_int()
    
    effect = np.exp(params['skin_tone'])
    # Delta method for standard error of exp(beta)
    se_exp = np.exp(params['skin_tone']) * bse['skin_tone']
    
    # 95% CI for IRR (exp(beta))
    ci_lower = np.exp(conf_int.loc['skin_tone', 0])
    ci_upper = np.exp(conf_int.loc['skin_tone', 1])
    
    output = {
        "effect_size": float(effect),
        "effect_type": "irr",
        "standard_error": float(se_exp),
        "p_value": float(pvalues['skin_tone']),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": "significant_effect" if pvalues['skin_tone'] < 0.05 else "no_significant_effect",
        "model_family": "poisson",
        "predictor_used": "skin_tone",
        "covariates_included": ["height", "weight", "position", "leagueCountry"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "clustered_se",
        "exclusions_applied": "dropped 288 rows with missing skin_tone"
    }
    
    print(json.dumps(output))

if __name__ == "__main__":
    analyze_bias()