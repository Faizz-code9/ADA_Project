import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

def analyze_data():
    file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_synthetic_neutral_T0.7_r2/data.csv'
    df = pd.read_csv(file_path)

    # Missing data strategy: Listwise deletion
    df = df.dropna(subset=['skin_tone'])

    # Model: Poisson regression for count data (redCards)
    # Using clustered standard errors by refereeID to account for referee-specific biases
    # Covariates: position, height, weight, leagueCountry, games, yellowCards
    formula = 'redCards ~ skin_tone + C(position) + height + weight + C(leagueCountry) + games + yellowCards'
    
    model = smf.poisson(formula, data=df)
    results = model.fit(cov_type='cluster', cov_kwds={'groups': df['refereeID']}, disp=False)

    # Extract estimands
    effect = np.exp(results.params['skin_tone'])
    se = results.bse['skin_tone']
    p_val = results.pvalues['skin_tone']
    conf = results.conf_int().loc['skin_tone']
    
    ci_lower = np.exp(conf[0])
    ci_upper = np.exp(conf[1])

    output = {
        "effect_size": float(effect),
        "effect_type": "irr",
        "standard_error": float(se),
        "p_value": float(p_val),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
        "model_family": "poisson",
        "predictor_used": "skin_tone",
        "covariates_included": ["position", "height", "weight", "leagueCountry", "games", "yellowCards"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "clustered_se",
        "exclusions_applied": "rows with missing skin_tone"
    }

    print(json.dumps(output))

if __name__ == "__main__":
    analyze_data()