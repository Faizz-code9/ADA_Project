import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_synthetic_neutral_T1.0_r2/data.csv"
df = pd.read_csv(file_path)

# 2. Clean data and handle missing values
# Missing skin_tone: 288 rows. We use listwise deletion.
df_clean = df.dropna(subset=["skin_tone", "redCards", "games", "yellowCards"]).copy()

# Since redCards are count data over a varying number of games, we use Poisson regression (or Negative Binomial)
# with an offset for exposure: log(games). If games can be 0, handle it, but min games is 1.
df_clean["log_games"] = np.log(df_clean["games"])

# 3. Model Fitting
# We model redCards ~ skin_tone + yellowCards + position + height + weight + leagueCountry, offset(log_games)
# Using Poisson regression with robust standard errors (or GEE / GLM) to account for potential player/referee clustering.
# Given multiple observations per player/referee, GEE with groups on playerID or robust Poisson is standard.
# Let's use statsmodels GLM with Poisson family and robust (HC1 or clustered) standard errors if possible,
# or standard Poisson regression. We'll use smf.glm with Poisson family.
formula = (
    "redCards ~ skin_tone + yellowCards + height + weight + C(position) + C(leagueCountry)"
)

model = smf.glm(
    formula=formula,
    data=df_clean,
    family=sm.families.Poisson(),
    offset=df_clean["log_games"],
)
result = model.fit(cov_type="HC1")

# 4. Extract primary estimand (skin_tone effect)
# Effect type for Poisson regression log-link coefficient exponentiated is IRR (Incidence Rate Ratio)
coef = result.params["skin_tone"]
se = result.bse["skin_tone"]
p_val = result.pvalues["skin_tone"]
ci = result.conf_int()
ci_lower_log = ci.loc["skin_tone", 0]
ci_upper_log = ci.loc["skin_tone", 1]

irr = np.exp(coef)
ci_lower = np.exp(ci_lower_log)
ci_upper = np.exp(ci_upper_log)

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

# 5. Build output JSON
output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "skin_tone",
    "covariates_included": [
        "yellowCards",
        "height",
        "weight",
        "position",
        "leagueCountry",
        "games (offset)",
    ],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "Dropped rows with missing skin_tone (288 rows)",
}

print(json.dumps(output))