import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

def run_analysis():
    # 1. Load data
    df = pd.read_csv('/kaggle/working/outputs/runs/gemini-3.1-flash-lite_placebo_confirmatory_T1.0_r2/data.csv')

    # 2. Preparation
    # Exclude rows where skin tone is missing (rater1 or rater2 null)
    df = df.dropna(subset=['rater1', 'rater2'])
    
    # Construct continuous skin tone variable as average of raters
    df['skin_tone'] = (df['rater1'] + df['rater2']) / 2
    
    # 3. Model Fitting
    # Using Poisson regression for rare events (redCards)
    # We cluster by refNum to account for referee-level bias in high-stress adjudication
    formula = "redCards ~ skin_tone + games + height + weight + yellowCards"
    
    model = smf.glm(
        formula=formula, 
        data=df, 
        family=sm.families.Poisson(),
        groups=df['refNum']
    )
    
    # Using GEE for clustered data (robust standard errors)
    gee_model = smf.gee(
        formula=formula, 
        data=df, 
        groups=df['refNum'],
        family=sm.families.Poisson(),
        cov_struct=sm.cov_struct.Exchangeable()
    )
    res = gee_model.fit()
    
    # 4. Extract metrics
    params = res.params
    bse = res.bse
    conf_int = res.conf_int()
    
    effect = params['skin_tone']
    std_err = bse['skin_tone']
    p_val = res.pvalues['skin_tone']
    ci_lower = conf_int.loc['skin_tone', 0]
    ci_upper = conf_int.loc['skin_tone', 1]
    
    # Convert coefficient to IRR (Incident Rate Ratio)
    irr = np.exp(effect)
    irr_se = irr * std_err
    irr_ci_lower = np.exp(ci_lower)
    irr_ci_upper = np.exp(ci_upper)
    
    output = {
        "effect_size": float(irr),
        "effect_type": "irr",
        "standard_error": float(irr_se),
        "p_value": float(p_val),
        "ci_lower": float(irr_ci_lower),
        "ci_upper": float(irr_ci_upper),
        "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
        "model_family": "gee",
        "predictor_used": "average of rater1 and rater2 skin tone scores",
        "covariates_included": ["games", "height", "weight", "yellowCards"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "gee",
        "exclusions_applied": "removed rows where rater1 or rater2 is missing"
    }
    
    print(json.dumps(output))

if __name__ == "__main__":
    run_analysis()