import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

# 1. Load data
file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_disguise_neutral_T0.0_r2/data.csv'
df = pd.read_csv(file_path)

# 2. Prepare data
# Primary predictor: average of alpha and beta scores (0-1 scale)
df['risk_score'] = df[['risk_evaluator_alpha_score', 'risk_evaluator_beta_score']].mean(axis=1)

# Exclusions: Drop rows where risk scores are missing (14.7% of data)
df_clean = df.dropna(subset=['risk_score', 'credit_score_index', 'annual_income_bracket']).copy()

# 3. Fit model
# Using Logistic Regression to model the probability of rejection (0 or 1)
# We use random intercepts for loan_officer_id to account for clustering
model = smf.mixedlm(
    "loan_application_rejections ~ risk_score + credit_score_index + annual_income_bracket",
    df_clean,
    groups=df_clean["loan_officer_id"]
)
result = model.fit()

# 4. Compute estimands
# Extract coefficient for risk_score
coef = result.params['risk_score']
se = result.bse['risk_score']
p_val = result.pvalues['risk_score']
ci = result.conf_int().loc['risk_score']

# 5. Prepare JSON output
output = {
    "effect_size": float(coef),
    "effect_type": "coefficient",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci[0]),
    "ci_upper": float(ci[1]),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "mixed_effects",
    "predictor_used": "mean of risk_evaluator_alpha_score and risk_evaluator_beta_score",
    "covariates_included": ["credit_score_index", "annual_income_bracket"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "random_intercepts",
    "exclusions_applied": "rows with missing risk scores, credit scores, or income brackets removed"
}

print(json.dumps(output))