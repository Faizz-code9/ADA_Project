import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

# 1. Load the CSV
file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_placebo_neutral_T1.0_r1/data.csv'
df = pd.read_csv(file_path)

# 2. Clean and Prepare
# Drop missing rater info
df = df.dropna(subset=['rater1', 'rater2'])
# Create predictor
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2.0
# Handle missing covariate values (simple listwise)
df = df.dropna(subset=['games', 'yellowCards', 'height', 'weight'])

# 3. Fit Model
# Using GEE for clustered data (by refNum) to handle dependency in referee decisions
# Using Poisson family for red card counts
fam = sm.families.Poisson()
ind = sm.cov_struct.Exchangeable()
formula = "redCards ~ skin_tone + games + yellowCards + height + weight"

model = smf.gee(formula, "refNum", data=df, family=fam, cov_struct=ind)
result = model.fit()

# 4. Compute primary estimand (IRR)
# The coefficient is for log(redCards), exponentiate to get IRR
coeff = result.params['skin_tone']
se = result.bse['skin_tone']
p_val = result.pvalues['skin_tone']
ci_lower = np.exp(coeff - 1.96 * se)
ci_upper = np.exp(coeff + 1.96 * se)

# 5. Output JSON
output = {
    "effect_size": float(np.exp(coeff)),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "gee",
    "predictor_used": "mean of rater1 and rater2",
    "covariates_included": ["games", "yellowCards", "height", "weight"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "gee",
    "exclusions_applied": "Removed rows with missing rater1, rater2, games, yellowCards, height, or weight"
}

print(json.dumps(output))