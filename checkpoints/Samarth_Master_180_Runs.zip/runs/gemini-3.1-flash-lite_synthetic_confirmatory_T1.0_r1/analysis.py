import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

def analyze_bias():
    # 1. Load data
    file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_synthetic_confirmatory_T1.0_r1/data.csv'
    df = pd.read_csv(file_path)

    # 2. Cleaning and preparation
    df = df.dropna(subset=['skin_tone'])
    # Ensure log_games is available in the dataframe for smf access
    df['log_games'] = np.log(df['games'])

    # 3. Fit model (Poisson Regression using GLM directly to handle offset)
    # Patasy formula error fixed by passing offset via the 'offset' argument in GLM
    formula = "redCards ~ skin_tone + height + weight + C(position) + C(leagueCountry) + yellowCards"
    
    # We fit the model using the offset as an array parameter
    X = sm.add_constant(pd.get_dummies(df[['skin_tone', 'height', 'weight', 'position', 'leagueCountry', 'yellowCards']], drop_first=True))
    # Handling categorical dummies explicitly for standard statsmodels GLM
    model = sm.GLM(df['redCards'], X, offset=df['log_games'], family=sm.families.Poisson()).fit()

    # 4. Compute estimands
    params = model.params
    bse = model.bse
    conf = model.conf_int()

    # Extract effect of skin_tone (using the coefficient from the regression)
    # Since we used pd.get_dummies, we must ensure skin_tone is the correct column index
    effect_log = params['skin_tone']
    se = bse['skin_tone']
    p_val = model.pvalues['skin_tone']
    
    # Exponentiate for Incidence Rate Ratio (IRR)
    irr = np.exp(effect_log)
    ci_lower = np.exp(conf.loc['skin_tone', 0])
    ci_upper = np.exp(conf.loc['skin_tone', 1])

    # 5. Format output
    result = {
        "effect_size": float(irr),
        "effect_type": "irr",
        "standard_error": float(se * irr),
        "p_value": float(p_val),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
        "model_family": "poisson",
        "predictor_used": "skin_tone",
        "covariates_included": ["height", "weight", "position", "leagueCountry", "yellowCards"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "none",
        "exclusions_applied": "Rows with missing skin_tone values (288 rows removed)"
    }

    print(json.dumps(result))

if __name__ == "__main__":
    analyze_bias()