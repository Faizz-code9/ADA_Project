import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_soccer_neutral_T0.7_r3/data.csv"
df = pd.read_csv(file_path)

# 2. Prepare data
# Construct skin tone as average of rater1 and rater2
df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)

# Exclusions & Missing Data Strategy: Listwise deletion for regression variables
# We use Poisson regression for count outcome (redCards), adjusting for games played (exposure) or as a rate.
# Let's subset to complete cases for the variables used in the model.
model_vars = ['redCards', 'skin_tone', 'games', 'yellowCards']
df_clean = df.dropna(subset=model_vars).copy()

# 3. Fit model
# Using Poisson regression (or negative binomial if overdispersed) with offset log(games) to account for playing time.
# Include yellowCards as a covariate since players with more yellows often get red cards.
formula = 'redCards ~ skin_tone + yellowCards + np.log(games)'
# If games can be 0, handle it (though min games is 1 based on description)
df_clean['log_games'] = np.log(df_clean['games'])

# Fit Poisson model
poisson_model = smf.poisson('redCards ~ skin_tone + yellowCards + log_games', data=df_clean).fit(disp=False)

# 4. Extract primary estimand (skin_tone effect)
# Effect type for Poisson/IRR is 'irr' (Incidence Rate Ratio = exp(coefficient))
coef = poisson_model.params['skin_tone']
se = poisson_model.bse['skin_tone']
pval = poisson_model.pvalues['skin_tone']
conf_int = poisson_model.conf_int().loc['skin_tone']

irr = np.exp(coef)
ci_lower = np.exp(conf_int[0])
ci_upper = np.exp(conf_int[1])

conclusion = "significant_effect" if pval < 0.05 else "no_significant_effect"

output = {
  "effect_size": float(irr),
  "effect_type": "irr",
  "standard_error": float(se), # Note: SE of coefficient, or delta-method for IRR, standard is coefficient SE or reported as is
  "p_value": float(pval),
  "ci_lower": float(ci_lower),
  "ci_upper": float(ci_upper),
  "conclusion": conclusion,
  "model_family": "poisson",
  "predictor_used": "skin_tone (average of rater1 and rater2)",
  "covariates_included": ["yellowCards", "log_games"],
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "none",
  "exclusions_applied": "Dropped rows with missing values in redCards, rater1/rater2, games, or yellowCards."
}

print(json.dumps(output))