import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_soccer_confirmatory_T0.7_r4/data.csv"
df = pd.read_csv(file_path)

# 2. Data preparation
# Average skin tone from rater1 and rater2
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2

# Filter out rows missing key variables
# The dataset has player-referee dyads (games played by player under referee)
subset = df.dropna(subset=['skin_tone', 'redCards', 'games']).copy()

# Poisson regression / Generalized Linear Model for count outcome (redCards)
# We include 'games' as an exposure variable (offset = log(games)) via sm.GLM or smf.glm
subset['log_games'] = np.log(subset['games'])

# Missing data strategy: listwise deletion on used variables
model_data = subset.dropna(subset=['skin_tone', 'redCards', 'games', 'log_games', 'meanIAT']).copy()

# 3. Fit Poisson model with robust standard errors clustered by player or referee if appropriate, 
# but here we use simple Poisson GLM with robust (HC1/HC3) or standard errors, or standard GLM.
formula = 'redCards ~ skin_tone + meanIAT + height + weight + yellowCards'
# Alternatively, using games as exposure:
# We can use smf.glm with Poisson family and log link, offsetting by log_games
# Let's specify the GLM:
model = smf.glm(
    formula='redCards ~ skin_tone + meanIAT + height + weight',
    data=model_data,
    family=sm.families.Poisson(),
    offset=model_data['log_games']
).fit(cov_type='HC1')

# 4. Extract primary estimand (skin_tone)
coef = model.params['skin_tone']
se = model.bse['skin_tone']
p_val = model.pvalues['skin_tone']
ci = model.conf_int().loc['skin_tone']

effect_size = float(np.exp(coef)) # IRR (incidence rate ratio)
ci_lower = float(np.exp(ci[0]))
ci_upper = float(np.exp(ci[1]))

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
  "effect_size": float(effect_size),
  "effect_type": "irr",
  "standard_error": float(se),
  "p_value": float(p_val),
  "ci_lower": float(ci_lower),
  "ci_upper": float(ci_upper),
  "conclusion": conclusion,
  "model_family": "poisson",
  "predictor_used": "skin_tone",
  "covariates_included": ["meanIAT", "height", "weight"],
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "none",
  "exclusions_applied": "Dropped rows with missing skin_tone, redCards, games, or covariates."
}

print(json.dumps(output))