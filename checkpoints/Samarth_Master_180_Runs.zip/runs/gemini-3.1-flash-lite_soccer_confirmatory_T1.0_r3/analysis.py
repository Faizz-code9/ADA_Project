import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

# 1. Load data
file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_soccer_confirmatory_T1.0_r3/data.csv'
df = pd.read_csv(file_path)

# 2. Preparation
df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)
df = df.dropna(subset=['skin_tone', 'games', 'meanIAT', 'refNum']).copy()

# The error in clustering often arises from index mismatches or non-integer group labels.
# We map refNum to categorical/integer indices to ensure statsmodels handles groups correctly.
df['ref_idx'] = df['refNum'].astype('category').cat.codes

# 3. Model Fitting
# Using Poisson with robust clustered standard errors. 
# We explicitly specify the formula and the cluster group.
formula = 'redCards ~ skin_tone + games + I(games**2) + meanIAT'
model = smf.poisson(formula, data=df).fit(
    cov_type='cluster', 
    cov_kwds={'groups': df['ref_idx']}, 
    method='nm', # Use Nelder-Mead if lbfgs fails to converge
    maxiter=1000
)

# 4. Extract statistics
params = model.params
pvalues = model.pvalues
bse = model.bse

# Ratio effect (IRR)
effect = np.exp(params['skin_tone'])
# Delta method for SE of exponentiated coefficient
se = bse['skin_tone'] * effect
ci_lower = np.exp(params['skin_tone'] - 1.96 * bse['skin_tone'])
ci_upper = np.exp(params['skin_tone'] + 1.96 * bse['skin_tone'])

# 5. Output
result = {
    "effect_size": float(effect),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(pvalues['skin_tone']),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if pvalues['skin_tone'] < 0.05 else "no_significant_effect",
    "model_family": "poisson",
    "predictor_used": "skin_tone (average of rater1 and rater2)",
    "covariates_included": ["games", "I(games**2)", "meanIAT"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "rows with missing skin_tone, games, meanIAT, or refNum removed"
}

print(json.dumps(result))