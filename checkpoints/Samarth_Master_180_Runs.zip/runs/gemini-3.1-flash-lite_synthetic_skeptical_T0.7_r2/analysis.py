import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json
import sys

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.1-flash-lite_synthetic_skeptical_T0.7_r2/data.csv"
df = pd.read_csv(file_path)

# 2. Preparation
# Exclude missing skin_tone values
df_clean = df.dropna(subset=['skin_tone']).copy()

# 3. Model Fitting
# Poisson regression is appropriate for count data (redCards)
# We use Generalized Estimating Equations (GEE) to account for clustering by referee
# as referees may have systematic bias tendencies.
model = smf.gee(
    "redCards ~ skin_tone + height + weight + yellowCards + C(position) + C(leagueCountry)",
    groups="refereeID",
    data=df_clean,
    family=sm.families.Poisson(),
    cov_struct=sm.cov_struct.Exchangeable()
)
result = model.fit()

# 4. Compute estimands
# Extract coefficient for skin_tone
coef = result.params['skin_tone']
se = result.bse['skin_tone']
p_val = result.pvalues['skin_tone']
ci_lower = coef - 1.96 * se
ci_upper = coef + 1.96 * se

# 5. Format Output
output = {
    "effect_size": float(np.exp(coef)), # IRR
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(np.exp(ci_lower)),
    "ci_upper": float(np.exp(ci_upper)),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "gee",
    "predictor_used": "skin_tone",
    "covariates_included": ["height", "weight", "yellowCards", "position", "leagueCountry"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "gee",
    "exclusions_applied": "rows with missing skin_tone"
}

print(json.dumps(output))