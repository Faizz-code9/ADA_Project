import pandas as pd
import numpy as np
import statsmodels.formula.api as smf
import statsmodels.api as sm
import json

# 1. Load data
file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_soccer_neutral_T1.0_r5/data.csv'
df = pd.read_csv(file_path)

# 2. Preparation
# Create skin_tone feature
df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)

# Drop missing values for required variables
df_clean = df.dropna(subset=['skin_tone', 'redCards', 'refNum', 'games', 'yellowCards']).copy()

# 3. Fit Model
# Using Poisson regression with clustered standard errors at the referee level
# Note: sm.families.Poisson is accessed via sm.families, not smf.families
model = smf.glm(
    formula='redCards ~ skin_tone + games + yellowCards',
    data=df_clean,
    family=sm.families.Poisson()
).fit(cov_type='cluster', cov_kwds={'groups': df_clean['refNum']})

# 4. Extract statistics
# Effect size for Poisson (IRR) is exp(coefficient)
coef = model.params['skin_tone']
se = model.bse['skin_tone']
p_val = model.pvalues['skin_tone']
irr = np.exp(coef)

# Calculate CI for IRR
ci_lower = np.exp(coef - 1.96 * se)
ci_upper = np.exp(coef + 1.96 * se)

# 5. Output
result = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "poisson",
    "predictor_used": "mean(rater1, rater2)",
    "covariates_included": ["games", "yellowCards"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "rows missing skin_tone, refNum, games, or yellowCards"
}

print(json.dumps(result))