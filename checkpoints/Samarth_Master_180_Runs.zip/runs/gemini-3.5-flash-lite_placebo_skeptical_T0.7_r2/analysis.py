import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_placebo_skeptical_T0.7_r2/data.csv"
df = pd.read_csv(file_path)

# 2. Data Preparation
df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)

# Drop rows missing essential variables
df_clean = df.dropna(subset=['skin_tone', 'redCards', 'games']).copy()

# Fill missing covariates with median to avoid massive listwise deletion
df_clean['height'] = df_clean['height'].fillna(df_clean['height'].median())
df_clean['weight'] = df_clean['weight'].fillna(df_clean['weight'].median())
df_clean['yellowCards'] = df_clean['yellowCards'].fillna(0)

df_clean['log_games'] = np.log(df_clean['games'].clip(lower=1))

# 3. Fit Model using statsmodels GLM directly to avoid patsy offset issues
X_cols = ['skin_tone', 'yellowCards', 'height', 'weight']
X = df_clean[X_cols].copy()
X = sm.add_constant(X)
y = df_clean['redCards']
offset = df_clean['log_games']

model = sm.GLM(
    y, 
    X, 
    family=sm.families.Poisson(), 
    offset=offset
).fit()

# 4. Extract Estimates
effect_size = np.exp(model.params['skin_tone'])
conf_int = np.exp(model.conf_int().loc['skin_tone'])
ci_lower = conf_int[0]
ci_upper = conf_int[1]
p_value = model.pvalues['skin_tone']
std_err = model.bse['skin_tone'] * effect_size  # Delta method for IRR

conclusion = "significant_effect" if p_value < 0.05 else "no_significant_effect"

output = {
  "effect_size": float(effect_size),
  "effect_type": "irr",
  "standard_error": float(std_err),
  "p_value": float(p_value),
  "ci_lower": float(ci_lower),
  "ci_upper": float(ci_upper),
  "conclusion": conclusion,
  "model_family": "poisson",
  "predictor_used": "skin_tone",
  "covariates_included": ["yellowCards", "height", "weight"],
  "missing_data_strategy": "other",
  "clustering_strategy": "none",
  "exclusions_applied": "Dropped rows with missing skin_tone, redCards, or games."
}

print(json.dumps(output))