import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

# 1. Load data
file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_disguise_confirmatory_T0.7_r1/data.csv'
df = pd.read_csv(file_path)

# 2. Prepare data
# Construct 'risk_evaluator_score' as the average of alpha and beta scores
df['risk_evaluator_score'] = df[['risk_evaluator_alpha_score', 'risk_evaluator_beta_score']].mean(axis=1)

# Keep only rows where risk score is available (removes 21,407 rows)
df_clean = df.dropna(subset=['risk_evaluator_score', 'credit_score_index', 'annual_income_bracket']).copy()

# 3. Model Fitting
# Logistic regression for loan_application_rejections (binary: 0 or 1, though some values are 2, treat as >0)
df_clean['rejected'] = (df_clean['loan_application_rejections'] > 0).astype(int)

# Predictors: risk_evaluator_score, adjusted for credit_score_index, annual_income_bracket
# Clustering by loan_officer_id to account for individual officer bias
model = smf.logit(
    "rejected ~ risk_evaluator_score + credit_score_index + annual_income_bracket", 
    data=df_clean
).fit(cov_type='cluster', cov_kwds={'groups': df_clean['loan_officer_id']})

# 4. Extract results
params = model.params
conf = model.conf_int()
effect_size = np.exp(params['risk_evaluator_score'])
se = model.bse['risk_evaluator_score']
p_val = model.pvalues['risk_evaluator_score']
ci_lower = np.exp(conf.loc['risk_evaluator_score', 0])
ci_upper = np.exp(conf.loc['risk_evaluator_score', 1])

# 5. Output JSON
output = {
    "effect_size": float(effect_size),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "logistic",
    "predictor_used": "risk_evaluator_score (average of alpha and beta scores)",
    "covariates_included": ["credit_score_index", "annual_income_bracket"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "Rows with missing risk_evaluator_score, credit_score_index, or annual_income_bracket removed."
}

print(json.dumps(output))