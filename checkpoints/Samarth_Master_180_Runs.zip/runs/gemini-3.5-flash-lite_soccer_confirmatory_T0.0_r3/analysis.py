import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_soccer_confirmatory_T0.0_r3/data.csv"
df = pd.read_csv(file_path)

# 2. Data preparation
# Construct skin tone predictor as the average of rater1 and rater2
df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)

# Listwise deletion for regression variables
# We use Poisson regression (or Negative Binomial) since the outcome 'redCards' is a count.
# Controlling for games played (as exposure or covariate) and other standard covariates.
model_vars = ['redCards', 'skin_tone', 'games', 'yellowCards', 'height', 'weight', 'meanIAT']
df_clean = df.dropna(subset=model_vars).copy()

# 3. Fit statistical model
# Using Poisson regression with robust standard errors or standard GLM Poisson
formula = 'redCards ~ skin_tone + games + yellowCards + height + weight + meanIAT'
model = smf.poisson(formula, data=df_clean)
results = model.fit(cov_type='HC1', disp=False)

# 4. Extract primary estimand (skin_tone effect)
effect_size = float(np.exp(results.params['skin_tone']))
std_error = float(results.bse['skin_tone'])
p_value = float(results.pvalues['skin_tone'])
ci_lower = float(np.exp(results.conf_int().loc['skin_tone', 0]))
ci_upper = float(np.exp(results.conf_int().loc['skin_tone', 1]))

conclusion = 'significant_effect' if p_value < 0.05 else 'no_significant_effect'

output = {
  "effect_size": effect_size,
  "effect_type": "irr",
  "standard_error": std_error,
  "p_value": p_value,
  "ci_lower": ci_lower,
  "ci_upper": ci_upper,
  "conclusion": conclusion,
  "model_family": "poisson",
  "predictor_used": "skin_tone",
  "covariates_included": ["games", "yellowCards", "height", "weight", "meanIAT"],
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "none",
  "exclusions_applied": "Rows with missing values in redCards, rater1, rater2, games, yellowCards, height, weight, or meanIAT were removed."
}

print(json.dumps(output))