import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_soccer_confirmatory_T1.0_r2/data.csv"
df = pd.read_csv(file_path)

# 2. Data preparation
# Create continuous skin tone measure as average of rater1 and rater2
df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)

# Drop missing values for skin_tone, redCards, and games
df_clean = df.dropna(subset=['skin_tone', 'redCards', 'games']).copy()

# Handle exposure (games) using statsmodels GLM API directly to avoid patsy offset issues
df_clean['games'] = df_clean['games'].replace(0, 1)  # avoid log(0)
df_clean['log_games'] = np.log(df_clean['games'])

# Design matrices for GLM
X = df_clean[['skin_tone']].copy()
X = sm.add_constant(X)
y = df_clean['redCards']
exposure = df_clean['log_games']

# 3. Model fitting via GLM Poisson with offset
model = sm.GLM(y, X, family=sm.families.Poisson(), offset=exposure)
result = model.fit()

# 4. Extract primary estimand (effect of skin_tone)
coef = result.params['skin_tone']
se = result.bse['skin_tone']
p_val = result.pvalues['skin_tone']
ci = result.conf_int().loc['skin_tone']

irr = np.exp(coef)
ci_lower = np.exp(ci[0])
ci_upper = np.exp(ci[1])

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

# 5. Format output JSON
output = {
  "effect_size": float(irr),
  "effect_type": "irr",
  "standard_error": float(se),
  "p_value": float(p_val),
  "ci_lower": float(ci_lower),
  "ci_upper": float(ci_upper),
  "conclusion": conclusion,
  "model_family": "poisson",
  "predictor_used": "skin_tone",
  "covariates_included": [],
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "none",
  "exclusions_applied": "Dropped rows with missing skin tone, red cards, or game counts."
}

print(json.dumps(output))