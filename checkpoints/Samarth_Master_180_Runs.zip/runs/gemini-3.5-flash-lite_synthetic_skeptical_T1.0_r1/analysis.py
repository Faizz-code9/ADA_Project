import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_synthetic_skeptical_T1.0_r1/data.csv"
df = pd.read_csv(file_path)

# 2. Clean and prepare data
initial_len = len(df)
df = df.dropna(subset=['skin_tone', 'redCards', 'games', 'yellowCards'])
exclusions_applied = f"Dropped {initial_len - len(df)} rows due to missing skin_tone"

df['log_games'] = np.log(df['games'])

# 3. Fit statistical model (Poisson Regression using smf.poisson)
formula = "redCards ~ skin_tone + yellowCards + height + weight + C(position) + C(leagueCountry)"
model = smf.poisson(formula=formula, data=df, offset=df['log_games']).fit(disp=False)

# 4. Compute primary estimand (IRR for skin_tone)
coef = model.params['skin_tone']
se = model.bse['skin_tone']
p_val = model.pvalues['skin_tone']
ci = model.conf_int().loc['skin_tone']

irr = np.exp(coef)
ci_lower = np.exp(ci[0])
ci_upper = np.exp(ci[1])

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

# 5. Output JSON
output = {
  "effect_size": float(irr),
  "effect_type": "irr",
  "standard_error": float(se),
  "p_value": float(p_val),
  "ci_lower": float(ci_lower),
  "ci_upper": float(ci_upper),
  "conclusion": conclusion,
  "model_family": "poisson",
  "predictor_used": "skin_tone",
  "covariates_included": ["yellowCards", "height", "weight", "position", "leagueCountry", "log_games"],
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "none",
  "exclusions_applied": exclusions_applied
}

print(json.dumps(output))