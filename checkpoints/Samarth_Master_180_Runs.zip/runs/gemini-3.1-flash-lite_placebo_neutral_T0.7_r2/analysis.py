import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

# 1. Load data
file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_placebo_neutral_T0.7_r2/data.csv'
df = pd.read_csv(file_path)

# 2. Prepare data
# Exclude rows where skin tone ratings are missing (14.7% of data)
df = df.dropna(subset=['rater1', 'rater2'])
# Create primary predictor: average of rater1 and rater2
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2.0

# 3. Model construction
# We use a Poisson regression as the outcome is a count of red cards.
# Adjusting for covariates that affect physical play or disciplinary risk.
# 'games' acts as an exposure variable.
formula = 'redCards ~ skin_tone + height + weight + games + yellowCards'
model = smf.glm(formula=formula, data=df, family=sm.families.Poisson(), offset=np.log(df['games'] + 1e-6))
result = model.fit()

# 4. Extract metrics
params = result.params
bse = result.bse
pvalues = result.pvalues
conf_int = result.conf_int()

effect_size = np.exp(params['skin_tone'])
ci_lower = np.exp(conf_int.loc['skin_tone', 0])
ci_upper = np.exp(conf_int.loc['skin_tone', 1])

# 5. Build output
output = {
    "effect_size": float(effect_size),
    "effect_type": "irr",
    "standard_error": float(bse['skin_tone']),
    "p_value": float(pvalues['skin_tone']),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if pvalues['skin_tone'] < 0.05 else "no_significant_effect",
    "model_family": "poisson",
    "predictor_used": "average of rater1 and rater2",
    "covariates_included": ["height", "weight", "games", "yellowCards"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "rows with missing rater1/rater2 values"
}

print(json.dumps(output))