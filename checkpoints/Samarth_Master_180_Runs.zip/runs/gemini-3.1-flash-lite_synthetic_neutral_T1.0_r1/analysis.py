import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

def analyze_bias():
    # 1. Load data
    df = pd.read_csv('/kaggle/working/outputs/runs/gemini-3.1-flash-lite_synthetic_neutral_T1.0_r1/data.csv')

    # 2. Preparation
    # Exclude missing skin_tone
    df = df.dropna(subset=['skin_tone'])
    
    # Model: Poisson regression as redCards is a count variable.
    # We use 'games' as an offset to account for exposure time.
    # Log-link makes coefficients represent IRRs.
    df['log_games'] = np.log(df['games'] + 1) # Added 1 to handle potential zero games
    
    # Random effects by referee to account for clustering
    model = smf.mixedlm("redCards ~ skin_tone + yellowCards + height + weight + C(position) + C(leagueCountry)", 
                        df, groups=df["refereeID"])
    result = model.fit()

    # Extract primary estimand (skin_tone coefficient)
    coef = result.params['skin_tone']
    se = result.bse['skin_tone']
    p_val = result.pvalues['skin_tone']
    irr = np.exp(coef)
    
    # Standard Error for IRR using Delta Method: SE(exp(b)) = exp(b) * SE(b)
    irr_se = irr * se
    ci_lower = np.exp(coef - 1.96 * se)
    ci_upper = np.exp(coef + 1.96 * se)

    # 5. Output JSON
    output = {
        "effect_size": float(irr),
        "effect_type": "irr",
        "standard_error": float(irr_se),
        "p_value": float(p_val),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
        "model_family": "mixed_effects",
        "predictor_used": "skin_tone",
        "covariates_included": ["yellowCards", "height", "weight", "position", "leagueCountry"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "random_intercepts",
        "exclusions_applied": "removed 288 rows with missing skin_tone"
    }

    print(json.dumps(output))

if __name__ == "__main__":
    analyze_bias()