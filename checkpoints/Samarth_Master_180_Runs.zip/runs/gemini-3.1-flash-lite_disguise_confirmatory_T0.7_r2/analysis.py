import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

# 1. Load data
file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_disguise_confirmatory_T0.7_r2/data.csv'
df = pd.read_csv(file_path)

# 2. Clean and prepare data
# Construct risk evaluator score (Average of alpha and beta as requested continuous metric 0-1)
df['risk_evaluator_score'] = df[['risk_evaluator_alpha_score', 'risk_evaluator_beta_score']].mean(axis=1)

# Keep only rows where risk evaluator score is available
df_clean = df.dropna(subset=['risk_evaluator_score', 'credit_score_index', 'annual_income_bracket']).copy()

# 3. Fit Model
# Logistic regression for loan rejection (binary outcome 0 or 1, assuming max 2 is rare or treated as rejection)
# Rejections > 0 treated as 1
df_clean['rejection_binary'] = (df_clean['loan_application_rejections'] > 0).astype(int)

# Covariates: credit_score_index, annual_income_bracket, total_applications_reviewed
# Using clustered standard errors by loan_officer_id to account for individual officer bias
formula = 'rejection_binary ~ risk_evaluator_score + credit_score_index + annual_income_bracket + total_applications_reviewed'
model = smf.logit(formula, data=df_clean)
result = model.fit(disp=0, cov_type='cluster', cov_kwds={'groups': df_clean['loan_officer_id']})

# 4. Compute primary estimand
# Effect is Odds Ratio
coef = result.params['risk_evaluator_score']
se = result.bse['risk_evaluator_score']
p_val = result.pvalues['risk_evaluator_score']
conf_int = result.conf_int().loc['risk_evaluator_score']

# 5. Output JSON
output = {
    "effect_size": float(np.exp(coef)),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(np.exp(conf_int[0])),
    "ci_upper": float(np.exp(conf_int[1])),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "logistic",
    "predictor_used": "risk_evaluator_score (mean of alpha and beta)",
    "covariates_included": ["credit_score_index", "annual_income_bracket", "total_applications_reviewed"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "dropped rows with missing risk_evaluator_score, credit_score_index, or annual_income_bracket"
}

print(json.dumps(output))