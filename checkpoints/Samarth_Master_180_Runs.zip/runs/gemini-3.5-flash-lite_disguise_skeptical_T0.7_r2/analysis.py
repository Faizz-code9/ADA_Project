import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_disguise_skeptical_T0.7_r2/data.csv"
df = pd.read_csv(file_path)

# 2. Data preparation
# Create main continuous risk predictor: average of alpha and beta scores
df['risk_score'] = df[['risk_evaluator_alpha_score', 'risk_evaluator_beta_score']].mean(axis=1)

# Ensure binary or count outcome: loan_application_rejections
# Since outcome is a count (min 0, max 2), let's use Poisson or Logistic. 
# The primary estimand asks for ratio effect of continuous risk evaluator score (0-1) on loan_application_rejections.
# We will use Poisson regression with robust standard errors (clustered by loan_officer_id) to model the incidence rate ratio (IRR).

# Drop rows missing critical variables for the model
model_vars = ['loan_application_rejections', 'risk_score', 'credit_score_index', 'annual_income_bracket', 'loan_officer_id']
df_clean = df.dropna(subset=model_vars).copy()

# 3. Fit statistical model (Poisson regression with clustered SEs)
formula = 'loan_application_rejections ~ risk_score + credit_score_index + annual_income_bracket'
model = smf.gee(
    formula, 
    data=df_clean, 
    groups=df_clean['loan_officer_id'], 
    family=sm.families.Poisson()
)
result = model.fit()

# 4. Extract primary estimand (risk_score coefficient -> IRR)
coef = result.params['risk_score']
se = result.bse['risk_score']
p_val = result.pvalues['risk_score']
ci = result.conf_int().loc['risk_score']

irr = np.exp(coef)
ci_lower = np.exp(ci[0])
ci_upper = np.exp(ci[1])

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
  "effect_size": float(irr),
  "effect_type": "irr",
  "standard_error": float(se),
  "p_value": float(p_val),
  "ci_lower": float(ci_lower),
  "ci_upper": float(ci_upper),
  "conclusion": conclusion,
  "model_family": "gee",
  "predictor_used": "risk_score (mean of risk_evaluator_alpha_score and risk_evaluator_beta_score)",
  "covariates_included": ["credit_score_index", "annual_income_bracket"],
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "gee",
  "exclusions_applied": "Dropped rows with missing values in outcome, risk_score, credit_score_index, or annual_income_bracket."
}

print(json.dumps(output))