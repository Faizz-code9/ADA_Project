import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load dataset
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_placebo_neutral_T0.7_r1/data.csv"
df = pd.read_csv(file_path)

# 2. Data Preparation
# Average rater1 and rater2 for skin tone continuous measure (0-1)
df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)

# Listwise deletion for key variables
cols_to_check = ['redCards', 'skin_tone', 'meanIAT', 'height', 'weight']
df_clean = df.dropna(subset=cols_to_check).copy()

# 3. Model Fitting
# Poisson regression for count outcome (redCards), adjusting for games played as exposure
# or including games as a covariate. Let's use Poisson with log(games) as exposure or control for games.
# Controlling for games, meanIAT, height, weight.
formula = 'redCards ~ skin_tone + meanIAT + height + weight + np.log(games + 1)'
model = smf.poisson(formula, data=df_clean)
results = model.fit(disp=False)

# 4. Extract primary estimand (skin_tone)
coef = results.params['skin_tone']
se = results.bse['skin_tone']
p_val = results.pvalues['skin_tone']
conf_int = results.conf_int().loc['skin_tone']

# Ratio effect: IRR (Incidence Rate Ratio)
irr = np.exp(coef)
ci_lower = np.exp(conf_int[0])
ci_upper = np.exp(conf_int[1])

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "skin_tone",
    "covariates_included": ["meanIAT", "height", "weight", "games"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "Dropped rows with missing skin_tone, redCards, meanIAT, height, or weight."
}

print(json.dumps(output))