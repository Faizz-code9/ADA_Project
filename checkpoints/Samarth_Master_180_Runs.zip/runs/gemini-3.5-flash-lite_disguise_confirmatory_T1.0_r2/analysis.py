import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load dataset
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_disguise_confirmatory_T1.0_r2/data.csv"
df = pd.read_csv(file_path)

# 2. Data Preparation & Cleaning
# Primary outcome: loan_application_rejections (count or binary; let's treat as binary / Poisson)
# Primary predictor: risk_evaluator_alpha_score (or create a composite, let's use risk_evaluator_alpha_score continuous 0-1)
# Missing data strategy: listwise deletion for variables used in regression
model_vars = ['loan_application_rejections', 'risk_evaluator_alpha_score', 'credit_score_index', 'annual_income_bracket']
df_clean = df.dropna(subset=model_vars).copy()

# Ensure outcome is non-negative integer
df_clean['loan_application_rejections'] = df_clean['loan_application_rejections'].astype(int)

# 3. Model Fitting (Poisson / Logistic regression for count/binary outcome)
# Using Poisson regression as loan_application_rejections can take values 0, 1, 2 (ratio effect / IRR)
formula = 'loan_application_rejections ~ risk_evaluator_alpha_score + credit_score_index + annual_income_bracket'
model = smf.poisson(formula, data=df_clean).fit(disp=False)

# 4. Extract Estimates
coef = model.params['risk_evaluator_alpha_score']
se = model.bse['risk_evaluator_alpha_score']
pval = model.pvalues['risk_evaluator_alpha_score']
ci = model.conf_int().loc['risk_evaluator_alpha_score']

irr = np.exp(coef)
ci_lower = np.exp(ci[0])
ci_upper = np.exp(ci[1])

conclusion = "significant_effect" if pval < 0.05 else "no_significant_effect"

output = {
  "effect_size": float(irr),
  "effect_type": "irr",
  "standard_error": float(se),
  "p_value": float(pval),
  "ci_lower": float(ci_lower),
  "ci_upper": float(ci_upper),
  "conclusion": conclusion,
  "model_family": "poisson",
  "predictor_used": "risk_evaluator_alpha_score",
  "covariates_included": ["credit_score_index", "annual_income_bracket"],
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "none",
  "exclusions_applied": "Rows with missing risk_evaluator_alpha_score, credit_score_index, or annual_income_bracket removed."
}

print(json.dumps(output))