import pandas as pd
import numpy as np
import statsmodels.formula.api as smf
import json

# 1. Load data
file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_placebo_confirmatory_T0.0_r1/data.csv'
df = pd.read_csv(file_path)

# 2. Clean and prepare
# Exclude rows where skin tone ratings are missing
df = df.dropna(subset=['rater1', 'rater2', 'position'])
# Construct skin tone variable
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2
# Ensure outcome is binary
df['red_card_binary'] = (df['redCards'] > 0).astype(int)

# Ensure the grouping variable (refNum) is compatible with statsmodels clustering
# It must be an integer or categorical index that matches the dataframe length
df['refNum'] = df['refNum'].astype(int)

# 3. Fit model
# Using Logistic Regression. 
# Note: statsmodels cluster robust covariance requires the groups to be passed correctly.
# We use the 'cov_type' parameter in fit().
formula = 'red_card_binary ~ skin_tone + games + C(position) + C(leagueCountry)'
model = smf.logit(formula, data=df)

# 4. Compute estimand
# We use 'cluster' and pass the groups array directly.
results = model.fit(cov_type='cluster', cov_kwds={'groups': df['refNum']}, disp=0)

params = results.params
conf = results.conf_int()
p_val = results.pvalues['skin_tone']
effect_size = np.exp(params['skin_tone'])
ci_lower = np.exp(conf.loc['skin_tone', 0])
ci_upper = np.exp(conf.loc['skin_tone', 1])

# 5. Output JSON
output = {
    "effect_size": float(effect_size),
    "effect_type": "odds_ratio",
    "standard_error": float(results.bse['skin_tone']),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "logistic",
    "predictor_used": "average of rater1 and rater2",
    "covariates_included": ["games", "position", "leagueCountry"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "rows with missing rater1, rater2, or position values"
}

print(json.dumps(output))