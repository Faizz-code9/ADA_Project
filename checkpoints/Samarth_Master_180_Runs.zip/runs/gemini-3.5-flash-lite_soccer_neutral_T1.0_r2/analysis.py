import json
import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_soccer_neutral_T1.0_r2/data.csv"
df = pd.read_csv(file_path)

# 2. Data preparation
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2

# Listwise deletion for regression variables and ensure complete alignment
cols_to_use = ['skin_tone', 'redCards', 'games', 'meanIAT', 'height', 'weight', 'refNum']
subset = df.dropna(subset=cols_to_use).copy()

# Add log(games) as exposure offset for Poisson model
subset['log_games'] = np.log(subset['games'])

# Ensure refNum is integer and contiguous/valid for bincount if needed, or convert to category codes
subset['refNum_code'] = subset['refNum'].astype('category').cat.codes

# 3. Fit Poisson model with robust standard errors clustered by referee code
formula = 'redCards ~ skin_tone + meanIAT + height + weight'
model = smf.glm(
    formula=formula,
    data=subset,
    family=sm.families.Poisson(),
    offset=subset['log_games']
)

# Fit with robust covariance clustered by refNum_code
results = model.fit(cov_type='cluster', cov_kwds={'groups': subset['refNum_code']})

# 4. Extract primary estimand (skin_tone coefficient -> IRR)
coef = results.params['skin_tone']
se = results.bse['skin_tone']
pval = results.pvalues['skin_tone']
ci = results.conf_int().loc['skin_tone']

irr = np.exp(coef)
ci_lower = np.exp(ci[0])
ci_upper = np.exp(ci[1])

conclusion = 'significant_effect' if pval < 0.05 else 'no_significant_effect'

output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(pval),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "skin_tone",
    "covariates_included": ["meanIAT", "height", "weight"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "Removed rows with missing skin_tone, games, redCards, meanIAT, height, weight, or refNum"
}

print(json.dumps(output))