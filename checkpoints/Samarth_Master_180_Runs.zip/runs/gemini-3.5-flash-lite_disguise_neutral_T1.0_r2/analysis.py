import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load dataset
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_disguise_neutral_T1.0_r2/data.csv"
df = pd.read_csv(file_path)

# 2. Data preparation & cleaning
# Primary predictor: risk_evaluator_alpha_score (continuous 0-1)
# Outcome: loan_application_rejections (0, 1, 2, etc.)
# Since loan_application_rejections is count-like (or binary/ordinal), we can use Poisson or Logistic. 
# The prompt asks for a ratio effect of continuous risk evaluator score on loan_application_rejections.
# We'll use Poisson regression (giving Incidence Rate Ratios, IRR).

# Let's construct a clean subset for the variables of interest
sub_cols = ['loan_application_rejections', 'risk_evaluator_alpha_score', 'credit_score_index', 'annual_income_bracket', 'prior_approved_loans', 'prior_denied_loans']
df_clean = df.dropna(subset=sub_cols).copy()

# Ensure binary/rejection as integer
df_clean['loan_application_rejections'] = df_clean['loan_application_rejections'].astype(int)

# 3. Fit Poisson regression model
formula = 'loan_application_rejections ~ risk_evaluator_alpha_score + credit_score_index + annual_income_bracket + prior_approved_loans + prior_denied_loans'
model = smf.poisson(formula, data=df_clean).fit(disp=False)

# 4. Extract estimates
params = model.params
conf = model.conf_int()

effect_size = float(np.exp(params['risk_evaluator_alpha_score']))
std_err = float(model.bse['risk_evaluator_alpha_score'])
p_val = float(model.pvalues['risk_evaluator_alpha_score'])
ci_lower = float(np.exp(conf.loc['risk_evaluator_alpha_score', 0]))
ci_upper = float(np.exp(conf.loc['risk_evaluator_alpha_score', 1]))

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
  "effect_size": effect_size,
  "effect_type": "irr",
  "standard_error": std_err,
  "p_value": p_val,
  "ci_lower": ci_lower,
  "ci_upper": ci_upper,
  "conclusion": conclusion,
  "model_family": "poisson",
  "predictor_used": "risk_evaluator_alpha_score",
  "covariates_included": ["credit_score_index", "annual_income_bracket", "prior_approved_loans", "prior_denied_loans"],
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "none",
  "exclusions_applied": "Dropped rows with missing values in risk evaluator or covariate fields."
}

print(json.dumps(output))