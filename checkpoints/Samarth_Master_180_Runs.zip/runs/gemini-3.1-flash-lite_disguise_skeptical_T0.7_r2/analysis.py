import pandas as pd
import numpy as np
import statsmodels.formula.api as smf
import statsmodels.api as sm
import json

# 1. Load data
file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_disguise_skeptical_T0.7_r2/data.csv'
df = pd.read_csv(file_path)

# 2. Prepare data
# Construct predictor: mean of alpha and beta scores
df['risk_score'] = df[['risk_evaluator_alpha_score', 'risk_evaluator_beta_score']].mean(axis=1)

# Drop missing values for required variables
df = df.dropna(subset=['risk_score', 'credit_score_index', 'annual_income_bracket', 'loan_officer_id'])

# Define outcome as binary indicator
df['rejection_binary'] = (df['loan_application_rejections'] > 0).astype(int)

# 3. Fit model
# Using GEE for clustered data; sm.families.Binomial() is the correct attribute
fam = sm.families.Binomial()
ind = sm.cov_struct.Exchangeable()
model = smf.gee(
    "rejection_binary ~ risk_score + credit_score_index + annual_income_bracket + prior_approved_loans",
    groups="loan_officer_id",
    data=df,
    family=fam,
    cov_struct=ind
)
result = model.fit()

# 4. Compute estimands
effect_size = result.params['risk_score']
std_err = result.bse['risk_score']
p_val = result.pvalues['risk_score']
ci_lower = result.conf_int().loc['risk_score', 0]
ci_upper = result.conf_int().loc['risk_score', 1]

# 5. Output result
output = {
    "effect_size": float(effect_size),
    "effect_type": "log_odds",
    "standard_error": float(std_err),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "gee",
    "predictor_used": "mean of risk_evaluator_alpha_score and risk_evaluator_beta_score",
    "covariates_included": ["credit_score_index", "annual_income_bracket", "prior_approved_loans"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "gee",
    "exclusions_applied": "removed rows with NaN in risk scores, credit score, income, or officer ID"
}

print(json.dumps(output))