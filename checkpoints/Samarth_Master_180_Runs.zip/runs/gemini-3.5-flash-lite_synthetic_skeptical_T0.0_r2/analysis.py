import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_synthetic_skeptical_T0.0_r2/data.csv"
df = pd.read_csv(file_path)

# 2. Clean and prepare data
# Missing data strategy: listwise deletion for skin_tone (the primary predictor)
df = df.dropna(subset=['skin_tone']).copy()

# Exposure handling for rate data: use log(games) as offset. Ensure games > 0.
df = df[df['games'] > 0].copy()
df['log_games'] = np.log(df['games'])

# 3. Fit Poisson regression model (Ratio effect on count outcome with exposure offset)
# Adjusting for basic covariates: position, height, weight, leagueCountry, yellowCards
formula = 'redCards ~ skin_tone + yellowCards + height + weight + C(position) + C(leagueCountry)'
model = smf.poisson(formula=formula, data=df, offset=df['log_games'])
results = model.fit(disp=False)

# 4. Extract primary estimand (skin_tone)
coef = results.params['skin_tone']
se = results.bse['skin_tone']
p_val = results.pvalues['skin_tone']
ci = results.conf_int().loc['skin_tone']

# Effect type is 'irr' (incidence rate ratio) since it's a Poisson model with offset
effect_size = np.exp(coef)
ci_lower = np.exp(ci[0])
ci_upper = np.exp(ci[1])

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
  "effect_size": float(effect_size),
  "effect_type": "irr",
  "standard_error": float(se), # Note: se of log(IRR), standard report format
  "p_value": float(p_val),
  "ci_lower": float(ci_lower),
  "ci_upper": float(ci_upper),
  "conclusion": conclusion,
  "model_family": "poisson",
  "predictor_used": "skin_tone",
  "covariates_included": ["yellowCards", "height", "weight", "position", "leagueCountry"],
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "none",
  "exclusions_applied": "Dropped rows with missing skin_tone and 0 games."
}

print(json.dumps(output))