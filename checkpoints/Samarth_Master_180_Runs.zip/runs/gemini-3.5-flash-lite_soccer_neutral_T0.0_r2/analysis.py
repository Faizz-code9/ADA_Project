import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_soccer_neutral_T0.0_r2/data.csv"
df = pd.read_csv(file_path)

# 2. Prepare data
# Construct skin tone predictor as the average of rater1 and rater2
df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)

# Drop rows with missing values in key variables for listwise deletion
subset_cols = ['redCards', 'skin_tone', 'meanIAT', 'height', 'weight']
df_clean = df.dropna(subset=subset_cols).copy()

# Exclusions applied description
exclusions_applied = f"Listwise deletion on {subset_cols}, removed {len(df) - len(df_clean)} rows."

# 3. Fit statistical model (Poisson regression for count outcome 'redCards')
formula = 'redCards ~ skin_tone + meanIAT + height + weight'
model = smf.poisson(formula, data=df_clean)
result = model.fit(disp=False)

# 4. Compute primary estimand and statistics
# The coefficient for skin_tone in Poisson regression represents log(IRR).
# Exponentiating gives the Incidence Rate Ratio (IRR).
beta = result.params['skin_tone']
se = result.bse['skin_tone']
p_value = result.pvalues['skin_tone']
ci_lower_log, ci_upper_log = result.conf_int().loc['skin_tone']

effect_size = np.exp(beta)
ci_lower = np.exp(ci_lower_log)
ci_upper = np.exp(ci_upper_log)

conclusion = "significant_effect" if p_value < 0.05 else "no_significant_effect"

# 5. Output JSON
output = {
  "effect_size": float(effect_size),
  "effect_type": "irr",
  "standard_error": float(se),
  "p_value": float(p_value),
  "ci_lower": float(ci_lower),
  "ci_upper": float(ci_upper),
  "conclusion": conclusion,
  "model_family": "poisson",
  "predictor_used": "skin_tone (average of rater1 and rater2)",
  "covariates_included": ["meanIAT", "height", "weight"],
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "none",
  "exclusions_applied": exclusions_applied
}

print(json.dumps(output))