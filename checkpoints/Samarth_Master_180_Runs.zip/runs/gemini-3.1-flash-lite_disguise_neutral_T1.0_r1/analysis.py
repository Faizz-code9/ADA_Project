import pandas as pd
import numpy as np
import statsmodels.formula.api as smf
import json
import sys

# 1. Load the data
file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_disguise_neutral_T1.0_r1/data.csv'
df = pd.read_csv(file_path)

# 2. Data Cleaning and Variable Construction
# Predictor: risk evaluator score (using average of alpha and beta as the composite measure)
df['risk_score'] = df[['risk_evaluator_alpha_score', 'risk_evaluator_beta_score']].mean(axis=1)

# Drop rows missing the target or key predictor
df = df.dropna(subset=['loan_application_rejections', 'risk_score', 'credit_score_index', 'annual_income_bracket'])

# The dependent variable is count of rejections (0, 1, 2). 
# Using Poisson regression to model the intensity of rejections.
# Adjusting for credit score and income as primary controls.

model = smf.poisson(
    "loan_application_rejections ~ risk_score + credit_score_index + annual_income_bracket", 
    data=df
).fit(cov_type='cluster', cov_kwds={'groups': df['loan_officer_id']})

# Extract statistics
params = model.params
bse = model.bse
pvalues = model.pvalues
conf_int = model.conf_int()

# Primary estimand: effect of risk_score
effect = params['risk_score']
std_err = bse['risk_score']
p_val = pvalues['risk_score']
ci_low = conf_int.loc['risk_score', 0]
ci_high = conf_int.loc['risk_score', 1]

# 3. Format output
result = {
    "effect_size": float(np.exp(effect)),  # IRR (Incident Rate Ratio)
    "effect_type": "irr",
    "standard_error": float(std_err),
    "p_value": float(p_val),
    "ci_lower": float(np.exp(ci_low)),
    "ci_upper": float(np.exp(ci_high)),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "poisson",
    "predictor_used": "average of risk_evaluator_alpha_score and risk_evaluator_beta_score",
    "covariates_included": ["credit_score_index", "annual_income_bracket"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "rows with missing risk scores or demographics were removed"
}

print(json.dumps(result))