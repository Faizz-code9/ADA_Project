import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

# 1. Load data
df = pd.read_csv('/kaggle/working/outputs/runs/gemini-3.1-flash-lite_soccer_neutral_T0.7_r5/data.csv')

# 2. Clean and prepare data
# Drop rows where skin tone ratings are missing
df = df.dropna(subset=['rater1', 'rater2'])

# Create continuous skin tone variable (average of rater1 and rater2)
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2

# Exclude rows with missing essential covariates for the model
df = df.dropna(subset=['games', 'yellowCards', 'refNum'])

# 3. Fit statistical model
# Using Poisson regression for count data (redCards)
# Controlling for games, yellowCards, and clustering by refNum
formula = 'redCards ~ skin_tone + games + yellowCards'
model = smf.glm(formula=formula, data=df, family=sm.families.Poisson()).fit(
    cov_type='cluster', cov_kwds={'groups': df['refNum']}
)

# 4. Compute primary estimand
# IRR = exp(coefficient)
coef = model.params['skin_tone']
se = model.bse['skin_tone']
conf = model.conf_int().loc['skin_tone']
p_val = model.pvalues['skin_tone']

# 5. Format Output
result = {
    "effect_size": np.exp(coef),
    "effect_type": "irr",
    "standard_error": se,
    "p_value": p_val,
    "ci_lower": np.exp(conf[0]),
    "ci_upper": np.exp(conf[1]),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "poisson",
    "predictor_used": "mean of rater1 and rater2",
    "covariates_included": ["games", "yellowCards"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "rows with missing rater1, rater2, games, yellowCards, or refNum"
}

print(json.dumps(result))