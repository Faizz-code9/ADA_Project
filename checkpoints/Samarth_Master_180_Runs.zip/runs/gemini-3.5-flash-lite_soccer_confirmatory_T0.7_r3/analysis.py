import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_soccer_confirmatory_T0.7_r3/data.csv"
df = pd.read_csv(file_path)

# 2. Prepare data and variables
# Skin tone predictor: average of rater1 and rater2
df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)

# Drop rows missing key variables for regression
model_vars = ['redCards', 'skin_tone', 'games', 'yellowCards', 'meanIAT', 'height', 'weight']
df_clean = df.dropna(subset=model_vars).copy()

# 3. Fit Poisson regression model with robust standard errors (clustered by player/ref if possible, or just robust)
# Using generalized linear model (Poisson) with robust covariance (HC1) to handle count nature of red cards and potential overdispersion/clustering
formula = 'redCards ~ skin_tone + games + yellowCards + meanIAT + height + weight'

# Fit GLM Poisson
try:
    model = smf.glm(formula, data=df_clean, family=sm.families.Poisson()).fit(cov_type='HC1')
    
    effect_size = np.exp(model.params['skin_tone'])
    std_err = model.bse['skin_tone']  # SE on log scale, IRR SE can be approximated or reported via log scale. Let's report coefficient log_odds/irr log scale? Wait, effect_type is 'irr'.
    # For Poisson, IRR = exp(beta). Delta method for SE of IRR: IRR * SE(beta).
    irr_se = effect_size * std_err
    p_val = model.pvalues['skin_tone']
    ci_low = np.exp(model.conf_int().loc['skin_tone', 0])
    ci_up = np.exp(model.conf_int().loc['skin_tone', 1])
    
    model_family = 'poisson'
    effect_type = 'irr'
    
    # If standard error is requested for the effect size scale:
    standard_error = irr_se
    
    conclusion = 'significant_effect' if p_val < 0.05 else 'no_significant_effect'

except Exception as e:
    # Fallback to OLS if GLM fails
    model = smf.ols(formula, data=df_clean).fit(cov_type='HC1')
    effect_size = model.params['skin_tone']
    standard_error = model.bse['skin_tone']
    p_val = model.pvalues['skin_tone']
    ci_low = model.conf_int().loc['skin_tone', 0]
    ci_up = model.conf_int().loc['skin_tone', 1]
    model_family = 'ols'
    effect_type = 'coefficient'
    conclusion = 'significant_effect' if p_val < 0.05 else 'no_significant_effect'

output = {
    "effect_size": float(effect_size),
    "effect_type": effect_type,
    "standard_error": float(standard_error),
    "p_value": float(p_val),
    "ci_lower": float(ci_low),
    "ci_upper": float(ci_up),
    "conclusion": conclusion,
    "model_family": model_family,
    "predictor_used": "skin_tone (average of rater1 and rater2)",
    "covariates_included": ["games", "yellowCards", "meanIAT", "height", "weight"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "dropped rows with missing skin_tone, redCards, games, yellowCards, meanIAT, height, or weight"
}

print(json.dumps(output))