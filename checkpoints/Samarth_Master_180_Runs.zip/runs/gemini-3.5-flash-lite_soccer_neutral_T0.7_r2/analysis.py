import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_soccer_neutral_T0.7_r2/data.csv"
df = pd.read_csv(file_path)

# 2. Prepare data
# Average rater1 and rater2 to get a continuous skin tone score (0 to 1)
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2.0

# Exclude rows where skin tone or redCards are missing (listwise deletion)
df_clean = df.dropna(subset=['skin_tone', 'redCards', 'games']).copy()

# Poisson regression (or Negative Binomial) is standard for count data like red cards.
# Since exposure/games vary, we can include log(games) as an exposure term (offset).
df_clean['log_games'] = np.log(df_clean['games'])

# Model specification
formula = 'redCards ~ skin_tone + meanIAT + meanExp + height + weight + offset(log_games)'

# 3. Fit model
# Using Poisson with robust standard errors clustered by referee (refNum) to handle dependencies
try:
    model = smf.poisson(formula, data=df_clean).fit(cov_type='cluster', cov_kwds={'groups': df_clean['refNum']}, disp=0)
    model_family = 'poisson'
    clustering_strategy = 'clustered_se'
except Exception:
    # Fallback to standard OLS if Poisson fails to converge
    model = smf.ols('redCards ~ skin_tone + meanIAT + meanExp + height + weight', data=df_clean).fit(cov_type='HC1')
    model_family = 'ols'
    clustering_strategy = 'none'

# 4. Extract primary estimand
param_name = 'skin_tone'
effect_size = float(np.exp(model.params[param_name])) if model_family == 'poisson' else float(model.params[param_name])
effect_type = 'irr' if model_family == 'poisson' else 'coefficient'
se = float(model.bse[param_name])
p_val = float(model.pvalues[param_name])
ci = model.conf_int()
ci_lower = float(np.exp(ci.loc[param_name, 0])) if model_family == 'poisson' else float(ci.loc[param_name, 0])
ci_upper = float(np.exp(ci.loc[param_name, 1])) if model_family == 'poisson' else float(ci.loc[param_name, 1])

conclusion = 'significant_effect' if p_val < 0.05 else 'no_significant_effect'

output = {
    "effect_size": effect_size,
    "effect_type": effect_type,
    "standard_error": se,
    "p_value": p_val,
    "ci_lower": ci_lower,
    "ci_upper": ci_upper,
    "conclusion": conclusion,
    "model_family": model_family,
    "predictor_used": "skin_tone",
    "covariates_included": ["meanIAT", "meanExp", "height", "weight"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": clustering_strategy,
    "exclusions_applied": "Dropped rows with missing skin_tone, redCards, or games."
}

print(json.dumps(output))