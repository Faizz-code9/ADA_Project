import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_soccer_neutral_T0.7_r1/data.csv"
df = pd.read_csv(file_path)

# 2. Prepare data
# Construct skin tone predictor as the average of rater1 and rater2
df['skinTone'] = (df['rater1'] + df['rater2']) / 2

# Drop missing values for key variables used in the model
subset_cols = ['redCards', 'skinTone', 'yellowCards', 'refNum']
df_clean = df.dropna(subset=subset_cols).copy()

exclusions_applied = f"Listwise deletion on {subset_cols}, dropped {len(df) - len(df_clean)} rows."

# 3. Model Fitting using GEE with correct covariance structure import
model = smf.gee(
    "redCards ~ skinTone + yellowCards",
    "refNum",
    data=df_clean,
    family=sm.families.Poisson(),
    cov_struct=sm.genmod.cov_struct.Exchangeable()
)
result = model.fit()

# 4. Extract Estimand & Statistics
beta = result.params['skinTone']
se = result.bse['skinTone']
p_val = result.pvalues['skinTone']
ci = result.conf_int().loc['skinTone']

irr = np.exp(beta)
ci_lower = np.exp(ci[0])
ci_upper = np.exp(ci[1])

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

# 5. Output JSON
output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "gee",
    "predictor_used": "skinTone (average of rater1 and rater2)",
    "covariates_included": ["yellowCards"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "gee",
    "exclusions_applied": exclusions_applied
}

print(json.dumps(output))