import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_soccer_neutral_T1.0_r4/data.csv"
df = pd.read_csv(file_path)

# 2. Data preparation
# Average the two raters for skin tone
df["skin_tone"] = df[["rater1", "rater2"]].mean(axis=1)

# Listwise deletion on necessary variables
vars_to_use = ["redCards", "skin_tone", "games", "yellowCards", "meanIAT"]
df_clean = df.dropna(subset=vars_to_use).copy()

# 3. Model Fitting
# Using a Poisson regression model for count outcome (redCards), adjusting for games played, yellowCards, and meanIAT
formula = "redCards ~ skin_tone + yellowCards + meanIAT + np.log(games)"
model = smf.poisson(formula, data=df_clean).fit(disp=False)

# 4. Extract Estimand and Statistics
# Coefficient for skin_tone in Poisson regression represents log(IRR)
effect_size = np.exp(model.params["skin_tone"])
std_err = model.bse["skin_tone"]
p_val = model.pvalues["skin_tone"]
ci = model.conf_int().loc["skin_tone"]
ci_lower = np.exp(ci[0])
ci_upper = np.exp(ci[1])

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

# 5. Format Output
result = {
    "effect_size": float(effect_size),
    "effect_type": "irr",
    "standard_error": float(std_err),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "skin_tone (average of rater1 and rater2)",
    "covariates_included": ["yellowCards", "meanIAT", "games"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "Removed rows with missing values in redCards, skin_tone, games, yellowCards, or meanIAT.",
}

print(json.dumps(result))