import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_synthetic_confirmatory_T0.7_r2/data.csv"
df = pd.read_csv(file_path)

# 2. Clean and prepare data
# Missing data strategy: listwise deletion for skin_tone
df_clean = df.dropna(subset=['skin_tone', 'redCards', 'games', 'yellowCards']).copy()
exclusions = "Dropped rows with missing skin_tone (8.0%)"

# Model: Poisson regression for count data (redCards), offset by log(games) to account for exposure.
# Adjusting for position, yellowCards, and clustering by playerID or refereeID using GEE or random intercepts.
# Let's use Poisson regression with robust standard errors clustered by playerID to account for repeated player observations.

df_clean['log_games'] = np.log(df_clean['games'])

# Fit GEE Poisson model
formula = 'redCards ~ skin_tone + yellowCards + C(position)'
fam = sm.families.Poisson()
# Using groups=playerID for clustering
model = smf.gee(formula, 'playerID', data=df_clean, family=fam, vcov='cluster')
result = model.fit()

# Extract parameters for skin_tone
effect_size = float(np.exp(result.params['skin_tone']))  # IRR
std_err = float(result.bse['skin_tone'])
p_val = float(result.pvalues['skin_tone'])
ci = result.conf_int().loc['skin_tone']
ci_lower = float(np.exp(ci[0]))
ci_upper = float(np.exp(ci[1]))

conclusion = 'significant_effect' if p_val < 0.05 else 'no_significant_effect'

output = {
  "effect_size": effect_size,
  "effect_type": "irr",
  "standard_error": std_err,
  "p_value": p_val,
  "ci_lower": ci_lower,
  "ci_upper": ci_upper,
  "conclusion": conclusion,
  "model_family": "gee",
  "predictor_used": "skin_tone",
  "covariates_included": ["yellowCards", "position"],
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "clustered_se",
  "exclusions_applied": exclusions
}

print(json.dumps(output))