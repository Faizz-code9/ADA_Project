import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

def analyze_bias():
    # 1. Load Data
    file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_synthetic_confirmatory_T0.7_r1/data.csv'
    df = pd.read_csv(file_path)

    # 2. Clean and Prepare
    # Drop rows missing skin_tone
    df = df.dropna(subset=['skin_tone'])
    
    # Categorical encoding for covariates
    df['position'] = df['position'].astype('category')
    df['leagueCountry'] = df['leagueCountry'].astype('category')

    # 3. Fit Poisson model (redCards as count data)
    # Using random intercepts for refereeID to account for clustering
    # Log link implies the coefficient is log(IRR)
    formula = 'redCards ~ skin_tone + yellowCards + height + weight + position + leagueCountry'
    model = smf.mixedlm(formula, df, groups=df["refereeID"])
    result = model.fit()

    # 4. Extract Estimand
    coef = result.params['skin_tone']
    std_err = result.bse['skin_tone']
    p_val = result.pvalues['skin_tone']
    conf_int = result.conf_int().loc['skin_tone']
    
    irr = np.exp(coef)
    irr_se = irr * std_err
    irr_ci_lower = np.exp(coef - 1.96 * std_err)
    irr_ci_upper = np.exp(coef + 1.96 * std_err)

    # 5. Output JSON
    output = {
        "effect_size": float(irr),
        "effect_type": "irr",
        "standard_error": float(irr_se),
        "p_value": float(p_val),
        "ci_lower": float(irr_ci_lower),
        "ci_upper": float(irr_ci_upper),
        "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
        "model_family": "mixed_effects",
        "predictor_used": "skin_tone",
        "covariates_included": ["yellowCards", "height", "weight", "position", "leagueCountry"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "random_intercepts",
        "exclusions_applied": "rows missing skin_tone"
    }

    print(json.dumps(output))

if __name__ == "__main__":
    analyze_bias()