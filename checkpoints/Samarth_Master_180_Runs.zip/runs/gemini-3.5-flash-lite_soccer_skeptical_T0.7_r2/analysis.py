import json
import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_soccer_skeptical_T0.7_r2/data.csv"
df = pd.read_csv(file_path)

# 2. Prepare data
df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)

# Drop rows missing essential variables
subset_cols = ['redCards', 'skin_tone', 'games', 'yellowCards', 'meanIAT']
df_clean = df.dropna(subset=subset_cols).copy()

# Add log games directly to dataframe to avoid patsy offset parsing issues
df_clean['log_games'] = np.log(df_clean['games'])

# 3. Fit Model using GLM with Poisson family and log link to correctly support offset
model = sm.GLM.from_formula(
    'redCards ~ skin_tone + yellowCards + meanIAT + log_games', 
    data=df_clean,
    family=sm.families.Poisson()
).fit(cov_type='HC1')

# 4. Extract Estimand (Ratio effect -> IRR = exp(coefficient))
coef = model.params['skin_tone']
se = model.bse['skin_tone']
p_val = model.pvalues['skin_tone']
ci = model.conf_int().loc['skin_tone']
irr = np.exp(coef)
ci_lower = np.exp(ci[0])
ci_upper = np.exp(ci[1])

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
  "effect_size": float(irr),
  "effect_type": "irr",
  "standard_error": float(se),
  "p_value": float(p_val),
  "ci_lower": float(ci_lower),
  "ci_upper": float(ci_upper),
  "conclusion": conclusion,
  "model_family": "poisson",
  "predictor_used": "skin_tone",
  "covariates_included": ["yellowCards", "meanIAT", "log_games"],
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "clustered_se",
  "exclusions_applied": "Dropped rows with missing redCards, skin_tone, games, yellowCards, or meanIAT"
}

print(json.dumps(output))