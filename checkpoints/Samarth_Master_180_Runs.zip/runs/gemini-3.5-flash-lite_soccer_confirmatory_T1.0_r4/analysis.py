import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_soccer_confirmatory_T1.0_r4/data.csv"
df = pd.read_csv(file_path)

# 2. Prepare predictor and outcome
# Skin tone: average of rater1 and rater2
df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)

# Filter out rows with missing skin tone or redCards
df = df.dropna(subset=['skin_tone', 'redCards', 'games'])

# Offset for exposure (games played) to model rate per game, or include games as covariate/exposure
# Using Poisson regression with log(games) as exposure or just controlling for games.
# Given the prompt asks for ratio effect of continuous skin tone on red cards, we use Poisson regression.

# 3. Model fitting
# We use statsmodels GLM with Poisson family and log link.
# Adjusting for games as exposure (log offset) and some basic covariates like yellowCards if relevant, 
# but let's follow standard specification for this classic dataset (Silz & Simonsohn / Many Analysts):
formula = 'redCards ~ skin_tone + np.log(games)'

model = smf.glm(formula=formula, data=df, family=sm.families.Poisson()).fit()

# Extract parameters for skin_tone
coef = model.params['skin_tone']
se = model.bse['skin_tone']
pval = model.pvalues['skin_tone']
ci = model.conf_int().loc['skin_tone']

# Ratio effect -> Incidence Rate Ratio (IRR) = exp(coef)
effect_size = np.exp(coef)
ci_lower = np.exp(ci[0])
ci_upper = np.exp(ci[1])

conclusion = "significant_effect" if pval < 0.05 else "no_significant_effect"

output = {
  "effect_size": float(effect_size),
  "effect_type": "irr",
  "standard_error": float(se), # Note: standard error of the log coefficient or approx; standard practice for IRR is reporting coefficient SE or delta method. Here we report coefficient SE or transformed? Usually effect_size is IRR, standard_error can be reported for the log scale or transformed. Let's provide coefficient SE or standard error of log scale.
  "p_value": float(pval),
  "ci_lower": float(ci_lower),
  "ci_upper": float(ci_upper),
  "conclusion": conclusion,
  "model_family": "poisson",
  "predictor_used": "skin_tone",
  "covariates_included": ["games"],
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "none",
  "exclusions_applied": "Dropped rows with missing skin_tone or redCards"
}

print(json.dumps(output))