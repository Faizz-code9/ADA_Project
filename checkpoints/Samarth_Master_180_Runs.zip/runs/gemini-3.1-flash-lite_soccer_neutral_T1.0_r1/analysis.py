import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.1-flash-lite_soccer_neutral_T1.0_r1/data.csv"
df = pd.read_csv(file_path)

# 2. Clean and prepare data
# Remove missing values for predictors and outcome
df = df.dropna(subset=['rater1', 'rater2', 'redCards', 'refNum', 'games', 'height', 'weight', 'meanIAT'])
# Construct skin tone measure (average of two raters)
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2

# Ensure refNum is numeric for clustering
df['refNum'] = df['refNum'].astype(int)

# 3. Fit model
# Using Poisson regression with robust clustered standard errors.
# To resolve the grouping issue, we use the GLM's cov_type functionality properly.
model = smf.glm(
    "redCards ~ skin_tone + games + height + weight + meanIAT", 
    data=df, 
    family=sm.families.Poisson()
)

# Fit model and specify clustering
res = model.fit(cov_type='cluster', cov_kwds={'groups': df['refNum']})

# 4. Compute quantities
params = res.params
se = res.bse
pvalues = res.pvalues
conf = res.conf_int()

# Target: effect of skin tone
effect_size = params['skin_tone']
std_err = se['skin_tone']
p_val = pvalues['skin_tone']
ci_low = conf.loc['skin_tone', 0]
ci_high = conf.loc['skin_tone', 1]

# 5. Output JSON
result = {
    "effect_size": float(effect_size),
    "effect_type": "coefficient",
    "standard_error": float(std_err),
    "p_value": float(p_val),
    "ci_lower": float(ci_low),
    "ci_upper": float(ci_high),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "poisson",
    "predictor_used": "average of rater1 and rater2",
    "covariates_included": ["games", "height", "weight", "meanIAT"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "rows with missing values in predictors, outcome, or covariates"
}

print(json.dumps(result))