import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

# 1. Load data
file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_disguise_confirmatory_T0.0_r2/data.csv'
df = pd.read_csv(file_path)

# 2. Clean and prepare
# Primary predictor: average of alpha and beta scores (0-1 scale)
df['risk_score'] = df[['risk_evaluator_alpha_score', 'risk_evaluator_beta_score']].mean(axis=1)

# Exclusions: Drop rows where risk_score is missing (14.7% of data)
df_clean = df.dropna(subset=['risk_score', 'credit_score_index', 'annual_income_bracket']).copy()

# 3. Fit model
# Logistic regression for binary outcome (rejections > 0 treated as 1)
df_clean['rejected'] = (df_clean['loan_application_rejections'] > 0).astype(int)

# Covariates: credit_score_index, annual_income_bracket, prior_denied_loans
formula = 'rejected ~ risk_score + credit_score_index + annual_income_bracket + prior_denied_loans'
model = smf.logit(formula, data=df_clean).fit(disp=0)

# 4. Compute estimand
params = model.params
conf = model.conf_int()
se = model.bse
p_val = model.pvalues['risk_score']

# 5. Prepare JSON output
result = {
    "effect_size": float(np.exp(params['risk_score'])),
    "effect_type": "odds_ratio",
    "standard_error": float(se['risk_score']),
    "p_value": float(p_val),
    "ci_lower": float(np.exp(conf.loc['risk_score', 0])),
    "ci_upper": float(np.exp(conf.loc['risk_score', 1])),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "logistic",
    "predictor_used": "mean of risk_evaluator_alpha_score and risk_evaluator_beta_score",
    "covariates_included": ["credit_score_index", "annual_income_bracket", "prior_denied_loans"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "rows with missing risk_score, credit_score_index, or annual_income_bracket"
}

print(json.dumps(result))