import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

# 1. Load data
df = pd.read_csv('/kaggle/working/outputs/runs/gemini-3.1-flash-lite_synthetic_skeptical_T0.7_r1/data.csv')

# 2. Prepare data
# Exclude missing skin_tone
df_clean = df.dropna(subset=['skin_tone']).copy()

# Ensure games is at least 1 to avoid log(0)
df_clean['log_games'] = np.log(df_clean['games'].replace(0, 1))

# 3. Fit Poisson model
# In statsmodels formula API, offset is handled by passing the offset argument separately
# rather than inside the formula string to avoid Patsy namespace errors.
formula = "redCards ~ skin_tone + C(position) + height + weight + C(leagueCountry)"
model = smf.glm(
    formula=formula, 
    data=df_clean, 
    family=sm.families.Poisson(),
    offset=df_clean['log_games']
).fit()

# 4. Extract metrics
coef = model.params['skin_tone']
se = model.bse['skin_tone']
p_val = model.pvalues['skin_tone']
ci = model.conf_int().loc['skin_tone']

# Calculate IRR (rate ratio)
irr = np.exp(coef)
irr_se = np.exp(coef) * se
irr_ci_lower = np.exp(ci[0])
irr_ci_upper = np.exp(ci[1])

# 5. Output JSON
results = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(irr_se),
    "p_value": float(p_val),
    "ci_lower": float(irr_ci_lower),
    "ci_upper": float(irr_ci_upper),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "poisson",
    "predictor_used": "skin_tone",
    "covariates_included": ["position", "height", "weight", "leagueCountry", "games"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "rows with missing skin_tone (288 rows)"
}

print(json.dumps(results))