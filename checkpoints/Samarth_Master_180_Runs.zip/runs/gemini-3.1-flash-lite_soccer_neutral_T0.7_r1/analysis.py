import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

# 1. Load data
file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_soccer_neutral_T0.7_r1/data.csv'
df = pd.read_csv(file_path)

# 2. Prepare data
# Exclude rows where skin tone is missing (rater1 and rater2 are identical in availability)
df = df.dropna(subset=['rater1', 'rater2'])
# Define skin tone as the average of the two raters
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2.0

# 3. Model Fit
# Use Poisson regression for count data (redCards). 
# Include referee random effects as clusters to account for intra-referee correlation.
# Covariates: position, leagueCountry, and meanIAT for systemic bias.
# Filter out NAs for covariates
cols_to_use = ['redCards', 'skin_tone', 'refNum', 'leagueCountry', 'meanIAT']
df_model = df.dropna(subset=cols_to_use)

model = smf.gee("redCards ~ skin_tone + meanIAT + C(leagueCountry)", 
                data=df_model, 
                groups=df_model['refNum'], 
                family=sm.families.Poisson(),
                cov_struct=sm.cov_struct.Exchangeable())

result = model.fit()

# 4. Extract Estimates
# We are interested in the coefficient of 'skin_tone'
params = result.params
bse = result.bse
conf_int = result.conf_int()

effect_size = params['skin_tone']
std_err = bse['skin_tone']
p_val = result.pvalues['skin_tone']
ci_lower = conf_int.loc['skin_tone', 0]
ci_upper = conf_int.loc['skin_tone', 1]

# 5. Output JSON
output = {
    "effect_size": float(np.exp(effect_size)), # IRR
    "effect_type": "irr",
    "standard_error": float(std_err),
    "p_value": float(p_val),
    "ci_lower": float(np.exp(ci_lower)),
    "ci_upper": float(np.exp(ci_upper)),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "gee",
    "predictor_used": "average of rater1 and rater2",
    "covariates_included": ["meanIAT", "leagueCountry"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "gee",
    "exclusions_applied": "Rows with missing rater1/rater2 or missing covariates"
}

print(json.dumps(output))