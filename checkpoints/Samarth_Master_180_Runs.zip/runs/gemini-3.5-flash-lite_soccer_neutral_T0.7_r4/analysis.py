import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_soccer_neutral_T0.7_r4/data.csv"
df = pd.read_csv(file_path)

# 2. Data preparation
# Average skin tone from rater1 and rater2
df["skin_tone"] = (df["rater1"] + df["rater2"]) / 2.0

# Filter out missing values for key variables to perform listwise deletion
model_vars = ["redCards", "skin_tone", "games", "yellowCards"]
df_clean = df.dropna(subset=model_vars).copy()

# 3. Fit model
# Using a Poisson regression model for count outcome (redCards), adjusting for games played and yellowCards as exposure/covariates.
# To account for clustering by referee or player, standard practice often uses robust SEs or mixed effects.
# Here we use Poisson regression with robust standard errors (HC1) clustered by refNum.
formula = "redCards ~ skin_tone + yellowCards + np.log(games)"

model = smf.poisson(formula, data=df_clean)
results = model.fit(cov_type="cluster", cov_kwds={"groups": df_clean["refNum"]}, disp=False)

# 4. Extract primary estimand (skin_tone coefficient -> IRR)
coef = results.params["skin_tone"]
se = results.bse["skin_tone"]
pval = results.pvalues["skin_tone"]
ci = results.conf_int().loc["skin_tone"]

irr = np.exp(coef)
ci_lower = np.exp(ci[0])
ci_upper = np.exp(ci[1])

conclusion = (
    "significant_effect" if pval < 0.05 else "no_significant_effect"
)

output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(pval),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "skin_tone",
    "covariates_included": ["yellowCards", "games"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "Dropped rows with missing skin_tone, redCards, games, or yellowCards.",
}

print(json.dumps(output))