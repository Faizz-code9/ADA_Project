import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_disguise_neutral_T0.0_r2/data.csv"
df = pd.read_csv(file_path)

# 2. Data preparation & cleaning
# We want to examine loan application rejections against external risk evaluation scores (e.g. risk_evaluator_alpha_score).
# The outcome is `loan_application_rejections`. Let's treat it as binary (0 vs >0) or count, but the prompt says ratio effect of continuous risk evaluator score (0-1) on loan_application_rejections. Since rejections are mostly 0, 1, 2, a Poisson or Logistic model works. Given "ratio effect", Poisson/IRR or Logistic/Odds Ratio is appropriate. Let's use Poisson regression for Incidence Rate Ratio (IRR), or Logistic for Odds Ratio. Let's use Poisson regression (log link) to get an IRR (ratio effect).
# Predictor: risk_evaluator_alpha_score (0 to 1).
# Covariates: credit_score_index, annual_income_bracket, prior_approved_loans, prior_denied_loans.

pred_col = "risk_evaluator_alpha_score"
outcome_col = "loan_application_rejections"

# Ensure binary outcome or count outcome. Let's look at unique values of rejections: 0, 1, 2. Poisson regression handles counts.
covariates = [
    "credit_score_index",
    "annual_income_bracket",
    "prior_approved_loans",
    "prior_denied_loans",
]

sub_cols = [outcome_col, pred_col] + covariates
data_sub = df[sub_cols].dropna()

# 3. Model Fitting
# Using Poisson regression via statsmodels GLM
formula = f"{outcome_col} ~ {pred_col} + credit_score_index + annual_income_bracket + prior_approved_loans + prior_denied_loans"
model = smf.poisson(formula, data=data_sub).fit(disp=False)

# Extract estimates for the predictor
coef = model.params[pred_col]
se = model.bse[pred_col]
p_val = model.pvalues[pred_col]
ci = model.conf_int().loc[pred_col]

irr = np.exp(coef)
ci_lower = np.exp(ci[0])
ci_upper = np.exp(ci[1])

conclusion = (
    "significant_effect" if p_val < 0.05 else "no_significant_effect"
)

output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": pred_col,
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "Rows with missing values in analysis variables were dropped via listwise deletion.",
}

print(json.dumps(output))