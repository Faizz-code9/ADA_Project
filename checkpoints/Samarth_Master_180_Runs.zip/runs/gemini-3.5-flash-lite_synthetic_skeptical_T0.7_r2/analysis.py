import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_synthetic_skeptical_T0.7_r2/data.csv"
df = pd.read_csv(file_path)

# 2. Clean and prepare data
# Missing data strategy: listwise deletion for skin_tone (288 missing)
initial_len = len(df)
df = df.dropna(subset=['skin_tone', 'redCards', 'games', 'yellowCards', 'position', 'leagueCountry'])
exclusions_applied = f"Removed {initial_len - len(df)} rows due to missing values (listwise deletion)."

# Offset for exposure: log(games) to account for exposure time
df['log_games'] = np.log(df['games'])

# 3. Model fit: Poisson regression (or Negative Binomial if overdispersed) with exposure
# Primary estimand: ratio effect of continuous skin_tone on redCards -> Incidence Rate Ratio (IRR)
formula = "redCards ~ skin_tone + yellowCards + height + weight + C(position) + C(leagueCountry)"
model = smf.poisson(formula=formula, data=df, offset=df['log_games']).fit(disp=False)

# Extract parameters
effect_size = np.exp(model.params['skin_tone'])
conf_int = model.conf_int().loc['skin_tone']
ci_lower = np.exp(conf_int[0])
ci_upper = np.exp(conf_int[1])
std_error = model.bse['skin_tone'] * effect_size # Delta method approx for IRR
p_value = model.pvalues['skin_tone']

conclusion = "significant_effect" if p_value < 0.05 else "no_significant_effect"

output = {
  "effect_size": float(effect_size),
  "effect_type": "irr",
  "standard_error": float(std_error),
  "p_value": float(p_value),
  "ci_lower": float(ci_lower),
  "ci_upper": float(ci_upper),
  "conclusion": conclusion,
  "model_family": "poisson",
  "predictor_used": "skin_tone",
  "covariates_included": ["yellowCards", "height", "weight", "position", "leagueCountry", "games (offset)"],
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "none",
  "exclusions_applied": exclusions_applied
}

print(json.dumps(output))