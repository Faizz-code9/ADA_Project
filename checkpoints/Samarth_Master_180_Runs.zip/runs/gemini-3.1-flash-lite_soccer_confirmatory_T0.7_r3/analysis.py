import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

def run_analysis():
    # 1. Load data
    df = pd.read_csv('/kaggle/working/outputs/runs/gemini-3.1-flash-lite_soccer_confirmatory_T0.7_r3/data.csv')

    # 2. Preparation
    # Drop rows where skin tone is missing
    df = df.dropna(subset=['rater1', 'rater2'])
    # Construct skin tone measure
    df['skin_tone'] = (df['rater1'] + df['rater2']) / 2.0
    # Handle missing positions for categorical variable
    df['position'] = df['position'].fillna('Unknown')
    # Ensure games > 0 for log transformation
    df = df[df['games'] > 0].copy()
    df['log_games'] = np.log(df['games'])
    
    # 3. Model Fitting
    # Using GLM with Poisson family and exposure (log_games) added as a fixed covariate
    # to avoid the Patsy 'offset' syntax error.
    formula = 'redCards ~ skin_tone + C(leagueCountry) + C(position) + log_games'
    model = smf.glm(formula, data=df, family=sm.families.Poisson()).fit(
        cov_type='cluster', 
        cov_kwds={'groups': df['refNum']}
    )

    # 4. Extract results
    params = model.params
    bse = model.bse
    conf = model.conf_int()
    
    # Exponentiate coefficient for IRR
    effect_size = np.exp(params['skin_tone'])
    ci_lower = np.exp(conf.loc['skin_tone', 0])
    ci_upper = np.exp(conf.loc['skin_tone', 1])
    p_val = model.pvalues['skin_tone']

    # 5. Output
    results = {
        "effect_size": float(effect_size),
        "effect_type": "irr",
        "standard_error": float(bse['skin_tone']),
        "p_value": float(p_val),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
        "model_family": "poisson",
        "predictor_used": "skin_tone (average of rater1 and rater2)",
        "covariates_included": ["leagueCountry", "position", "log_games"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "clustered_se",
        "exclusions_applied": "rows with missing rater1/rater2 or 0 games"
    }

    print(json.dumps(results))

if __name__ == "__main__":
    run_analysis()