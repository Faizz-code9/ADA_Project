import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_synthetic_neutral_T1.0_r1/data.csv"
df = pd.read_csv(file_path)

# 2. Cleaning and preparation
# Missing data strategy: listwise deletion for missing skin_tone
missing_count = df['skin_tone'].isnull().sum()
exclusions_desc = f"Removed {missing_count} rows due to missing skin_tone." if missing_count > 0 else "none"
df_clean = df.dropna(subset=['skin_tone']).copy()

# Exposure offset: log(games) to model rate per game
df_clean['log_games'] = np.log(df_clean['games'])

# 3. Model Fitting
# Using Poisson regression with an offset for games played to get IRRs
model = smf.poisreg(
    formula='redCards ~ skin_tone + yellowCards + height + weight + C(position) + C(leagueCountry)',
    data=df_clean,
    offset=df_clean['log_games']
) if hasattr(smf, 'poisreg') else None

# Alternatively using GLM Poisson with log link
formula = 'redCards ~ skin_tone + yellowCards + height + weight + C(position) + C(leagueCountry)'
glm_model = smf.glm(
    formula=formula,
    data=df_clean,
    family=sm.families.Poisson(),
    offset=df_clean['log_games']
).fit()

# 4. Compute primary estimand (IRR for skin_tone)
coef = glm_model.params['skin_tone']
se = glm_model.bse['skin_tone']
p_val = glm_model.pvalues['skin_tone']
ci = glm_model.conf_int().loc['skin_tone']

effect_size = np.exp(coef)
ci_lower = np.exp(ci[0])
ci_upper = np.exp(ci[1])
conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

# 5. Output JSON
result = {
    "effect_size": float(effect_size),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "skin_tone",
    "covariates_included": ["yellowCards", "height", "weight", "position", "leagueCountry", "games (offset)"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": exclusions_desc
}

print(json.dumps(result))