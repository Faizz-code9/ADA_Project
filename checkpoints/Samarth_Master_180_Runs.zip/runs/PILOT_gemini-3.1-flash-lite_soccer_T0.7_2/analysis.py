import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

# 1. Load data
file_path = "/kaggle/working/outputs/runs/PILOT_gemini-3.1-flash-lite_soccer_T0.7_2/data.csv"
df = pd.read_csv(file_path)

# 2. Cleaning and preparation
# Drop rows where critical variables contain missing values
# Specifically handle the predictors and covariates used in the model
cols_to_clean = ['rater1', 'rater2', 'meanIAT', 'games', 'leagueCountry', 'refNum']
df = df.dropna(subset=cols_to_clean)

# Create continuous skin tone variable (average of two raters)
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2
# Ensure outcome is binary (red card or no red card)
df['has_red_card'] = (df['redCards'] > 0).astype(int)

# 3. Model
# Using MixedLM for random intercepts per referee. 
# Explicitly drop rows that might have NaN in model factors if any remain.
model = smf.mixedlm("has_red_card ~ skin_tone + meanIAT + games + C(leagueCountry)", 
                    df, 
                    groups=df["refNum"])
result = model.fit()

# 4. Extract Estimands
params = result.params
bse = result.bse
conf = result.conf_int()

effect_size = params['skin_tone']
std_err = bse['skin_tone']
p_val = result.pvalues['skin_tone']
ci_lower = conf.loc['skin_tone', 0]
ci_upper = conf.loc['skin_tone', 1]

# 5. Output JSON
output = {
    "effect_size": float(effect_size),
    "effect_type": "log_odds",
    "standard_error": float(std_err),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "mixed_effects",
    "predictor_used": "average of rater1 and rater2",
    "covariates_included": ["meanIAT", "games", "leagueCountry"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "random_intercepts",
    "exclusions_applied": "dropped rows with missing values in rater1, rater2, meanIAT, or other covariates"
}

print(json.dumps(output))