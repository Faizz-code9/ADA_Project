import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_synthetic_skeptical_T0.0_r1/data.csv"
df = pd.read_csv(file_path)

# 2. Data Cleaning & Preparation
# Missing data strategy: listwise_deletion for skin_tone
df_clean = df.dropna(subset=["skin_tone"]).copy()

# Exposure / offset: games played
# Since redCards is a count, we use Poisson regression with log(games) as offset
df_clean["log_games"] = np.log(df_clean["games"])

# Covariates: height, weight, yellowCards, position, leagueCountry
# We include yellowCards as a critical confounder for red cards, plus player physical characteristics and league.
covariates = [
    "height",
    "weight",
    "yellowCards",
    "position",
    "leagueCountry",
]

# 3. Fit Statistical Model (Poisson with exposure)
formula = (
    "redCards ~ skin_tone + height + weight + yellowCards + C(position) + C(leagueCountry)"
)

model = smf.glm(
    formula=formula,
    data=df_clean,
    offset=df_clean["log_games"],
    family=sm.families.Poisson(),
).fit()

# 4. Extract primary estimand (skin_tone ratio effect -> Incidence Rate Ratio)
effect_size = np.exp(model.params["skin_tone"])
std_error = model.bse["skin_tone"]
p_value = model.pvalues["skin_tone"]

confint = model.conf_int().loc["skin_tone"]
ci_lower = np.exp(confint[0])
ci_upper = np.exp(confint[1])

conclusion = (
    "significant_effect" if p_value < 0.05 else "no_significant_effect"
)

output = {
    "effect_size": float(effect_size),
    "effect_type": "irr",
    "standard_error": float(
        std_error * effect_size
    ),  # Delta method approx for IRR SE
    "p_value": float(p_value),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "skin_tone",
    "covariates_included": [
        "height",
        "weight",
        "yellowCards",
        "position",
        "leagueCountry",
    ],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "Dropped 288 rows with missing skin_tone",
}

print(json.dumps(output))