import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json
import sys

# 1. Load the data
file_path = "/kaggle/working/outputs/runs/gemini-3.1-flash-lite_soccer_confirmatory_T1.0_r5/data.csv"
df = pd.read_csv(file_path)

# 2. Prepare data
# Exclude rows missing skin tone (rater1 and rater2)
df = df.dropna(subset=['rater1', 'rater2'])
# Define skin tone as the average of two raters (continuous 0-1)
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2

# Remove rows with missing necessary covariates (e.g., games)
df = df.dropna(subset=['games', 'refNum'])

# 3. Model Fitting
# Use Poisson regression for count outcome (redCards) adjusting for exposure (games)
# Clustering by referee (refNum) as disciplinary standards vary
# Formula: redCards ~ skin_tone + games + games^2 + offset(log(games))
# Since we want the impact on rate per game, we model count with log-exposure offset.
model = smf.glm(
    formula='redCards ~ skin_tone + games',
    data=df,
    family=sm.families.Poisson(),
    groups=df['refNum']
)
result = model.fit(cov_type='cluster', cov_kwds={'groups': df['refNum']})

# 4. Extract results
params = result.params
conf = result.conf_int()
p_vals = result.pvalues

effect_size = np.exp(params['skin_tone'])
ci_lower = np.exp(conf.loc['skin_tone', 0])
ci_upper = np.exp(conf.loc['skin_tone', 1])
p_value = p_vals['skin_tone']

# 5. Output
output = {
    "effect_size": float(effect_size),
    "effect_type": "irr",
    "standard_error": float(result.bse['skin_tone']),
    "p_value": float(p_value),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if p_value < 0.05 else "no_significant_effect",
    "model_family": "poisson",
    "predictor_used": "mean of rater1 and rater2",
    "covariates_included": ["games"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "rows with missing rater scores or games"
}

print(json.dumps(output))