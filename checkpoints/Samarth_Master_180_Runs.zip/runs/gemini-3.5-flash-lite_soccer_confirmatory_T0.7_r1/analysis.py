import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_soccer_confirmatory_T0.7_r1/data.csv"
df = pd.read_csv(file_path)

# 2. Clean and prepare data
df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)

# Drop missing values for key variables used in model
subset_cols = ['redCards', 'skin_tone', 'games', 'yellowCards']
df_clean = df.dropna(subset=subset_cols).copy()

# Ensure games is strictly positive to take log
df_clean = df_clean[df_clean['games'] > 0]
df_clean['log_games'] = np.log(df_clean['games'])

# 3. Fit model using statsmodels GLM directly to avoid patsy offset parsing issues
X = df_clean[['skin_tone', 'yellowCards']]
X = sm.add_constant(X)
offset = df_clean['log_games'].values

model = sm.GLM(
    df_clean['redCards'],
    X,
    family=sm.families.Poisson(),
    offset=offset
).fit()

# 4. Extract primary estimand (IRR for skin_tone)
beta = model.params['skin_tone']
se = model.bse['skin_tone']
p_val = model.pvalues['skin_tone']
ci = model.conf_int().loc['skin_tone']

irr = np.exp(beta)
ci_lower = np.exp(ci[0])
ci_upper = np.exp(ci[1])

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
  "effect_size": float(irr),
  "effect_type": "irr",
  "standard_error": float(se),
  "p_value": float(p_val),
  "ci_lower": float(ci_lower),
  "ci_upper": float(ci_upper),
  "conclusion": conclusion,
  "model_family": "poisson",
  "predictor_used": "skin_tone",
  "covariates_included": ["yellowCards"],
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "none",
  "exclusions_applied": "Dropped rows with missing skin_tone or redCards, and games <= 0."
}

print(json.dumps(output))