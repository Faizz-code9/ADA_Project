import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_synthetic_neutral_T0.7_r2/data.csv"
df = pd.read_csv(file_path)

# 2. Clean and prepare data
# Handle missing skin_tone using listwise deletion as stated
initial_len = len(df)
df = df.dropna(subset=['skin_tone']).copy()
exclusions_applied = f"Dropped {initial_len - len(df)} rows due to missing skin_tone"

# Include exposure (log of games) for rate model if desired, but Poisson with offset(np.log(games)) is standard
df['log_games'] = np.log(df['games'])

# 3. Fit Poisson regression model (Ratio effect -> IRR)
formula = "redCards ~ skin_tone + yellowCards + height + weight + C(position) + C(leagueCountry)"
model = smf.poisreg = smf.glm(
    formula=formula,
    data=df,
    family=sm.families.Poisson(),
    offset=df['log_games']
).fit()

# 4. Compute primary estimand (IRR for skin_tone)
beta = model.params['skin_tone']
se = model.bse['skin_tone']
p_val = model.pvalues['skin_tone']
ci = model.conf_int().loc['skin_tone']

irr = np.exp(beta)
ci_lower = np.exp(ci[0])
ci_upper = np.exp(ci[1])

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

# 5. Output JSON
output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "skin_tone",
    "covariates_included": ["yellowCards", "height", "weight", "position", "leagueCountry", "log_games"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": exclusions_applied
}

print(json.dumps(output))