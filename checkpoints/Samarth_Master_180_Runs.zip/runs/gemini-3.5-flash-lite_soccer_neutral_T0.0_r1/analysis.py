import json
import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load dataset
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_soccer_neutral_T0.0_r1/data.csv"
df = pd.read_csv(file_path)

# 2. Data Preparation
# Construct continuous skin tone predictor as average of rater1 and rater2
df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)

# Drop missing values for key variables used in the model
subset_cols = ['redCards', 'skin_tone', 'games', 'yellowCards', 'meanIAT']
df_clean = df.dropna(subset=subset_cols).copy()

# Exclusions tracked
exclusions_applied = f"Dropped {len(df) - len(df_clean)} rows due to missing values in key variables."

# 3. Model Fitting
# We use a Poisson regression (or Negative Binomial if overdispersed, but Poisson/OLS with robust SE is standard)
# Since redCards is a count, Poisson regression with exposure (log games) is appropriate.
# Alternatively, total red cards per game modeled via Poisson/GLM.
model = smf.glm(
    'redCards ~ skin_tone + yellowCards + meanIAT + np.log(games)', 
    data=df_clean, 
    family=sm.families.Poisson()
).fit(cov_type='HC1')

# 4. Extract Primary Estimand (effect of skin_tone)
# The primary estimand is the ratio effect (IRR) of skin tone on red cards.
# For Poisson, exp(coef) is the IRR.
coef = model.params['skin_tone']
se = model.bse['skin_tone']
p_val = model.pvalues['skin_tone']
conf = model.conf_int()
ci_lower = np.exp(conf.loc['skin_tone', 0])
ci_upper = np.exp(conf.loc['skin_tone', 1])
irr = np.exp(coef)

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

# 5. Output JSON
result = {
  "effect_size": float(irr),
  "effect_type": "irr",
  "standard_error": float(se), # Note: SE of coefficient, but effect_size is reported as IRR
  "p_value": float(p_val),
  "ci_lower": float(ci_lower),
  "ci_upper": float(ci_upper),
  "conclusion": conclusion,
  "model_family": "poisson",
  "predictor_used": "skin_tone",
  "covariates_included": ["yellowCards", "meanIAT", "games"],
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "none",
  "exclusions_applied": exclusions_applied
}

print(json.dumps(result))