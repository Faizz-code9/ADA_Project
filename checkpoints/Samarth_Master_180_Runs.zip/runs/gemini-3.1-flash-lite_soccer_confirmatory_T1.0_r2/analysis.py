import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

def analyze_soccer_bias():
    file_path = "/kaggle/working/outputs/runs/gemini-3.1-flash-lite_soccer_confirmatory_T1.0_r2/data.csv"
    df = pd.read_csv(file_path)

    # Prepare data
    df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)
    # Exclusions: drop rows missing key identifiers for the model
    df = df.dropna(subset=['skin_tone', 'redCards', 'games', 'refNum'])
    
    # Poisson model with offset for exposure
    # Use robust standard errors via GEE to avoid the clustering index mismatch in GLM
    # GEE handles clustering (refNum) natively without the bincount issue
    df['log_games'] = np.log(df['games'])
    
    # Formula construction
    formula = "redCards ~ skin_tone + C(leagueCountry) + C(position)"
    
    # GEE handles correlated data (cluster=refNum)
    model = smf.gee(
        formula=formula, 
        data=df, 
        groups=df['refNum'],
        family=sm.families.Poisson(),
        offset=df['log_games']
    ).fit()

    params = model.params
    conf = model.conf_int()
    
    # Results for skin_tone
    effect_coef = params['skin_tone']
    se = model.bse['skin_tone']
    p_val = model.pvalues['skin_tone']
    ci_lower = conf.loc['skin_tone', 0]
    ci_upper = conf.loc['skin_tone', 1]
    
    # IRR transformation
    irr = np.exp(effect_coef)
    ci_lower_irr = np.exp(ci_lower)
    ci_upper_irr = np.exp(ci_upper)

    result = {
        "effect_size": float(irr),
        "effect_type": "irr",
        "standard_error": float(se),
        "p_value": float(p_val),
        "ci_lower": float(ci_lower_irr),
        "ci_upper": float(ci_upper_irr),
        "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
        "model_family": "gee",
        "predictor_used": "mean of rater1 and rater2",
        "covariates_included": ["leagueCountry", "position"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "gee",
        "exclusions_applied": "rows with missing rater scores, redCards, games, or refNum"
    }
    
    print(json.dumps(result))

if __name__ == "__main__":
    analyze_soccer_bias()