import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
df = pd.read_csv('/kaggle/working/outputs/runs/gemini-3.5-flash-lite_placebo_skeptical_T0.0_r1/data.csv')

# 2. Data Preparation
# Construct skin_tone as the average of rater1 and rater2
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2

# Exclude rows where skin_tone or redCards are missing
# Also we need games as exposure or control. Let's use Poisson regression with log(games) as offset, or simply control for games.
sub_df = df.dropna(subset=['skin_tone', 'redCards', 'games']).copy()

# Filter out zero/negative games just in case, though min is 1
sub_df = sub_df[sub_df['games'] > 0]
sub_df['log_games'] = np.log(sub_df['games'])

# 3. Model Fitting
# Poisson regression for count outcome (redCards) with log(games) offset
formula = 'redCards ~ skin_tone + log_games'
model = smf.poisson(formula, data=sub_df).fit(disp=False)

# 4. Extract Estimates
# Primary estimand: ratio effect of continuous skin tone on red cards -> IRR (incidence rate ratio)
effect_size = np.exp(model.params['skin_tone'])
standard_error = model.bse['skin_tone']
p_value = model.pvalues['skin_tone']
ci = model.conf_int().loc['skin_tone']
ci_lower = np.exp(ci[0])
ci_upper = np.exp(ci[1])

conclusion = "no_significant_effect" if p_value > 0.05 else "significant_effect"

output = {
  "effect_size": float(effect_size),
  "effect_type": "irr",
  "standard_error": float(standard_error),
  "p_value": float(p_value),
  "ci_lower": float(ci_lower),
  "ci_upper": float(ci_upper),
  "conclusion": conclusion,
  "model_family": "poisson",
  "predictor_used": "skin_tone",
  "covariates_included": ["log_games"],
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "none",
  "exclusions_applied": "dropped rows with missing skin_tone, redCards, or games"
}

print(json.dumps(output))