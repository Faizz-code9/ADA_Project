import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_disguise_confirmatory_T0.7_r1/data.csv"
df = pd.read_csv(file_path)

# 2. Data preparation
# Construct continuous risk evaluator score predictor.
df["risk_score"] = df[
    ["risk_evaluator_alpha_score", "risk_evaluator_beta_score"]
].mean(axis=1)

# Covariates
covariates = [
    "credit_score_index",
    "annual_income_bracket",
    "prior_denied_loans",
]

# Missing data strategy: listwise deletion on variables used
model_vars = ["loan_application_rejections", "risk_score"] + covariates
df_clean = df.dropna(subset=model_vars).copy()

# 3. Fit Poisson model
formula = (
    "loan_application_rejections ~ risk_score + credit_score_index + "
    "annual_income_bracket + prior_denied_loans"
)

model = smf.poisson(formula, data=df_clean).fit(disp=False)

# 4. Extract primary estimand (risk_score coefficient)
coef = model.params["risk_score"]
se = model.bse["risk_score"]
p_val = model.pvalues["risk_score"]
ci = model.conf_int().loc["risk_score"]
irr = np.exp(coef)
ci_lower = np.exp(ci[0])
ci_upper = np.exp(ci[1])

conclusion = (
    "significant_effect" if p_val < 0.05 else "no_significant_effect"
)

output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "risk_score",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": f"Dropped {len(df) - len(df_clean)} rows with missing values in key variables.",
}

print(json.dumps(output))