import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load dataset
file_path = (
    "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_disguise_skeptical_T1.0_r2/data.csv"
)
df = pd.read_csv(file_path)

# 2. Prepare variables
sub_df = df[[
    "loan_application_rejections",
    "risk_evaluator_alpha_score",
    "credit_score_index",
    "annual_income_bracket",
    "prior_denied_loans",
]].dropna()

# 3. Fit model (Poisson regression for ratio effect / IRR)
formula = (
    "loan_application_rejections ~ risk_evaluator_alpha_score + "
    "credit_score_index + annual_income_bracket + prior_denied_loans"
)

model = smf.poisson(formula, data=sub_df).fit(disp=False)

# Extract parameters for risk_evaluator_alpha_score
coef = model.params["risk_evaluator_alpha_score"]
se = model.bse["risk_evaluator_alpha_score"]
pval = model.pvalues["risk_evaluator_alpha_score"]
ci = model.conf_int().loc["risk_evaluator_alpha_score"]

irr = np.exp(coef)
ci_lower = np.exp(ci[0])
ci_upper = np.exp(ci[1])

conclusion = (
    "significant_effect" if pval < 0.05 else "no_significant_effect"
)

output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(pval),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "risk_evaluator_alpha_score",
    "covariates_included": [
        "credit_score_index",
        "annual_income_bracket",
        "prior_denied_loans",
    ],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "Dropped rows with missing values in regression variables.",
}

print(json.dumps(output))