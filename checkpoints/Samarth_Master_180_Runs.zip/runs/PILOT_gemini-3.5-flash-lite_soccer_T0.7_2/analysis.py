import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

# 1. Load data
file_path = "/kaggle/working/outputs/runs/PILOT_gemini-3.5-flash-lite_soccer_T0.7_2/data.csv"
df = pd.read_csv(file_path)

# 2. Prepare data
df["skin_tone"] = df[["rater1", "rater2"]].mean(axis=1)

analysis_vars = ["redCards", "skin_tone", "games", "yellowCards", "meanIAT"]
df_clean = df.dropna(subset=analysis_vars).copy()

# Avoid log(0) just in case, though games >= 1 based on description
df_clean["log_games"] = np.log(df_clean["games"].clip(lower=1))

# 3. Fit Model using statsmodels GLM directly to avoid patsy offset parsing issues
# Construct design matrix manually or use GLM with exposure/offset
features = ["skin_tone", "yellowCards", "meanIAT"]
X = sm.add_constant(df_clean[features])
y = df_clean["redCards"]
exposure = df_clean["log_games"]

model = sm.GLM(
    y,
    X,
    family=sm.families.Poisson(),
    exposure=exposure,
)
result = model.fit()

# 4. Extract primary estimand (skin_tone effect)
effect_size = np.exp(result.params["skin_tone"])
std_err = result.bse["skin_tone"]
p_val = result.pvalues["skin_tone"]
conf_int = result.conf_int().loc["skin_tone"]
ci_lower = np.exp(conf_int[0])
ci_upper = np.exp(conf_int[1])

conclusion = (
    "significant_effect" if p_val < 0.05 else "no_significant_effect"
)

output = {
    "effect_size": float(effect_size),
    "effect_type": "irr",
    "standard_error": float(std_err),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "skin_tone (mean of rater1 and rater2)",
    "covariates_included": ["yellowCards", "meanIAT", "log_games"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "Removed rows with missing skin tone, red cards, or control variables",
}

print(json.dumps(output))