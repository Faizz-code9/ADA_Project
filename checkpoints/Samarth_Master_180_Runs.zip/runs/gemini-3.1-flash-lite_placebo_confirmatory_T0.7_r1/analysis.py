import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

def run_analysis():
    # 1. Load data
    file_path = "/kaggle/working/outputs/runs/gemini-3.1-flash-lite_placebo_confirmatory_T0.7_r1/data.csv"
    df = pd.read_csv(file_path)

    # 2. Preparation
    # Construct skin tone as mean of rater1 and rater2
    df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)
    
    # Exclusions: Drop rows where skin tone or position is missing
    df = df.dropna(subset=['skin_tone', 'position'])
    
    # 3. Fit Model
    # Using Poisson GLM. 'smf.glm' does not support 'groups' parameter directly in the call.
    # To use clustered standard errors, we fit the GLM and then use get_robustcov_results.
    # We must ensure the design matrix is created before calculating cluster SEs.
    formula = "redCards ~ skin_tone + C(position) + games + yellowCards"
    
    # Fit the model
    model = smf.glm(formula=formula, data=df, family=sm.families.Poisson()).fit()
    
    # Get clustered standard errors separately
    # The error was caused by passing 'groups' to the constructor.
    # Correct way: use get_robustcov_results on the fitted object.
    model_robust = model.get_robustcov_results(
        cov_type='cluster', 
        groups=df['refNum']
    )

    # 4. Extract results
    params = model_robust.params
    conf = model_robust.conf_int()
    
    effect_size = np.exp(params['skin_tone'])
    ci_lower = np.exp(conf.loc['skin_tone', 0])
    ci_upper = np.exp(conf.loc['skin_tone', 1])
    p_value = model_robust.pvalues['skin_tone']
    
    result = {
        "effect_size": float(effect_size),
        "effect_type": "irr",
        "standard_error": float(model_robust.bse['skin_tone']),
        "p_value": float(p_value),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": "significant_effect" if p_value < 0.05 else "no_significant_effect",
        "model_family": "poisson",
        "predictor_used": "mean(rater1, rater2)",
        "covariates_included": ["position", "games", "yellowCards"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "clustered_se",
        "exclusions_applied": "rows with missing skin_tone ratings or position"
    }
    
    print(json.dumps(result))

if __name__ == "__main__":
    run_analysis()