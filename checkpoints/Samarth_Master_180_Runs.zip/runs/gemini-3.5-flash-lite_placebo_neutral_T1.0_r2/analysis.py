import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load dataset
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_placebo_neutral_T1.0_r2/data.csv"
df = pd.read_csv(file_path)

# 2. Data Preparation & Cleaning
# Construct skin tone as average of rater1 and rater2
df['skinTone'] = df[['rater1', 'rater2']].mean(axis=1)

# Drop rows missing skinTone or redCards
subset_cols = ['redCards', 'skinTone', 'games', 'yellowCards', 'meanIAT']
df_clean = df.dropna(subset=subset_cols).copy()

# Exclusions applied description
exclusions_applied = f"Dropped {len(df) - len(df_clean)} rows with missing values in key variables."

# 3. Model Fitting
# We use a Poisson regression model for red cards (count outcome), adjusting for games played, yellow cards, and meanIAT.
# Using robust standard errors (HC1) to account for potential heteroskedasticity.
formula = 'redCards ~ skinTone + games + yellowCards + meanIAT'
model = smf.poisson(formula, data=df_clean)
result = model.fit(cov_type='HC1', disp=False)

# 4. Extract Primary Estimand (skinTone)
# Effect type is 'irr' (Incident Rate Ratio) for Poisson regression
coef = result.params['skinTone']
irr = np.exp(coef)
se = result.bse['skinTone']
p_val = result.pvalues['skinTone']
ci_lower = np.exp(coef - 1.96 * se)
ci_upper = np.exp(coef + 1.96 * se)

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
  "effect_size": float(irr),
  "effect_type": "irr",
  "standard_error": float(se),
  "p_value": float(p_val),
  "ci_lower": float(ci_lower),
  "ci_upper": float(ci_upper),
  "conclusion": conclusion,
  "model_family": "poisson",
  "predictor_used": "skinTone",
  "covariates_included": ["games", "yellowCards", "meanIAT"],
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "none",
  "exclusions_applied": exclusions_applied
}

print(json.dumps(output))