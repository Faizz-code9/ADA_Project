import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

# 1. Load data
file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_soccer_skeptical_T0.0_r3/data.csv'
df = pd.read_csv(file_path)

# 2. Clean and prepare
# Drop rows where skin tone ratings are missing (rater1/rater2)
df = df.dropna(subset=['rater1', 'rater2'])
# Construct skin tone variable as average of rater1 and rater2
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2
# Ensure redCards is numeric
df['redCards'] = df['redCards'].astype(int)

# 3. Fit model
# Using Poisson regression for count data (redCards)
# Adjusting for leagueCountry (fixed effects) and clustering by referee (refNum)
# We use GEE to handle clustering by referee
model = smf.gee("redCards ~ skin_tone + C(leagueCountry)", 
                data=df, 
                groups=df['refNum'], 
                family=sm.families.Poisson())
result = model.fit()

# 4. Compute estimands
# Extract coefficient for skin_tone
coef = result.params['skin_tone']
se = result.bse['skin_tone']
p_val = result.pvalues['skin_tone']
conf_int = result.conf_int().loc['skin_tone']

# 5. Print JSON
output = {
    "effect_size": float(np.exp(coef)),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(np.exp(conf_int[0])),
    "ci_upper": float(np.exp(conf_int[1])),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "gee",
    "predictor_used": "average of rater1 and rater2",
    "covariates_included": ["leagueCountry"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "gee",
    "exclusions_applied": "rows with missing rater1 or rater2 values"
}

print(json.dumps(output))