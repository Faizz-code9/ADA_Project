import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_synthetic_confirmatory_T1.0_r1/data.csv"
df = pd.read_csv(file_path)

# 2. Clean and prepare data
df_clean = df.dropna(subset=['skin_tone']).copy()
df_clean = df_clean[df_clean['games'] > 0]
df_clean['log_games'] = np.log(df_clean['games'])

# 3. Fit statistical model using statsmodels GLM with Negative Binomial family 
# to properly handle the offset parameter without patsy syntax issues.
formula = "redCards ~ skin_tone + yellowCards + height + weight + C(position) + C(leagueCountry)"
model = smf.glm(
    formula=formula,
    data=df_clean,
    family=sm.families.NegativeBinomial(),
    offset=df_clean['log_games']
)
result = model.fit()

# 4. Extract primary estimand (skin_tone effect)
effect_size = float(np.exp(result.params['skin_tone']))  # IRR
std_err = float(result.bse['skin_tone'])
p_val = float(result.pvalues['skin_tone'])

conf_int = result.conf_int()
ci_lower = float(np.exp(conf_int.loc['skin_tone', 0]))
ci_upper = float(np.exp(conf_int.loc['skin_tone', 1]))

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
  "effect_size": effect_size,
  "effect_type": "irr",
  "standard_error": std_err,
  "p_value": p_val,
  "ci_lower": ci_lower,
  "ci_upper": ci_upper,
  "conclusion": conclusion,
  "model_family": "negative_binomial",
  "predictor_used": "skin_tone",
  "covariates_included": ["yellowCards", "height", "weight", "position", "leagueCountry", "log_games"],
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "none",
  "exclusions_applied": "Removed rows with missing skin_tone or zero games."
}

print(json.dumps(output))