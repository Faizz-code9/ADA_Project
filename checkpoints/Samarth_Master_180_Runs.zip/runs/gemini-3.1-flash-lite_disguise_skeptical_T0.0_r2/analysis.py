import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

# 1. Load data
file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_disguise_skeptical_T0.0_r2/data.csv'
df = pd.read_csv(file_path)

# 2. Clean and prepare
# The error "endog must be in the unit interval" occurs because loan_application_rejections 
# contains values > 1 (max is 2). We treat this as a count variable or binary indicator.
# Given the hypothesis is about rejection bias, we convert to a binary indicator (1 if rejected, 0 otherwise).
df['rejection_binary'] = (df['loan_application_rejections'] > 0).astype(int)
df['risk_score'] = df[['risk_evaluator_alpha_score', 'risk_evaluator_beta_score']].mean(axis=1)

# Exclusions: Drop rows where risk scores or covariates are missing
df_clean = df.dropna(subset=['risk_score', 'credit_score_index', 'annual_income_bracket']).copy()

# 3. Model fitting
# Using Logistic Regression on the binary outcome
formula = 'rejection_binary ~ risk_score + credit_score_index + annual_income_bracket'
model = smf.logit(formula, data=df_clean).fit(disp=0)

# 4. Compute estimands
params = model.params
conf = model.conf_int()
p_values = model.pvalues
se = model.bse

# Odds Ratio calculation
effect_size = np.exp(params['risk_score'])
ci_lower = np.exp(conf.loc['risk_score', 0])
ci_upper = np.exp(conf.loc['risk_score', 1])

# 5. Output JSON
result = {
    "effect_size": float(effect_size),
    "effect_type": "odds_ratio",
    "standard_error": float(se['risk_score']),
    "p_value": float(p_values['risk_score']),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if p_values['risk_score'] < 0.05 else "no_significant_effect",
    "model_family": "logistic",
    "predictor_used": "mean of risk_evaluator_alpha_score and risk_evaluator_beta_score",
    "covariates_included": ["credit_score_index", "annual_income_bracket"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "rows with missing risk scores or covariates removed; outcome binarized"
}

print(json.dumps(result))