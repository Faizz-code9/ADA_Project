import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

# 1. Load data
file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_synthetic_confirmatory_T0.0_r2/data.csv'
df = pd.read_csv(file_path)

# 2. Clean and prepare
# Listwise deletion for missing skin_tone
df = df.dropna(subset=['skin_tone'])

# 3. Model fitting
# Since redCards is a count variable, Poisson regression is appropriate.
# We include exposure (games) as an offset to model the rate of red cards per game.
# We cluster by playerID to account for repeated observations of the same player.
df['log_games'] = np.log(df['games'])
formula = 'redCards ~ skin_tone + height + weight + C(position) + C(leagueCountry) + yellowCards'

model = smf.glm(
    formula=formula, 
    data=df, 
    family=sm.families.Poisson(), 
    offset=df['log_games']
).fit(cov_type='cluster', cov_kwds={'groups': df['playerID']})

# 4. Compute estimands
params = model.params
bse = model.bse
conf = model.conf_int()

effect_size = np.exp(params['skin_tone'])
se_log = bse['skin_tone']
p_val = model.pvalues['skin_tone']
ci_lower = np.exp(conf.loc['skin_tone', 0])
ci_upper = np.exp(conf.loc['skin_tone', 1])

# 5. Output JSON
result = {
    "effect_size": float(effect_size),
    "effect_type": "irr",
    "standard_error": float(se_log),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "poisson",
    "predictor_used": "skin_tone",
    "covariates_included": ["height", "weight", "position", "leagueCountry", "yellowCards"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "rows with missing skin_tone removed"
}

print(json.dumps(result))