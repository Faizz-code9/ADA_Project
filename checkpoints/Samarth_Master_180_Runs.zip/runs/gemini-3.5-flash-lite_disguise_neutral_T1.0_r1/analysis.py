import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load the CSV from the absolute file path
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_disguise_neutral_T1.0_r1/data.csv"
df = pd.read_csv(file_path)

# 2. Cleans and prepares the data
# Construct predictor: average of risk_evaluator_alpha_score and risk_evaluator_beta_score
df['risk_evaluator_score'] = df[['risk_evaluator_alpha_score', 'risk_evaluator_beta_score']].mean(axis=1)

# Ensure outcome is binary (loan application rejections)
# Note: outcome has max value 2 in description, we can treat it as binary or count, 
# but hypothesis/prompt specifies "loan_application_rejections" and ratio effect (odds ratio / IRR).
# Let's treat >0 as 1 or use Poisson/Negative Binomial or Logistic. 
# Usually, loan rejection is binary (0 or 1+). Let's binarize or use poisson if count. 
# Max is 2, mean is 0.0125. Let's make it binary (rejection >= 1) for logistic regression (odds ratio).
df['loan_rejected_bin'] = (df['loan_application_rejections'] > 0).astype(int)

# Missing data strategy: listwise deletion on used variables
model_vars = ['loan_rejected_bin', 'risk_evaluator_score', 'credit_score_index', 'annual_income_bracket']
df_clean = df.dropna(subset=model_vars).copy()

# 3. Fits an appropriate statistical model
# Using Logistic Regression to obtain Odds Ratio for the continuous risk evaluator score (0-1)
formula = 'loan_rejected_bin ~ risk_evaluator_score + credit_score_index + annual_income_bracket'
model = smf.logit(formula=formula, data=df_clean)
result = model.fit(disp=False)

# 4. Compute the primary estimand (Odds Ratio, SE, p-value, 95% CI)
param_name = 'risk_evaluator_score'
log_odds = result.params[param_name]
se_log_odds = result.bse[param_name]
p_value = result.pvalues[param_name]
conf_int = result.conf_int().loc[param_name]

effect_size = float(np.exp(log_odds))
ci_lower = float(np.exp(conf_int[0]))
ci_upper = float(np.exp(conf_int[1]))
# Standard error for odds ratio via delta method: SE(OR) = OR * SE(log_odds)
effect_se = float(effect_size * se_log_odds)

conclusion = "significant_effect" if p_value < 0.05 else "no_significant_effect"

output = {
  "effect_size": effect_size,
  "effect_type": "odds_ratio",
  "standard_error": effect_se,
  "p_value": float(p_value),
  "ci_lower": ci_lower,
  "ci_upper": ci_upper,
  "conclusion": conclusion,
  "model_family": "logistic",
  "predictor_used": "risk_evaluator_score",
  "covariates_included": ["credit_score_index", "annual_income_bracket"],
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "none",
  "exclusions_applied": "Dropped rows with missing values in risk evaluator scores, credit score, or income."
}

print(json.dumps(output))