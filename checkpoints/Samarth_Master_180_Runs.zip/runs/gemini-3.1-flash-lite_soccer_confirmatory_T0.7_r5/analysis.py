import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

# 1. Load the data
file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_soccer_confirmatory_T0.7_r5/data.csv'
df = pd.read_csv(file_path)

# 2. Clean and prepare data
# Drop rows where skin tone ratings are missing
df = df.dropna(subset=['rater1', 'rater2', 'refNum'])
# Create primary predictor: average of the two raters
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2
# Handle missing values for other covariates
df = df.dropna(subset=['redCards', 'games', 'meanIAT', 'height', 'weight'])
# Ensure refNum is categorical for clustering
df['refNum'] = df['refNum'].astype(int)

# 3. Fit Model
# Using Poisson regression with robust standard errors clustered by referee (refNum)
# statsmodels GLM with cluster robust SEs requires explicit handling
# We use smf.glm and provide the cluster covariance via cov_type='cluster'
# To avoid the previous grouping error, we ensure the index aligns with the data
df = df.reset_index(drop=True)

model = smf.glm(
    formula='redCards ~ skin_tone + meanIAT + height + weight',
    data=df,
    family=sm.families.Poisson(),
    offset=np.log(df['games'] + 1e-6)
).fit(cov_type='cluster', cov_kwds={'groups': df['refNum']})

# 4. Compute primary estimand
# Extracting coefficient for skin_tone (log-scale)
coef = model.params['skin_tone']
se = model.bse['skin_tone']
p_val = model.pvalues['skin_tone']
ci = model.conf_int().loc['skin_tone']

# Convert log-scale coefficient to IRR (Incidence Rate Ratio)
irr = np.exp(coef)
ci_lower = np.exp(ci[0])
ci_upper = np.exp(ci[1])

# 5. Output JSON
results = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "poisson",
    "predictor_used": "average of rater1 and rater2",
    "covariates_included": ["meanIAT", "height", "weight"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "dropped rows missing rater scores, refNum, or essential covariates"
}

print(json.dumps(results))