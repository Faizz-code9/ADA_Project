import pandas as pd
import numpy as np
import statsmodels.api as sm
import json
import sys

# 1. Load the data
file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_soccer_skeptical_T1.0_r1/data.csv'
df = pd.read_csv(file_path)

# 2. Prepare data
# Exclude rows where skin tone rater data is missing
df = df.dropna(subset=['rater1', 'rater2'])
# Create primary predictor: average of the two raters
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2
# Dependent variable: redCards (count)
# We use Poisson regression as it counts events. 
# We adjust for exposure (games) by using it as an offset or log exposure.
df['log_games'] = np.log(df['games'])

# Covariates: position (one-hot), league (one-hot)
# Filling missing position as 'Unknown'
df['position'] = df['position'].fillna('Unknown')
dummies = pd.get_dummies(df[['position', 'leagueCountry']], drop_first=True).astype(float)
df = pd.concat([df, dummies], axis=1)

covariates = list(dummies.columns)
# Include exposure variable log_games in covariates for model fit, though used as offset
features = ['skin_tone'] + covariates
X = sm.add_constant(df[features])
y = df['redCards']

# 3. Model Fit
# Poisson regression with clustered standard errors by referee (refNum)
model = sm.GLM(y, X, family=sm.families.Poisson(), offset=df['log_games'])
# Using GEE for clustered standard errors as standard Poisson doesn't support them natively
# but GEE does.
gee = sm.GEE(y, X, groups=df['refNum'], family=sm.families.Poisson(), offset=df['log_games'])
result = gee.fit()

# 4. Extract results
effect_size = np.exp(result.params['skin_tone'])
std_err = result.bse['skin_tone']
p_val = result.pvalues['skin_tone']
ci_lower = np.exp(result.params['skin_tone'] - 1.96 * std_err)
ci_upper = np.exp(result.params['skin_tone'] + 1.96 * std_err)

# 5. Format Output
output = {
    "effect_size": float(effect_size),
    "effect_type": "irr",
    "standard_error": float(std_err),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "gee",
    "predictor_used": "average of rater1 and rater2",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "gee",
    "exclusions_applied": "rows with missing rater1/rater2"
}

print(json.dumps(output))