import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load dataset
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_disguise_confirmatory_T0.0_r2/data.csv"
df = pd.read_csv(file_path)

# 2. Data preparation
# Define primary predictor (e.g., risk_evaluator_alpha_score) and outcome
# Let's use risk_evaluator_alpha_score as the continuous risk evaluator score (0-1).
# We also include typical covariates to control for confounding: credit_score_index, annual_income_bracket, prior_denied_loans.
predictor = "risk_evaluator_alpha_score"
outcome = "loan_application_rejections"
covariates = [
    "credit_score_index",
    "annual_income_bracket",
    "prior_denied_loans",
]

sub_df = df[[outcome, predictor] + covariates].dropna()

# 3. Fit statistical model (Poisson / Negative Binomial for count outcome, or Logistic if binary, 
# but outcome max is 2 and mean is 0.0125. Poisson or Logistic are standard. 
# The estimand requests ratio effect (irr or odds_ratio). Let's use Poisson for IRR.)
formula = f"{outcome} ~ {predictor} + {' + '.join(covariates)}"
model = smf.poisson(formula, data=sub_df).fit(disp=False)

# 4. Extract primary estimand metrics
effect_size = float(np.exp(model.params[predictor]))  # IRR
std_err = float(model.bse[predictor])  # SE of log scale, but let's report parameter SE or transformed? 
# Usually, standard_error for the coefficient or IRR. Let's provide coefficient SE or delta method, 
# or standard coefficient log_odds/irr SE. Let's check typical reporting: coefficient SE.
# Wait, effect_type = 'irr' means effect_size is exponentiated. Let's report coefficient SE or delta-method SE.
# Actually, statsmodels gives bse on the log scale. Let's provide the log-scale SE or exponentiated SE. 
# Let's use coefficient SE and note effect_type 'irr'.
p_val = float(model.pvalues[predictor])
ci = model.conf_int().loc[predictor]
ci_lower = float(np.exp(ci[0]))
ci_upper = float(np.exp(ci[1]))

conclusion = (
    "significant_effect" if p_val < 0.05 else "no_significant_effect"
)

output = {
    "effect_size": effect_size,
    "effect_type": "irr",
    "standard_error": float(std_err),
    "p_value": p_val,
    "ci_lower": ci_lower,
    "ci_upper": ci_upper,
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": predictor,
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "listwise deletion of missing values in selected variables",
}

print(json.dumps(output))