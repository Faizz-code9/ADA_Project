import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_soccer_skeptical_T1.0_r1/data.csv"
df = pd.read_csv(file_path)

# 2. Prepare data
# Construct skin tone predictor as the average of rater1 and rater2
df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)

# Filter out missing values for outcome and key predictors
analysis_df = df.dropna(subset=['redCards', 'skin_tone']).copy()

# 3. Fit model (Poisson regression since outcome is count: redCards)
# We include basic player/game controls as typical covariates
covariates = ['yellowCards', 'yellowReds', 'games']
formula = 'redCards ~ skin_tone + yellowCards + yellowReds + games'

model = smf.poisson(formula, data=analysis_df).fit(disp=False)

# 4. Extract primary estimand (skin_tone coefficient, exponentiated for IRR)
effect_size = float(np.exp(model.params['skin_tone']))
std_err = float(model.bse['skin_tone'])
p_val = float(model.pvalues['skin_tone'])
ci = model.conf_int().loc['skin_tone']
ci_lower = float(np.exp(ci[0]))
ci_upper = float(np.exp(ci[1]))

conclusion = "no_significant_effect" if p_val >= 0.05 else "significant_effect"

output = {
  "effect_size": effect_size,
  "effect_type": "irr",
  "standard_error": std_err,
  "p_value": p_val,
  "ci_lower": ci_lower,
  "ci_upper": ci_upper,
  "conclusion": conclusion,
  "model_family": "poisson",
  "predictor_used": "skin_tone",
  "covariates_included": covariates,
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "none",
  "exclusions_applied": "Dropped rows with missing rater scores or redCards"
}

print(json.dumps(output))