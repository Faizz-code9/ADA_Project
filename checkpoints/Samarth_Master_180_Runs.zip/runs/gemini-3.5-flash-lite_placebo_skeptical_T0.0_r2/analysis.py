import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
df = pd.read_csv('/kaggle/working/outputs/runs/gemini-3.5-flash-lite_placebo_skeptical_T0.0_r2/data.csv')

# 2. Clean and prepare data
df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)

# Covariates
covariates = ['yellowCards', 'leagueCountry']

# Drop missing for required variables
model_data = df.dropna(subset=['skin_tone', 'redCards', 'yellowCards', 'games', 'refNum', 'leagueCountry']).copy()

# 3. Fit Poisson model using robust standard errors with GEE or standard GLM with HC1 (since statsmodels cluster syntax uses `cov_kwds={'groups': ...}`)
formula = 'redCards ~ skin_tone + yellowCards + C(leagueCountry)'
model = smf.poisson(formula, data=model_data)

# Fix for statsmodels cluster robust covariance passing
results = model.fit(cov_type='cluster', cov_kwds={'groups': model_data['refNum']}, disp=False)

# 4. Extract primary estimand (skin_tone coefficient -> IRR)
coef = results.params['skin_tone']
se = results.bse['skin_tone']
p_val = results.pvalues['skin_tone']
ci = results.conf_int().loc['skin_tone']

effect_size = float(np.exp(coef))
ci_lower = float(np.exp(ci[0]))
ci_upper = float(np.exp(ci[1]))

conclusion = 'significant_effect' if p_val < 0.05 else 'no_significant_effect'

output = {
  "effect_size": effect_size,
  "effect_type": "irr",
  "standard_error": float(se),
  "p_value": float(p_val),
  "ci_lower": ci_lower,
  "ci_upper": ci_upper,
  "conclusion": conclusion,
  "model_family": "poisson",
  "predictor_used": "skin_tone",
  "covariates_included": covariates,
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "clustered_se",
  "exclusions_applied": "dropped rows with missing skin_tone, redCards, yellowCards, games, refNum, or leagueCountry"
}

print(json.dumps(output))