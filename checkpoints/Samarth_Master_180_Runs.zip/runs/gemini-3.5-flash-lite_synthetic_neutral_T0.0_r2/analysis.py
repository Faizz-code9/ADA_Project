import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_synthetic_neutral_T0.0_r2/data.csv"
df = pd.read_csv(file_path)

# 2. Cleaning and preparation
# Missing data strategy: listwise deletion for skin_tone
df_clean = df.dropna(subset=['skin_tone']).copy()

# Since redCards is count data and players have varying exposure (games), 
# we can use a Poisson regression model with log(games) as an offset,
# or adjust for games. Let's use Poisson regression (or Negative Binomial if overdispersed).
# To account for exposure, offset = np.log(games). If games == 0, handle it.
df_clean['games'] = np.maximum(df_clean['games'], 1)
df_clean['log_games'] = np.log(df_clean['games'])

# 3. Fit statistical model (Poisson regression with robust SE or standard Poisson)
# We adjust for yellowCards, height, weight, position, leagueCountry as standard covariates.
formula = "redCards ~ skin_tone + yellowCards + height + weight + C(position) + C(leagueCountry)"
model = smf.poisson(formula=formula, data=df_clean, offset=df_clean['log_games']).fit(disp=False)

# 4. Compute primary estimand (IRR for skin_tone)
coef = model.params['skin_tone']
se = model.bse['skin_tone']
p_val = model.pvalues['skin_tone']
ci = model.conf_int().loc['skin_tone']

irr = np.exp(coef)
ci_lower = np.exp(ci[0])
ci_upper = np.exp(ci[1])

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

# 5. Output JSON
output = {
  "effect_size": float(irr),
  "effect_type": "irr",
  "standard_error": float(se),
  "p_value": float(p_val),
  "ci_lower": float(ci_lower),
  "ci_upper": float(ci_upper),
  "conclusion": conclusion,
  "model_family": "poisson",
  "predictor_used": "skin_tone",
  "covariates_included": ["yellowCards", "height", "weight", "position", "leagueCountry", "games (offset)"],
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "none",
  "exclusions_applied": "Dropped 288 rows with missing skin_tone"
}

print(json.dumps(output))