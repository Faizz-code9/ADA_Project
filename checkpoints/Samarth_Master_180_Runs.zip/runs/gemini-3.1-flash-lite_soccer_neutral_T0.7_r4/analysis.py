import pandas as pd
import numpy as np
import statsmodels.formula.api as smf
import statsmodels.api as sm
import json

# 1. Load data
file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_soccer_neutral_T0.7_r4/data.csv'
df = pd.read_csv(file_path)

# 2. Prepare data
# Exclude rows missing rater information
df = df.dropna(subset=['rater1', 'rater2'])
# Construct skin tone as average of the two raters
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2

# 3. Fit Model
# Using Poisson regression via GLM with the correct import for the family
# We use games as an offset to account for exposure time (number of games)
# Formula: redCards ~ skin_tone + C(leagueCountry) + offset(log(games))
df['log_games'] = np.log(df['games'])
model = smf.glm(
    formula='redCards ~ skin_tone + C(leagueCountry) + offset(log_games)',
    data=df,
    family=sm.families.Poisson()
).fit()

# 4. Compute results
params = model.params
conf = model.conf_int()
p_values = model.pvalues

# The parameter is on the log scale, so exp() gives the IRR
effect_size = np.exp(params['skin_tone'])
# Standard error for the IRR is approximated via the delta method or 
# simply report the SE of the coefficient if log-scale is preferred.
# Following standard reporting for IRR:
se = model.bse['skin_tone']
p_val = p_values['skin_tone']
ci_lower = np.exp(conf.loc['skin_tone', 0])
ci_upper = np.exp(conf.loc['skin_tone', 1])

# 5. Output JSON
result = {
    "effect_size": float(effect_size),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "poisson",
    "predictor_used": "skin_tone (average of rater1 and rater2)",
    "covariates_included": ["leagueCountry", "games (as offset)"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "Removed rows where rater1 or rater2 were missing"
}

print(json.dumps(result))