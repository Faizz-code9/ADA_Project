import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_placebo_confirmatory_T1.0_r1/data.csv"
df = pd.read_csv(file_path)

# 2. Clean and prepare data
# Construct skin tone predictor as the average of rater1 and rater2
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2.0

# Drop rows where essential variables are missing
# Primary estimand requires redCards and skin_tone. Let's also control for games played (exposure) if using Poisson.
# Or use Poisson regression with exposure: ln(games) or games as offset.
# Since redCards is count data per row (which represents a player-match-referee interaction block), let's check 'games' as exposure.
# Actually, the dataset rows are player-referee dyads or similar aggregation. Let's use Poisson regression.
subset_cols = ['redCards', 'skin_tone', 'games', 'height', 'weight', 'yellowCards']
df_clean = df.dropna(subset=subset_cols).copy()

# Ensure games > 0
df_clean = df_clean[df_clean['games'] > 0]

# Missing data strategy: listwise deletion on used columns
# Clustering strategy: clustered standard errors by playerShort or refNum to account for repeated observations.
# Let's cluster by playerShort or refNum. Using GEE or GLM with robust sandwich SEs (cluster).

# 3. Fit statistical model
# Poisson regression for count outcome (redCards), with log(games) as offset to account for exposure.
formula = 'redCards ~ skin_tone + height + weight + yellowCards'

# We can use statsmodels GLM with Poisson family and cluster robust standard errors (cov_type='cluster', cov_kwds={'groups': df_clean['playerShort']})
model = smf.glm(
    formula=formula,
    data=df_clean,
    family=sm.families.Poisson(),
    offset=np.log(df_clean['games'])
)

results = model.fit(cov_type='cluster', cov_kwds={'groups': df_clean['playerShort']})

# 4. Extract primary estimand (skin_tone coefficient -> Incidence Rate Ratio)
coef = results.params['skin_tone']
se = results.bse['skin_tone']
pval = results.pvalues['skin_tone']
ci = results.conf_int().loc['skin_tone']

irr = np.exp(coef)
ci_lower = np.exp(ci[0])
ci_upper = np.exp(ci[1])

conclusion = "significant_effect" if pval < 0.05 else "no_significant_effect"

output = {
  "effect_size": float(irr),
  "effect_type": "irr",
  "standard_error": float(se),
  "p_value": float(pval),
  "ci_lower": float(ci_lower),
  "ci_upper": float(ci_upper),
  "conclusion": conclusion,
  "model_family": "poisson",
  "predictor_used": "skin_tone",
  "covariates_included": ["height", "weight", "yellowCards"],
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "clustered_se",
  "exclusions_applied": "Removed rows with missing skin_tone, redCards, games, height, weight, or yellowCards, and games <= 0."
}

print(json.dumps(output))