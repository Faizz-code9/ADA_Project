import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

# 1. Load data
file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_synthetic_neutral_T0.0_r1/data.csv'
df = pd.read_csv(file_path)

# 2. Clean and prepare
# Drop rows with missing skin_tone
df_clean = df.dropna(subset=['skin_tone']).copy()

# 3. Fit model
# Since redCards is a count variable, Poisson regression is appropriate.
# We include exposure (games) as an offset to model the rate of red cards per game.
# We cluster standard errors by refereeID to account for referee-specific bias.
df_clean['log_games'] = np.log(df_clean['games'])
formula = 'redCards ~ skin_tone + height + weight + C(position) + C(leagueCountry) + yellowCards'

model = smf.glm(
    formula=formula, 
    data=df_clean, 
    offset=df_clean['log_games'], 
    family=sm.families.Poisson()
).fit(cov_type='cluster', cov_kwds={'groups': df_clean['refereeID']})

# 4. Compute estimands
params = model.params
conf = model.conf_int()

effect_size = np.exp(params['skin_tone'])
se = model.bse['skin_tone']
p_val = model.pvalues['skin_tone']
ci_lower = np.exp(conf.loc['skin_tone', 0])
ci_upper = np.exp(conf.loc['skin_tone', 1])

# 5. Output JSON
result = {
    "effect_size": float(effect_size),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "poisson",
    "predictor_used": "skin_tone",
    "covariates_included": ["height", "weight", "position", "leagueCountry", "yellowCards"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "rows with missing skin_tone removed"
}

print(json.dumps(result))