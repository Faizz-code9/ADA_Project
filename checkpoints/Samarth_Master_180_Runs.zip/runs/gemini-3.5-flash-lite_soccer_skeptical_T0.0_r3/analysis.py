import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load dataset
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_soccer_skeptical_T0.0_r3/data.csv"
df = pd.read_csv(file_path)

# 2. Clean and prepare data
# Construct skin tone as average of rater1 and rater2
df['skinTone'] = df[['rater1', 'rater2']].mean(axis=1)

# Drop rows where essential variables are missing
subset_cols = ['redCards', 'skinTone', 'games', 'yellowCards']
df_clean = df.dropna(subset=subset_cols).copy()

# Since redCards is a count, Poisson or Negative Binomial regression is appropriate.
# We can include 'games' as an exposure variable (log(games)) to account for playing time.
df_clean['log_games'] = np.log(df_clean['games'].clip(lower=1))

# 3. Fit model
# Using Poisson regression with robust standard errors clustered by referee (refNum)
formula = 'redCards ~ skinTone + yellowCards + log_games'
model = smf.poisson(formula, data=df_clean)
result = model.fit(cov_type='cluster', cov_kwds={'groups': df_clean['refNum']}, disp=False)

# 4. Extract primary estimand (effect of skinTone)
effect_size = float(np.exp(result.params['skinTone']))
std_err = float(result.bse['skinTone'])
p_val = float(result.pvalues['skinTone'])
conf_int = result.conf_int().loc['skinTone']
ci_lower = float(np.exp(conf_int[0]))
ci_upper = float(np.exp(conf_int[1]))

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
  "effect_size": effect_size,
  "effect_type": "irr",
  "standard_error": std_err,
  "p_value": p_val,
  "ci_lower": ci_lower,
  "ci_upper": ci_upper,
  "conclusion": conclusion,
  "model_family": "poisson",
  "predictor_used": "skinTone",
  "covariates_included": ["yellowCards", "log_games"],
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "clustered_se",
  "exclusions_applied": "Dropped rows missing skinTone, redCards, games, or yellowCards."
}

print(json.dumps(output))