import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_disguise_skeptical_T1.0_r1/data.csv"
df = pd.read_csv(file_path)

# 2. Data Preparation & Cleaning
# Construct a combined continuous risk evaluator score (mean of alpha and beta scores, or just one if available, but let's average them or use alpha)
df["risk_score"] = df[
    ["risk_evaluator_alpha_score", "risk_evaluator_beta_score"]
].mean(axis=1)

# Drop missing for primary variables
model_vars = [
    "loan_application_rejections",
    "risk_score",
    "credit_score_index",
    "annual_income_bracket",
]
df_clean = df.dropna(subset=model_vars).copy()

# Ensure binary outcome (rejections > 0 vs 0, or count model? Primary estimand says ratio effect on loan_application_rejections, typically Poisson/NegBin or Logistic. Let's use Poisson for count/ratio effect).
# Wait, loan_application_rejections max is 2, mean 0.012. A Poisson or Logistic regression works. Let's check Poisson for rate ratio (irr).
# Actually, logistic for binary rejection is very common, but Poisson gives an IRR. The prompt asks for ratio effect (irr or odds_ratio).

# Let's define binary rejection indicator or use Poisson for count:
df_clean["rejection_bin"] = (df_clean["loan_application_rejections"] > 0).astype(
    int
)

# 3. Fit Model (Poisson for IRR)
# Covariates: credit_score_index, annual_income_bracket
formula = "loan_application_rejections ~ risk_score + credit_score_index + annual_income_bracket"
model = smf.poisson(formula, data=df_clean).fit(disp=False)

# 4. Extract Estimates
effect_size = np.exp(model.params["risk_score"])
conf_int = np.exp(model.conf_int().loc["risk_score"])
ci_lower = conf_int[0]
ci_upper = conf_int[1]
p_value = model.pvalues["risk_score"]
std_err = model.bse["risk_score"] * effect_size  # Delta method approx for IRR se

conclusion = (
    "significant_effect" if p_value < 0.05 else "no_significant_effect"
)

output = {
    "effect_size": float(effect_size),
    "effect_type": "irr",
    "standard_error": float(std_err),
    "p_value": float(p_value),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": str(conclusion),
    "model_family": "poisson",
    "predictor_used": "risk_score",
    "covariates_included": ["credit_score_index", "annual_income_bracket"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "Dropped rows with missing values in risk score, outcome, or key covariates.",
}

print(json.dumps(output))