import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_soccer_skeptical_T1.0_r5/data.csv"
df = pd.read_csv(file_path)

# 2. Data preparation
# Average rater1 and rater2 for continuous skin tone (0-1)
df["skin_tone"] = (df["rater1"] + df["rater2"]) / 2

# Exclusions & Missing Data Strategy: listwise deletion on required variables
required_vars = ["redCards", "skin_tone", "games"]
df_clean = df.dropna(subset=required_vars).copy()

# Offset for Poisson/Negative Binomial model to account for varying games played (exposure)
df_clean["log_games"] = np.log(df_clean["games"])

# 3. Fit Model (Poisson regression with robust standard errors clustered by referee)
# Alternatively, negative binomial can be used if overdispersed, but Poisson with robust SEs is robust.
# Let's use Poisson via statsmodels GLM with HC1 (clustered or robust) or GEE.
# Using GEE for clustering by refNum:
formula = "redCards ~ skin_tone"
fam = sm.families.Poisson()
# Note: offset is log(games)
mod = smf.gee(
    formula,
    "refNum",
    data=df_clean,
    family=fam,
    offset=df_clean["log_games"],
    cov_struct=sm.cov_struct.Exchangeable(),
)
res = mod.fit()

# 4. Extract primary estimand (ratio effect -> IRR)
coef = res.params["skin_tone"]
se = res.bse["skin_tone"]
p_val = res.pvalues["skin_tone"]
ci = res.conf_int()
ci_lower = np.exp(ci.loc["skin_tone", 0])
ci_upper = np.exp(ci.loc["skin_tone", 1])
irr = np.exp(coef)

conclusion = (
    "significant_effect" if p_val < 0.05 else "no_significant_effect"
)

output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "gee",
    "predictor_used": "skin_tone",
    "covariates_included": [],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "gee",
    "exclusions_applied": "Dropped rows missing skin_tone or redCards",
}

print(json.dumps(output))