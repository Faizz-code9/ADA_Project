import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

# 1. Load data
file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_disguise_neutral_T0.7_r2/data.csv'
df = pd.read_csv(file_path)

# 2. Data Cleaning & Construction
# The error "endog must be in the unit interval" indicates loan_application_rejections 
# is not strictly binary (0/1). Checking unique values: 0, 1, 2. 
# We will treat this as a count process or Poisson regression since it represents 
# number of rejections per application event.
df['risk_evaluator_score'] = df[['risk_evaluator_alpha_score', 'risk_evaluator_beta_score']].mean(axis=1)

# Drop missing values for required columns
df = df.dropna(subset=['risk_evaluator_score', 'loan_application_rejections', 'credit_score_index', 'annual_income_bracket'])

# 3. Model Fitting
# Use Poisson regression for count data (number of rejections)
formula = 'loan_application_rejections ~ risk_evaluator_score + credit_score_index + annual_income_bracket'
model = smf.poisson(formula, data=df)
# Use cluster-robust standard errors
res = model.fit(cov_type='cluster', cov_kwds={'groups': df['loan_officer_id']}, disp=0)

# 4. Extract Estimates
params = res.params
conf_int = res.conf_int()
p_val = res.pvalues['risk_evaluator_score']
# IRR (Incidence Rate Ratio) is exponentiated coefficient for Poisson
effect = np.exp(params['risk_evaluator_score'])
ci_lower = np.exp(conf_int.loc['risk_evaluator_score', 0])
ci_upper = np.exp(conf_int.loc['risk_evaluator_score', 1])

# 5. Output JSON
output = {
    "effect_size": float(effect),
    "effect_type": "irr",
    "standard_error": float(res.bse['risk_evaluator_score']),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "poisson",
    "predictor_used": "average of risk_evaluator_alpha_score and risk_evaluator_beta_score",
    "covariates_included": ["credit_score_index", "annual_income_bracket"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "rows with missing risk evaluator scores or core demographic covariates"
}

print(json.dumps(output))