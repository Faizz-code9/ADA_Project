import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

# 1. Load data
file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_soccer_neutral_T0.0_r2/data.csv'
df = pd.read_csv(file_path)

# 2. Clean and prepare
# Drop rows where skin tone ratings are missing
df = df.dropna(subset=['rater1', 'rater2'])
# Construct skin tone variable as average of two raters
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2
# Ensure redCards is binary for logistic regression (though mean is low, some have >1)
df['red_binary'] = (df['redCards'] > 0).astype(int)

# 3. Fit model
# Using Logistic Regression with clustered standard errors by referee (refNum)
# Covariates: games (exposure), position (categorical), leagueCountry (categorical)
# We use GEE for clustering as it handles the binary outcome and clustering well
model = smf.gee("red_binary ~ skin_tone + games + C(position) + C(leagueCountry)", 
                data=df, 
                groups=df['refNum'], 
                family=sm.families.Binomial())
result = model.fit()

# 4. Compute estimand
# Extract coefficient for skin_tone
coef = result.params['skin_tone']
se = result.bse['skin_tone']
p_val = result.pvalues['skin_tone']
ci = result.conf_int().loc['skin_tone']

# 5. Prepare JSON output
output = {
    "effect_size": np.exp(coef),
    "effect_type": "odds_ratio",
    "standard_error": se,
    "p_value": p_val,
    "ci_lower": np.exp(ci[0]),
    "ci_upper": np.exp(ci[1]),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "gee",
    "predictor_used": "average of rater1 and rater2",
    "covariates_included": ["games", "position", "leagueCountry"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "gee",
    "exclusions_applied": "rows with missing rater1 or rater2 values"
}

print(json.dumps(output))