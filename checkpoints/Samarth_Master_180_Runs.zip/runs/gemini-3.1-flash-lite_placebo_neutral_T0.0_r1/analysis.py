import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

# 1. Load data
file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_placebo_neutral_T0.0_r1/data.csv'
df = pd.read_csv(file_path)

# 2. Clean and prepare
# Drop rows where skin tone ratings are missing
df = df.dropna(subset=['rater1', 'rater2'])
# Construct skin tone variable as average of two raters
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2
# Ensure outcome is binary for logistic regression (redCards can be > 1, but usually treated as indicator)
df['red_card_binary'] = (df['redCards'] > 0).astype(int)

# 3. Fit model
# Using Logistic Regression with clustering by referee (refNum)
# Covariates: games (exposure), position (categorical), leagueCountry (categorical)
# We use GEE to handle clustering by referee
model = smf.gee("red_card_binary ~ skin_tone + games + C(position) + C(leagueCountry)", 
                groups=df['refNum'], 
                data=df, 
                family=sm.families.Binomial())
result = model.fit()

# 4. Compute estimand
# Extract coefficient for skin_tone
coef = result.params['skin_tone']
se = result.bse['skin_tone']
p_val = result.pvalues['skin_tone']
ci_lower = coef - 1.96 * se
ci_upper = coef + 1.96 * se

# 5. Output JSON
output = {
    "effect_size": float(np.exp(coef)),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(np.exp(ci_lower)),
    "ci_upper": float(np.exp(ci_upper)),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "gee",
    "predictor_used": "average of rater1 and rater2",
    "covariates_included": ["games", "position", "leagueCountry"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "gee",
    "exclusions_applied": "rows with missing rater1 or rater2 values"
}

print(json.dumps(output))