import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

# 1. Load the data
file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_soccer_neutral_T0.7_r2/data.csv'
df = pd.read_csv(file_path)

# 2. Prepare data
# Calculate mean skin tone and drop rows where rater data is missing
df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)
df_clean = df.dropna(subset=['skin_tone', 'refNum', 'games', 'yellowCards', 'redCards']).copy()

# Ensure we have at least one game played to avoid structural zeros
df_clean = df_clean[df_clean['games'] > 0]

# 3. Fit model
# Using Logistic Regression for binary outcome (redCards is 0 or >0)
# We treat redCards as a binary indicator since the mean is very low (~0.01)
df_clean['red_card_binary'] = (df_clean['redCards'] > 0).astype(int)

# Formula includes refNum as a random effect proxy via clustering to account for referee bias
# We adjust for games and yellowCards as they are direct indicators of disciplinary action
formula = 'red_card_binary ~ skin_tone + games + yellowCards'
model = smf.logit(formula, data=df_clean).fit(cov_type='cluster', cov_kwds={'groups': df_clean['refNum']}, disp=0)

# 4. Compute estimand
params = model.params
conf_int = model.conf_int()
p_values = model.pvalues

effect_size = params['skin_tone']
se = model.bse['skin_tone']
ci_lower = conf_int.loc['skin_tone', 0]
ci_upper = conf_int.loc['skin_tone', 1]
p_val = p_values['skin_tone']

# 5. Output JSON
result = {
    "effect_size": float(np.exp(effect_size)), # Exponentiated to get Odds Ratio
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(np.exp(ci_lower)),
    "ci_upper": float(np.exp(ci_upper)),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "logistic",
    "predictor_used": "mean of rater1 and rater2",
    "covariates_included": ["games", "yellowCards"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "rows with missing rater data or zero games"
}

print(json.dumps(result))