import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

def run_analysis():
    # 1. Load data
    file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_soccer_skeptical_T1.0_r4/data.csv'
    df = pd.read_csv(file_path)

    # 2. Clean and prepare
    # We focus on rows where skin tone data exists
    df = df.dropna(subset=['rater1', 'rater2'])
    
    # Construct mean skin tone
    df['skin_tone'] = (df['rater1'] + df['rater2']) / 2
    
    # We use Poisson regression for count outcome (redCards) 
    # and include refNum as a random effect/cluster variable
    # Predictor: skin_tone, Covariates: games, yellowCards (risk exposure)
    
    # 3. Model
    # Using GEE for clustered data by referee to handle non-independence of decisions
    formula = "redCards ~ skin_tone + games + yellowCards"
    
    fam = sm.families.Poisson()
    ind = sm.cov_struct.Exchangeable()
    
    model = smf.gee(formula, "refNum", df, family=fam, cov_struct=ind)
    result = model.fit()

    # 4. Extract metrics
    params = result.params
    bse = result.bse
    pvalues = result.pvalues
    conf = result.conf_int()
    
    effect = params['skin_tone']
    se = bse['skin_tone']
    p_val = pvalues['skin_tone']
    ci_low = conf.loc['skin_tone', 0]
    ci_high = conf.loc['skin_tone', 1]
    
    # JSON Output
    output = {
        "effect_size": float(np.exp(effect)),
        "effect_type": "irr",
        "standard_error": float(se),
        "p_value": float(p_val),
        "ci_lower": float(np.exp(ci_low)),
        "ci_upper": float(np.exp(ci_high)),
        "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
        "model_family": "gee",
        "predictor_used": "average of rater1 and rater2 skin tone ratings",
        "covariates_included": ["games", "yellowCards"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "gee",
        "exclusions_applied": "dropped rows with missing rater1/rater2 values (21,407 rows)"
    }
    
    print(json.dumps(output))

if __name__ == "__main__":
    run_analysis()