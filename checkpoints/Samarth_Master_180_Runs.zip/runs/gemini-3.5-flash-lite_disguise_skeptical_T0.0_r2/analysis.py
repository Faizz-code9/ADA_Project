import json
import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_disguise_skeptical_T0.0_r2/data.csv"
df = pd.read_csv(file_path)

# 2. Data Preparation & Construction
# Predictor: continuous risk evaluator score. We can average alpha and beta scores to get a single 0-1 risk score.
df['risk_evaluator_score'] = (df['risk_evaluator_alpha_score'] + df['risk_evaluator_beta_score']) / 2.0

# Define outcome: loan_application_rejections (binary or count, let's treat as binary/logistic given standard banking rejections, or count via Poisson/GLM. Since rejections max is 2 and mean is ~0.0125, logistic or poisson works. Let's use Logistic Regression as standard for rejections).
# Wait, outcome is count of rejections (max 2). Let's convert to binary indicator for logistic regression or use Poisson. Let's use binary logistic regression (rejection > 0 vs 0) or Poisson. Let's check max: 2. Let's treat as binary: rejected_flag = (loan_application_rejections > 0).
df['rejected_flag'] = (df['loan_application_rejections > 0'] if 'loan_application_rejections > 0' in df else (df['loan_application_rejections'] > 0).astype(int))

# Covariates: credit_score_index, annual_income_bracket
covariates = ['credit_score_index', 'annual_income_bracket']

# Missing data strategy: listwise deletion on used columns
model_data = df[['rejected_flag', 'risk_evaluator_score', 'credit_score_index', 'annual_income_bracket']].dropna()

# 3. Fit Model (Logistic Regression)
X = model_data[['risk_evaluator_score', 'credit_score_index', 'annual_income_bracket']]
X = sm.add_constant(X)
y = model_data['rejected_flag']

logit_model = sm.Logit(y, X).fit(disp=False)

# 4. Extract primary estimand (odds ratio for risk_evaluator_score)
params = logit_model.params
conf = logit_model.conf_int()

effect_log_odds = params['risk_evaluator_score']
effect_size = np.exp(effect_log_odds)
se_log_odds = logit_model.bse['risk_evaluator_score']
p_val = logit_model.pvalues['risk_evaluator_score']
ci_lower = np.exp(conf.loc['risk_evaluator_score', 0])
ci_upper = np.exp(conf.loc['risk_evaluator_score', 1])

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
  "effect_size": float(effect_size),
  "effect_type": "odds_ratio",
  "standard_error": float(se_log_odds),
  "p_value": float(p_val),
  "ci_lower": float(ci_lower),
  "ci_upper": float(ci_upper),
  "conclusion": conclusion,
  "model_family": "logistic",
  "predictor_used": "risk_evaluator_score",
  "covariates_included": covariates,
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "none",
  "exclusions_applied": "dropped rows with missing values in regression variables"
}

print(json.dumps(output))