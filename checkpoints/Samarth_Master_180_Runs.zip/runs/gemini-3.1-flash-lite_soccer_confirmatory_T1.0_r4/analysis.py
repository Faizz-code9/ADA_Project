import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

def run_analysis():
    # 1. Load data
    df = pd.read_csv('/kaggle/working/outputs/runs/gemini-3.1-flash-lite_soccer_confirmatory_T1.0_r4/data.csv')

    # 2. Cleaning and preparation
    # Filter for observations where skin tone ratings exist
    df = df.dropna(subset=['rater1', 'rater2'])
    
    # Construct primary predictor: average skin tone (0-1)
    df['skin_tone'] = (df['rater1'] + df['rater2']) / 2.0
    
    # Ensure binary outcome
    df['red_cards_binary'] = (df['redCards'] > 0).astype(int)
    
    # 3. Model fitting
    # We use Logistic Regression for the ratio effect (odds ratio)
    # Using clustered standard errors at the referee level as red card decisions 
    # are often associated with individual referees.
    model = smf.logit(
        'red_cards_binary ~ skin_tone + games + yellowCards', 
        data=df
    )
    
    # Fit with clustered SEs by refNum
    res = model.fit(cov_type='cluster', cov_kwds={'groups': df['refNum']}, disp=0)
    
    # 4. Extract quantities
    params = res.params
    conf = res.conf_int()
    
    # Ratio effect (Odds Ratio)
    effect_size = np.exp(params['skin_tone'])
    ci_lower = np.exp(conf.loc['skin_tone', 0])
    ci_upper = np.exp(conf.loc['skin_tone', 1])
    
    # Calculate SE for Odds Ratio using Delta Method approx: SE(OR) = OR * SE(coef)
    # Note: res.bse is the clustered SE of the coefficient
    se_or = effect_size * res.bse['skin_tone']
    
    p_value = res.pvalues['skin_tone']
    
    # 5. Output JSON
    result = {
        "effect_size": float(effect_size),
        "effect_type": "odds_ratio",
        "standard_error": float(se_or),
        "p_value": float(p_value),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": "significant_effect" if p_value < 0.05 else "no_significant_effect",
        "model_family": "logistic",
        "predictor_used": "average_of_rater1_and_rater2",
        "covariates_included": ["games", "yellowCards"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "clustered_se",
        "exclusions_applied": "rows with missing rater data"
    }
    
    print(json.dumps(result))

if __name__ == "__main__":
    run_analysis()