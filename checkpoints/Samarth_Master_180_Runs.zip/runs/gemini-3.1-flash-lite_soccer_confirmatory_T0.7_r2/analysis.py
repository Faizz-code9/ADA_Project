import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

# 1. Load Data
file_path = "/kaggle/working/outputs/runs/gemini-3.1-flash-lite_soccer_confirmatory_T0.7_r2/data.csv"
df = pd.read_csv(file_path)

# 2. Prepare Data
# Exclude missing rater data
df = df.dropna(subset=['rater1', 'rater2'])
# Create primary predictor: average of the two raters
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2

# To handle clustering correctly with GLM, we ensure the index aligns with the grouping vector
df = df.sort_values('refNum').reset_index(drop=True)

# 3. Fit Model
# Using Poisson regression. 
# We use Generalized Estimating Equations (GEE) as it is robust for clustered count data
# and avoids the specific index alignment issues of GLM with cluster keywords.
fam = sm.families.Poisson()
ind = sm.cov_struct.Exchangeable()
model = smf.gee(
    "redCards ~ skin_tone + height + weight", 
    "refNum", 
    data=df, 
    family=fam,
    cov_struct=ind
)
results = model.fit()

# 4. Compute Estimands
# GEE results: effect size is exponentiated coefficient
params = results.params
bse = results.bse
pvalues = results.pvalues
conf = results.conf_int()

effect_size = np.exp(params['skin_tone'])
ci_lower = np.exp(conf.loc['skin_tone', 0])
ci_upper = np.exp(conf.loc['skin_tone', 1])
p_value = pvalues['skin_tone']

# 5. Format JSON output
output = {
    "effect_size": float(effect_size),
    "effect_type": "irr",
    "standard_error": float(bse['skin_tone']),
    "p_value": float(p_value),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if p_value < 0.05 else "no_significant_effect",
    "model_family": "gee",
    "predictor_used": "average of rater1 and rater2",
    "covariates_included": ["height", "weight"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "gee",
    "exclusions_applied": "rows with missing rater1 or rater2 values removed"
}

print(json.dumps(output))