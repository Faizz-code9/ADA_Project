import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_placebo_skeptical_T1.0_r1/data.csv"
df = pd.read_csv(file_path)

# 2. Data prep / variable construction
# Average skin tone from rater1 and rater2
df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)

# Drop rows missing skin_tone or redCards
df_clean = df.dropna(subset=['skin_tone', 'redCards']).copy()

# 3. Fit model
# Since redCards is a count/rare event and the primary estimand is a ratio effect (IRR),
# we use a Poisson regression with robust standard errors (or standard Poisson).
# Alternatively, a log-link GLM (Poisson).
formula = 'redCards ~ skin_tone + height + weight + yellowCards'
model = smf.poisson(formula, data=df_clean)
results = model.fit(disp=False, cov_type='HC1')

# 4. Extract primary estimand (skin_tone effect)
# Effect type is 'irr' (incidence rate ratio)
coef = results.params['skin_tone']
se = results.bse['skin_tone']
pval = results.pvalues['skin_tone']
ci = results.conf_int().loc['skin_tone']

irr = np.exp(coef)
ci_lower = np.exp(ci[0])
ci_upper = np.exp(ci[1])

conclusion = 'significant_effect' if pval < 0.05 else 'no_significant_effect'

output = {
  "effect_size": float(irr),
  "effect_type": "irr",
  "standard_error": float(se),
  "p_value": float(pval),
  "ci_lower": float(ci_lower),
  "ci_upper": float(ci_upper),
  "conclusion": conclusion,
  "model_family": "poisson",
  "predictor_used": "skin_tone",
  "covariates_included": ["height", "weight", "yellowCards"],
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "none",
  "exclusions_applied": "Dropped rows with missing skin_tone or redCards"
}

print(json.dumps(output))