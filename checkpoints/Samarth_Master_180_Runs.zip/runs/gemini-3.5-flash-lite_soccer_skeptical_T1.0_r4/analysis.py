import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_soccer_skeptical_T1.0_r4/data.csv"
df = pd.read_csv(file_path)

# 2. Data preparation
# Create average skin tone predictor
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2

# Filter out rows with missing skin tone or redCards
df_clean = df.dropna(subset=['skin_tone', 'redCards']).copy()

# 3. Fit Poisson model (or negative binomial if overdispersed)
# Using Poisson regression as primary estimand is an IRR (incidence rate ratio) for count outcome (redCards)
model = smf.poisson('redCards ~ skin_tone', data=df_clean).fit(disp=False)

# 4. Extract metrics
effect_size = np.exp(model.params['skin_tone'])
se = model.bse['skin_tone']
p_val = model.pvalues['skin_tone']
ci = model.conf_int().loc['skin_tone']
ci_lower = np.exp(ci[0])
ci_upper = np.exp(ci[1])

conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

output = {
    "effect_size": float(effect_size),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "skin_tone",
    "covariates_included": [],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "Removed rows with missing rater1/rater2 or redCards"
}

print(json.dumps(output))