import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

def analyze_bias():
    # 1. Load data
    file_path = "/kaggle/working/outputs/runs/gemini-3.1-flash-lite_synthetic_confirmatory_T1.0_r2/data.csv"
    df = pd.read_csv(file_path)

    # 2. Preparation: Listwise deletion for skin_tone (missingness 8%)
    df = df.dropna(subset=['skin_tone'])

    # 3. Model: Poisson regression to estimate IRR for redCards (count data)
    # Including controls for position and games played to account for exposure
    # Using clustered standard errors at the referee level as bias is referee-dependent
    formula = "redCards ~ skin_tone + C(position) + yellowCards + games + C(leagueCountry)"
    model = smf.poisson(formula, data=df).fit(cov_type='cluster', cov_kwds={'groups': df['refereeID']}, disp=False)

    # 4. Extract parameters
    params = model.params
    bse = model.bse
    conf = model.conf_int()

    effect_size = np.exp(params['skin_tone'])
    se_log = bse['skin_tone']
    
    # Delta method for standard error of IRR
    se_irr = effect_size * se_log
    
    ci_lower = np.exp(conf.loc['skin_tone', 0])
    ci_upper = np.exp(conf.loc['skin_tone', 1])
    p_val = model.pvalues['skin_tone']

    # 5. Construct result
    result = {
        "effect_size": float(effect_size),
        "effect_type": "irr",
        "standard_error": float(se_irr),
        "p_value": float(p_val),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
        "model_family": "poisson",
        "predictor_used": "skin_tone",
        "covariates_included": ["position", "yellowCards", "games", "leagueCountry"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "clustered_se",
        "exclusions_applied": "rows with missing skin_tone"
    }

    print(json.dumps(result))

if __name__ == "__main__":
    analyze_bias()