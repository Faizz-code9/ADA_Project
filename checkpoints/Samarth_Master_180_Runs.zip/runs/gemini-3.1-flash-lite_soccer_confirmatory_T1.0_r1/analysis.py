import pandas as pd
import numpy as np
import statsmodels.formula.api as smf
import statsmodels.api as sm
import json

def run_analysis():
    # 1. Load data
    file_path = "/kaggle/working/outputs/runs/gemini-3.1-flash-lite_soccer_confirmatory_T1.0_r1/data.csv"
    df = pd.read_csv(file_path)

    # 2. Clean and prepare data
    # Drop rows where skin tone ratings are missing (the primary predictor)
    df = df.dropna(subset=['rater1', 'rater2'])
    
    # Construct continuous skin tone variable
    df['skin_tone'] = (df['rater1'] + df['rater2']) / 2
    
    # Subset to necessary columns and drop rows with missing covariates
    cols_to_use = ['redCards', 'skin_tone', 'games', 'height', 'weight', 'refNum']
    df_model = df[cols_to_use].dropna()

    # 3. Fit model
    # Use GEE for count data (redCards) to account for referee clustering
    # Note: statsmodels.genmod.families contains Poisson
    fam = sm.families.Poisson()
    ind = sm.cov_struct.Exchangeable()
    
    model = smf.gee("redCards ~ skin_tone + games + height + weight", 
                    data=df_model, 
                    groups=df_model['refNum'], 
                    family=fam,
                    cov_struct=ind)
    results = model.fit()

    # 4. Compute primary estimand
    # IRR is exponentiated coefficient
    coef = results.params['skin_tone']
    se = results.bse['skin_tone']
    irr = np.exp(coef)
    
    # Wald CI for IRR
    z_score = 1.96
    ci_lower = np.exp(coef - z_score * se)
    ci_upper = np.exp(coef + z_score * se)
    
    # P-value (Wald test)
    p_val = results.pvalues['skin_tone']

    # 5. Output JSON
    output = {
        "effect_size": float(irr),
        "effect_type": "irr",
        "standard_error": float(se),
        "p_value": float(p_val),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
        "model_family": "gee",
        "predictor_used": "average of rater1 and rater2 skin tone",
        "covariates_included": ["games", "height", "weight"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "gee",
        "exclusions_applied": "removed rows with missing rater1/rater2 ratings or covariates"
    }

    print(json.dumps(output))

if __name__ == "__main__":
    run_analysis()