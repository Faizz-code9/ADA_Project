import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

# 1. Load data
file_path = '/kaggle/working/outputs/runs/gemini-3.1-flash-lite_soccer_neutral_T1.0_r3/data.csv'
df = pd.read_csv(file_path)

# 2. Prepare data
# Exclusions: Drop rows where skin tone raters are missing
df = df.dropna(subset=['rater1', 'rater2'])
# Construct skin tone measure (average of two raters)
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2

# Exclude missing covariates used in adjustment
covariates = ['height', 'weight', 'position']
df = df.dropna(subset=covariates)

# 3. Model
# Using GEE for clustered data (referee clustering). 
# Note: sm.families.Poisson is the correct call.
model = smf.gee("redCards ~ skin_tone + height + weight + C(position)", 
                data=df, 
                groups=df["refNum"], 
                family=sm.families.Poisson())
result = model.fit()

# 4. Extract statistics
# Effect size (IRR = exp(coef))
coef = result.params['skin_tone']
irr = np.exp(coef)
# Standard error for IRR via Delta Method: SE(exp(b)) = exp(b) * SE(b)
se_irr = irr * result.bse['skin_tone']
p_val = result.pvalues['skin_tone']
ci_lower = np.exp(coef - 1.96 * result.bse['skin_tone'])
ci_upper = np.exp(coef + 1.96 * result.bse['skin_tone'])

# 5. Output JSON
output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se_irr),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
    "model_family": "gee",
    "predictor_used": "average of rater1 and rater2",
    "covariates_included": ["height", "weight", "position"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "gee",
    "exclusions_applied": "removed rows with missing rater scores, height, weight, or position"
}

print(json.dumps(output))