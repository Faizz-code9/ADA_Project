import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

# 1. Load data
file_path = "/kaggle/working/outputs/runs/gemini-3.5-flash-lite_placebo_skeptical_T0.7_r1/data.csv"
df = pd.read_csv(file_path)

# 2. Clean and prepare data
# Construct skin tone as average of rater1 and rater2
df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)

# Drop rows where skin tone or redCards are missing
df_clean = df.dropna(subset=['skin_tone', 'redCards']).copy()

# Listwise deletion strategy for missing variables used in model
model_vars = ['redCards', 'skin_tone', 'yellowCards', 'games']
df_clean = df_clean.dropna(subset=model_vars)

# 3. Fit Poisson regression model (ratio effect for count outcome)
# Using robust standard errors clustered by referee (refNum) to account for dependencies
formula = "redCards ~ skin_tone + yellowCards + games"
model = smf.poisson(formula, data=df_clean)
result = model.fit(cov_type='cluster', cov_kwds={'groups': df_clean['refNum']}, disp=False)

# 4. Extract primary estimand (skin_tone coefficient)
effect_size = np.exp(result.params['skin_tone'])
std_err = result.bse['skin_tone']  # SE on log scale, but let's report coefficient/IRR properly
p_value = result.pvalues['skin_tone']
ci_lower = np.exp(result.conf_int().loc['skin_tone', 0])
ci_upper = np.exp(result.conf_int().loc['skin_tone', 1])

# Determine conclusion
conclusion = "no_significant_effect" if p_value > 0.05 else "significant_effect"

# 5. Output JSON
output = {
  "effect_size": float(effect_size),
  "effect_type": "irr",
  "standard_error": float(result.bse['skin_tone']),
  "p_value": float(p_value),
  "ci_lower": float(ci_lower),
  "ci_upper": float(ci_upper),
  "conclusion": conclusion,
  "model_family": "poisson",
  "predictor_used": "skin_tone",
  "covariates_included": ["yellowCards", "games"],
  "missing_data_strategy": "listwise_deletion",
  "clustering_strategy": "clustered_se",
  "exclusions_applied": "Dropped rows with missing skin tone, red cards, or covariates."
}

print(json.dumps(output))