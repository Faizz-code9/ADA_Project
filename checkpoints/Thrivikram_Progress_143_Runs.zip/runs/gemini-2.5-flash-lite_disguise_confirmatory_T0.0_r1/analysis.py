import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

def run_analysis():
    file_path = '/kaggle/working/outputs/runs/gemini-2.5-flash-lite_disguise_confirmatory_T0.0_r1/data.csv'
    
    try:
        df = pd.read_csv(file_path)
    except FileNotFoundError:
        return

    # The hypothesis asks for the effect of risk evaluator scores on loan rejections.
    # The primary estimand is the ratio effect of continuous risk evaluator score (0-1).
    # Since 'loan_application_rejections' is a count (0, 1, 2), and we want a ratio effect,
    # a Poisson regression or Negative Binomial is appropriate. 
    # However, the prompt asks for "ratio effect" which in the context of counts 
    # usually implies an Incidence Rate Ratio (IRR).
    
    # Data Cleaning
    # We need to handle missing values in the predictor and outcome.
    # risk_evaluator_alpha_score and risk_evaluator_beta_score have 14.7% missing.
    # The prompt implies a single continuous score. I will use the average of alpha and beta 
    # or choose one. Given the prompt says "risk evaluator score (0-1)", 
    # and both alpha and beta are 0-1, I'll use alpha as the primary predictor.
    
    df['risk_score'] = df['risk_evaluator_alpha_score']
    
    # Target: loan_application_rejections (count)
    # Predictor: risk_score (continuous 0-1)
    
    # Exclusions: rows where target or predictor is NaN
    initial_len = len(df)
    df_clean = df.dropna(subset=['loan_application_rejections', 'risk_score']).copy()
    exclusions = f"Removed {initial_len - len(df_clean)} rows due to missing values in target or predictor."

    # Model: Poisson regression to get Incidence Rate Ratio (IRR)
    # IRR = exp(coefficient)
    X = sm.add_constant(df_clean['risk_score'])
    y = df_clean['loan_application_rejections']
    
    model = sm.GLM(y, X, family=sm.families.Poisson()).fit()
    
    coeff = model.params['risk_score']
    std_err = model.bse['risk_score']
    p_val = model.pvalues['risk_score']
    irr = np.exp(coeff)
    ci_lower = np.exp(model.conf_int().loc['risk_score'][0])
    ci_upper = np.exp(model.conf_int().loc['risk_score'][1])
    
    conclusion = 'significant_effect' if p_val < 0.05 else 'no_significant_effect'
    
    result = {
        "effect_size": float(irr),
        "effect_type": "irr",
        "standard_error": float(std_err), # Note: SE of coefficient is standard, SE of IRR is different, but usually SE refers to the model parameter
        "p_value": float(p_val),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": conclusion,
        "model_family": "poisson",
        "predictor_used": "risk_evaluator_alpha_score",
        "covariates_included": [],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "none",
        "exclusions_applied": exclusions
    }
    
    # Adjusting standard_error to be the SE of the IRR for consistency if needed, 
    # but standard practice in these tasks is the model parameter SE.
    # However, to be mathematically precise for the IRR:
    # SE_irr = irr * std_err_coeff
    result["standard_error"] = float(irr * std_err)

    print(json.dumps(result))

if __name__ == "__main__":
    run_analysis()