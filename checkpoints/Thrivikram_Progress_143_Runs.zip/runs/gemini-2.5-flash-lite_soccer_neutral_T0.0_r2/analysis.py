import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

def solve():
    file_path = '/kaggle/working/outputs/runs/gemini-2.5-flash-lite_T0.0_r2/data.csv'
    try:
        df = pd.read_csv(file_path)
    except FileNotFoundError:
        # Fallback for local testing if path differs, though instructions say use absolute path
        return

    # 1. Data Cleaning and Preparation
    # Primary estimand: ratio effect of continuous skin tone on red cards.
    # Skin tone is provided by rater1 and rater2. We'll use the mean.
    # redCards is the outcome.
    
    # Drop rows where outcome or predictor is missing
    initial_count = len(df)
    df = df.dropna(subset=['redCards', 'rater1', 'rater2'])
    
    # Construct continuous skin tone predictor
    df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)
    
    # Since redCards is a count (0, 1, 2), and we want the "ratio effect" 
    # (Incidence Rate Ratio), a Poisson regression is appropriate.
    # We use 'games' as an offset to account for exposure (number of games played).
    # However, the data dictionary shows 'redCards' is likely the total count per player/entry.
    # If redCards is a count, Poisson with log link gives IRR.
    
    # Exclude rows where games <= 0 to avoid log(0) in offset
    df = df[df['games'] > 0]
    
    # Covariates: height, weight, yellowCards (to control for general disciplinary tendency)
    # We'll use listwise deletion for rows with missing covariates
    covariates = ['height', 'weight', 'yellowCards']
    df = df.dropna(subset=covariates)
    
    final_count = len(df)
    exclusions = f"Removed {initial_count - final_count} rows due to missing values or games=0"

    # 2. Statistical Modeling
    # Poisson regression: log(E[redCards]) = beta0 + beta1*skin_tone + ... + log(games)
    # The coefficient beta1 is the log(IRR). IRR = exp(beta1).
    
    formula = "redCards ~ skin_tone + height + weight + yellowCards"
    # We use log(games) as an offset to model the rate of red cards per game
    model = smf.poisson(formula, data=df, offset=np.log(df['games']))
    results = model.fit(disp=False)

    # 3. Compute Estimands
    beta_skin = results.params['skin_tone']
    se_skin = results.bse['skin_tone']
    p_val = results.pvalues['skin_tone']
    
    # IRR (Incidence Rate Ratio)
    irr = np.exp(beta_skin)
    ci_lower = np.exp(results.conf_int().loc['skin_tone', 0])
    ci_upper = np.exp(results.conf_int().loc['skin_tone', 1])

    # 4. Prepare JSON Output
    output = {
        "effect_size": float(irr),
        "effect_type": "irr",
        "standard_error": float(se_skin), # SE of the coefficient (log scale) is standard for reporting
        "p_value": float(p_val),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
        "model_family": "poisson",
        "predictor_used": "mean(rater1, rater2)",
        "covariates_included": covariates,
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "none",
        "exclusions_applied": exclusions
    }

    print(json.dumps(output, indent=2))

if __name__ == "__main__":
    solve()