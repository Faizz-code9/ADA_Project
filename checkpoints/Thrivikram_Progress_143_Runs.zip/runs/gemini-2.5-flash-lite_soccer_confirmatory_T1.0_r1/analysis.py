import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

def analyze():
    path = "/kaggle/working/outputs/runs/gemini-2.5-flash-lite_soccer_confirmatory_T1.0_r1/data.csv"
    df = pd.read_csv(path)

    # 1. Data Cleaning & Variable Construction
    # The primary predictor is skin tone. The dictionary provides rater1 and rater2.
    # We'll use the mean of rater1 and rater2 as the continuous skin tone variable.
    df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)

    # Outcome: redCards (count data)
    # Since redCards is a count (0, 1, 2), a Poisson regression is appropriate for the ratio effect.
    # The hypothesis asks for the ratio effect of continuous skin tone.
    # In a Poisson model, the exponentiated coefficient is the Incidence Rate Ratio (IRR).

    # Select relevant columns and remove rows with missing skin_tone or redCards
    # redCards has 0 missing, but skin_tone depends on rater1/rater2 which have 14.7% missing.
    cols_to_keep = ['redCards', 'skin_tone', 'games', 'yellowCards']
    df_clean = df.dropna(subset=['skin_tone', 'redCards']).copy()
    
    # We use 'games' as an offset to model the rate of red cards per game
    # However, redCards is often recorded as cumulative in such datasets. 
    # Given 'games' is in the data, we treat it as exposure.
    # rate = redCards / games. To use Poisson, we model redCards with log(games) as offset.
    df_clean = df_clean[df_clean['games'] > 0]
    df_clean['log_games'] = np.log(df_clean['games'])

    # 2. Model Fitting
    # Poisson regression to estimate the effect of skin_tone on the rate of redCards.
    # Controlling for yellowCards to isolate the specific bias if possible.
    X = df_clean[['skin_tone', 'yellowCards']]
    X = sm.add_constant(X)
    y = df_clean['redCards']
    offset = df_clean['log_games']

    try:
        model = sm.GLM(y, X, family=sm.families.Poisson(), offset=offset).fit()
        
        # 3. Computation of Estimands
        # The coefficient of skin_tone is the log-IRR.
        # The effect_size (IRR) is exp(coef).
        beta_skin = model.params['skin_tone']
        se_skin = model.bse['skin_tone']
        p_val = model.pvalues['skin_tone']
        
        irr = np.exp(beta_skin)
        ci_low = np.exp(model.conf_int().loc['skin_tone'][0])
        ci_high = np.exp(model.conf_int().loc['skin_tone'][1])
        
        conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"
        
        result = {
            "effect_size": float(irr),
            "effect_type": "irr",
            "standard_error": float(se_skin), # SE of log-scale coefficient
            "p_value": float(p_val),
            "ci_lower": float(ci_low),
            "ci_upper": float(ci_high),
            "conclusion": conclusion,
            "model_family": "poisson",
            "predictor_used": "mean(rater1, rater2)",
            "covariates_included": ["yellowCards", "games_offset"],
            "missing_data_strategy": "listwise_deletion",
            "clustering_strategy": "none",
            "exclusions_applied": f"Removed {len(df) - len(df_clean)} rows due to missing skin tone or games=0"
        }
        
        print(json.dumps(result))

    except Exception as e:
        # Fallback if Poisson fails due to convergence or data issues
        print(json.dumps({"error": str(e)}))

if __name__ == "__main__":
    analyze()