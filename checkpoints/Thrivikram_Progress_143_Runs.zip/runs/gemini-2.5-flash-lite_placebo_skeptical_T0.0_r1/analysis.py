import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

def solve():
    file_path = '/kaggle/working/outputs/runs/gemini-2.5-flash-lite_placebo_skeptical_T0.0_r1/data.csv'
    df = pd.read_csv(file_path)

    # Data Cleaning
    # Primary estimand: ratio effect of continuous skin tone (0-1) on red cards.
    # Skin tone is provided by rater1 and rater2. We use the mean of the two raters.
    # redCards is the outcome.
    
    # Drop rows where outcome or predictor is missing
    df = df.dropna(subset=['redCards', 'rater1', 'rater2'])
    
    # Construct predictor: mean skin tone
    df['skin_tone_avg'] = df[['rater1', 'rater2']].mean(axis=1)
    
    # Exclusions: rows with invalid skin tone values (though dictionary says 0-1)
    df = df[(df['skin_tone_avg'] >= 0) & (df['skin_tone_avg'] <= 1)]
    
    # Since redCards is a count (0, 1, 2), and we want a "ratio effect" (IRR),
    # a Poisson regression is appropriate for count data.
    # The coefficient in Poisson is the log of the Incidence Rate Ratio (IRR).
    
    y = df['redCards']
    X = sm.add_constant(df['skin_tone_avg'])
    
    # Model: Poisson regression
    # We include 'games' as a covariate to account for exposure/opportunity
    # However, the prompt asks for the effect of skin tone on red cards.
    # To get a proper rate, we should use 'games' as an offset (log(games)).
    # But 'games' can be 0? Dictionary says min 1.
    
    df = df[df['games'] > 0]
    offset = np.log(df['games'])
    X = sm.add_constant(df[['skin_tone_avg']])
    
    model = sm.GLM(df['redCards'], X, family=sm.families.Poisson(), offset=offset)
    results = model.fit()
    
    # Extracting parameters for the skin_tone_avg coefficient
    # coefficient = log(IRR) -> IRR = exp(coefficient)
    log_irr = results.params['skin_tone_avg']
    irr = np.exp(log_irr)
    
    # Standard error for IRR: SE(log(IRR)) * IRR
    se_log_irr = results.bse['skin_tone_avg']
    se_irr = se_log_irr * irr
    
    # Confidence Interval for IRR
    ci_log_lower = results.conf_int().loc['skin_tone_avg', 0]
    ci_log_upper = results.conf_int().loc['skin_tone_avg', 1]
    ci_lower = np.exp(ci_log_lower)
    ci_upper = np.exp(ci_log_upper)
    
    p_val = results.pvalues['skin_tone_avg']
    
    output = {
        "effect_size": float(irr),
        "effect_type": "irr",
        "standard_error": float(se_irr),
        "p_value": float(p_val),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
        "model_family": "poisson",
        "predictor_used": "mean(rater1, rater2)",
        "covariates_included": ["games (as offset)"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "none",
        "exclusions_applied": "removed rows with missing rater values or redCards"
    }
    
    print(json.dumps(output))

if __name__ == "__main__":
    solve()