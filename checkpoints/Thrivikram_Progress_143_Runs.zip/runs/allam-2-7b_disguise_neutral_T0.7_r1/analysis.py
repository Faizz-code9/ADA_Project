import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

# Load data
df = pd.read_csv("/kaggle/working/outputs/runs/allam-2-7b_disguise_neutral_T0.7_r1/data.csv")

# Clean data: Keep only rows where risk_evaluator_alpha_score is not missing
df = df.dropna(subset=['risk_evaluator_alpha_score', 'loan_application_rejections', 'credit_score_index', 'annual_income_bracket'])

# Construct predictor: continuous risk evaluator score (use alpha score as the primary external risk evaluation)
# The hypothesis asks about "external risk evaluation scores" - we'll use risk_evaluator_alpha_score
# Keep it continuous (0-1) as specified, do not dichotomize

# Define covariates to adjust for
covariates = ['credit_score_index', 'annual_income_bracket', 'total_applications_reviewed']

# Fit a Poisson regression model (count outcome: loan_application_rejections)
# Using statsmodels GLM with Poisson family
X = df[covariates + ['risk_evaluator_alpha_score']]
X = sm.add_constant(X)
y = df['loan_application_rejections']

# Fit Poisson model
model = sm.GLM(y, X, family=sm.families.Poisson())
result = model.fit()

# Extract coefficient for risk_evaluator_alpha_score
coeff_name = 'risk_evaluator_alpha_score'
coef = result.params[coeff_name]
se = result.bse[coeff_name]
p_val = result.pvalues[coeff_name]
ci = result.conf_int().loc[coeff_name]

# Effect size is the Incidence Rate Ratio (IRR) for continuous predictor
# IRR = exp(coefficient)
irr = np.exp(coef)
irr_se = se * irr  # Delta method approximation
irr_ci_lower = np.exp(ci[0])
irr_ci_upper = np.exp(ci[1])

# Conclusion
conclusion = 'significant_effect' if p_val < 0.05 else 'no_significant_effect'

# Build JSON output
output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(irr_se),
    "p_value": float(p_val),
    "ci_lower": float(irr_ci_lower),
    "ci_upper": float(irr_ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "risk_evaluator_alpha_score (continuous, 0-1)",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "Rows with missing risk_evaluator_alpha_score, loan_application_rejections, credit_score_index, or annual_income_bracket removed"
}

print(json.dumps(output))