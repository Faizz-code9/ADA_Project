import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

# Load data
df = pd.read_csv('/kaggle/working/outputs/runs/allam-2-7b_placebo_confirmatory_T0.7_r1/data.csv')

# Construct skin tone variable (average of rater1 and rater2)
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2

# Exclude rows where skin tone is missing
df = df.dropna(subset=['skin_tone'])

# Define outcome and predictors
df['red_card_binary'] = (df['redCards'] > 0).astype(int)

# Covariates
covariates = ['leagueCountry', 'position', 'height']

# Encode categorical variables
df = pd.get_dummies(df, columns=['leagueCountry', 'position'], drop_first=True, prefix=['league', 'pos'])
covariate_cols = [c for c in df.columns if c.startswith('league_') or c.startswith('pos_')]

# Prepare X
X = df[covariate_cols + ['skin_tone']].copy()
X = sm.add_constant(X)
y = df['red_card_binary']

# Fit logistic regression
model = sm.Logit(y, X).fit(disp=0)

# Extract results
skin_tone_coef = model.params['skin_tone']
skin_tone_se = model.bse['skin_tone']
skin_tone_pval = model.pvalues['skin_tone']
ci = model.conf_int().loc['skin_tone']

# Convert to odds ratio
odds_ratio = np.exp(skin_tone_coef)
se_odds_ratio = odds_ratio * skin_tone_se  # Delta method approximation
ci_lower = np.exp(ci[0])
ci_upper = np.exp(ci[1])

# Conclusion
conclusion = 'significant_effect' if skin_tone_pval < 0.05 else 'no_significant_effect'

result = {
    "effect_size": float(odds_ratio),
    "effect_type": "odds_ratio",
    "standard_error": float(se_odds_ratio),
    "p_value": float(skin_tone_pval),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "logistic",
    "predictor_used": "skin_tone",
    "covariates_included": covariate_cols,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "Rows with missing skin tone ratings"
}

print(json.dumps(result))