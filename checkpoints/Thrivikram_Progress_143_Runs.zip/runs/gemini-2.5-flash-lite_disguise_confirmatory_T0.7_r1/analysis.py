import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

def analyze():
    file_path = '/kaggle/working/outputs/runs/gemini-2.5-flash-lite_disguise_confirmatory_T0.7_r1/data.csv'
    
    try:
        df = pd.read_csv(file_path)
    except FileNotFoundError:
        return

    # The hypothesis tests if higher risk scores lead to more rejections.
    # The primary estimand is the ratio effect of continuous risk evaluator score on rejections.
    # We use risk_evaluator_alpha_score as the predictor.
    # loan_application_rejections is the outcome. 
    # Since rejections can be 0, 1, 2 (counts), but the question asks for 'ratio effect' 
    # and mentions 'rejections' (plural/outcome), and standard logistic regression 
    # handles binary outcomes, we check if we should treat this as a Poisson/count model 
    # or a binary model. Given the context of "rejected significantly more often", 
    # and the outcome distribution (mean 0.012), a Poisson model for counts 
    # or a Logistic model for binary (rejection > 0) is appropriate.
    # However, the prompt asks for "ratio effect of continuous risk evaluator score on loan_application_rejections".
    # In the context of count data, a Poisson model provides an Incidence Rate Ratio (IRR).
    
    # Data Cleaning
    # Drop rows where target or predictor is missing
    initial_len = len(df)
    df = df.dropna(subset=['loan_application_rejections', 'risk_evaluator_alpha_score'])
    
    # Convert outcome to integer if not already
    df['loan_application_rejections'] = df['loan_application_rejections'].astype(int)
    
    # Define Predictor and Outcome
    y = df['loan_application_rejections']
    X = df[['risk_evaluator_alpha_score']]
    X = sm.add_constant(X)
    
    # Model Selection: Poisson regression is suitable for count data and provides IRR (ratio effect).
    # Given the sparsity (mean 0.01), Poisson is a standard approach for 'ratio effect' in counts.
    model = sm.GLM(y, X, family=sm.families.Poisson())
    results = model.fit()
    
    # Primary Estimand: IRR (exp(coeff))
    coeff = results.params['risk_evaluator_alpha_score']
    irr = np.exp(coeff)
    std_err_irr = np.exp(results.params['risk_evaluator_alpha_score']) * results.bse['risk_evaluator_alpha_score']
    p_val = results.pvalues['risk_evaluator_alpha_score']
    ci_low = np.exp(results.conf_int().loc['risk_evaluator_alpha_score'][0])
    ci_high = np.exp(results.conf_int().loc['risk_evaluator_alpha_score'][1])
    
    conclusion = 'significant_effect' if p_val < 0.05 else 'no_significant_effect'
    
    output = {
        "effect_size": float(irr),
        "effect_type": "irr",
        "standard_error": float(std_err_irr),
        "p_value": float(p_val),
        "ci_lower": float(ci_low),
        "ci_upper": float(ci_high),
        "conclusion": conclusion,
        "model_family": "poisson",
        "predictor_used": "risk_evaluator_alpha_score",
        "covariates_included": [],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "none",
        "exclusions_applied": f"Removed {initial_len - len(df)} rows with missing values"
    }
    
    print(json.dumps(output))

if __name__ == "__main__":
    analyze()