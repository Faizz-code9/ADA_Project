import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

def run_analysis():
    file_path = '/kaggle/working/outputs/runs/gemini-2.5-flash-lite_soccer_neutral_T1.0_r3/data.csv'
    
    try:
        df = pd.read_csv(file_path)
    except FileNotFoundError:
        return

    # Data Cleaning and Preparation
    # Primary Predictor: average skin tone from rater1 and rater2
    # We must drop rows where skin tone information is missing as it is our primary predictor
    df = df.dropna(subset=['rater1', 'rater2', 'redCards'])
    df['skin_tone_avg'] = df[['rater1', 'rater2']].mean(axis=1)
    
    # Covariates for control: position, league (dummy), and games played (exposure)
    # Using 'games' as an offset/exposure or covariate is vital because red cards are count-like
    # but the primary estimand asks for the effect of skin tone on red cards.
    # Since redCards is a count (0, 1, 2), Poisson regression with offset is appropriate.
    
    # Clean other covariates
    df['position'] = df['position'].fillna('Unknown')
    df['leagueCountry'] = df['leagueCountry'].fillna('Unknown')
    
    # For Poisson, we use the log of games as an offset to model the rate per game
    # However, 'games' can be 0? The dictionary says min 1, so we are safe.
    df['log_games'] = np.log(df['games'].clip(lower=1))
    
    # Prepare dummies
    df = pd.get_dummies(df, columns=['position', 'leagueCountry'], drop_first=True)
    
    # Define model features
    # We'll use skin_tone_avg as the main predictor. 
    # To provide a robust estimate, we include common demographic/match variables.
    covariates = ['skin_tone_avg', 'log_games']
    # Add position and league dummies to covariates
    covariate_cols = [col for col in df.columns if col.startswith(('position_', 'leagueCountry_'))]
    all_covariates = covariates + covariate_cols
    
    X = df[all_covariates]
    X = sm.add_constant(X)
    y = df['redCards']
    
    # Poisson model to handle count data
    # We use the 'log_games' as an offset to find the rate effect
    # In statsmodels, offset is passed as a separate array
    offset = df['log_games']
    
    # We need to ensure X doesn't contain the offset variable itself if we use it as an offset
    # In statsmodels Poisson, we can use the 'offset' argument.
    # However, to keep the math clean for the "ratio effect", we'll use Poisson regression.
    # A coefficient in Poisson (with log link) represents the log-rate ratio.
    # exp(coeff) = Rate Ratio.
    
    model = sm.GLM(y, X, offset=offset, family=sm.families.Poisson())
    results = model.fit()
    
    # Extracting the effect for 'skin_tone_avg'
    # The coefficient is log(rate_ratio). The ratio effect is exp(coeff).
    coeff = results.params['skin_tone_avg']
    se_coeff = results.bse['skin_tone_avg']
    p_val = results.pvalues['skin_tone_avg']
    
    # Confidence intervals for the coefficient
    ci_log_lower = results.conf_int().loc['skin_tone_avg', 0]
    ci_log_upper = results.conf_int().loc['skin_tone_avg', 1]
    
    # Transform to ratio space
    effect_size = np.exp(coeff)
    ci_lower = np.exp(ci_log_lower)
    ci_upper = np.exp(ci_log_upper)
    # SE for the ratio is trickier (Delta method), 
    # but for a standard 'effect_size' output in JSON, we provide the RR or log-RR.
    # The prompt asks for 'ratio effect', so we provide the Rate Ratio.
    # Standard error for ratio using delta method: SE(exp(b)) approx exp(b) * SE(b)
    se_ratio = effect_size * se_coeff

    output = {
        "effect_size": float(effect_size),
        "effect_type": "irr",
        "standard_error": float(se_ratio),
        "p_value": float(p_val),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
        "model_family": "poisson",
        "predictor_used": "average of rater1 and rater2 skin tone",
        "covariates_included": ["log_games", "position", "leagueCountry"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "none",
        "exclusions_applied": "Rows with missing skin tone ratings or redCards removed"
    }
    
    print(json.dumps(output))

if __name__ == "__main__":
    run_analysis()