import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

def run_analysis():
    # 1. Load Data
    file_path = '/kaggle/working/outputs/runs/gemini-2.5-flash-lite_soccer_skeptical_T1.0_r3/data.csv'
    try:
        df = pd.read_csv(file_path)
    except FileNotFoundError:
        return

    # 2. Data Preparation
    # Predictor: skin tone is provided by rater1 and rater2. 
    # Use the mean of the two raters to construct a continuous skin tone variable.
    # Target: redCards (count-like, but mostly 0s/1s/2s). 
    # Since the estimand is 'ratio effect', Poisson regression is appropriate for counts.
    
    # Create mean skin tone
    df['skin_tone_mean'] = df[['rater1', 'rater2']].mean(axis=1)
    
    # Identify rows with missing values in essential columns
    # redCards is target, skin_tone_mean is predictor.
    # Also check for other covariates used.
    initial_len = len(df)
    df_clean = df.dropna(subset=['redCards', 'skin_tone_mean', 'games', 'yellowCards', 'leagueCountry']).copy()
    
    # Exclusions: Rows where redCards/yellowCards/games are negative or invalid (though data dict says int64)
    df_clean = df_clean[df_clean['redCards'] >= 0]
    
    # For Poisson regression, we should use 'games' as an offset to account for exposure/opportunity
    # However, 'games' is the number of games played by the player, which is the observation context.
    # Actually, redCards is the count in the context of the observation.
    # A common way is to model log(redCards + 1) or use Poisson with offset log(exposure).
    # Given the variable 'games', it represents the exposure.
    df_clean['log_exposure'] = np.log(df_clean['games'].replace(0, 1))

    # 3. Statistical Model
    # Hypothesis: skin_tone_bias is statistically absent (effect == 0).
    # Model: Poisson regression (since redCards is a count)
    # Formula: redCards ~ skin_tone_mean + yellowCards + log_exposure
    # We use 'games' (log_exposure) as an offset to handle the varying number of games per player.
    
    # Regression model: Poisson
    # Using statsmodels GLM for Poisson
    formula = "redCards ~ skin_tone_mean + yellowCards"
    # Note: We use the offset for the exposure (games)
    model = smf.glm(formula=formula, 
                    data=df_clean, 
                    family=sm.families.Poisson(),
                    offset=df_clean['log_exposure']).fit()

    # 4. Compute Primary Estimand
    # Estimand: ratio effect of continuous skin tone (IRR = exp(coef))
    coef = model.params['skin_tone_mean']
    se = model.bse['skin_tone_mean']
    p_val = model.pvalues['skin_tone_mean']
    
    irr = np.exp(coef)
    ci_lower = np.exp(model.conf_int().loc['skin_tone_mean'][0])
    ci_upper = np.exp(model.conf_int().loc['skin_tone_mean'][1])

    # 5. Prepare Result
    conclusion = 'significant_effect' if p_val < 0.05 else 'no_significant_effect'
    
    result = {
        "effect_size": float(irr),
        "effect_type": "irr",
        "standard_error": float(se), # Note: SE of log scale usually, but standard practice is often reported as SE of the coefficient
        "p_value": float(p_val),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": conclusion,
        "model_family": "poisson",
        "predictor_used": "mean(rater1, rater2)",
        "covariates_included": ["yellowCards", "games_offset"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "none",
        "exclusions_applied": f"Removed {initial_len - len(df_clean)} rows with missing values or invalid data"
    }
    
    print(json.dumps(result))

if __name__ == "__main__":
    run_analysis()