import pandas as pd
import numpy as np
import json
import statsmodels.api as sm
from statsmodels.formula.api import glm
from scipy import stats

# Load data
df = pd.read_csv('/kaggle/working/outputs/runs/allam-2-7b_placebo_neutral_T0.7_r1/data.csv')

# Clean data: drop rows where rater1 or rater2 is missing
df_clean = df.dropna(subset=['rater1', 'rater2']).copy()

# Create average skin tone predictor
df_clean['skin_tone'] = (df_clean['rater1'] + df_clean['rater2']) / 2

# Prepare variables for model
# Outcome: redCards (binary, 0 or 1 mostly, but can be 2; treat as binary for logistic)
df_clean['red_card_binary'] = (df_clean['redCards'] > 0).astype(int)

# Covariates
covariates = ['leagueCountry', 'position', 'games']

# One-hot encode categorical variables
for col in ['leagueCountry', 'position']:
    dummies = pd.get_dummies(df_clean[col], prefix=col, drop_first=True, dtype=float)
    df_clean = pd.concat([df_clean, dummies], axis=1)

# Define model formula
# Use skin_tone as main predictor
formula = 'red_card_binary ~ skin_tone + ' + ' + '.join([c for c in df_clean.columns if c.startswith('leagueCountry_') or c.startswith('position_')]) + ' + games'

# Fit logistic regression
X = sm.add_constant(df_clean[[c for c in df_clean.columns if c != 'red_card_binary' and not c.startswith(('player', 'club', 'photo', 'ref', 'mean', 'n', 'se'))]])
y = df_clean['red_card_binary']

# Select only numeric and encoded columns
model_cols = ['const', 'skin_tone', 'games'] + [c for c in X.columns if c.startswith('leagueCountry_') or c.startswith('position_')]
X = X[model_cols]

model = sm.Logit(y, X).fit(disp=0)

# Extract results for skin_tone
coef = model.params['skin_tone']
se = model.bse['skin_tone']
pval = model.pvalues['skin_tone']
ci = model.conf_int().loc['skin_tone']

# Compute odds ratio
or_value = np.exp(coef)
or_ci_lower = np.exp(ci[0])
or_ci_upper = np.exp(ci[1])

# Determine conclusion
conclusion = 'significant_effect' if pval < 0.05 else 'no_significant_effect'

# Build output
result = {
    "effect_size": float(or_value),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(pval),
    "ci_lower": float(or_ci_lower),
    "ci_upper": float(or_ci_upper),
    "conclusion": conclusion,
    "model_family": "logistic",
    "predictor_used": "average_skin_tone (mean of rater1 and rater2)",
    "covariates_included": ["leagueCountry", "position", "games"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "rows with missing rater1 or rater2 (14.7% of data)"
}

print(json.dumps(result))