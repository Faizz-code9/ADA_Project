import pandas as pd
import numpy as np
import json
import statsmodels.api as sm

DATA_PATH = "/kaggle/working/outputs/runs/allam-2-7b_soccer_skeptical_T1.0_r3/data.csv"

df = pd.read_csv(DATA_PATH)

# Construct skin tone predictor as average of rater1 and rater2
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2.0

# Listwise deletion: remove rows missing predictor, key covariates
covariate_cols = ['height', 'weight', 'position']
pred_col = ['skin_tone']
df_clean = df.dropna(subset=pred_col + covariate_cols).copy()

# Drop rows with total missingness if too sparse (keep it simple)
y = df_clean['redCards'].astype(int)

# Create dummy variables
X_vars = ['skin_tone', 'height', 'weight', 'games']
dummies = pd.get_dummies(df_clean['position'], prefix='pos', drop_first=True, dtype=float)
X = pd.concat([df_clean[X_vars].reset_index(drop=True), dummies], axis=1)
X = sm.add_constant(X)

# Fit Poisson regression (count outcome, rare events)
model = sm.GLM(y, X, family=sm.families.Poisson())
result = model.fit()

# Extract coefficient for skin_tone
# conf_int returns DataFrame with columns 0 and 1 in newer statsmodels, or named
ci = result.conf_int()
# Handle column naming: older versions use numeric indices, newer may use 'lower'/'upper'
# statsmodels conf_int() default alpha returns DataFrame with columns 0, 1
try:
    ci_lower_log = ci.loc['skin_tone', 0]
    ci_upper_log = ci.loc['skin_tone', 1]
except:
    ci_lower_log = ci.loc['skin_tone', 'lower']
    ci_upper_log = ci.loc['skin_tone', 'upper']

beta = result.params['skin_tone']
se = result.bse['skin_tone']
p_val = result.pvalues['skin_tone']

# IRR = exp(beta), SE of IRR approx via delta: IRR * se (for small se)
# More accurate: exp(beta ± 1.96*se) for CI
irr = np.exp(beta)
# Delta method for SE of IRR: se_irr = irr * se_beta
se_irr = irr * se
ci_lower = np.exp(ci_lower_log)
ci_upper = np.exp(ci_upper_log)

alpha = 0.05
conclusion = 'significant_effect' if p_val < alpha else 'no_significant_effect'

# Covariates included
covariates_included = []
if 'height' in X.columns: covariates_included.append('height')
if 'weight' in X.columns: covariates_included.append('weight')
if 'games' in X.columns: covariates_included.append('games')
if any('pos_' in str(c) for c in X.columns): covariates_included.append('position')

output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se_irr),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "skin_tone (mean of rater1 and rater2)",
    "covariates_included": covariates_included,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "dropped rows with missing skin_tone, height, weight, or position"
}

print(json.dumps(output))