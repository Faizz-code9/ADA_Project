import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

# Load data
df = pd.read_csv('/kaggle/working/outputs/runs/allam-2-7b_soccer_confirmatory_T0.0_r1/data.csv')

# Construct skin tone predictor (average of rater1 and rater2)
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2.0

# Exclude rows with missing skin tone
df = df.dropna(subset=['skin_tone'])

# Define outcome and predictor
y = df['redCards']
X = df[['skin_tone']]

# Add covariates: leagueCountry, position, height, weight, games
# One-hot encode leagueCountry and position
df['leagueCountry'] = df['leagueCountry'].astype('category')
df['position'] = df['position'].fillna('Unknown').astype('category')

# Create dummy variables
league_dummies = pd.get_dummies(df['leagueCountry'], prefix='league', drop_first=True, dtype=float)
position_dummies = pd.get_dummies(df['position'], prefix='pos', drop_first=True, dtype=float)

# Combine all predictors
X = pd.concat([df[['skin_tone', 'height', 'weight', 'games']], league_dummies, position_dummies], axis=1)

# Drop rows with missing covariates
X = X.dropna()
y = y.loc[X.index]

# Add constant
X = sm.add_constant(X)

# Fit Poisson regression (red cards are count data)
model = sm.GLM(y, X, family=sm.families.Poisson())
result = model.fit()

# Extract results for skin_tone
coef = result.params['skin_tone']
se = result.bse['skin_tone']
p_val = result.pvalues['skin_tone']
ci = result.conf_int().loc['skin_tone']

# Compute IRR (Incident Rate Ratio)
irr = np.exp(coef)
irr_se = se * irr
irr_ci_lower = np.exp(ci[0])
irr_ci_upper = np.exp(ci[1])

# Determine conclusion
conclusion = 'significant_effect' if p_val < 0.05 else 'no_significant_effect'

# Build JSON output
output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(irr_se),
    "p_value": float(p_val),
    "ci_lower": float(irr_ci_lower),
    "ci_upper": float(irr_ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "skin_tone (average of rater1 and rater2)",
    "covariates_included": ["height", "weight", "games", "leagueCountry", "position"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "Rows with missing skin tone or covariates removed"
}

print(json.dumps(output))