import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

def solve():
    file_path = '/kaggle/working/outputs/runs/gemini-2.5-flash-lite_T0.0_r1/data.csv'
    try:
        df = pd.read_csv(file_path)
    except FileNotFoundError:
        # Fallback for local testing if path differs, though instructions say use absolute path
        return

    # 1. Data Cleaning and Preparation
    # Primary Estimand: ratio effect of continuous skin tone on red cards.
    # Skin tone is provided by rater1 and rater2. We'll use the mean.
    df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)
    
    # Outcome is redCards. Since redCards is a count (0, 1, 2), 
    # and we want the "ratio effect" (Incidence Rate Ratio), 
    # a Poisson regression is appropriate.
    
    # Exclusions: Remove rows where skin_tone or redCards is NaN
    initial_count = len(df)
    df_clean = df.dropna(subset=['skin_tone', 'redCards', 'games']).copy()
    
    # We must account for exposure (number of games played) to model the rate of red cards.
    # Poisson regression with an offset of log(games) models the rate.
    df_clean['log_games'] = np.log(df_clean['games'].replace(0, 1))
    
    # Covariates: yellowCards (to control for general disciplinary tendency), 
    # height, weight (physicality), and leagueCountry (contextual differences).
    # We'll use a subset of available columns to ensure stability.
    df_clean = df_clean.dropna(subset=['yellowCards', 'height', 'weight', 'leagueCountry'])
    
    exclusions_desc = f"Removed {initial_count - len(df_clean)} rows due to missing values in skin_tone, redCards, games, yellowCards, height, weight, or leagueCountry."

    # 2. Statistical Modeling
    # Model: redCards ~ skin_tone + yellowCards + height + weight + C(leagueCountry)
    # Offset: log(games)
    # This estimates the log(rate). exponentiating the coefficient gives the IRR.
    
    formula = "redCards ~ skin_tone + yellowCards + height + weight + C(leagueCountry)"
    model = smf.poisson(formula, data=df_clean, offset=df_clean['log_games'])
    results = model.fit(disp=False)

    # 3. Compute Primary Estimand (IRR)
    # The coefficient for skin_tone is the log-rate ratio.
    # IRR = exp(coef)
    coef = results.params['skin_tone']
    se_coef = results.bse['skin_tone']
    p_val = results.pvalues['skin_tone']
    
    irr = np.exp(coef)
    ci_lower = np.exp(results.conf_int().loc['skin_tone'][0])
    ci_upper = np.exp(results.conf_int().loc['skin_tone'][1])
    
    # Standard error for the IRR is approximated via the Delta Method: SE(exp(x)) = exp(x) * SE(x)
    se_irr = irr * se_coef

    # 4. Construct JSON Output
    output = {
        "effect_size": float(irr),
        "effect_type": "irr",
        "standard_error": float(se_irr),
        "p_value": float(p_val),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
        "model_family": "poisson",
        "predictor_used": "mean(rater1, rater2)",
        "covariates_included": ["yellowCards", "height", "weight", "leagueCountry", "games (offset)"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "none",
        "exclusions_applied": exclusions_desc
    }

    print(json.dumps(output))

if __name__ == "__main__":
    solve()