import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

def run_analysis(file_path):
    # Load data
    df = pd.read_csv(file_path)
    
    # Initial count for exclusions tracking
    initial_count = len(df)
    
    # Data Cleaning
    # skin_tone has 8% missing values. Hypothesis tests continuous skin_tone.
    # Using listwise deletion as is standard for statistical modeling when predictors are missing.
    df_clean = df.dropna(subset=['skin_tone', 'redCards'])
    excluded_count = initial_count - len(df_clean)
    
    # Since redCards is a count variable (0, 1, 2, 3), we use Poisson regression
    # The primary estimand is the 'ratio effect' (Incidence Rate Ratio - IRR)
    # Model: redCards ~ skin_tone
    
    try:
        # Poisson regression is appropriate for small integer counts like redCards
        # We include refereeID as a random effect (clustering/mixed effects) 
        # because observations are nested within referees, but the instruction 
        # asks for the ratio effect of continuous skin_tone.
        # Given the constraints, a Poisson GLM with a log link is the standard approach for IRR.
        
        model = smf.poisson('redCards ~ skin_tone', data=df_clean).fit(disp=0)
        
        # Extract coefficients
        # beta is the log(IRR)
        log_irr = model.params['skin_tone']
        se_log_irr = model.bse['skin_tone']
        p_val = model.pvalues['skin_tone']
        
        # Transform to IRR
        irr = np.exp(log_irr)
        ci_lower = np.exp(model.conf_int().loc['skin_tone', 0])
        ci_upper = np.exp(model.conf_int().loc['skin_tone', 1])
        
        # Standard error for ratio (Delta method approx: SE(exp(b)) approx exp(b) * SE(b))
        se_irr = irr * se_log_irr
        
        conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"
        
        result = {
            "effect_size": float(irr),
            "effect_type": "irr",
            "standard_error": float(se_irr),
            "p_value": float(p_val),
            "ci_lower": float(ci_lower),
            "ci_upper": float(ci_upper),
            "conclusion": conclusion,
            "model_family": "poisson",
            "predictor_used": "skin_tone",
            "covariates_included": [],
            "missing_data_strategy": "listwise_deletion",
            "clustering_strategy": "none",
            "exclusions_applied": f"Removed {excluded_count} rows due to missing skin_tone" if excluded_count > 0 else "none"
        }
        
        print(json.dumps(result, indent=2))

    except Exception as e:
        # Fallback to OLS if Poisson fails (though unlikely for this data structure)
        model = smf.ols('redCards ~ skin_tone', data=df_clean).fit()
        irr = model.params['skin_tone'] # coef for OLS
        se = model.bse['skin_tone']
        p_val = model.pvalues['skin_tone']
        ci = model.conf_int().loc['skin_tone']
        
        result = {
            "effect_size": float(irr),
            "effect_type": "coefficient",
            "standard_error": float(se),
            "p_value": float(p_val),
            "ci_lower": float(ci[0]),
            "ci_upper": float(ci[1]),
            "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
            "model_family": "ols",
            "predictor_used": "skin_tone",
            "covariates_included": [],
            "missing_data_strategy": "listwise_deletion",
            "clustering_strategy": "none",
            "exclusions_applied": f"Removed {excluded_count} rows due to missing skin_tone"
        }
        print(json.dumps(result, indent=2))

if __name__ == "__main__":
    DATA_PATH = "/kaggle/working/outputs/runs/gemini-2.5-flash-lite_synthetic_skeptical_T1.0_r1/data.csv"
    run_analysis(DATA_PATH)