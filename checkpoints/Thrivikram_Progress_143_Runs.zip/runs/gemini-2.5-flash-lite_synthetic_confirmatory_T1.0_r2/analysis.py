import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

def main():
    # 1. Load data
    file_path = '/kaggle/working/outputs/runs/gemini-2.5-flash-lite_synthetic_confirmatory_T1.0_r2/data.csv'
    df = pd.read_csv(file_path)

    # 2. Clean and prepare data
    # Strategy: listwise deletion for missing skin_tone values
    initial_len = len(df)
    df = df.dropna(subset=['skin_tone'])
    exclusions = f"Removed {initial_len - len(df)} rows due to missing skin_tone"
    
    # redCards is a count variable (0, 1, 2, 3). 
    # We model the rate of red cards per game/observation.
    # Since we want the 'ratio effect' of continuous skin_tone, a Poisson model is appropriate.
    # The exponentiated coefficient of a Poisson regression is the Incident Rate Ratio (IRR).
    
    # Formula: redCards ~ skin_tone + position + height + weight + yellowCards (control for card propensity)
    # We use Poisson regression as it is standard for count data.
    
    model = smf.poisson('redCards ~ skin_tone + position + height + weight + yellowCards', data=df)
    results = model.fit(disp=False)

    # 3. Extract primary estimand
    # The hypothesis is about the ratio effect of skin_tone.
    # In Poisson, coefficient b -> IRR = exp(b)
    coeff = results.params['skin_tone']
    irr = np.exp(coeff)
    
    # Standard error of the IRR can be approximated via the Delta Method: SE(exp(b)) = exp(b) * SE(b)
    se_coeff = results.bse['skin_tone']
    irr_se = irr * se_coeff
    
    # Confidence intervals for IRR
    ci_lower_coeff = results.conf_int().loc['skin_tone', 0]
    ci_upper_coeff = results.conf_int().loc['skin_tone', 1]
    ci_lower = np.exp(ci_lower_coeff)
    ci_upper = np.exp(ci_upper_coeff)
    
    p_val = results.pvalues['skin_tone']
    
    # 4. Prepare JSON output
    output = {
        "effect_size": float(irr),
        "effect_type": "irr",
        "standard_error": float(irr_se),
        "p_value": float(p_val),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
        "model_family": "poisson",
        "predictor_used": "skin_tone (continuous 0-1)",
        "covariates_included": ["position", "height", "weight", "yellowCards"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "none",
        "exclusions_applied": exclusions
    }

    print(json.dumps(output, indent=2))

if __name__ == "__main__":
    main()