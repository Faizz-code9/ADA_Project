import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

def main():
    file_path = '/kaggle/working/outputs/runs/gemini-2.5-flash-lite_placebo_neutral_T1.0_r1/data.csv'
    
    # Load data
    df = pd.read_csv(file_path)
    
    # Define variables
    # Hypothesis: skin tone (rater1, rater2) vs redCards
    # Estimand: ratio effect (IRR) of continuous skin tone. 
    # Since redCards can be 0, 1, or 2, we use Poisson regression to model the count.
    # A Poisson regression coefficient exponentiated gives the Incidence Rate Ratio (IRR).
    
    # 1. Data Cleaning & Preparation
    # Create mean skin tone predictor
    df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)
    
    # Select relevant columns and handle missingness
    # Red cards (outcome), skin_tone (predictor), games (offset/exposure), yellowCards (covariate)
    cols_to_keep = ['redCards', 'skin_tone', 'games', 'yellowCards', 'position']
    df_clean = df[cols_to_keep].dropna()
    
    # Exclusion: rows with zero games (cannot have red cards if no games played)
    # or rows where skin_tone is NaN (already handled by dropna)
    initial_len = len(df)
    df_clean = df_clean[df_clean['games'] > 0]
    exclusions = f"Removed {initial_len - len(df_clean)} rows due to missing skin tone, redCards, or zero games."

    # 2. Statistical Modeling
    # We use a Poisson model because redCards is a count variable.
    # To account for the fact that players play different numbers of games, 
    # we use 'games' as an offset (log(games)).
    # The coefficient for skin_tone in a Poisson model, when exponentiated, is the IRR.
    
    # Formula: redCards ~ skin_tone + yellowCards + position
    # Using log(games) as offset
    df_clean['log_games'] = np.log(df_clean['games'])
    
    # Poisson Regression
    # We add position as a categorical covariate to control for playstyle/role
    model = smf.poisson('redCards ~ skin_tone + yellowCards + C(position)', 
                        offset=df_clean['log_games'], 
                        data=df_clean).fit(disp=False)
    
    # 3. Extract Estimands
    # Primary estimand: ratio effect of continuous skin tone (IRR)
    irr = np.exp(model.params['skin_tone'])
    se_irr = np.exp(model.params['skin_tone'] + model.bse['skin_tone']) - np.exp(model.params['skin_tone']) # approximation, better to use delta method or simply use the log-scale SE
    
    # Accurate way for CI and SE of exponentiated parameter (IRR):
    # CI of coeff: exp(coef +/- 1.96 * se_coef)
    ci_lower_coeff = model.conf_int().loc['skin_tone', 0]
    ci_upper_coeff = model.conf_int().loc['skin_tone', 1]
    
    irr_ci_lower = np.exp(ci_lower_coeff)
    irr_ci_upper = np.exp(ci_upper_coeff)
    
    # Standard error of IRR is roughly IRR * SE_of_log_IRR
    se_irr = irr * model.bse['skin_tone']
    
    p_val = model.pvalues['skin_tone']
    
    # 4. Construct JSON
    result = {
        "effect_size": float(irr),
        "effect_type": "irr",
        "standard_error": float(se_irr),
        "p_value": float(p_val),
        "ci_lower": float(irr_ci_lower),
        "ci_upper": float(irr_ci_upper),
        "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
        "model_family": "poisson",
        "predictor_used": "mean(rater1, rater2)",
        "covariates_included": ["yellowCards", "position", "games_offset"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "none",
        "exclusions_applied": exclusions
    }
    
    print(json.dumps(result))

if __name__ == "__main__":
    main()