import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

def solve():
    file_path = '/kaggle/working/outputs/runs/gemini-2.5-flash-lite_placebo_confirmatory_T0.7_r1/data.csv'
    df = pd.read_csv(file_path)

    # Cleaning: Skin tone is provided by rater1 and rater2. 
    # We construct a continuous skin tone variable as the mean of the two raters.
    # Exclude rows where skin tone is missing.
    df = df.dropna(subset=['rater1', 'rater2', 'redCards'])
    df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)
    
    # The outcome redCards is a count. Given the low mean and discrete nature, 
    # Poisson regression is appropriate for modeling the rate.
    # We include 'games' as an offset to model the rate of red cards per game.
    # We include 'yellowCards' as a covariate to control for general disciplinary tendency.
    
    # Ensure redCards and games are non-negative
    df = df[df['redCards'] >= 0]
    df = df[df['games'] > 0]
    
    # Fit Poisson model
    # log(E[redCards]) = beta0 + beta1 * skin_tone + beta2 * yellowCards + log(games)
    model = smf.poisson('redCards ~ skin_tone + yellowCards', offset=np.log(df['games']), data=df).fit(disp=False)
    
    # The primary estimand is the ratio effect (IRR) of continuous skin tone.
    # IRR = exp(coefficient)
    coef = model.params['skin_tone']
    irr = np.exp(coef)
    se_log = model.bse['skin_tone']
    se_irr = irr * se_log  # Delta method approximation for SE of exponentiated coefficient
    
    p_val = model.pvalues['skin_tone']
    ci_log = model.conf_int().loc['skin_tone']
    ci_lower = np.exp(ci_log[0])
    ci_upper = np.exp(ci_log[1])
    
    conclusion = 'significant_effect' if p_val < 0.05 else 'no_significant_effect'
    
    results = {
        "effect_size": float(irr),
        "effect_type": "irr",
        "standard_error": float(se_irr),
        "p_value": float(p_val),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": conclusion,
        "model_family": "poisson",
        "predictor_used": "mean(rater1, rater2)",
        "covariates_included": ["yellowCards", "games (offset)"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "none",
        "exclusions_applied": "removed rows with missing skin tone or redCards/games"
    }
    
    print(json.dumps(results))

if __name__ == "__main__":
    solve()