import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

# Load data
df = pd.read_csv("/kaggle/working/outputs/runs/allam-2-7b_disguise_confirmatory_T1.0_r1/data.csv")

# Identify key columns
outcome_col = 'loan_application_rejections'
predictor_candidates = ['risk_evaluator_alpha_score', 'risk_evaluator_beta_score']

# Check which predictor column has less missing data
missing_alpha = df['risk_evaluator_alpha_score'].isna().sum()
missing_beta = df['risk_evaluator_beta_score'].isna().sum()

# Use the predictor with less missing data
if missing_alpha <= missing_beta:
    predictor_col = 'risk_evaluator_alpha_score'
else:
    predictor_col = 'risk_evaluator_beta_score'

# Clean: drop rows where outcome or predictor is NaN
df_clean = df.dropna(subset=[outcome_col, predictor_col]).copy()

exclusions_applied = f"Dropped {len(df) - len(df_clean)} rows with missing outcome or predictor"

# Fit a Poisson regression (appropriate for count outcome with many zeros)
X = df_clean[predictor_col].values.reshape(-1, 1)
y = df_clean[outcome_col].values

X_with_const = sm.add_constant(X)
model = sm.GLM(y, X_with_const, family=sm.families.Poisson())
result = model.fit()

# Extract results for the predictor variable
coef = result.params[1]
se = result.bse[1]
p_val = result.pvalues[1]
ci = result.conf_int()
ci_lower = ci[1, 0]
ci_upper = ci[1, 1]

# Compute IRR (Incident Rate Ratio)
irr = np.exp(coef)
irr_lower = np.exp(ci_lower)
irr_upper = np.exp(ci_upper)

# Compute SE for IRR using delta method: SE_irr = irr * SE_coef
se_irr = irr * se

# Determine conclusion
conclusion = 'significant_effect' if p_val < 0.05 else 'no_significant_effect'

# Build JSON output
output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se_irr),
    "p_value": float(p_val),
    "ci_lower": float(irr_lower),
    "ci_upper": float(irr_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": f"{predictor_col} (continuous, 0-1 scale)",
    "covariates_included": [],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": exclusions_applied
}

print(json.dumps(output, default=float))