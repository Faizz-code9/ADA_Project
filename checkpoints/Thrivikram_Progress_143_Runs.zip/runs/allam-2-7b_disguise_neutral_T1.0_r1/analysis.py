import json
import pandas as pd
import numpy as np
from scipy import stats
import statsmodels.api as sm

# Load data
file_path = "/kaggle/working/outputs/runs/allam-2-7b_disguise_neutral_T1.0_r1/data.csv"
df = pd.read_csv(file_path)

# Cleaning: Drop rows where key predictors or outcome are missing
# Key variables: loan_application_rejections, risk_evaluator_alpha_score, risk_evaluator_beta_score
# We'll use both risk scores as the main predictor (mean or pick one? The hypothesis says "external risk evaluation scores").
# Let's construct a combined risk score or use one. Given the phrasing "scores" (plural) but a single estimand,
# I will use the average of alpha and beta as a continuous risk index, or just pick one.
# Actually, missingness for dossiers and risk scores is identical (21,407).
# Let's drop rows where risk_evaluator_alpha_score is NaN.
df_clean = df.dropna(subset=['loan_application_rejections', 'risk_evaluator_alpha_score', 'risk_evaluator_beta_score']).copy()

# Construct a continuous predictor: average of the two risk scores
# The hypothesis asks for effect of "continuous risk evaluator score". 
# I will use the mean of alpha and beta as a single composite score.
excl_count = len(df) - len(df_clean)
df_clean['external_risk_score'] = (df_clean['risk_evaluator_alpha_score'] + df_clean['risk_evaluator_beta_score']) / 2.0

# Outcome: loan_application_rejections is a small count (0, 1, 2).
# Since the mean is very low (0.012) and max is 2, Poisson is appropriate.
# We want the "ratio effect" ... "Do not dichotomize".
# This implies an Incidence Rate Ratio (IRR) from a Poisson model.
# Y ~ Poisson. X ~ continuous.
# Model: log(E[Y]) = b0 + b1 * X
# IRR = exp(b1)

# Covariates: credit_score_index, total_applications_reviewed, prior_denied_loans
# Let's check for missing in covariates. Listwise deletion within the subset.
covariates = ['credit_score_index', 'total_applications_reviewed', 'prior_denied_loans']
df_model = df_clean.dropna(subset=covariates).copy()
excl_count_total = len(df) - len(df_model)

X = df_model[covariates + ['external_risk_score']].copy()
X = sm.add_constant(X)
y = df_model['loan_application_rejections'].astype(float)

# Fit Poisson GLM
model = sm.GLM(y, X, family=sm.families.Poisson())
result = model.fit()

# Extract results for external_risk_score
param_name = 'external_risk_score'
beta_hat = result.params[param_name]
se_beta = result.bse[param_name]
p_val = result.pvalues[param_name]

# For IRR:
# Point estimate = exp(beta_hat)
# SE of IRR (via delta method): exp(beta_hat) * SE_beta
# CI: exp(beta_hat + z * SE_beta)
point_est = np.exp(beta_hat)
z_val = 1.959964
se_irr = se_beta * point_est
ci_lower = np.exp(beta_hat - z_val * se_beta)
ci_upper = np.exp(beta_hat + z_val * se_beta)

# Conclusion
conclusion = 'significant_effect' if p_val < 0.05 else 'no_significant_effect'

output = {
    "effect_size": float(point_est),
    "effect_type": "irr",
    "standard_error": float(se_irr),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "avg(risk_evaluator_alpha_score, risk_evaluator_beta_score)",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": f"Dropped {excl_count_total} rows with missing info in outcome, risk scores, or covariates"
}

print(json.dumps(output))