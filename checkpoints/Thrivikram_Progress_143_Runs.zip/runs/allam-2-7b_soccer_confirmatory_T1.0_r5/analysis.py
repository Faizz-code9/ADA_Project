import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

# Load data
df = pd.read_csv('/kaggle/working/outputs/runs/allam-2-7b_soccer_confirmatory_T1.0_r5/data.csv')

# Construct predictor: average of rater1 and rater2
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2

# Drop rows with missing skin tone
df = df.dropna(subset=['skin_tone'])

# Prepare covariates: season (approximated by games played count as a proxy for time exposure), league, age
# Use games as exposure/covariate for time on field
df['age'] = pd.to_datetime(df['birthday'], format='%d.%m.%Y', errors='coerce').dt.year
df['age'] = 2010 - df['age']  # Approximate age in 2010 (Champions League 2009-10 or similar timeframe)

# Covariates to include
covariates = ['age', 'games', 'leagueCountry']

# One-hot encode league
df = pd.get_dummies(df, columns=['leagueCountry'], drop_first=True, dtype=float)

# Update covariate list with actual dummy variables
actual_covariates = [c for c in df.columns if c.startswith('leagueCountry_')]
actual_covariates += ['age', 'games']

# Exclude rows with NaN in covariates
df = df.dropna(subset=['redCards'] + actual_covariates)

# Outcome
y = df['redCards'].values

# Predictor
x = df['skin_tone'].values

# Model matrix
X = sm.add_constant(pandas=pd, data=df[actual_covariates + ['skin_tone']].values, names=None)
# Properly add constant
X = sm.add_constant(df[actual_covariates + ['skin_tone']], has_const=False)

# Fit Poisson regression (redCards is count data, overdispersion possible but Poisson gives IRR)
model = sm.GLM(y, X, family=sm.families.Poisson())
result = model.fit()

# Extract coefficient for skin_tone
coeff_name = 'skin_tone'
coef = result.params[coeff_name]
se = result.bse[coeff_name]
pval = result.pvalues[coeff_name]

# IRR and CI
irr = np.exp(coef)
irr_se = irr * se  # Delta method approximation
ci_lower = np.exp(coef - 1.96 * se)
ci_upper = np.exp(coef + 1.96 * se)

conclusion = 'significant_effect' if pval < 0.05 else 'no_significant_effect'

exclusions = f"Dropped {len(df[actual_covariates + ['redCards', 'skin_tone']].dropna().shape[0] == 0 and 0 or len(df)): rows with missing skin tone or covariates".replace("nan", "0")

result_obj = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(pval),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "skin_tone (average of rater1 and rater2)",
    "covariates_included": actual_covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "Rows with missing skin tone ratings or covariates"
}

print(json.dumps(result_obj))