import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

def analyze():
    file_path = '/kaggle/working/outputs/runs/gemini-2.5-flash-lite_soccer_neutral_T1.0_r5/data.csv'
    df = pd.read_csv(file_path)

    # 1. Data Cleaning and Preparation
    # Predictor: skin tone (mean of rater1 and rater2)
    # Outcome: redCards (count-like, but sparse/binary-ish in many slices; 
    # for a 'ratio effect' in continuous context with count data, Poisson is standard)
    
    # Identify columns
    target = 'redCards'
    rater1 = 'rater1'
    rater2 = 'rater2'
    
    # Drop rows missing skin tone or outcome
    initial_len = len(df)
    df = df.dropna(subset=[target, rater1, rater2])
    
    # Create averaged skin tone predictor
    df['skin_tone'] = df[[rater1, rater2]].mean(axis=1)
    
    # Filter valid skin tone range (0-1) and redCards >= 0
    df = df[(df['skin_tone'] >= 0) & (df['skin_tone'] <= 1)]
    df = df[df[target] >= 0]
    
    # Exclusions check
    exclusions = f"Removed {initial_len - len(df)} rows due to missing values or invalid skin tone/target."

    # 2. Statistical Modeling
    # Hypothesis: Ratio effect of continuous skin tone on red cards.
    # Since redCards is a count variable (0, 1, 2), Poisson regression is appropriate.
    # The ratio effect (IRR) is exp(coefficient).
    
    # We include 'games' as a covariate to account for exposure/opportunity.
    # We include 'yellowCards' to account for general disciplinary tendencies.
    # We use 'refNum' as a clustering variable (random effects/GEE/Cluster SE) 
    # because referee decisions are nested within referees.
    
    # Using Generalized Estimating Equations (GEE) with Poisson family 
    # to handle the clustering of observations by referee (refNum).
    
    model = smf.gee("redCards ~ skin_tone + games + yellowCards", 
                    groups=df['refNum'], 
                    data=df, 
                    family=sm.families.Poisson())
    
    res = model.fit()
    
    # 3. Compute Estimands
    coef = res.params['skin_tone']
    std_err = res.bse['skin_tone']
    p_val = res.pvalues['skin_tone']
    irr = np.exp(coef)
    ci_lower = np.exp(res.conf_int().loc['skin_tone', 0])
    ci_upper = np.exp(res.conf_int().loc['skin_tone', 1])
    
    # Result dictionary
    result = {
        "effect_size": float(irr),
        "effect_type": "irr",
        "standard_error": float(std_err), # Note: SE for log-coeff, standard practice
        "p_value": float(p_val),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
        "model_family": "gee",
        "predictor_used": "mean(rater1, rater2)",
        "covariates_included": ["games", "yellowCards"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "gee",
        "exclusions_applied": exclusions
    }
    
    print(json.dumps(result))

if __name__ == "__main__":
    analyze()