import pandas as pd
import numpy as np
import json
import statsmodels.api as sm
from scipy import stats

# Load data
df = pd.read_csv('/kaggle/working/outputs/runs/allam-2-7b_soccer_skeptical_T0.7_r4/data.csv')

# Prepare skin tone predictor: average of rater1 and rater2
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2.0

# Exclude rows where skin tone is missing
df = df.dropna(subset=['skin_tone'])

# For robustness, let's drop missing height, weight, and position as well to avoid NaN issues in dummies/features
# position has 12% missing, height 0.2%, weight 1.5%
# We will perform listwise deletion on the final set of covariates used.

# Covariates: leagueCountry, position, height, weight, games
# Let's create dummy variables for leagueCountry and position
# First, ensure no NaNs in the columns we intend to use for dummies or continuous vars

cols_to_keep = ['skin_tone', 'leagueCountry', 'position', 'height', 'weight', 'games', 'redCards']
df_clean = df[cols_to_keep].dropna()

# Re-verify skin_tone is not NaN (should be fine after dropna on cols_to_keep if it was included, but explicit is better)
# Actually, position is object, so dropna handles it.

# Build design matrix
X = df_clean[['skin_tone', 'height', 'weight', 'games']]

# Dummies for leagueCountry
league_dummies = pd.get_dummies(df_clean['leagueCountry'], prefix='league', drop_first=True, dtype=float)
# Dummies for position
pos_dummies = pd.get_dummies(df_clean['position'], prefix='pos', drop_first=True, dtype=float)

X = pd.concat([X, league_dummies, pos_dummies], axis=1)
X = sm.add_constant(X)

y = df_clean['redCards'].values

# Check for any remaining NaNs or infs
if X.isna().any().any() or np.any(np.isinf(X.values)):
    # If any remain, drop them
    mask = ~X.isna().any(axis=1) & ~np.any(np.isinf(X.values), axis=1)
    X = X[mask]
    y = y[mask]

# Fit Poisson model
model = sm.GLM(y, X, family=sm.families.Poisson())
result = model.fit()

# Extract coefficient for skin_tone
coef = result.params['skin_tone']
se = result.bse['skin_tone']
p_val = result.pvalues['skin_tone']
ci = result.conf_int().loc['skin_tone']

# Effect type: IRR (Incidence Rate Ratio) for Poisson
effect_size = np.exp(coef)
ci_lower = np.exp(ci[0])
ci_upper = np.exp(ci[1])

# Standard error for the IRR using Delta Method: SE_IRR = IRR * SE_log
se_irr = effect_size * se

# Conclusion
conclusion = 'significant_effect' if p_val < 0.05 else 'no_significant_effect'

# Covariates included (exclude constant and main predictor)
covariates_included = [c for c in X.columns if c not in ['const', 'skin_tone']]

output = {
    "effect_size": float(effect_size),
    "effect_type": "irr",
    "standard_error": float(se_irr),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "skin_tone (average of rater1 and rater2)",
    "covariates_included": covariates_included,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "Rows with missing skin_tone, position, height, or weight"
}

print(json.dumps(output))