import pandas as pd
import numpy as np
import json
import statsmodels.api as sm

# Load data
df = pd.read_csv('/kaggle/working/outputs/runs/allam-2-7b_soccer_confirmatory_T0.7_r2/data.csv')

# Clean data: keep rows with valid skin tone measurements
df = df.dropna(subset=['rater1', 'rater2'])

# Construct continuous skin tone variable (average of two raters)
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2.0

# Outcome variable: red cards (binary: 0 or 1+). We'll use a binary indicator
df['has_red'] = (df['redCards'] > 0).astype(int)

# Covariates: games played, position (dummy variables), league country
# Handle missing position
df['position'] = df['position'].fillna('Unknown')

# Create dummy variables for position (drop first to avoid multicollinearity)
pos_dummies = pd.get_dummies(df['position'], prefix='pos', drop_first=True, dtype=float)
df = pd.concat([df, pos_dummies], axis=1)

# Create dummy variables for league country
league_dummies = pd.get_dummies(df['leagueCountry'], prefix='league', drop_first=True, dtype=float)
df = pd.concat([df, league_dummies], axis=1)

# Define independent variables
X_cols = ['skin_tone', 'games'] + list(pos_dummies.columns) + list(league_dummies.columns)

# Ensure all X columns exist and have no NaN
X = df[X_cols].copy()
X = X.fillna(0)  # Fill any remaining NaNs with 0

# Add constant
X = sm.add_constant(X)

# Dependent variable
y = df['has_red']

# Fit logistic regression model
model = sm.Logit(y, X)
result = model.fit(disp=0)

# Extract results for skin_tone
effect = result.params['skin_tone']
se = result.bse['skin_tone']
p_val = result.pvalues['skin_tone']

# Odds ratio
odds_ratio = np.exp(effect)
se_rob = se * odds_ratio  # Delta method approximation

# Confidence interval for odds ratio
ci_lower = np.exp(effect - 1.96 * se)
ci_upper = np.exp(effect + 1.96 * se)

# Conclusion
conclusion = 'significant_effect' if p_val < 0.05 else 'no_significant_effect'

# Build output
output = {
    "effect_size": float(odds_ratio),
    "effect_type": "odds_ratio",
    "standard_error": float(se_rob),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "logistic",
    "predictor_used": "skin_tone (average of rater1 and rater2, continuous 0-1)",
    "covariates_included": X_cols,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "Rows missing rater1 or rater2 (21,407 rows removed)"
}

print(json.dumps(output))