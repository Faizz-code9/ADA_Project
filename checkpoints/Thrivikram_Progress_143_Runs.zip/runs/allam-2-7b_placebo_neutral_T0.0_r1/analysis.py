import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

# Load data
df = pd.read_csv('/kaggle/working/outputs/runs/allam-2-7b_placebo_neutral_T0.0_r1/data.csv')

# Construct skin tone variable (average of rater1 and rater2)
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2.0

# Drop rows where skin_tone is NaN
df = df.dropna(subset=['skin_tone'])

# Prepare outcome: binary red card
df['red_card_binary'] = (df['redCards'] > 0).astype(int)

# Handle missing covariates
df['position'] = df['position'].fillna('Unknown')
df['height'] = df['height'].fillna(df['height'].median())
df['weight'] = df['weight'].fillna(df['weight'].median())

# One-hot encode position and leagueCountry
pos_dummies = pd.get_dummies(df['position'], prefix='pos', drop_first=True, dtype=float)
league_dummies = pd.get_dummies(df['leagueCountry'], prefix='league', drop_first=True, dtype=float)

# Build design matrix
X = pd.concat([df[['skin_tone', 'height', 'weight', 'games']], pos_dummies, league_dummies], axis=1)
X = sm.add_constant(X)

# Drop any remaining NaN/Inf
X = X.replace([np.inf, -np.inf], np.nan).dropna()
y = df.loc[X.index, 'red_card_binary']

# Fit logistic regression
model = sm.Logit(y, X).fit(disp=0)

# Extract results for skin_tone
coef = model.params['skin_tone']
se = model.bse['skin_tone']
p_val = model.pvalues['skin_tone']
ci = model.conf_int().loc['skin_tone']

# Effect size: odds ratio
odds_ratio = np.exp(coef)
ci_lower = np.exp(ci[0])
ci_upper = np.exp(ci[1])

# Conclusion
conclusion = 'significant_effect' if p_val < 0.05 else 'no_significant_effect'

# Covariates included
covariates = ['height', 'weight', 'games', 'position', 'leagueCountry']

result = {
    "effect_size": float(odds_ratio),
    "effect_type": "odds_ratio",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "logistic",
    "predictor_used": "skin_tone (average of rater1 and rater2)",
    "covariates_included": covariates,
    "missing_data_strategy": "mean_imputation",
    "clustering_strategy": "none",
    "exclusions_applied": "rows with missing rater1 or rater2; rows with remaining NaN/Inf in covariates"
}

print(json.dumps(result))