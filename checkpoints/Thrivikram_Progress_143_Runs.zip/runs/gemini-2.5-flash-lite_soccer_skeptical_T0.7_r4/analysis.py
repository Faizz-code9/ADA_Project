import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

def analyze_bias():
    file_path = '/kaggle/working/outputs/runs/gemini-2.5-flash-lite_soccer_skeptical_T0.7_r4/data.csv'
    df = pd.read_csv(file_path)

    # Define the skin tone predictor (average of rater1 and rater2)
    # Missing values in rater1/rater2 are associated with missing photoID.
    # We use listwise deletion for the core analysis.
    df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)
    
    # Outcome is redCards. Since redCards can be 0, 1, 2 (count data), 
    # and the primary estimand is a "ratio effect" (Rate Ratio), 
    # a Poisson model with a log link is appropriate for count data.
    # We will use 'games' as an offset to model the rate of red cards per game.
    
    cols_to_keep = ['redCards', 'skin_tone', 'games', 'leagueCountry', 'refCountry']
    df_clean = df[cols_to_keep].dropna().copy()
    
    # Ensure games > 0 to avoid log(0) in offset
    df_clean = df_clean[df_clean['games'] > 0]

    # Poisson regression: log(E[redCards]) = beta0 + beta1*skin_tone + log(games)
    # The exponentiated coefficient (exp(beta1)) is the Incident Rate Ratio (IRR).
    model = smf.poisson('redCards ~ skin_tone + C(leagueCountry) + C(refCountry)', 
                        offset=np.log(df_clean['games']), 
                        data=df_clean).fit(disp=False)

    # Extracting parameters for skin_tone
    beta_skin = model.params['skin_tone']
    se_skin = model.bse['skin_tone']
    p_val = model.pvalues['skin_tone']
    
    # Primary estimand: Ratio effect (IRR)
    irr = np.exp(beta_skin)
    ci_lower = np.exp(model.conf_int().loc['skin_tone'][0])
    ci_upper = np.exp(model.conf_int().loc['skin_tone'][1])

    output = {
        "effect_size": float(irr),
        "effect_type": "irr",
        "standard_error": float(se_skin), # SE of the coefficient is standard, but we provide SE of the estimator if needed. 
                                          # Usually, in these tasks, we provide SE of the coefficient or the effect. 
                                          # Given the JSON structure, we'll provide the SE of the coefficient for mathematical rigor.
        "p_value": float(p_val),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
        "model_family": "poisson",
        "predictor_used": "mean(rater1, rater2)",
        "covariates_included": ["leagueCountry", "refCountry", "games (offset)"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "none",
        "exclusions_applied": "Removed rows with missing skin tone, redCards, games, or league/ref country"
    }
    
    # Correcting SE: Standard practice for IRR is exp(beta +/- 1.96*se_beta). 
    # The prompt asks for standard_error. For a ratio, SE is often reported for the log-ratio.
    # We will provide the SE of the coefficient.
    output["standard_error"] = float(se_skin)

    print(json.dumps(output))

if __name__ == "__main__":
    analyze_bias()