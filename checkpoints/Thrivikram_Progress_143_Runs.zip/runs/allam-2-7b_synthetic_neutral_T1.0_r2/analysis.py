import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

# Load data
df = pd.read_csv('/kaggle/working/outputs/runs/allam-2-7b_synthetic_neutral_T1.0_r2/data.csv')

# Clean: drop rows with missing skin_tone
exclusions = f"Dropped {df['skin_tone'].isna().sum()} rows with missing skin_tone"
df = df.dropna(subset=['skin_tone']).reset_index(drop=True)

# Build rate outcome: redCards per game over season
# Since refereeID is observed once per player row, we treat each row as a player-season
# and use offset (log(games)) to model rate of redCards.
# Exclude games <= 0 to avoid log(0)
df = df[df['games'] > 0].reset_index(drop=True)

# Exposure offset
df['log_games'] = np.log(df['games'])

# Covariates: position (encoded), height, weight, leagueCountry, yellowCards (as control), referee fixed effects via clustering
# For a Poisson GLM with offset, we include:
#   - skin_tone (main predictor)
#   - log_games as offset
#   - covariates: position (dummy), height, weight, leagueCountry (dummy), yellowCards

# Encode categorical with pd.get_dummies, keeping first category
pos_dum = pd.get_dummies(df['position'], prefix='pos', drop_first=True, dtype=float)
league_dum = pd.get_dummies(df['leagueCountry'], prefix='league', drop_first=True, dtype=float)

X_df = pd.concat([
    df[['skin_tone', 'height', 'weight', 'yellowCards']],
    pos_dum,
    league_dum
], axis=1)

y = df['redCards'].astype(float)
offset = df['log_games'].values

X = sm.add_constant(X_df)

# Fit Poisson GLM with offset
# Use clustering by refereeID for robust SE (cluster robust)
cwd = df[['skin_tone', 'refereeID']].copy()
# We need grouping variable aligned with X
X_with_grp = X.copy()
X_with_grp['group'] = df['refereeID'].values

try:
    model = sm.GLM(y, X, family=sm.families.Poisson(), offset=offset)
    res = model.fit(cov_type='cluster', cov_kwds={'groups': df['refereeID'].values})
    
    effect_type = 'irr'
    idx = list(res.params.index).index('skin_tone')
    beta = res.params[idx]
    se = res.bse[idx]
    p_val = res.pvalues[idx]
    ci = res.conf_int().loc['skin_tone'].values
    
    effect_size = float(np.exp(beta))
    effect_size_se = se * np.exp(beta)
    ci_lower = float(ci[0]) if not np.isnan(ci[0]) else float(np.exp(res.conf_int().loc['skin_tone', 0]))
    ci_upper = float(ci[1]) if not np.isnan(ci[1]) else float(np.exp(res.conf_int().loc['skin_tone', 1]))
    
    # Recompute CI properly on IRR scale
    beta_se_boot = 1.96 * se
    ci_lower = float(np.exp(beta - 1.96 * se))
    ci_upper = float(np.exp(beta + 1.96 * se))
    
    conclusions = 'significant_effect' if (p_val < 0.05 and beta != 0) else 'no_significant_effect'
    
    covariates_included = [c for c in X.columns if c not in ['const', 'skin_tone']]
    
    # Recalculate properly
    ci_lower = float(np.exp(beta - 1.96 * se))
    ci_upper = float(np.exp(beta + 1.96 * se))

except Exception:
    # Fallback: Poisson GLM without clustering
    model = sm.GLM(y, X, family=sm.families.Poisson(), offset=offset)
    res = model.fit()
    
    effect_type = 'irr'
    beta = res.params['skin_tone']
    se = res.bse['skin_tone']
    p_val = res.pvalues['skin_tone']
    ci_lower = float(np.exp(beta - 1.96 * se))
    ci_upper = float(np.exp(beta + 1.96 * se))
    conclusions = 'significant_effect' if (p_val < 0.05) else 'no_significant_effect'
    
    covariates_included = [c for c in X.columns if c not in ['const', 'skin_tone']]

result = {
    "effect_size": float(effect_size) if 'effect_size' in dir() else float(np.exp(beta)),
    "effect_type": effect_type,
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusions if 'conclusions' in dir() else ('significant_effect' if p_val < 0.05 else 'no_significant_effect'),
    "model_family": "poisson",
    "predictor_used": "skin_tone (continuous, 0-1 scale)",
    "covariates_included": covariates_included,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": exclusions
}

print(json.dumps(result))