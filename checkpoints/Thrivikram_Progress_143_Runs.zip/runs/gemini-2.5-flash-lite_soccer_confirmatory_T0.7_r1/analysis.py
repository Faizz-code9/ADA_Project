import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

def main():
    # Load data
    file_path = '/kaggle/working/outputs/runs/gemini-2.5-flash-lite_soccer_confirmatory_T0.7_r1/data.csv'
    try:
        df = pd.read_csv(file_path)
    except FileNotFoundError:
        return

    # Clean and prepare data
    # Predictor: average skin tone from rater1 and rater2
    # Outcome: redCards
    # The hypothesis asks for the ratio effect of continuous skin tone on red cards.
    # Since redCards is a count (0, 1, 2) and the data is likely overdispersed, 
    # Poisson or Negative Binomial is appropriate.
    # Given the request for "ratio effect", an Incidence Rate Ratio (IRR) from a Poisson model
    # is the standard way to interpret the coefficient of a continuous predictor in a count model.
    
    # Drop rows where skin tone or outcome is missing
    df_clean = df.dropna(subset=['rater1', 'rater2', 'redCards']).copy()
    
    # Construct continuous skin tone variable
    df_clean['skin_tone_avg'] = (df_clean['rater1'] + df_clean['rater2']) / 2.0
    
    # Exclusions: Rows where redCards might be invalid (though dictionary says 0-2)
    df_clean = df_clean[df_clean['redCards'] >= 0]
    
    # We use a Poisson regression to model the count.
    # The exponentiated coefficient of the Poisson model is the Incidence Rate Ratio (IRR).
    # This represents the ratio of the expected number of red cards for a unit increase in skin tone.
    
    model = smf.poisson('redCards ~ skin_tone_avg', data=df_clean)
    results = model.fit(disp=False)
    
    # Extract statistics
    coeff = results.params['skin_tone_avg']
    se_coeff = results.bse['skin_tone_avg']
    p_val = results.pvalues['skin_tone_avg']
    
    # For IRR:
    irr = np.exp(coeff)
    # Standard error for IRR is approximated via Delta Method: exp(coeff) * se(coeff)
    irr_se = irr * se_coeff
    
    # Confidence Interval for IRR
    ci_low_coeff = results.conf_int().loc['skin_tone_avg', 0]
    ci_high_coeff = results.conf_int().loc['skin_tone_avg', 1]
    irr_ci_lower = np.exp(ci_low_coeff)
    irr_ci_upper = np.exp(ci_high_coeff)
    
    output = {
        "effect_size": float(irr),
        "effect_type": "irr",
        "standard_error": float(irr_se),
        "p_value": float(p_val),
        "ci_lower": float(irr_ci_lower),
        "ci_upper": float(irr_ci_upper),
        "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
        "model_family": "poisson",
        "predictor_used": "mean(rater1, rater2)",
        "covariates_included": [],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "none",
        "exclusions_applied": f"Removed {len(df) - len(df_clean)} rows with missing skin tone or redCards"
    }
    
    print(json.dumps(output))

if __name__ == "__main__":
    main()