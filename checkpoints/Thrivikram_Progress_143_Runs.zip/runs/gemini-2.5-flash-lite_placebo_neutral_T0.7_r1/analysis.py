import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

def analyze_bias():
    file_path = '/kaggle/working/outputs/runs/gemini-2.5-flash-lite_placebo_neutral_T0.7_r1/data.csv'
    
    # Load data
    try:
        df = pd.read_csv(file_path)
    except FileNotFoundError:
        return

    # 1. Cleaning and Variable Construction
    # Primary predictor: Average skin tone from rater1 and rater2
    df['skin_tone_avg'] = df[['rater1', 'rater2']].mean(axis=1)
    
    # Outcome: redCards
    # Since redCards is count data (0, 1, 2), a Poisson or Negative Binomial model is appropriate.
    # The hypothesis asks for the "ratio effect" of continuous skin tone.
    # In a Poisson model, exp(beta) represents the Incidence Rate Ratio (IRR).
    
    # Target columns for model
    target_col = 'redCards'
    predictor_col = 'skin_tone_avg'
    
    # Exclude missing values for the variables used in regression
    # We use listwise deletion for the subset of variables required
    initial_len = len(df)
    cols_to_use = [target_col, predictor_col, 'games', 'yellowCards', 'refNum']
    df_clean = df.dropna(subset=cols_to_use).copy()
    
    # Exclude rows where skin_tone_avg is NaN (already handled by dropna)
    # and ensure redCards is treated as non-negative integer
    df_clean = df_clean[df_clean[target_col] >= 0]
    
    exclusions_description = f"Removed rows with missing {target_col}, {predictor_col}, or covariates."
    if len(df_clean) == initial_len:
        exclusions_description = "none"
    else:
        exclusions_description = f"Removed {initial_len - len(df_clean)} rows due to missingness."

    # 2. Statistical Modeling
    # We use a Poisson regression because redCards is a count variable.
    # We include 'games' as an offset (log(games)) to account for exposure/opportunity,
    # or simply as a covariate. Using log(games) as an offset is standard for rate models.
    # However, for simplicity and to capture the "ratio effect" on the count directly:
    # Model: redCards ~ skin_tone_avg + games + yellowCards
    
    # To ensure stability with small counts, we use a Poisson GLM with a log link.
    # The coefficient of skin_tone_avg in log-link Poisson is the log of the IRR.
    
    model = smf.poisson(f"{target_col} ~ {predictor_col} + games + yellowCards", data=df_clean)
    results = model.fit(disp=False)
    
    # 3. Compute Estimands
    # effect_size (IRR) = exp(coefficient)
    coef = results.params[predictor_col]
    se_coef = results.bse[predictor_col]
    irr = np.exp(coef)
    
    # Confidence Interval for IRR
    ci_lower_log = results.conf_int().loc[predictor_col, 0]
    ci_upper_log = results.conf_int().loc[predictor_col, 1]
    ci_lower = np.exp(ci_lower_log)
    ci_upper = np.exp(ci_upper_log)
    
    p_value = results.pvalues[predictor_col]
    
    # Standard error of the IRR is more complex, but the prompt asks for 
    # standard error of the effect. Usually, in ratio contexts, we report SE of the log-ratio.
    # However, to be consistent with typical "effect_size" reporting in these tasks:
    # We will provide the SE of the coefficient (log-scale) or the delta method SE.
    # Given the prompt structure, SE of the coefficient is the standard statistical output.
    # But if effect_type is 'irr', the SE is often expected for the parameter.
    # We'll provide the SE of the coefficient to maintain mathematical rigor.
    
    output = {
        "effect_size": float(irr),
        "effect_type": "irr",
        "standard_error": float(se_coef),
        "p_value": float(p_value),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": "significant_effect" if p_value < 0.05 else "no_significant_effect",
        "model_family": "poisson",
        "predictor_used": "mean(rater1, rater2)",
        "covariates_included": ["games", "yellowCards"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "none",
        "exclusions_applied": exclusions_description
    }
    
    print(json.dumps(output))

if __name__ == "__main__":
    analyze_bias()