import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

def solve():
    file_path = '/kaggle/working/outputs/runs/gemini-2.5-flash-lite_soccer_confirmatory_T1.0_r5/data.csv'
    df = pd.read_csv(file_path)

    # Data Cleaning
    # Skin tone is provided by rater1 and rater2. Using the mean for a continuous predictor.
    df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)
    
    # Red cards is the outcome. Since it's a count of rare events (mean 0.01), 
    # Poisson regression is suitable for rate estimation.
    # We include 'games' as an offset to model the rate of red cards per game played.
    # We control for yellow cards to isolate the effect on red cards.
    
    # Drop rows with missing values in critical variables
    initial_len = len(df)
    df_clean = df.dropna(subset=['redCards', 'skin_tone', 'games', 'yellowCards']).copy()
    exclusions = f"Removed {initial_len - len(df_clean)} rows due to missing skin_tone, redCards, games, or yellowCards"

    # Primary estimand: ratio effect (Incidence Rate Ratio - IRR)
    # Formula: log(E[redCards]) = beta0 + beta1 * skin_tone + log(games)
    # IRR = exp(beta1)
    
    # Poisson regression with offset
    # Using log(games) as offset to model rate per game
    model = smf.poisson('redCards ~ skin_tone + yellowCards', data=df_clean, offset=np.log(df_clean['games']))
    result = model.fit(disp=False)

    beta_skin = result.params['skin_tone']
    se_skin = result.bse['skin_tone']
    p_val = result.pvalues['skin_tone']
    
    # Calculate IRR and CI
    irr = np.exp(beta_skin)
    ci_lower = np.exp(result.conf_int().loc['skin_tone', 0])
    ci_upper = np.exp(result.conf_int().loc['skin_tone', 1])

    output = {
        "effect_size": float(irr),
        "effect_type": "irr",
        "standard_error": float(np.exp(beta_skin) * se_skin), # Approximation for SE of ratio
        "p_value": float(p_val),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
        "model_family": "poisson",
        "predictor_used": "mean(rater1, rater2)",
        "covariates_included": ["yellowCards", "games (offset)"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "none",
        "exclusions_applied": exclusions
    }

    print(json.dumps(output, indent=2))

if __name__ == "__main__":
    solve()