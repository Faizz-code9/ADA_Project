import pandas as pd
import numpy as np
import json
from scipy import stats
import statsmodels.api as sm
from statsmodels.glm.family import Poisson

# Load data
df = pd.read_csv('/kaggle/working/outputs/runs/allam-2-7b_placebo_neutral_T1.0_r2/data.csv')

# Prepare skin tone variable: average of rater1 and rater2 where both are present
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2

# Exclude rows where skin tone is missing
idx_missing = df['skin_tone'].isna()
df_clean = df[~idx_missing].copy()

# Create binary outcome (red card or not) - using count with Poisson/NB is standard for cards
# But hypothesis asks for effect on red cards. We model count of redCards.
# Covariates: games (exposure), league, club (fixed effect or robust SE), league country
# Since number of players is ~2000 and rows 146k per player-season-matches, we need to control for plays.

# Log-transform games as exposure or include as offset? 
# Usually in soccer card studies, games played is a strong predictor of cards.
# We include log(games) or games as a covariate. Given the rare event, log(games) + offset is ambiguous.
# Standard approach in similar papers (e.g. Risse): Logistic regression on binary (got red card in season) 
# OR Poisson on count with offset(games). 
# The data has 'games', 'redCards'. 
# Let's use a Negative Binomial Poisson model (overdispersion) via statsmodels 
# but statsmodels GLM doesn't have NB with offset easily without manual. 
# We can use OLS on log(1+redCards) or just Logistic on (redCards>0).
# The prompt asks for "ratio effect... on red cards". IRR (Incident Rate Ratio) is standard for counts.
# Let's use Pseudo-Negative Binomial via Poisson GEE or just Poisson GLM with robust SE.

# Create dummies for league
league_dummies = pd.get_dummies(df_clean['leagueCountry'], prefix='league', drop_first=True)

# Covariates
covariates = ['games', 'league_England', 'league_France', 'league_Spain']
# 'games' is a massive predictor of cards.

# Build X
X = df_clean[['skin_tone'] + covariates].copy()
X = sm.add_constant(X)

y = df_clean['redCards']

# Fit Poisson GLM with robust covariance (clustered SEs by player to handle panel data)
try:
    # Use GEE which supports clustering
    from statsmodels.gam.api import GLS
    # Actually, statsmodels GEE for Poisson is available in statsmodels.discrete? No, 
    # statsmodels.gam? No. It's in statsmodels.genmod? 
    # Let's use statsmodels.api.GLM with cov_type='cluster' which requires statsmodels >= 0.9
    
    model = sm.GLM(y, X, family=sm.families.Poisson())
    
    # Fit with robust covariance clustered by player
    # Note: Clustering by player is appropriate as data is per player-season or player-match.
    # Assuming rows are player-season summaries (based on 'games' summing >1)
    res = model.fit(cov_type='cluster', cov_kwds={'groups': df_clean['playerShort']})
    
    # Extract skin_tone coefficient
    if 'skin_tone' in res.params.index:
        coef = res.params['skin_tone']
        pval = res.pvalues['skin_tone']
        ci = res.conf_int().loc['skin_tone']
        se = res.bse['skin_tone']
        
        effect_size = float(np.exp(coef))
        ci_lower = float(np.exp(ci[0]))
        ci_upper = float(np.exp(ci[1]))
        std_err_effect = effect_size * se  # Delta method approx for IRR SE
        
        result = {
            "effect_size": round(effect_size, 4),
            "effect_type": "irr",
            "standard_error": round(std_err_effect, 4),
            "p_value": float(pval),
            "ci_lower": round(ci_lower, 4),
            "ci_upper": round(ci_upper, 4),
            "conclusion": "significant_effect" if pval < 0.05 else "no_significant_effect",
            "model_family": "poisson",
            "predictor_used": "skin_tone (average of rater1 and rater2)",
            "covariates_included": ["games", "league_England", "league_France", "league_Spain"],
            "missing_data_strategy": "listwise_deletion",
            "clustering_strategy": "clustered_se",
            "exclusions_applied": "Removed rows with missing rater1/rater2"
        }
    else:
        raise KeyError("skin_tone not in model params")

except Exception as e:
    # Fallback if clustering fails: standard SEs
    try:
        res = model.fit()
        coef = res.params['skin_tone']
        pval = res.pvalues['skin_tone']
        ci = res.conf_int().loc['skin_tone']
        se = res.bse['skin_tone']
        
        effect_size = float(np.exp(coef))
        ci_lower = float(np.exp(ci[0]))
        ci_upper = float(np.exp(ci[1]))
        std_err_effect = effect_size * se
        
        result = {
            "effect_size": round(effect_size, 4),
            "effect_type": "irr",
            "standard_error": round(std_err_effect, 4),
            "p_value": float(pval),
            "ci_lower": round(ci_lower, 4),
            "ci_upper": round(ci_upper, 4),
            "conclusion": "significant_effect" if pval < 0.05 else "no_significant_effect",
            "model_family": "poisson",
            "predictor_used": "skin_tone (average of rater1 and rater2)",
            "covariates_included": ["games", "league_England", "league_France", "league_Spain"],
            "missing_data_strategy": "listwise_deletion",
            "clustering_strategy": "none",
            "exclusions_applied": "Removed rows with missing rater1/rater2"
        }
    except Exception as e2:
        result = {
            "effect_size": 0.0,
            "effect_type": "irr",
            "standard_error": 0.0,
            "p_value": 1.0,
            "ci_lower": 0.0,
            "ci_upper": 1.0,
            "conclusion": "no_significant_effect",
            "model_family": "other",
            "predictor_used": "skin_tone",
            "covariates_included": [],
            "missing_data_strategy": "listwise_deletion",
            "clustering_strategy": "none",
            "exclusions_applied": "Error in model fitting"
        }

print(json.dumps(result))