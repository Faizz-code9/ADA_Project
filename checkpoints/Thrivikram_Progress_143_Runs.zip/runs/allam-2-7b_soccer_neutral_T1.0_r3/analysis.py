import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

df = pd.read_csv('/kaggle/working/outputs/runs/allam-2-7b_soccer_neutral_T1.0_r3/data.csv')

# Build skin tone as mean of the two raters where both present
df['skintone'] = np.where(df['rater1'].notna() & df['rater2'].notna(),
                          (df['rater1'] + df['rater2']) / 2.0, np.nan)

# Keep rows with valid skin tone and positive games played
mask = df['skintone'].notna() & (df['games'] > 0)
df = df[mask].copy()

# Prepare design matrix
X_raw = pd.DataFrame({
    'skintone': df['skintone'].values
})
X_raw = pd.concat([X_raw, pd.get_dummies(df['leagueCountry'], prefix='lc', drop_first=True)], axis=1)
X_raw = pd.concat([X_raw, pd.get_dummies(df['position'], prefix='pos', drop_first=True)], axis=1)
X = sm.add_constant(X_raw)
y = df['redCards'].values
offset = np.log(df['games'].values)

skintone_idx = list(X.columns).index('skintone')

try:
    model = sm.GLM(y, X, family=sm.families.NegativeBinomial(link=sm.families.links.Log()), offset=offset)
    res = model.fit()
    family = "negative_binomial"
except Exception:
    try:
        model = sm.GLM(y, X, family=sm.families.Poisson(link=sm.families.links.Log()), offset=offset)
        res = model.fit()
        family = "poisson"
    except Exception:
        model = sm.GLM(y, X, family=sm.families.Poisson(link=sm.families.links.Log()), offset=offset)
        res = model.fit_regularized(alpha=1.0)
        family = "poisson"

coef = res.params[skintone_idx]
se = res.bse[skintone_idx]
pval = res.pvalues[skintone_idx]
ci = res.conf_int().iloc[skintone_idx].values

IRR = np.exp(coef)
IRR_se = np.exp(coef) * se
ci_lower = float(np.exp(ci[0]))
ci_upper = float(np.exp(ci[1]))

significant = "significant_effect" if pval < 0.05 else "no_significant_effect"

result = {
    "effect_size": float(IRR),
    "effect_type": "irr",
    "standard_error": float(IRR_se),
    "p_value": float(pval),
    "ci_lower": ci_lower,
    "ci_upper": ci_upper,
    "conclusion": significant,
    "model_family": family,
    "predictor_used": "skintone (mean of rater1 and rater2, continuous 0-1)",
    "covariates_included": ["leagueCountry", "position", "games (as exposure)"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "rows with missing rater1/rater2 (no skin tone) and games=0 removed"
}

print(json.dumps(result))