import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

# 1. Load data
df = pd.read_csv("/kaggle/working/outputs/runs/allam-2-7b_soccer_neutral_T0.7_r3/data.csv")

# 2. Data Preparation
# Construct composite skin tone variable (average of rater1 and rater2)
df['skin_tone_avg'] = (df['rater1'] + df['rater2']) / 2

# Handle missing values in skin_tone_avg: drop rows where skin tone is missing
# Also drop rows where position is missing if we plan to use it, but let's stick to simpler covariates first.
# The hypothesis asks for bias based on skin tone.
# We need to decide on covariates. Common confounders: Position, League Country, Age (from birthday), Height, Weight.
# However, to keep it robust and simple within line limits, we will use:
# - leagueCountry (categorical)
# - position (categorical, but has 12% missing. We can drop these or treat as separate category. Dropping is safer for listwise deletion strategy consistency if we use others).
# - height, weight (continuous, small missingness)
# - games (exposure? No, red cards are per player aggregate in this dataset? 
#   Looking at the data: 'games' mean 2.9, 'redCards' mean 0.01. 
#   The data seems to be aggregated by player or player-match? 
#   'playerShort' unique 2053, rows 146k. This looks like player-season or player-match level data.
#   Given 'games' max 47, it's likely player-season or player-tournament.
#   Let's assume the unit of analysis is the row (player observation).
#   
#   Since redCards is a count (0, 1, 2), and mean is low (0.01), Poisson or Negative Binomial is appropriate.
#   Overdispersion is likely. We will use Negative Binomial.

# Drop rows with missing skin tone
df = df.dropna(subset=['skin_tone_avg'])

# Covariates:
# We will include 'leagueCountry' and 'position'.
# Position has 12% missing. We will drop these rows to maintain listwise deletion for all covariates.
# Height/Weight have small missingness. We will drop those too for clean listwise deletion.

covariates = ['leagueCountry', 'position', 'height', 'weight']
# Create dummies for categorical variables
df_model = df.dropna(subset=covariates).copy()

# Encode leagueCountry
league_dummies = pd.get_dummies(df_model['leagueCountry'], prefix='league', drop_first=True, dtype=float)
# Encode position
pos_dummies = pd.get_dummies(df_model['position'], prefix='pos', drop_first=True, dtype=float)

df_model = pd.concat([df_model, league_dummies, pos_dummies], axis=1)

# Define predictors
X_cols = ['skin_tone_avg', 'height', 'weight'] + list(league_dummies.columns) + list(pos_dummies.columns)
X = df_model[X_cols]
X = sm.add_constant(X)
y = df_model['redCards']

# 3. Fit Model
# Use Negative Binomial due to likely overdispersion in count data
try:
    model = sm.GLM(y, X, family=sm.families.NegativeBinomial())
    result = model.fit()
    model_family = "negative_binomial"
except:
    # Fallback to Poisson if NB fails
    model = sm.GLM(y, X, family=sm.families.Poisson())
    result = model.fit()
    model_family = "poisson"

# 4. Compute Primary Estimand
# The primary estimand is the effect of skin_tone_avg.
# In a count model (Poisson/NB), the coefficient is the log of the Incidence Rate Ratio (IRR).
# The "ratio effect" usually implies the IRR itself (exponentiated coefficient).
coef = result.params['skin_tone_avg']
se = result.bse['skin_tone_avg']
p_val = result.pvalues['skin_tone_avg']

# Confidence Interval for the coefficient (log scale)
ci_lower_log = result.conf_int().loc['skin_tone_avg'][0]
ci_upper_log = result.conf_int().loc['skin_tone_avg'][1]

# Exponentiate to get IRR
effect_size = np.exp(coef)
ci_lower = np.exp(ci_lower_log)
ci_upper = np.exp(ci_upper_log)

# Standard Error for the IRR can be approximated using delta method or just reported as log-scale SE?
# The prompt asks for "standard_error". Usually, this refers to the SE of the estimated effect.
# If effect_type is 'irr', the SE is on the log scale typically reported, or delta method.
# Let's provide the SE of the log coefficient as is common in model summaries, but clarify effect_type.
# However, strictly speaking, if effect_size is IRR, the SE should correspond to that scale.
# Delta method: SE_IRR = IRR * SE_log
se_irr = effect_size * se

# Conclusion
conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

# Clustering Strategy
# The data is aggregated. We are not explicitly clustering by player or referee in this simple GLM.
# If we were to cluster, we'd need to group by refNum or playerShort.
# Given the constraints and single script, we assume independent observations for the GLM unless specified.
# However, referees are a strong cluster. Let's check if we should use GEE.
# The prompt allows 'gee'. But GEE requires specifying a cov_type.
# Given the complexity and line limit, and that the "primary estimand" is just the ratio effect,
# a standard GLM with Robust SE (Clustered by refNum) would be better.
# Let's re-run with Robust SE clustered by refNum to account for referee bias.

# Refit with robust covariance clustered by refNum
# We need to align the refNum with the filtered dataframe
df_model['refNum'] = df_model['refNum'] 
# statsmodels GLM fit with cov_type='cluster' requires groups
# We use the filtered data's refNum
groups = df_model['refNum'].values

try:
    # Recreate model object to use robust fit
    # sm.GLM.fit() supports cov_type='cluster'
    result_robust = model.fit(cov_type='cluster', cov_kwds={'groups': groups})
    coef = result_robust.params['skin_tone_avg']
    se = result_robust.bse['skin_tone_avg']
    p_val = result_robust.pvalues['skin_tone_avg']
    ci_lower_log = result_robust.conf_int().loc['skin_tone_avg'][0]
    ci_upper_log = result_robust.conf_int().loc['skin_tone_avg'][1]
    clustering_strategy = "clustered_se"
except Exception:
    # If clustering fails, stick to the original MLR
    clustering_strategy = "none"
    # Values from 'result' are already set if this path is taken, but we need to be careful.
    # The code above already set coef/se/p_val from the first fit. 
    # If the second fit succeeds, it overwrites. If it fails, we keep the first.

# Recalculate IRR stats based on the final result used
effect_size = np.exp(coef)
ci_lower = np.exp(ci_lower_log)
ci_upper = np.exp(ci_upper_log)
se_irr = effect_size * se
conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

# 5. Output JSON
output = {
    "effect_size": float(effect_size),
    "effect_type": "irr",
    "standard_error": float(se_irr),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": model_family,
    "predictor_used": "skin_tone_avg (mean of rater1 and rater2)",
    "covariates_included": [c for c in X_cols if c != 'skin_tone_avg' and c != 'const'],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": clustering_strategy,
    "exclusions_applied": "Rows with missing skin tone ratings or missing covariates (position, height, weight, leagueCountry) were removed."
}

print(json.dumps(output))