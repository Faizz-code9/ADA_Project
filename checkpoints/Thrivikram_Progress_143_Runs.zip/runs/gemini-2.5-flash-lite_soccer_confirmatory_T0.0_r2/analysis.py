import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

def solve():
    file_path = '/kaggle/working/outputs/runs/gemini-2.5-flash-lite_soccer_confirmatory_T0.0_r2/data.csv'
    df = pd.read_csv(file_path)

    # Data Cleaning
    # Primary estimand: ratio effect of continuous skin tone on red cards.
    # Skin tone is provided by rater1 and rater2. We use the mean as the continuous predictor.
    # redCards is the outcome. Since redCards is a count (0, 1, 2), Poisson or Negative Binomial is appropriate.
    # However, the hypothesis asks for a "ratio effect", which in a Poisson context is the Incident Rate Ratio (IRR).
    
    # Handle missing values
    # rater1/rater2 missingness is linked to photoID. 
    # redCards is the outcome.
    # We'll use listwise deletion for rows missing the predictor or outcome.
    df_clean = df.dropna(subset=['rater1', 'rater2', 'redCards', 'games']).copy()
    
    # Construct predictor: mean skin tone
    df_clean['skin_tone'] = df_clean[['rater1', 'rater2']].mean(axis=1)
    
    # We need to account for exposure (games played) to avoid bias where players with more games 
    # naturally have more red cards. We use 'games' as an offset.
    # Poisson model: log(E[redCards]) = beta0 + beta1 * skin_tone + log(games)
    # The IRR is exp(beta1).
    
    # Filter out players with 0 games to avoid log(0) in offset
    df_clean = df_clean[df_clean['games'] > 0]
    df_clean['log_games'] = np.log(df_clean['games'])

    # Fit Poisson model
    # Formula: redCards ~ skin_tone
    # Offset: log_games
    model = smf.poisson('redCards ~ skin_tone', data=df_clean, offset=df_clean['log_games'])
    results = model.fit(disp=False)

    # Extract statistics
    beta_skin = results.params['skin_tone']
    se_skin = results.bse['skin_tone']
    p_val = results.pvalues['skin_tone']
    
    # IRR (Incident Rate Ratio)
    irr = np.exp(beta_skin)
    ci_lower = np.exp(results.conf_int().loc['skin_tone', 0])
    ci_upper = np.exp(results.conf_int().loc['skin_tone', 1])

    conclusion = 'significant_effect' if p_val < 0.05 else 'no_significant_effect'

    output = {
        "effect_size": float(irr),
        "effect_type": "irr",
        "standard_error": float(se_skin), # SE of the coefficient is standard, but for IRR we usually report SE of log(IRR)
        "p_value": float(p_val),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": conclusion,
        "model_family": "poisson",
        "predictor_used": "mean(rater1, rater2)",
        "covariates_included": ["games (as offset)"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "none",
        "exclusions_applied": "Removed rows with missing skin tone, redCards, or games; removed games=0"
    }

    print(json.dumps(output))

if __name__ == "__main__":
    solve()