import pandas as pd
import numpy as np
import statsmodels.api as sm
import json
from scipy import stats

# Load data
df = pd.read_csv('/kaggle/working/outputs/runs/allam-2-7b_placebo_skeptical_T1.0_r1/data.csv')

# Construct continuous skin tone variable (mean of rater1 and rater2)
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2.0

# Drop rows with missing skin_tone, height, or weight
df = df.dropna(subset=['skin_tone', 'height', 'weight'])

# Encoders for categorical variables
position_map = {'Goalkeeper': 0, 'Center Back': 1, 'Center Forward': 2, 'Defensive Midfielder': 3, 'Attacking Midfielder': 4, 'Left Fullback': 5, 'Right Fullback': 6}
df['position_enc'] = df['position'].map(position_map)
df['position_enc'] = df['position_enc'].fillna(-1) # Keep position column, not required to be fully discrete but we can treat NaN as category too

df = df.dropna(subset=['position_enc'])

# Prepare variables
X = df[['skin_tone', 'height', 'weight', 'position_enc', 'games']].copy()
X['games'] = X['games'].astype(float) # Ensure float for consistency
X = sm.add_constant(X)

y = df['redCards'].values

# The outcome: RedCards is count, but very sparse (mostly 0, some 1, few 2).
# It is binary-like. Logistic regression ("Logistic") is appropriate.
# We want the effect of skin_tone on redCards.

# Fit OLS on logit scale? Or directly Logistic?
# Given prevalence (mean 0.012), Logistic is standard.
# However, the prompt asks for "ratio effect" as primary estimand.
# In logistic regression, exponentiating the coefficient gives the Odds Ratio.
# The question asks for "ratio effect ... on red cards". Since the outcome is a single event per observation, we can interpret the effect as the odds ratio.
# statsmodels Logit fits this.

import statsmodels.api as sm

try:
    model = sm.Logit(y, X)
    res = model.fit(disp=0)

    # Extract results for skin_tone
    coef = res.params['skin_tone']
    se = res.bse['skin_tone']
    p = res.pvalues['skin_tone']

    # Effect size is Odds Ratio
    effect_size = float(np.exp(coef))
    se_irr = float(se * np.exp(coef))
    ci_lower = float(coef - 1.96 * se)
    ci_upper = float(coef + 1.96 * se)
    ci_lower = np.exp(ci_lower)
    ci_upper = np.exp(ci_upper)

    model_family = 'logistic'
    effect_type = 'odds_ratio'
except Exception as e:
    # Fallback to OLS if Logit fails
    model = sm.OLS(y, X)
    res = model.fit()
    coef = res.params['skin_tone']
    se = res.bse['skin_tone']
    p = res.pvalues['skin_tone']
    effect_size = float(coef)
    se_irr = float(se)
    ci_lower = float(coef - 1.96 * se)
    ci_upper = float(coef + 1.96 * se)
    model_family = 'ols'
    effect_type = 'coefficient'

conclusion = 'significant_effect' if p < 0.05 else 'no_significant_effect'

result = {
    "effect_size": effect_size,
    "effect_type": effect_type,
    "standard_error": se_irr,
    "p_value": float(p),
    "ci_lower": ci_lower,
    "ci_upper": ci_upper,
    "conclusion": conclusion,
    "model_family": model_family,
    "predictor_used": "skin_tone (average of rater1 and rater2)",
    "covariates_included": ["height", "weight", "position_enc", "games"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "Rows with missing skin_tone (based on rater data), height, weight, or position"
}

print(json.dumps(result))