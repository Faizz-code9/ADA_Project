import pandas as pd
import numpy as np
import scipy.stats as stats
import statsmodels.api as sm
import json

# Load data
df = pd.read_csv('/kaggle/working/outputs/runs/allam-2-7b_soccer_skeptical_T0.7_r1/data.csv')

# Construct skin tone predictor (average of rater1 and rater2)
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2.0

# Handle missing values: listwise deletion for relevant columns
cols_needed = ['skin_tone', 'redCards', 'height', 'weight', 'position', 'leagueCountry', 'refNum', 'games']
df_clean = df.dropna(subset=cols_needed).copy()

# Create one-hot for position (keep top categories to avoid explosion)
pos_dummies = pd.get_dummies(df_clean['position'], prefix='pos', drop_first=True)
df_model = pd.concat([df_clean, pos_dummies], axis=1)

# One-hot for leagueCountry
league_dummies = pd.get_dummies(df_clean['leagueCountry'], prefix='league', drop_first=True)
df_model = pd.concat([df_model, league_dummies], axis=1)

# Define model variables
y = df_model['redCards'].astype(int)
X_cols = ['skin_tone', 'height', 'weight', 'games'] + list(pos_dummies.columns) + list(league_dummies.columns)
X = df_model[X_cols]

# Add constant
X = sm.add_constant(X)

# Fit negative binomial model (red cards are count data, likely overdispersed)
try:
    model = sm.GLM(y, X, family=sm.families.NegativeBinomial())
    result = model.fit()
    
    # Extract coefficient for skin_tone
    coef = result.params['skin_tone']
    se = result.bse['skin_tone']
    p_val = result.pvalues['skin_tone']
    
    # Compute IRR (Incident Rate Ratio) as the ratio effect
    irr = np.exp(coef)
    se_irr = irr * se  # Delta method approximation
    
    # CI for IRR
    ci_lower = np.exp(coef - 1.96 * se)
    ci_upper = np.exp(coef + 1.96 * se)
    
    effect_type = 'irr'
    model_family = 'negative_binomial'
    
except Exception as e:
    # Fallback to Poisson if negative binomial fails
    model = sm.GLM(y, X, family=sm.families.Poisson())
    result = model.fit()
    
    coef = result.params['skin_tone']
    se = result.bse['skin_tone']
    p_val = result.pvalues['skin_tone']
    
    irr = np.exp(coef)
    se_irr = irr * se
    
    ci_lower = np.exp(coef - 1.96 * se)
    ci_upper = np.exp(coef + 1.96 * se)
    
    effect_type = 'irr'
    model_family = 'poisson'

# Determine conclusion
conclusion = 'significant_effect' if p_val < 0.05 else 'no_significant_effect'

# Build output
output = {
    "effect_size": float(irr),
    "effect_type": effect_type,
    "standard_error": float(se_irr),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": model_family,
    "predictor_used": "skin_tone (average of rater1 and rater2, continuous 0-1)",
    "covariates_included": ['height', 'weight', 'games', 'position', 'leagueCountry'],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "Rows with missing skin tone, redCards, height, weight, position, or leagueCountry"
}

print(json.dumps(output))