import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

def run_analysis():
    file_path = '/kaggle/working/outputs/runs/gemini-2.5-flash-lite_disguise_neutral_T0.7_r1/data.csv'
    
    try:
        df = pd.read_csv(file_path)
    except FileNotFoundError:
        # Fallback for local testing if needed, though not required by prompt
        return

    # 1. Data Preparation
    # The hypothesis asks for the effect of continuous risk evaluator score (0-1).
    # The data dictionary provides 'risk_evaluator_alpha_score' and 'risk_evaluator_beta_score'.
    # Since the prompt mentions "risk evaluator scores" (plural) but asks for "the" ratio effect,
    # we will use the average of the alpha and beta scores as the composite continuous risk score.
    # Note: Both have 14.7% missingness.
    
    df['risk_score_composite'] = df[['risk_evaluator_alpha_score', 'risk_evaluator_beta_score']].mean(axis=1)
    
    # Target: loan_application_rejections (count/integer)
    # Since the target is a count (0, 1, 2) and we want a ratio effect, 
    # a Poisson regression is appropriate. The 'ratio effect' in Poisson is the IRR (Incidence Rate Ratio).
    
    # Select relevant columns for modeling
    # We exclude rows with NaN in the primary variables
    initial_len = len(df)
    df_clean = df.dropna(subset=['risk_score_composite', 'loan_application_rejections', 'credit_score_index', 'annual_income_bracket']).copy()
    
    # Exclusions applied description
    exclusions = f"Removed rows with missing risk scores or target variables. Initial: {initial_len}, Final: {len(df_clean)}"

    # 2. Statistical Modeling
    # Model: Poisson regression (to get IRR for the continuous predictor)
    # Formula: loan_application_rejections ~ risk_score_composite + credit_score_index + annual_income_bracket
    
    X = df_clean[['risk_score_composite', 'credit_score_index', 'annual_income_bracket']]
    X = sm.add_constant(X)
    y = df_clean['loan_application_rejections']
    
    model = sm.GLM(y, X, family=sm.families.Poisson()).fit()
    
    # 3. Extract Estimands
    # Coefficient for risk_score_composite
    coef = model.params['risk_score_composite']
    std_err = model.bse['risk_score_composite']
    p_val = model.pvalues['risk_score_composite']
    
    # IRR (Incidence Rate Ratio) is exp(coef)
    irr = np.exp(coef)
    ci_lower = np.exp(model.conf_int().loc['risk_score_composite', 0])
    ci_upper = np.exp(model.conf_int().loc['risk_score_composite', 1])
    
    # 4. Construct JSON output
    result = {
        "effect_size": float(irr),
        "effect_type": "irr",
        "standard_error": float(std_err), # Note: SE of coefficient is standard, but prompt asks for SE of effect. 
                                          # In Poisson, standard practice is to report SE of log-scale coef.
                                          # However, for consistency with 'irr' type, we provide SE of the log-scale.
        "p_value": float(p_val),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
        "model_family": "poisson",
        "predictor_used": "mean(risk_evaluator_alpha_score, risk_evaluator_beta_score)",
        "covariates_included": ["credit_score_index", "annual_income_bracket"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "none",
        "exclusions_applied": exclusions
    }
    
    print(json.dumps(result))

if __name__ == "__main__":
    run_analysis()