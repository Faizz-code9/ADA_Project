import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

def solve():
    file_path = '/kaggle/working/outputs/runs/gemini-2.5-flash-lite_disguise_neutral_T0.0_r1/data.csv'
    
    try:
        df = pd.read_csv(file_path)
    except FileNotFoundError:
        return

    # Data Cleaning
    # The hypothesis asks for the effect of continuous risk evaluator score on rejections.
    # We have two scores: alpha and beta. The prompt implies a single continuous score.
    # Given the missingness pattern (14.7% missing in both alpha and beta, matching identification_dossier_id),
    # we will use the average of alpha and beta as the 'risk_evaluator_score' to maximize data usage,
    # or simply pick one if they are highly correlated. Let's use the mean of alpha and beta.
    
    # Target: loan_application_rejections (count data: 0, 1, 2)
    # Predictor: risk_evaluator_alpha_score or beta_score. 
    # The prompt says "continuous risk evaluator score (0-1)". 
    # Let's construct a composite score.
    
    df['risk_score'] = df[['risk_evaluator_alpha_score', 'risk_evaluator_beta_score']].mean(axis=1)
    
    # Drop rows where risk_score is NaN (this handles the 14.7% missingness)
    initial_count = len(df)
    df_clean = df.dropna(subset=['risk_score', 'loan_application_rejections', 'credit_score_index', 'annual_income_bracket']).copy()
    exclusions = f"Dropped {initial_count - len(df_clean)} rows due to missing values in risk scores or covariates."

    # Since the outcome is a count (0, 1, 2), Poisson regression is appropriate.
    # However, the prompt asks for "ratio effect". In Poisson, the exponentiated coefficient 
    # is the Incidence Rate Ratio (IRR).
    
    X = df_clean[['risk_score', 'credit_score_index', 'annual_income_bracket']]
    X = sm.add_constant(X)
    y = df_clean['loan_application_rejections']
    
    model = sm.GLM(y, X, family=sm.families.Poisson())
    results = model.fit()
    
    # Primary Estimand: ratio effect (IRR) of the risk score
    # IRR = exp(coefficient)
    coeff = results.params['risk_score']
    irr = np.exp(coeff)
    std_err_coeff = results.bse['risk_score']
    # Standard error for IRR is approx exp(coeff) * std_err_coeff
    irr_se = irr * std_err_coeff
    
    p_val = results.pvalues['risk_score']
    ci_low_coeff = results.conf_int().loc['risk_score', 0]
    ci_high_coeff = results.conf_int().loc['risk_score', 1]
    ci_lower = np.exp(ci_low_coeff)
    ci_upper = np.exp(ci_high_coeff)
    
    output = {
        "effect_size": float(irr),
        "effect_type": "irr",
        "standard_error": float(irr_se),
        "p_value": float(p_val),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
        "model_family": "poisson",
        "predictor_used": "mean(risk_evaluator_alpha_score, risk_evaluator_beta_score)",
        "covariates_included": ["credit_score_index", "annual_income_bracket"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "none",
        "exclusions_applied": exclusions
    }
    
    print(json.dumps(output))

if __name__ == "__main__":
    solve()