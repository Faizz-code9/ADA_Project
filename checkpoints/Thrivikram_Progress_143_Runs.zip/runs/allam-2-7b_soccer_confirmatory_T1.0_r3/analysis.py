import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

# Load data
df = pd.read_csv('/kaggle/working/outputs/runs/allam-2-7b_soccer_confirmatory_T1.0_r3/data.csv')

# Construct skin tone predictor: average of rater1 and rater2
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2.0

# Exclude rows with missing skin tone (14.7% missing)
n_before = len(df)
df = df.dropna(subset=['skin_tone']).reset_index(drop=True)
excl_msg = f"Excluded {n_before - len(df)} rows with missing rater1/rater2 (skin tone)"

# Outcome: redCards (count: 0, 1, 2). Given rarity and counts, use Poisson.
# Model: Poisson regression for redCards ~ skin_tone + covariates
# Covariates: leagueCountry, position, height, weight, games
# Use listwise deletion for missing covariates

covariates = ['leagueCountry', 'position', 'height', 'weight', 'games']

# One-hot encode categorical columns for the model
df_model = df[['skin_tone', 'redCards'] + covariates].dropna().reset_index(drop=True)

# Build design matrix
X_vars = []
X_parts = [pd.DataFrame({'skin_tone': df_model['skin_tone']})]
covariates_included = ['skin_tone']

for col in ['leagueCountry', 'position']:
    dummies = pd.get_dummies(df_model[col], prefix=col, drop_first=True)
    X_parts.append(dummies)
    covariates_included += list(dummies.columns)

for col in ['height', 'weight', 'games']:
    X_parts.append(df_model[[col]].astype(float))
    covariates_included.append(col)

X = pd.concat(X_parts, axis=1).astype(float)
y = df_model['redCards'].astype(float)

X = sm.add_constant(X)

# Fit Poisson model
model = sm.GLM(y, X, family=sm.families.Poisson())
result = model.fit()

# Extract effect for skin_tone
skin_tone_col = 'skin_tone'
coef = result.params[skin_tone_col]
se = result.bse[skin_tone_col]
p_value = result.pvalues[skin_tone_col]

# IRR (Incident Rate Ratio) = exp(coef)
effect_size = np.exp(coef)
se_irm = se * np.exp(coef)

# CI
ci_lower = np.exp(coef - 1.96 * se)
ci_upper = np.exp(coef + 1.96 * se)

# Conclusion
conclusion = 'significant_effect' if p_value < 0.05 else 'no_significant_effect'

# Missing data strategy: listwise deletion
# Clustering strategy: none (independent observations assumed)

output = {
    "effect_size": float(effect_size),
    "effect_type": "irr",
    "standard_error": float(se_irm),
    "p_value": float(p_value),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "skin_tone (mean of rater1 and rater2)",
    "covariates_included": sorted(set([c for c in covariates_included if c != 'skin_tone'])),
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": excl_msg
}

print(json.dumps(output))