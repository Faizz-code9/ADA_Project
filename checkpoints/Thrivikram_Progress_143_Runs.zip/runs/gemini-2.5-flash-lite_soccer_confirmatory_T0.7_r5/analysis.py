import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

def run_analysis():
    # 1. Load data
    file_path = "/kaggle/working/outputs/runs/gemini-2.5-flash-lite_soccer_confirmatory_T0.7_r5/data.csv"
    df = pd.read_csv(file_path)

    # 2. Clean and Prepare Data
    # Skin tone is provided by rater1 and rater2. Average them.
    df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)
    
    # Target: redCards (count). Exposure: games.
    # Exclude rows where skin_tone, redCards, or games are missing.
    initial_count = len(df)
    df_clean = df.dropna(subset=['skin_tone', 'redCards', 'games']).copy()
    
    # Ensure games > 0 for log offset
    df_clean = df_clean[df_clean['games'] > 0]
    df_clean['log_games'] = np.log(df_clean['games'])
    
    # Red cards and yellow cards as integers
    df_clean['redCards'] = df_clean['redCards'].astype(int)
    df_clean['yellowCards'] = df_clean['yellowCards'].astype(int)
    
    exclusions = f"Removed {initial_count - len(df_clean)} rows due to missing skin tone, redCards, or zero/missing games."

    # 3. Fit Model
    # Using sm.GLM instead of smf.poisson to avoid the Patsy 'offset' syntax error.
    # sm.GLM handles the offset argument directly.
    
    # Prepare endog and exog
    y = df_clean['redCards']
    # Add constant for intercept
    X = sm.add_constant(df_clean[['skin_tone', 'yellowCards']])
    offset = df_clean['log_games']
    
    # Poisson model with log link
    model = sm.GLM(y, X, family=sm.families.Poisson(), offset=offset)
    results = model.fit()

    # 4. Compute Estimands
    # The coefficient for skin_tone is the log of the Incidence Rate Ratio (IRR)
    coef_skin = results.params['skin_tone']
    irr = np.exp(coef_skin)
    
    # Standard error for IRR using Delta Method: SE(exp(beta)) = exp(beta) * SE(beta)
    se_skin = results.bse['skin_tone']
    se_irr = irr * se_skin
    
    p_val = results.pvalues['skin_tone']
    
    # Confidence Intervals for IRR
    ci_log = results.conf_int().loc['skin_tone']
    ci_lower = np.exp(ci_log[0])
    ci_upper = np.exp(ci_log[1])

    conclusion = "significant_effect" if p_val < 0.05 else "no_significant_effect"

    # 5. Output JSON
    output = {
        "effect_size": float(irr),
        "effect_type": "irr",
        "standard_error": float(se_irr),
        "p_value": float(p_val),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": conclusion,
        "model_family": "poisson",
        "predictor_used": "mean(rater1, rater2)",
        "covariates_included": ["yellowCards", "games (offset)"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "none",
        "exclusions_applied": exclusions
    }

    print(json.dumps(output))

if __name__ == "__main__":
    run_analysis()