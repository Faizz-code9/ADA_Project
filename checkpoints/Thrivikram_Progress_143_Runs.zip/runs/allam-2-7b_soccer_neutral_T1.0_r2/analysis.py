import pandas as pd
import numpy as np
import statsmodels.api as sm
from scipy import stats
import json

# Hypothesis: Determine whether referee disciplinary decisions (red cards) show statistically significant bias based on skin tone rating.
# Primary estimand: ratio effect of continuous skin tone (0-1) on red cards.
# Since 'redCards' is a count (0, 1, 2) and low frequency, Poisson regression is appropriate.
# The "ratio effect" for a count outcome (like red cards) is the Incidence Rate Ratio (IRR).
# Therefore, effect_type should be 'irr'.

# Read data
file_path = "/kaggle/working/outputs/runs/allam-2-7b_soccer_neutral_T1.0_r2/data.csv"
df = pd.read_csv(file_path)

# Data Cleaning & Variable Construction
# 1. Create a composite skin tone variable
# The hypothesis asks about "skin tone rating". We have rater1 and rater2.
# We will average them to create a single continuous variable 'skin_tone'.
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2

# 2. Handle missing values
# Rows without skin tone data (photoID/rater missing) cannot be analyzed for this specific hypothesis.
initial_len = len(df)
df = df.dropna(subset=['skin_tone', 'redCards'])
excluded_rows = initial_len - len(df)

# Covariates
# We should control for variables that affect the probability of getting a red card but are not caused by skin tone.
# Good covariates:
# - 'games': Exposure (more games, more chances for a red card). We will use this as an offset or covariate.
#   In Poisson regression, 'games' is often an offset. However, the prompt asks for a standard model.
#   Let's include 'games' as a log-offset or just a covariate?
#   Standard practice for "rate" per game is offset(log(games)). But here we have individual player/season aggregates?
#   Looking at the data, 'games' varies. If we want the rate *per game*, we use offset.
#   If we want just the count, we don't. The hypothesis is about "bias based on skin tone".
#   Usually, bias is assessed conditional on the opportunity to receive a card.
#   Let's include 'games' as a covariate (log-transformed) or offset.
#   Given 'redCards' is the outcome, and we want to see if skin tone predicts red cards *given* the player's exposure.
#   Using `offset=np.log(df['games'].replace(0, 1))` might cause issues if games=0, but min games is 1.
#   Let's use log(games) as a covariate to be safe and interpretable as a coefficient, or offset.
#   Offset is more theoretically correct for rates. Let's use offset.
#   However, statsmodels Poisson can take an offset.
#   Let's stick to a simpler model first: Poisson with skin_tone as predictor, controlling for potential confounders like 'leagueCountry' (different leagues may have different refereeing styles/bias) and 'position' (defenders get more cards).
#   'position' has 12% missing. We can drop those or impute. Let's drop rows where position is missing to keep it simple, or just not include it if we want to keep the sample size.
#   Given the sample size is large (146k), dropping ~15k rows is fine, but let's check if we can just include league.
#   Let's include:
#   - skin_tone (main predictor)
#   - leagueCountry (categorical, control for league-level differences)
#   - games (offset for exposure)

# Exclude rows with missing position if we want to use it, but we decided to use league and offset.
# We need to handle 'games' offset.
# Ensure games > 0.
df = df[df['games'] > 0].copy()

# Create dummy variables for league
league_dummies = pd.get_dummies(df['leagueCountry'], prefix='league', drop_first=True)
df = pd.concat([df, league_dummies], axis=1)

# Prepare design matrix
X_cols = ['skin_tone'] + list(league_dummies.columns)
X = df[X_cols]
X = sm.add_constant(X)
y = df['redCards']
offset = np.log(df['games'])

# Fit Poisson Regression
model = sm.families.Poisson()
res = sm.GLM(y, X, family=model, offset=offset).fit()

# Extract results for 'skin_tone'
try:
    effect_size_log = res.params['skin_tone']
    se_log = res.bse['skin_tone']
    p_val = res.pvalues['skin_tone']
except KeyError:
    # Fallback if variable names changed
    effect_size_log = res.params.iloc[1]
    se_log = res.bse.iloc[1]
    p_val = res.pvalues.iloc[1]

# Convert log-rate to Incidence Rate Ratio (IRR)
effect_size = np.exp(effect_size_log)
se = se_log * effect_size  # Delta method approximation for SE of exp(beta)
# More precise CI:
ci_lower = np.exp(effect_size_log - 1.96 * se_log)
ci_upper = np.exp(effect_size_log + 1.96 * se_log)

# Conclusion
conclusion = 'significant_effect' if p_val < 0.05 else 'no_significant_effect'

# Construct JSON output
output = {
    "effect_size": float(effect_size),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "skin_tone (mean of rater1 and rater2)",
    "covariates_included": ["leagueCountry_dummies", "offset_log_games"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "rows with missing skin tone ratings or games <= 0"
}

print(json.dumps(output))