import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

def solve():
    file_path = '/kaggle/working/outputs/runs/gemini-2.5-flash-lite_placebo_neutral_T0.0_r1/data.csv'
    df = pd.read_csv(file_path)

    # 1. Data Cleaning and Variable Construction
    # Primary predictor: average skin tone from rater1 and rater2
    # Outcome: redCards (count data)
    # We use Poisson regression for count data (red cards)
    
    # Drop rows where skin tone or redCards is missing
    # Note: redCards has 0 missing, but rater1/rater2 have 21,407 missing
    df_clean = df.dropna(subset=['rater1', 'rater2', 'redCards']).copy()
    
    # Construct continuous skin tone predictor
    df_clean['skin_tone_avg'] = (df_clean['rater1'] + df_clean['rater2']) / 2
    
    # Exclusions: rows where redCards is not a non-negative integer (though data says it is)
    # We also exclude rows where skin_tone_avg might be invalid, though it's 0-1
    df_clean = df_clean[df_clean['redCards'] >= 0]
    
    # Covariates: games (to account for exposure/opportunity), yellowCards (to control for general aggression)
    # We use an offset for 'games' to model the rate of red cards per game
    # However, the prompt asks for the "ratio effect of continuous skin tone on red cards".
    # In a Poisson model, the coefficient of a predictor is the log of the Incidence Rate Ratio (IRR).
    
    # Prepare for Poisson regression
    # We use log(games) as an offset to model the rate of red cards per game played
    # To avoid log(0), we ensure games >= 1 (data says min is 1)
    df_clean['log_games'] = np.log(df_clean['games'].clip(lower=1))
    
    # Model: redCards ~ skin_tone_avg + yellowCards + height + weight
    # We use Poisson regression.
    model = smf.poisson('redCards ~ skin_tone_avg + yellowCards + height + weight', 
                        offset=df_clean['log_games'], 
                        data=df_clean).fit(disp=False)

    # 2. Extract Estimands
    # The coefficient for skin_tone_avg is the log(IRR)
    log_irr = model.params['skin_tone_avg']
    irr = np.exp(log_irr)
    std_err_log = model.bse['skin_tone_avg']
    std_err_irr = irr * std_err_log # Delta method approximation for IRR SE
    p_val = model.pvalues['skin_tone_avg']
    
    # CI for IRR
    ci_log_lower = model.conf_int().loc['skin_tone_avg', 0]
    ci_log_upper = model.conf_int().loc['skin_tone_avg', 1]
    ci_lower = np.exp(ci_log_lower)
    ci_upper = np.exp(ci_log_upper)

    conclusion = 'significant_effect' if p_val < 0.05 else 'no_significant_effect'

    # 3. Prepare JSON output
    result = {
        "effect_size": float(irr),
        "effect_type": "irr",
        "standard_error": float(std_err_irr),
        "p_value": float(p_val),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": conclusion,
        "model_family": "poisson",
        "predictor_used": "average of rater1 and rater2 (skin_tone_avg)",
        "covariates_included": ["yellowCards", "height", "weight", "games (offset)"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "none",
        "exclusions_applied": f"Removed {len(df) - len(df_clean)} rows due to missing skin tone ratings"
    }

    print(json.dumps(result))

if __name__ == "__main__":
    solve()