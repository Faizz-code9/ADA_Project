import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

def solve():
    file_path = '/kaggle/working/outputs/runs/gemini-2.5-flash-lite_soccer_skeptical_T0.0_r2/data.csv'
    df = pd.read_csv(file_path)

    # Data Cleaning
    # Primary estimand: ratio effect of continuous skin tone (0-1) on red cards.
    # Skin tone is provided by rater1 and rater2. We use the mean of the two raters.
    # redCards is the outcome.
    
    # Drop rows where outcome or predictor is missing
    initial_len = len(df)
    df = df.dropna(subset=['redCards', 'rater1', 'rater2'])
    
    # Construct continuous skin tone predictor
    df['skin_tone_avg'] = df[['rater1', 'rater2']].mean(axis=1)
    
    # Since redCards is a count (0, 1, 2), and we want a "ratio effect" (rate ratio),
    # a Poisson regression with a log link is appropriate.
    # The coefficient in a Poisson model is the log of the Incidence Rate Ratio (IRR).
    # To get the IRR, we exponentiate the coefficient.
    
    # We include 'games' as an offset to model the rate of red cards per game.
    # However, the prompt asks for the effect of skin tone on red cards. 
    # In disciplinary data, 'games' is the exposure.
    df['log_games'] = np.log(df['games'].replace(0, 1)) # Ensure no log(0)
    
    # Model: Poisson regression
    # Formula: redCards ~ skin_tone_avg + offset(log_games)
    # We'll also control for leagueCountry to account for different disciplinary cultures.
    model = smf.poisson('redCards ~ skin_tone_avg + C(leagueCountry)', 
                        offset=np.log(df['games'].clip(lower=1)), 
                        data=df).fit(disp=False)
    
    # Extract results for skin_tone_avg
    # The coefficient is the log(IRR)
    coef = model.params['skin_tone_avg']
    se = model.bse['skin_tone_avg']
    p_val = model.pvalues['skin_tone_avg']
    
    # Primary estimand: ratio effect (IRR)
    irr = np.exp(coef)
    ci_lower = np.exp(model.conf_int().loc['skin_tone_avg', 0])
    ci_upper = np.exp(model.conf_int().loc['skin_tone_avg', 1])
    
    conclusion = 'significant_effect' if p_val < 0.05 else 'no_significant_effect'
    
    output = {
        "effect_size": float(irr),
        "effect_type": "irr",
        "standard_error": float(se), # Note: SE of log(IRR) is standard, but prompt asks for SE. 
                                     # Usually, for IRR, SE is reported for the log-scale.
                                     # We provide the SE of the coefficient as is standard in stats output.
        "p_value": float(p_val),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": conclusion,
        "model_family": "poisson",
        "predictor_used": "mean(rater1, rater2)",
        "covariates_included": ["leagueCountry", "games (offset)"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "none",
        "exclusions_applied": f"Removed rows with missing rater or redCard values. Original: {initial_len}, Remaining: {len(df)}"
    }
    
    print(json.dumps(output))

if __name__ == "__main__":
    solve()