import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

def analyze():
    file_path = '/kaggle/working/outputs/runs/gemini-2.5-flash-lite_synthetic_skeptical_T0.7_r2/data.csv'
    df = pd.read_csv(file_path)
    
    # Initial count for exclusions tracking
    initial_count = len(df)
    
    # Data Cleaning
    # skin_tone has 8% missing values. We use listwise deletion for the primary analysis.
    df_clean = df.dropna(subset=['skin_tone', 'redCards']).copy()
    exclusions = f"Removed {initial_count - len(df_clean)} rows due to missing skin_tone"
    
    # The outcome 'redCards' is a count. 
    # However, the hypothesis is about the effect of skin_tone on redCards.
    # Given redCards is a non-negative integer (count data) and we want a 'ratio effect',
    # Poisson regression is the standard for count data, where the coefficient 
    # exponentiated gives the Incident Rate Ratio (IRR).
    
    # Model: Poisson Regression (GLM)
    # We control for yellowCards and games to ensure the effect is specific to skin_tone.
    # We also use refereeID as a random effect or cluster-robust standard errors if needed,
    # but for a simple Poisson model with Poisson error structure:
    try:
        # Using Poisson GLM with a log link
        # Formula: redCards ~ skin_tone + yellowCards + games
        model = smf.glm(formula="redCards ~ skin_tone + yellowCards + games", 
                        data=df_clean, 
                        family=sm.families.Poisson()).fit()
        
        # Primary Estimand: Ratio effect (IRR) of continuous skin_tone
        # IRR = exp(beta)
        beta_skin = model.params['skin_tone']
        se_skin = model.bse['skin_tone']
        p_val = model.pvalues['skin_tone']
        
        irr = np.exp(beta_skin)
        ci_lower = np.exp(model.conf_int().loc['skin_tone'][0])
        ci_upper = np.exp(model.conf_int().loc['skin_tone'][1])
        
        # Standard error for the IRR is not the same as SE of beta.
        # Using Delta Method: SE(exp(b)) approx exp(b) * SE(b)
        se_irr = irr * se_skin
        
        conclusion = 'significant_effect' if p_val < 0.05 else 'no_significant_effect'
        
        result = {
            "effect_size": float(irr),
            "effect_type": "irr",
            "standard_error": float(se_irr),
            "p_value": float(p_val),
            "ci_lower": float(ci_lower),
            "ci_upper": float(ci_upper),
            "conclusion": conclusion,
            "model_family": "poisson",
            "predictor_used": "skin_tone",
            "covariates_included": ["yellowCards", "games"],
            "missing_data_strategy": "listwise_deletion",
            "clustering_strategy": "none",
            "exclusions_applied": exclusions
        }
        
        print(json.dumps(result))

    except Exception as e:
        # Fallback to OLS if Poisson fails (though unlikely with this data)
        model = smf.ols(formula="redCards ~ skin_tone + yellowCards + games", data=df_clean).fit()
        beta = model.params['skin_tone']
        p_val = model.pvalues['skin_tone']
        result = {
            "effect_size": float(beta),
            "effect_type": "coefficient",
            "standard_error": float(model.bse['skin_tone']),
            "p_value": float(p_val),
            "ci_lower": float(model.conf_int().loc['skin_tone'][0]),
            "ci_upper": float(model.conf_int().loc['skin_tone'][1]),
            "conclusion": 'significant_effect' if p_val < 0.05 else 'no_significant_effect',
            "model_family": "ols",
            "predictor_used": "skin_tone",
            "covariates_included": ["yellowCards", "games"],
            "missing_data_strategy": "listwise_deletion",
            "clustering_strategy": "none",
            "exclusions_applied": exclusions
        }
        print(json.dumps(result))

if __name__ == "__main__":
    analyze()