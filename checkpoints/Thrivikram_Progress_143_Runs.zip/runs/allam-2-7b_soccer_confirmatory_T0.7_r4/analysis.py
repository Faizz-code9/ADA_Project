import pandas as pd
import numpy as np
import json
from scipy import stats
import statsmodels.api as sm

# 1. Load data
file_path = "/kaggle/working/outputs/runs/allam-2-7b_soccer_confirmatory_T0.7_r4/data.csv"
df = pd.read_csv(file_path)

# 2. Clean and prepare data
# Construct continuous skin tone variable (average of rater1 and rater2)
# Drop rows where rater1 or rater2 is missing (listwise deletion for this variable)
df = df.dropna(subset=['rater1', 'rater2'])
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2.0

# Outcome: redCards (count data, low frequency)
# Since redCards has max value 2 and mean ~0.012, Poisson or Negative Binomial is appropriate.
# We will use Poisson regression as a baseline, but given the low counts, it's a standard choice.
# Alternatively, logistic regression could be used if we treat it as binary (0 vs >0), 
# but the prompt asks for "ratio effect" which implies a count model (IRR).
# Let's use Poisson regression for the count of red cards.

# Covariates to control for:
# - leagueCountry (categorical)
# - position (categorical, but has missing values)
# - height, weight (continuous)
# - games (exposure/effort)

# For position, we'll drop rows with missing position to keep the model clean
df = df.dropna(subset=['position', 'height', 'weight'])

# Create dummy variables for leagueCountry
league_dummies = pd.get_dummies(df['leagueCountry'], prefix='league', drop_first=True, dtype=float)
df = pd.concat([df, league_dummies], axis=1)

# Create dummy variables for position
pos_dummies = pd.get_dummies(df['position'], prefix='pos', drop_first=True, dtype=float)
df = pd.concat([df, pos_dummies], axis=1)

# Define variables
y = df['redCards']
X_vars = ['skin_tone', 'height', 'weight', 'games'] + \
         [c for c in league_dummies.columns] + \
         [c for c in pos_dummies.columns]

X = df[X_vars].copy()
X = sm.add_constant(X)

# 3. Fit model
# Using Poisson GLM
model = sm.GLM(y, X, family=sm.families.Poisson())
results = model.fit()

# 4. Compute primary estimand
# The primary estimand is the effect of skin_tone.
# In a Poisson model, exp(coefficient) is the Incidence Rate Ratio (IRR).
coef = results.params['skin_tone']
se = results.bse['skin_tone']
p_val = results.pvalues['skin_tone']
ci_lower_raw = results.conf_int().loc['skin_tone', 0]
ci_upper_raw = results.conf_int().loc['skin_tone', 1]

# Transform to IRR scale
irr = np.exp(coef)
se_irr = se * np.exp(coef)  # Delta method approximation for SE of IRR
ci_lower = np.exp(ci_lower_raw)
ci_upper = np.exp(ci_upper_raw)

# Conclusion
conclusion = 'significant_effect' if p_val < 0.05 else 'no_significant_effect'

# Covariates included (excluding constant)
covariates_included = [c for c in X_vars]

# 5. Output JSON
output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(se_irr),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "skin_tone (mean of rater1 and rater2)",
    "covariates_included": covariates_included,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "Rows with missing rater1, rater2, position, height, or weight were removed."
}

print(json.dumps(output))