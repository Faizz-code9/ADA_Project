import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

def main():
    file_path = '/kaggle/working/outputs/runs/gemini-2.5-flash-lite_synthetic_confirmatory_T0.0_r2/data.csv'
    df = pd.read_csv(file_path)

    # Data Cleaning
    # skin_tone has 8% missing values. Using listwise deletion as per standard practice for small missingness.
    initial_len = len(df)
    df = df.dropna(subset=['skin_tone', 'redCards'])
    exclusions = f"Removed {initial_len - len(df)} rows due to missing skin_tone"

    # The outcome 'redCards' is a count variable (0, 1, 2, 3). 
    # The hypothesis asks for the ratio effect of continuous skin_tone.
    # A Poisson regression is appropriate for count data.
    # The 'ratio effect' in Poisson is the Incident Rate Ratio (IRR), which is exp(coefficient).
    
    # Model: redCards ~ skin_tone + position + height + weight + games + yellowCards
    # We include yellowCards and games as covariates to control for player aggression/exposure.
    model = smf.poisson('redCards ~ skin_tone + position + height + weight + games + yellowCards', data=df)
    results = model.fit(disp=False)

    # Extracting primary estimand (skin_tone)
    coef = results.params['skin_tone']
    se = results.bse['skin_tone']
    p_val = results.pvalues['skin_tone']
    
    # IRR = exp(coefficient)
    irr = np.exp(coef)
    ci_lower = np.exp(results.conf_int().loc['skin_tone'][0])
    ci_upper = np.exp(results.conf_int().loc['skin_tone'][1])

    output = {
        "effect_size": float(irr),
        "effect_type": "irr",
        "standard_error": float(se), # SE of the coefficient is standard, but for IRR we report the coefficient SE or transform. 
                                     # However, standard practice in these tasks is the SE of the log-scale parameter.
        "p_value": float(p_val),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
        "model_family": "poisson",
        "predictor_used": "skin_tone",
        "covariates_included": ["position", "height", "weight", "games", "yellowCards"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "none",
        "exclusions_applied": exclusions
    }

    print(json.dumps(output))

if __name__ == "__main__":
    main()