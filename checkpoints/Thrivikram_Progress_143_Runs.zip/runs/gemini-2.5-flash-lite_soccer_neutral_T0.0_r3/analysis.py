import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

def solve():
    file_path = '/kaggle/working/outputs/runs/gemini-2.5-flash-lite_soccer_neutral_T0.0_r3/data.csv'
    df = pd.read_csv(file_path)

    # Data Cleaning
    # Primary predictor: average skin tone from rater1 and rater2
    # Outcome: redCards (count data)
    # We need to handle missing values in rater1, rater2, and redCards
    # The dictionary says redCards has 0 missing, but rater1/2 have 14.7% missing.
    # Since rater1/2 are tied to photoID, missingness is likely due to missing photos.
    
    df = df.dropna(subset=['rater1', 'rater2', 'redCards'])
    
    # Construct continuous skin tone predictor
    df['skin_tone_avg'] = df[['rater1', 'rater2']].mean(axis=1)
    
    # Since redCards is a count variable (0, 1, 2), Poisson regression is appropriate.
    # However, the hypothesis asks for the "ratio effect" of continuous skin tone.
    # In a Poisson model, the exponentiated coefficient is the Incidence Rate Ratio (IRR).
    
    # Covariates: games (to account for exposure/opportunity), yellowCards (to control for aggression)
    # We use 'games' as an offset or just a covariate. Given the structure, 
    # redCards per game is the rate. We'll use Poisson with games as an offset (log(games)).
    # But 'games' can be 0? Dictionary says min 1.
    
    df['log_games'] = np.log(df['games'].replace(0, 1))
    
    # Fit Poisson model
    # Formula: redCards ~ skin_tone_avg + yellowCards + games
    # We use Poisson to model the count.
    model = smf.poisson('redCards ~ skin_tone_avg + yellowCards', data=df, offset=np.log(df['games']))
    result = model.fit(disp=False)
    
    # Extracting the effect of skin_tone_avg
    coef = result.params['skin_tone_avg']
    se = result.bse['skin_tone_avg']
    p_val = result.pvalues['skin_tone_avg']
    
    # Primary estimand: ratio effect (IRR)
    irr = np.exp(coef)
    ci_lower = np.exp(result.conf_int().loc['skin_tone_avg'][0])
    ci_upper = np.exp(result.conf_int().loc['skin_tone_avg'][1])
    
    conclusion = 'significant_effect' if p_val < 0.05 else 'no_significant_effect'
    
    output = {
        "effect_size": float(irr),
        "effect_type": "irr",
        "standard_error": float(se), # Note: SE of log-scale coefficient is standard, but we provide it for the model
        "p_value": float(p_val),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": conclusion,
        "model_family": "poisson",
        "predictor_used": "mean(rater1, rater2)",
        "covariates_included": ["yellowCards", "games (offset)"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "none",
        "exclusions_applied": "Removed rows with missing rater scores or redCards"
    }
    
    print(json.dumps(output))

if __name__ == "__main__":
    solve()