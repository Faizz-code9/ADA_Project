import json
import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf

# Load data
df = pd.read_csv("/kaggle/working/outputs/runs/allam-2-7b_synthetic_confirmatory_T0.7_r2/data.csv")

# Clean data: remove rows with missing skin_tone
n_before = len(df)
df = df.dropna(subset=["skin_tone"]).reset_index(drop=True)
exclusions = f"Removed {n_before - len(df)} rows with missing skin_tone"

# Prepare variables
# Outcome: redCards, Predictor: skin_tone
# Covariates: position, height, weight, leagueCountry
# 'games' is exposure, use as offset in Poisson model
# 'yellowCards' is excluded to avoid mediation issues

# Fit GEE Poisson model with clustering by refereeID
# Using C() notation for categorical variables
formula = "redCards ~ skin_tone + C(position) + C(leagueCountry) + height + weight + offset(log(games))"

try:
    model = smf.gee(formula, data=df, groups="refereeID", family=sm.families.Poisson(), corr="exchangeable")
    result = model.fit()
    
    # Extract results for skin_tone
    log_effect = result.params['skin_tone']
    se_log = result.bse['skin_tone']
    p_value = result.pvalues['skin_tone']
    
    # Confidence Interval on log scale
    ci_log = result.conf_int().loc['skin_tone']
    ci_log_lower = ci_log[0]
    ci_log_upper = ci_log[1]
    
    # Transform to IRR (Incidence Rate Ratio) scale
    irr = np.exp(log_effect)
    se_irr = irr * se_log  # Delta method approximation
    ci_lower_irr = np.exp(ci_log_lower)
    ci_upper_irr = np.exp(ci_log_upper)
    
    conclusion = "significant_effect" if p_value < 0.05 else "no_significant_effect"
    
    output = {
        "effect_size": float(irr),
        "effect_type": "irr",
        "standard_error": float(se_irr),
        "p_value": float(p_value),
        "ci_lower": float(ci_lower_irr),
        "ci_upper": float(ci_upper_irr),
        "conclusion": conclusion,
        "model_family": "gee",
        "predictor_used": "skin_tone (continuous 0-1)",
        "covariates_included": ["position", "leagueCountry", "height", "weight"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "gee",
        "exclusions_applied": exclusions
    }
    
except Exception as e:
    # Fallback to OLS on log(1+redCards) if GEE fails
    df['log_redCards'] = np.log1p(df['redCards'])
    formula_ols = "log_redCards ~ skin_tone + C(position) + C(leagueCountry) + height + weight"
    model_ols = smf.ols(formula_ols, data=df).fit()
    
    log_effect = model_ols.params['skin_tone']
    se_log = model_ols.bse['skin_tone']
    p_value = model_ols.pvalues['skin_tone']
    
    ci_log = model_ols.conf_int().loc['skin_tone']
    ci_log_lower = ci_log[0]
    ci_log_upper = ci_log[1]
    
    irr = np.exp(log_effect)
    se_irr = irr * se_log
    ci_lower_irr = np.exp(ci_log_lower)
    ci_upper_irr = np.exp(ci_log_upper)
    
    conclusion = "significant_effect" if p_value < 0.05 else "no_significant_effect"
    
    output = {
        "effect_size": float(irr),
        "effect_type": "irr",
        "standard_error": float(se_irr),
        "p_value": float(p_value),
        "ci_lower": float(ci_lower_irr),
        "ci_upper": float(ci_upper_irr),
        "conclusion": conclusion,
        "model_family": "ols",
        "predictor_used": "skin_tone (continuous 0-1)",
        "covariates_included": ["position", "leagueCountry", "height", "weight"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "none",
        "exclusions_applied": exclusions
    }

print(json.dumps(output))