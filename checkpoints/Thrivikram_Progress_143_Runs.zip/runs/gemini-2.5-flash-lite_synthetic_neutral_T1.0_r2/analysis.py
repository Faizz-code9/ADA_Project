import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

def solve():
    file_path = '/kaggle/working/outputs/runs/gemini-2.5-flash-lite_synthetic_neutral_T1.0_r2/data.csv'
    df = pd.read_csv(file_path)

    # Data Cleaning
    # skin_tone has 8% missing values
    initial_count = len(df)
    df = df.dropna(subset=['skin_tone', 'redCards', 'playerID', 'refereeID'])
    exclusions = f"Removed {initial_count - len(df)} rows with missing values"
    
    # The primary estimand is the ratio effect of continuous skin_tone on redCards.
    # redCards is a count variable (0, 1, 2, 3). 
    # Poisson regression is appropriate for count data to estimate Incidence Rate Ratios (IRR).
    
    # Model: Poisson regression to find the rate ratio (IRR)
    # We include refereeID and playerID as potential sources of clustering/random effects
    # However, to stay robust and simple within constraints, we use Poisson with robust SEs or GEE.
    # Given the structure, a Poisson model with robust standard errors handles overdispersion/heteroscedasticity.
    
    model = smf.poisson('redCards ~ skin_tone', data=df).fit(disp=False)
    
    # The coefficient in Poisson is log(IRR)
    log_irr = model.params['skin_tone']
    irr = np.exp(log_irr)
    se_log_irr = model.bse['skin_tone']
    # SE for IRR: exp(log_irr + se_log_irr) - exp(log_irr - se_log_irr) is an approximation, 
    # but standard practice is reporting the IRR and its CI via exponentiating the log-scale CI.
    
    p_value = model.pvalues['skin_tone']
    conf_int_log = model.conf_int().loc['skin_tone']
    ci_lower = np.exp(conf_int_log[0])
    ci_upper = np.exp(conf_int_log[1])
    
    # Standard Error of the IRR itself (Delta method approximation)
    # SE(exp(theta)) approx exp(theta) * SE(theta)
    se_irr = irr * se_log_irr

    output = {
        "effect_size": float(irr),
        "effect_type": "irr",
        "standard_error": float(se_irr),
        "p_value": float(p_value),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": "significant_effect" if p_value < 0.05 else "no_significant_effect",
        "model_family": "poisson",
        "predictor_used": "skin_tone (continuous 0-1)",
        "covariates_included": [],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "none",
        "exclusions_applied": exclusions
    }

    print(json.dumps(output))

if __name__ == "__main__":
    solve()