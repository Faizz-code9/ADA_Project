import pandas as pd
import numpy as np
import json
import statsmodels.api as sm
from statsmodels.stats.conrobust import cov_adjust

# Load data
df = pd.read_csv('/kaggle/working/outputs/runs/allam-2-7b_placebo_confirmatory_T1.0_r2/data.csv')

# Create continuous skin tone predictor (0-1) from rater1 and rater2
df['skin_tone'] = (df['rater1'].fillna(df['rater2']) + df['rater2'].fillna(df['rater1'])) / 2

# Handle missing skin tone: keep only rows where at least one rater is available
df = df.dropna(subset=['skin_tone'])

# Model: negative binomial regression for redCards ~ skin_tone + covariates
# Covariates: leagueCountry, position, club, refNum (for clustering)
# Use refNum as group for robust/clustered SE

# Prepare model
X = pd.get_dummies(df[['leagueCountry', 'position', 'club']], drop_first=True, dtype=float)
X['skin_tone'] = df['skin_tone'].values
X = sm.add_constant(X)
y = df['redCards'].values

# Fit negative binomial
model = sm.NegativeBinomial(y, X, disp=np.nan)
results = model.fit(method='newton')

# Compute clustered standard errors by referee
cluster_groups = df['refNum'].values
clusters = pd.Series(cluster_groups, index=X.index).values
cov_rb = cov_adjust(results.cov_params(), X, clusters, use_correction=True)
cov_rb = np.asarray(cov_rb)

# Extract primary coefficient
skin_tone_idx = list(X.columns).index('skin_tone')
coef = results.params[skin_tone_idx]
se = np.sqrt(cov_rb[skin_tone_idx, skin_tone_idx])
t_stat = coef / se
p_value = 2 * (1 - sm.stats.ttools.studentt.pdf(t_stat, len(clusters) - 1))
ci_lower = coef - 1.96 * se
ci_upper = coef + 1.96 * se

# For count model, exponentiate to get IRR (incidence rate ratio)
irr = np.exp(coef)
irr_se = se * np.exp(coef)
irr_ci_lower = np.exp(ci_lower)
irr_ci_upper = np.exp(ci_upper)

# Transform p-value for the log-coefficient (which corresponds to the IRR test)
# The p-value for testing H0: log_ODDS=0 (i.e., IRR=1) is the same as testing the coefficient = 0
p_value_irr = p_value

output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(irr_se),
    "p_value": float(p_value_irr),
    "ci_lower": float(irr_ci_lower),
    "ci_upper": float(irr_ci_upper),
    "conclusion": "significant_effect" if p_value_irr < 0.05 else "no_significant_effect",
    "model_family": "negative_binomial",
    "predictor_used": "skin_tone (continuous 0-1, mean of rater1 and rater2)",
    "covariates_included": ["leagueCountry", "position", "club"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "clustered_se",
    "exclusions_applied": "Rows with no rater data (missing skin tone)"
}

print(json.dumps(output, indent=2))