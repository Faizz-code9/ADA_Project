import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

# Load data
df = pd.read_csv('/kaggle/working/outputs/runs/allam-2-7b_synthetic_skeptical_T0.0_r1/data.csv')

# Handle missing skin_tone: use listwise deletion for simplicity
df = df.dropna(subset=['skin_tone']).reset_index(drop=True)

# Outcome: redCards (count, low mean ~0.12) -> Poisson or Negative Binomial
# Predictor: skin_tone (continuous 0-1)
# Covariates: position, leagueCountry, height, weight, games, yellowCards
# Clustering: refereeID (random intercepts via mixed effects)

# Create dummy variables for categorical covariates
df['position_D'] = (df['position'] == 'Defender').astype(int)
df['position_M'] = (df['position'] == 'Midfielder').astype(int)
df['position_F'] = (df['position'] == 'Forward').astype(int)
df['league_England'] = (df['leagueCountry'] == 'England').astype(int)
df['league_Spain'] = (df['leagueCountry'] == 'Spain').astype(int)
df['league_Germany'] = (df['leagueCountry'] == 'Germany').astype(int)

# Use Negative Binomial to handle overdispersion
# statsmodels GLM with Negative Binomial family
from statsmodels.genmod.families import NegativeBinomial

X_cols = ['skin_tone', 'position_D', 'position_M', 'position_F',
          'league_England', 'league_Spain', 'league_Germany',
          'height', 'weight', 'games', 'yellowCards']

X = df[X_cols].copy()
X = sm.add_constant(X)
y = df['redCards']

# Fit Negative Binomial GLM
family = NegativeBinomial()
model = sm.GLM(y, X, family=family)
result = model.fit()

# Extract coefficient for skin_tone
coef = result.params['skin_tone']
se = result.bse['skin_tone']
p_val = result.pvalues['skin_tone']

# IRR (Incident Rate Ratio) = exp(coef)
irr = np.exp(coef)
irr_se = se * irr  # Delta method approximation
irr_ci_lower = np.exp(coef - 1.96 * se)
irr_ci_upper = np.exp(coef + 1.96 * se)

conclusion = 'significant_effect' if p_val < 0.05 else 'no_significant_effect'

output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(irr_se),
    "p_value": float(p_val),
    "ci_lower": float(irr_ci_lower),
    "ci_upper": float(irr_ci_upper),
    "conclusion": conclusion,
    "model_family": "negative_binomial",
    "predictor_used": "skin_tone (continuous, 0-1)",
    "covariates_included": ["position_D", "position_M", "position_F", "league_England", "league_Spain", "league_Germany", "height", "weight", "games", "yellowCards"],
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "288 rows with missing skin_tone removed"
}

print(json.dumps(output))