import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

def solve():
    file_path = '/kaggle/working/outputs/runs/gemini-2.5-flash-lite_soccer_skeptical_T0.0_r3/data.csv'
    df = pd.read_csv(file_path)

    # Data Cleaning
    # Primary estimand: ratio effect of continuous skin tone (0-1) on red cards.
    # Skin tone is provided by rater1 and rater2. We use the mean of the two raters.
    # redCards is the outcome.
    
    # Drop rows where outcome or predictors are missing
    initial_len = len(df)
    df = df.dropna(subset=['redCards', 'rater1', 'rater2'])
    
    # Construct continuous skin tone predictor
    df['skin_tone_avg'] = df[['rater1', 'rater2']].mean(axis=1)
    
    # Since redCards is a count (0, 1, 2), and we want a "ratio effect" (rate ratio),
    # a Poisson regression with a log link is appropriate.
    # The coefficient in a Poisson model is the log of the Incidence Rate Ratio (IRR).
    # To get the IRR, we exponentiate the coefficient.
    
    # We include 'games' as an offset (log(games)) to model the rate of red cards per game.
    # However, the prompt asks for the effect of skin tone on red cards. 
    # Given the data structure, redCards is likely the count per observation (which represents a set of games).
    # Let's use Poisson regression.
    
    # Exclude rows where games <= 0 to avoid log(0)
    df = df[df['games'] > 0]
    df['log_games'] = np.log(df['games'])
    
    # Model: redCards ~ skin_tone_avg + offset(log_games)
    # We'll also control for leagueCountry to account for different disciplinary cultures.
    model = smf.poisson('redCards ~ skin_tone_avg + C(leagueCountry)', offset=df['log_games'], data=df)
    results = model.fit(disp=False)
    
    # Extract coefficient for skin_tone_avg
    coef = results.params['skin_tone_avg']
    se = results.bse['skin_tone_avg']
    p_val = results.pvalues['skin_tone_avg']
    
    # Primary estimand: ratio effect (IRR)
    irr = np.exp(coef)
    ci_lower = np.exp(results.conf_int().loc['skin_tone_avg', 0])
    ci_upper = np.exp(results.conf_int().loc['skin_tone_avg', 1])
    
    conclusion = 'significant_effect' if p_val < 0.05 else 'no_significant_effect'
    
    output = {
        "effect_size": float(irr),
        "effect_type": "irr",
        "standard_error": float(se), # Note: SE of log(IRR) is returned, but standard practice for IRR is often the SE of the coefficient or transformed. 
                                     # However, the prompt asks for SE of the estimand. 
                                     # For IRR, SE is usually calculated via Delta Method.
                                     # Let's provide the SE of the coefficient for mathematical rigor or the Delta Method SE.
                                     # Delta method: SE(exp(b)) approx exp(b) * SE(b)
        "p_value": float(p_val),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": conclusion,
        "model_family": "poisson",
        "predictor_used": "mean(rater1, rater2)",
        "covariates_included": ["leagueCountry", "games (offset)"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "none",
        "exclusions_applied": f"Removed rows with missing rater/redcard data or games=0. Total removed: {initial_len - len(df)}"
    }
    
    # Correcting SE for the IRR using Delta Method
    output["standard_error"] = float(irr * se)

    print(json.dumps(output))

if __name__ == "__main__":
    solve()