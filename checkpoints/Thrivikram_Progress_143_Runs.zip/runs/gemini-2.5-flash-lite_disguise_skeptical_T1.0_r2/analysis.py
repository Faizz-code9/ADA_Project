import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

def solve():
    file_path = '/kaggle/working/outputs/runs/gemini-2.5-flash-lite_disguise_skeptical_T1.0_r2/data.csv'
    df = pd.read_csv(file_path)

    # The hypothesis concerns risk evaluation scores (alpha or beta) 
    # and their effect on loan_application_rejections.
    # The primary estimand is the ratio effect of continuous risk evaluator score.
    # Since 'loan_application_rejections' is a count (0, 1, 2), Poisson regression is appropriate.
    # 'ratio effect' for Poisson implies the Incidence Rate Ratio (IRR).
    
    # Data Cleaning: 
    # risk_evaluator_alpha_score and beta_score have 14.7% missingness (aligned with identification_dossier_id).
    # We'll use risk_evaluator_alpha_score as the main predictor.
    # We must exclude rows where predictor or outcome is missing.
    
    initial_len = len(df)
    df_clean = df.dropna(subset=['risk_evaluator_alpha_score', 'loan_application_rejections', 'credit_score_index']).copy()
    
    # Controlling for credit_score_index to isolate the effect of the risk score.
    # Using Poisson model to estimate the rate of rejections.
    
    model = smf.poisson('loan_application_rejections ~ risk_evaluator_alpha_score + credit_score_index', data=df_clean)
    results = model.fit(disp=False)
    
    # Extract coefficients
    # coefficient in Poisson is log(IRR)
    coeff = results.params['risk_evaluator_alpha_score']
    std_err = results.bse['risk_evaluator_alpha_score']
    p_val = results.pvalues['risk_evaluator_alpha_score']
    
    # Primary estimand: ratio effect (IRR)
    irr = np.exp(coeff)
    ci_lower = np.exp(results.conf_int().loc['risk_evaluator_alpha_score', 0])
    ci_upper = np.exp(results.conf_int().loc['risk_evaluator_alpha_score', 1])
    
    output = {
        "effect_size": float(irr),
        "effect_type": "irr",
        "standard_error": float(std_err), # Note: SE for coefficient; for IRR it's often delta method, but here standard reporting is fine
        "p_value": float(p_val),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
        "model_family": "poisson",
        "predictor_used": "risk_evaluator_alpha_score",
        "covariates_included": ["credit_score_index"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "none",
        "exclusions_applied": f"Removed rows with missing risk score or outcome (Total removed: {initial_len - len(df_clean)})"
    }
    
    print(json.dumps(output))

if __name__ == "__main__":
    solve()