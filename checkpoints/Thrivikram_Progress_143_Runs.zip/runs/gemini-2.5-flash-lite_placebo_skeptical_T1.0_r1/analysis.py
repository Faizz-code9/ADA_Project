import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

def run_analysis():
    file_path = '/kaggle/working/outputs/runs/gemini-2.5-flash-lite_placebo_skeptical_T1.0_r1/data.csv'
    try:
        df = pd.read_csv(file_path)
    except FileNotFoundError:
        return

    # Data Cleaning
    # The primary estimand is the ratio effect of continuous skin tone on red cards.
    # Skin tone is provided as rater1 and rater2. We will average them to get a continuous predictor.
    # The outcome 'redCards' can be > 1 (0, 1, 2 in dictionary), suggesting a count model.
    # Since we want the "ratio effect", a Poisson model or Negative Binomial is appropriate.
    # A Poisson regression coefficient exponentiated gives the Incidence Rate Ratio (IRR).
    
    df['skin_tone_avg'] = df[['rater1', 'rater2']].mean(axis=1)
    
    # Define relevant columns for the model
    # redCards is count. skin_tone_avg is continuous.
    # We use covariates like yellowCards or games to adjust if necessary, 
    # but the prompt implies testing the absence of bias specifically.
    # Let's include yellowCards as a control to isolate red card bias.
    
    cols_to_use = ['redCards', 'skin_tone_avg', 'yellowCards', 'games']
    clean_df = df.dropna(subset=['redCards', 'skin_tone_avg', 'yellowCards', 'games']).copy()
    
    # Count data often requires an offset if we consider the rate over games played.
    # However, the question asks for the effect of skin tone on red cards.
    # To treat redCards as a rate, we use log(games) as an offset.
    # Given redCards can be 0, we must ensure games > 0.
    clean_df = clean_df[clean_df['games'] > 0]
    clean_df['log_games'] = np.log(clean_df['games'])

    # Model: Poisson regression to get Incidence Rate Ratio (IRR)
    # Formula: redCards ~ skin_tone_avg + yellowCards
    y = clean_df['redCards']
    X = clean_df[['skin_tone_avg', 'yellowCards']]
    X = sm.add_constant(X)
    offset = clean_df['log_games']

    try:
        model = sm.GLM(y, X, family=sm.families.Poisson(), offset=offset).fit()
        
        # Extract stats for skin_tone_avg (index 1 if constant is 0)
        # We want the ratio effect (IRR)
        beta_name = 'skin_tone_avg'
        idx = X.columns.get_loc(beta_name)
        
        coef = model.params[idx]
        se = model.bse[idx]
        p_val = model.pvalues[idx]
        
        irr = np.exp(coef)
        ci_lower = np.exp(model.conf_int().iloc[idx, 0])
        ci_upper = np.exp(model.conf_int().iloc[idx, 1])
        
        result = {
            "effect_size": float(irr),
            "effect_type": "irr",
            "standard_error": float(se), # We report SE of the coefficient for statistical consistency or SE of IRR? 
            # Usually, SE is for the parameter. Standard error of IRR is more complex. 
            # I will provide the SE of the log-coefficient as it's the standard statistical output.
            "p_value": float(p_val),
            "ci_lower": float(ci_lower),
            "ci_upper": float(ci_upper),
            "conclusion": "significant_effect" if p_val < 0.05 else "no_significant_effect",
            "model_family": "poisson",
            "predictor_used": "average of rater1 and rater2 (skin_tone_avg)",
            "covariates_included": ["yellowCards", "games (as offset)"],
            "missing_data_strategy": "listwise_deletion",
            "clustering_strategy": "none",
            "exclusions_applied": "removed rows with missing skin tone, cards, or games; games=0 removed"
        }
        # Correcting SE to match the logic of effect_type being IRR? 
        # Most statistical software reports SE of the log-parameter. 
        # However, I'll provide the SE of the coefficient.
        result["standard_error"] = float(se)

        print(json.dumps(result, indent=2))

    except Exception as e:
        # Fallback in case of convergence issues
        pass

if __name__ == "__main__":
    run_analysis()