import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

def main():
    file_path = '/kaggle/working/outputs/runs/gemini-2.5-flash-lite_synthetic_neutral_T0.0_r1/data.csv'
    
    # Load data
    df = pd.read_csv(file_path)
    
    # Initial count for exclusions tracking
    initial_count = len(df)
    
    # Data Cleaning
    # skin_tone has 8% missing values. We use listwise deletion as per standard practice for regression.
    df_clean = df.dropna(subset=['skin_tone', 'redCards'])
    exclusions = f"Removed {initial_count - len(df_clean)} rows due to missing skin_tone"
    
    # The outcome 'redCards' is a count variable (0, 1, 2, 3). 
    # Given the low mean (0.1197) and discrete nature, Poisson regression is appropriate.
    # The hypothesis asks for the 'ratio effect' of continuous skin_tone.
    # In a Poisson model with a log link, the exponentiated coefficient is the Incidence Rate Ratio (IRR).
    
    try:
        # Model: redCards ~ skin_tone + position + leagueCountry
        # We include position and leagueCountry as covariates to isolate the skin_tone effect.
        # We use Poisson regression.
        model = smf.poisson('redCards ~ skin_tone + position + leagueCountry', data=df_clean).fit(disp=False)
        
        # Extracting parameters for skin_tone
        coef = model.params['skin_tone']
        se = model.bse['skin_tone']
        p_val = model.pvalues['skin_tone']
        
        # Primary Estimand: Ratio effect (IRR)
        irr = np.exp(coef)
        ci_lower = np.exp(model.conf_int().loc['skin_tone', 0])
        ci_upper = np.exp(model.conf_int().loc['skin_tone', 1])
        
        conclusion = 'significant_effect' if p_val < 0.05 else 'no_significant_effect'
        
        result = {
            "effect_size": float(irr),
            "effect_type": "irr",
            "standard_error": float(se), # Note: SE of the coefficient is returned, but standard for IRR reporting is often SE of log(IRR)
            "p_value": float(p_val),
            "ci_lower": float(ci_lower),
            "ci_upper": float(ci_upper),
            "conclusion": conclusion,
            "model_family": "poisson",
            "predictor_used": "skin_tone",
            "covariates_included": ["position", "leagueCountry"],
            "missing_data_strategy": "listwise_deletion",
            "clustering_strategy": "none",
            "exclusions_applied": exclusions
        }
        
        # Adjusting SE to be the SE of the IRR for consistency in reporting if desired, 
        # but standard statsmodels returns SE of the coefficient. 
        # To be mathematically precise for the IRR: SE(irr) approx irr * SE(coef)
        result["standard_error"] = float(irr * se)

    except Exception as e:
        # Fallback if model fails
        result = {
            "error": str(e)
        }

    print(json.dumps(result, indent=2))

if __name__ == "__main__":
    main()