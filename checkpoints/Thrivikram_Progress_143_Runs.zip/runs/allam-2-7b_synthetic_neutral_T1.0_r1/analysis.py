import pandas as pd
import numpy as np
from scipy import stats
import json
import statsmodels.api as sm
import statsmodels.formula.api as smf

# Load data
df = pd.read_csv('/kaggle/working/outputs/runs/allam-2-7b_synthetic_neutral_T1.0_r1/data.csv')

# Handling missing values: Listwise deletion for the main predictor
df_model = df.dropna(subset=['skin_tone']).copy()
exclusions = f"{len(df) - len(df_model)} rows with missing skin_tone removed"

# Variables
y = df_model['redCards']
X = df_model[['skin_tone', 'position', 'height', 'weight', 'leagueCountry', 'refereeID']]

# Encode categoricals
X = pd.get_dummies(X, columns=['position', 'leagueCountry', 'refereeID'], drop_first=True)

# Ensure skin_tone is the first column if using sm, but we will use formula
# Let's stick to statsmodels formula for clarity in coefficients
# But first, let's prepare the data for a negative binomial model since redCards are counts and likely overdispersed.
# Alternatively, Poisson might be simplest, but let's check dispersion or just use NegBin if possible in statsmodels easily.
# Statsmodels has GLM with link='log' family=Poisson. For Negative Binomial, there is a specific class `GLMNegativeBinomial`.

# Let's define the formula
# We need to create one-hot encoded variables for the formula or use C()
# Since we already have unique IDs, let's use the dataframe approach with statsmodels.stats.api or just standard OLS/GLM.
# Given the low mean of redCards (0.12), a count model is appropriate.
# Let's try Negative Binomial as it handles overdispersion.

from statsmodels.genmod.families import NegativeBinomial

# Construct the matrix for statsmodels
# We need an intercept
# Let's use the formula API to handle dummies automatically for C variables
# However, formula API might struggle with many dummy variables in the string if not careful.
# Let's manually construct X for sm.GLM or use formula.

# Using formula is cleaner for the output keys.
# covariates: position, height, weight, leagueCountry, refereeID
# Main predictor: skin_tone

# To handle the formula correctly with the pre-dummed data, let's just use the pre-dummed X with sm.NegativeBinomial
# This is more robust than formula if we have mixed types.

# Ensure all numeric
X = X.reset_index(drop=True)
y = y.reset_index(drop=True)

X.insert(0, 'const', 1)

# Fit Negative Binomial model
# Note: NegativeBinomial in statsmodels requires the variance parameter to be estimated.
try:
    model = sm.NegativeBinomial(y, X, dispersion='parametric')
    result = model.fit(method='newton', disp=0)
    
    # Get skin_tone coefficient
    coef = result.params['skin_tone']
    se = result.bse['skin_tone']
    p_val = result.pvalues['skin_tone']
    
    # Exp for IRR
    irr = np.exp(coef)
    irr_low = np.exp(coef + 1.96 * se)
    irr_high = np.exp(coef - 1.96 * se)
    # CI: exp(coef +/- 1.96*se)
    ci_lower = np.exp(coef - 1.96 * se)
    ci_upper = np.exp(coef + 1.96 * se)
    
    model_family = 'negative_binomial'
    effect_type = 'irr'
    effect_size = irr

except Exception as e:
    # Fallback to Poisson if NegBin fails for some reason
    model = sm.GLM(y, X, family=sm.families.Poisson())
    result = model.fit(disp=0)
    coef = result.params['skin_tone']
    se = result.bse['skin_tone']
    p_val = result.pvalues['skin_tone']
    
    irr = np.exp(coef)
    ci_lower = np.exp(coef - 1.96 * se)
    ci_upper = np.exp(coef + 1.96 * se)
    
    model_family = 'poisson'
    effect_type = 'irr'
    effect_size = irr

# Cluster Robust Standard Errors?
# The hypothesis implies bias in referee decisions. Players are clustered by referee?
# Or players are distinct individuals?
# The data has `playerID` and `refereeID`.
# If we assume independence of players, standard SE is fine.
# However, if multiple players are evaluated by the same referee, there might be "referee effect".
# We included `refereeID` and `leagueCountry` as fixed effects (dummies).
# This controls for referee-specific baseline rates.
# So standard SE from the model with fixed effects is appropriate.
# Clustering strategy: 'none' because we used fixed effects for high-dimensional clusters (referees).
# Alternatively, we could use GEE or Mixed effects.
# With 60 referees, fixed effects are perfectly feasible and often preferred for small cluster counts in empirical work if focusing on player-level effects.

# Conclusion
conclusion = 'significant_effect' if p_val < 0.05 else 'no_significant_effect'

# Covariates included
covariates = ['position', 'height', 'weight', 'leagueCountry', 'refereeID']

output = {
    "effect_size": float(effect_size),
    "effect_type": effect_type,
    "standard_error": float(se),
    "p_value": float(p_val),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": model_family,
    "predictor_used": "skin_tone",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": exclusions
}

print(json.dumps(output))