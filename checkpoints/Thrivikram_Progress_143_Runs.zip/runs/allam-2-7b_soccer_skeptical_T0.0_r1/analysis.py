import pandas as pd
import numpy as np
import json
import statsmodels.api as sm
from scipy import stats

# Load data
df = pd.read_csv('/kaggle/working/outputs/runs/allam-2-7b_soccer_skeptical_T0.0_r1/data.csv')

# Construct skin tone predictor: average of rater1 and rater2
df['skin_tone'] = (df['rater1'] + df['rater2']) / 2.0

# Exclude rows where skin_tone is missing
df = df.dropna(subset=['skin_tone'])

# Outcome: redCards (count data, low mean ~0.0126, highly skewed)
# Use Poisson regression with log link
# Covariates: height, weight, position (one-hot), leagueCountry (one-hot), games
# To keep it simple and robust, include height, weight, games, and leagueCountry

# Handle missing height/weight: drop rows with missing height or weight
df = df.dropna(subset=['height', 'weight'])

# One-hot encode position and leagueCountry
pos_dummies = pd.get_dummies(df['position'], prefix='pos', drop_first=True, dtype=float)
league_dummies = pd.get_dummies(df['leagueCountry'], prefix='league', drop_first=True, dtype=float)

# Build design matrix
X = pd.concat([
    df[['skin_tone', 'height', 'weight', 'games']],
    pos_dummies,
    league_dummies
], axis=1)

X = sm.add_constant(X)
y = df['redCards']

# Fit Poisson GLM
model = sm.GLM(y, X, family=sm.families.Poisson())
result = model.fit()

# Extract coefficient for skin_tone
coef = result.params['skin_tone']
se = result.bse['skin_tone']
p_val = result.pvalues['skin_tone']

# IRR = exp(coef)
irr = np.exp(coef)
irr_se = se * irr  # Delta method
irr_ci_lower = np.exp(coef - 1.96 * se)
irr_ci_upper = np.exp(coef + 1.96 * se)

# Conclusion
conclusion = 'significant_effect' if p_val < 0.05 else 'no_significant_effect'

# Covariates included
covariates = ['height', 'weight', 'games'] + list(pos_dummies.columns) + list(league_dummies.columns)

output = {
    "effect_size": float(irr),
    "effect_type": "irr",
    "standard_error": float(irr_se),
    "p_value": float(p_val),
    "ci_lower": float(irr_ci_lower),
    "ci_upper": float(irr_ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "skin_tone (average of rater1 and rater2)",
    "covariates_included": covariates,
    "missing_data_strategy": "listwise_deletion",
    "clustering_strategy": "none",
    "exclusions_applied": "rows with missing rater1/rater2, height, or weight"
}

print(json.dumps(output))