import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

def run_analysis():
    file_path = '/kaggle/working/outputs/runs/gemini-2.5-flash-lite_soccer_neutral_T1.0_r1/data.csv'
    try:
        df = pd.read_csv(file_path)
    except FileNotFoundError:
        return

    # 1. Data Cleaning and Preparation
    # Target: redCards (count data, often modeled with Poisson or Negative Binomial)
    # Predictor: skin tone (average of rater1 and rater2)
    # Exclude rows with missing skin tone or target
    df = df.dropna(subset=['redCards', 'rater1', 'rater2'])
    
    # Construct the main predictor: mean skin tone rating
    df['avg_skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)
    
    # Since redCards is a count, and the primary estimand is a "ratio effect", 
    # we use a Poisson regression. The exponentiated coefficient is the Incidence Rate Ratio (IRR).
    # We control for 'games' to account for exposure (denominator for rate).
    # We also control for 'yellowCards' as a proxy for overall disciplinary intensity.
    
    # Check for rows where games <= 0 to avoid division issues/model instability
    df = df[df['games'] > 0]
    
    # Model setup: Poisson regression with an offset for exposure (log(games))
    # Formula: redCards ~ avg_skin_tone + yellowCards + height + weight
    # We use log(games) as an offset to model the rate of red cards per game.
    df['log_games'] = np.log(df['games'])
    
    # Selecting covariates to reduce noise but maintain model robustness
    # Note: position is categorical, we will handle it via dummies if included.
    # Given the data size and goal, we'll keep it simple: skin_tone, yellowCards, and height.
    df['position_cat'] = df['position'].astype('category').cat.codes
    
    # Listwise deletion for covariates used
    cols_to_keep = ['redCards', 'avg_skin_tone', 'log_games', 'yellowCards', 'height', 'position_cat']
    df_clean = df[cols_to_keep].dropna()

    # 2. Statistical Modeling
    # We use Poisson regression because redCards is a count variable.
    # The coefficient of avg_skin_tone in a Poisson model with log offset is the log(IRR).
    # The effect_type requested is 'irr' (Incidence Rate Ratio).
    
    model = smf.glm(
        formula="redCards ~ avg_skin_tone + yellowCards + height + position_cat",
        data=df_clean,
        family=sm.families.Poisson(),
        offset=df_clean['log_games']
    )
    results = model.fit()

    # 3. Extract Estimands
    # Primary estimand: Ratio effect (IRR) of continuous skin tone
    coef = results.params['avg_skin_tone']
    se = results.bse['avg_skin_tone']
    p_val = results.pvalues['avg_skin_tone']
    
    # IRR = exp(coef)
    irr = np.exp(coef)
    # CI for IRR = exp(coef +/- 1.96 * se)
    ci_lower = np.exp(coef - 1.96 * se)
    ci_upper = np.exp(coef + 1.96 * se)

    conclusion = 'significant_effect' if p_val < 0.05 else 'no_significant_effect'

    # 4. Format Output
    output = {
        "effect_size": float(irr),
        "effect_type": "irr",
        "standard_error": float(se),
        "p_value": float(p_val),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": conclusion,
        "model_family": "poisson",
        "predictor_used": "avg_skin_tone (mean of rater1 and rater2)",
        "covariates_included": ["yellowCards", "height", "position_cat", "games_offset"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "none",
        "exclusions_applied": f"Removed rows with missing skin tone, redCards, or games. Removed rows with games=0."
    }

    print(json.dumps(output))

if __name__ == "__main__":
    run_analysis()