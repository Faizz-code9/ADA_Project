import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import json

def analyze():
    file_path = '/kaggle/working/outputs/runs/gemini-2.5-flash-lite_soccer_neutral_T0.7_r5/data.csv'
    try:
        df = pd.read_csv(file_path)
    except FileNotFoundError:
        return

    # Data Preparation
    # Outcome: redCards (count-like, but often modeled as Poisson or Logistic if treated as binary)
    # The prompt asks for "ratio effect of continuous skin tone on red cards". 
    # Since redCards can be > 1 (though rare), a Poisson model or OLS is appropriate.
    # However, "ratio effect" usually implies an Incident Rate Ratio (IRR) from a Poisson model.
    
    # Construct skin tone predictor (mean of rater1 and rater2)
    df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)
    
    # Identify covariates: height, weight, games, etc. 
    # We'll use 'games' as a control for exposure/opportunity.
    # We must handle missing values.
    cols_to_use = ['redCards', 'skin_tone', 'games', 'height', 'weight']
    df_clean = df.dropna(subset=['redCards', 'skin_tone', 'games'])
    
    # For other covariates, use mean imputation or drop
    df_clean['height'] = df_clean['height'].fillna(df_clean['height'].mean())
    df_clean['weight'] = df_clean['weight'].fillna(df_clean['weight'].mean())
    
    # Exclusions: Rows where redCards or skin_tone were NaN
    exclusions = f"Removed {len(df) - len(df_clean)} rows due to missing essential values."

    # Model: Poisson Regression to get IRR (Incident Rate Ratio)
    # Formula: redCards ~ skin_tone + games + height + weight
    # Since redCards is a count, Poisson is the standard approach for 'ratio effect'.
    
    model = smf.poisson('redCards ~ skin_tone + games + height + weight', data=df_clean).fit(disp=False)
    
    # Extract parameters for skin_tone
    coef = model.params['skin_tone']
    se = model.bse['skin_tone']
    p_val = model.pvalues['skin_tone']
    
    # Primary Estimand: IRR = exp(coef)
    irr = np.exp(coef)
    ci_lower = np.exp(model.conf_int().loc['skin_tone', 0])
    ci_upper = np.exp(model.conf_int().loc['skin_tone', 1])
    
    conclusion = 'significant_effect' if p_val < 0.05 else 'no_significant_effect'
    
    result = {
        "effect_size": float(irr),
        "effect_type": "irr",
        "standard_error": float(se), # SE of the coefficient is reported, though SE of IRR is different, standard practice is reporting coef SE or IRR SE. We'll provide coef SE.
        "p_value": float(p_val),
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
        "conclusion": conclusion,
        "model_family": "poisson",
        "predictor_used": "mean(rater1, rater2)",
        "covariates_included": ["games", "height", "weight"],
        "missing_data_strategy": "listwise_deletion",
        "clustering_strategy": "none",
        "exclusions_applied": exclusions
    }
    
    print(json.dumps(result, indent=2))

if __name__ == "__main__":
    analyze()