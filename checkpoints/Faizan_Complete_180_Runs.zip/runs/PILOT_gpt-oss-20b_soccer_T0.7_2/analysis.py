import pandas as pd
import numpy as np
import statsmodels.api as sm
import json
import sys

# Load data
file_path = '/kaggle/working/outputs/runs/PILOT_gpt-oss-20b_soccer_T0.7_2/data.csv'
df = pd.read_csv(file_path)

# Construct continuous skin tone variable (average of two raters)
df['skin_tone'] = df[['rater1', 'rater2']].mean(axis=1)

# Exclude rows with missing skin tone or games (games is offset)
excluded_rows = df[(df['skin_tone'].isna()) | (df['games'].isna())].index
df_clean = df.drop(index=excluded_rows).copy()

# Listwise deletion strategy
missing_data_strategy = 'listwise_deletion'

# Prepare formula: include position and leagueCountry as categorical covariates
formula = 'redCards ~ skin_tone + C(position) + C(leagueCountry)'

# Offset: log of games played
offset = np.log(df_clean['games'])

# Fit Poisson GLM
model = sm.GLM.from_formula(formula, data=df_clean, family=sm.families.Poisson(), offset=offset)
result = model.fit()

# Extract coefficient for skin_tone
coef = result.params['skin_tone']
se = result.bse['skin_tone']
p_value = result.pvalues['skin_tone']

# Incidence Rate Ratio (IRR)
effect_size = np.exp(coef)
ci_lower = np.exp(coef - 1.96 * se)
ci_upper = np.exp(coef + 1.96 * se)

conclusion = 'significant_effect' if p_value < 0.05 else 'no_significant_effect'

output = {
    "effect_size": effect_size,
    "effect_type": "irr",
    "standard_error": se,
    "p_value": p_value,
    "ci_lower": ci_lower,
    "ci_upper": ci_upper,
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "average of rater1 and rater2 skin tone",
    "covariates_included": ["position", "leagueCountry"],
    "missing_data_strategy": missing_data_strategy,
    "clustering_strategy": "none",
    "exclusions_applied": f"Removed {len(excluded_rows)} rows with missing skin tone or games"
}

print(json.dumps(output))