import pandas as pd
import numpy as np
import json
import statsmodels.api as sm
import statsmodels.formula.api as smf

# Load data
df = pd.read_csv('/kaggle/working/outputs/runs/PILOT_gpt-oss-20b_synthetic_T0.0_1/data.csv')

# Exclusions: none
exclusions_applied = 'none'

# Missing data strategy: drop rows with missing skin_tone
df = df.dropna(subset=['skin_tone'])
missing_data_strategy = 'listwise_deletion'

# Define covariates (excluding outcome and main predictor)
covariates = ['games', 'yellowCards', 'height', 'weight',
              'position', 'leagueCountry', 'refereeID']

# Build formula
formula = 'redCards ~ skin_tone + games + yellowCards + height + weight + C(position) + C(leagueCountry) + C(refereeID)'

# Fit Poisson GLM with cluster-robust SE by refereeID
model = smf.glm(formula=formula, data=df, family=sm.families.Poisson())
result = model.fit(cov_type='cluster', cov_kwds={'groups': df['refereeID']})

# Extract coefficient for skin_tone
coef = result.params['skin_tone']
se = result.bse['skin_tone']
p_value = result.pvalues['skin_tone']

# Incidence Rate Ratio (exponentiated coefficient)
effect_size = np.exp(coef)
ci_lower = np.exp(coef - 1.96 * se)
ci_upper = np.exp(coef + 1.96 * se)

# Conclusion
conclusion = 'significant_effect' if p_value < 0.05 else 'no_significant_effect'

# Prepare JSON output
output = {
    "effect_size": float(effect_size),
    "effect_type": "irr",
    "standard_error": float(se),
    "p_value": float(p_value),
    "ci_lower": float(ci_lower),
    "ci_upper": float(ci_upper),
    "conclusion": conclusion,
    "model_family": "poisson",
    "predictor_used": "skin_tone",
    "covariates_included": covariates,
    "missing_data_strategy": missing_data_strategy,
    "clustering_strategy": "clustered_se",
    "exclusions_applied": exclusions_applied
}

print(json.dumps(output))