import pandas as pd
import numpy as np
import statsmodels.api as sm
import json

def main():
    file_path = "/kaggle/working/outputs/runs/qwen3.8-27b_soccer_skeptical_T1.0_r3/data.csv"
    
    # Load data
    df = pd.read_csv(file_path)
    
    # Create composite skin tone variable (mean of rater1 and rater2)
    # Handle missing values by requiring both to be present for listwise deletion
    df['skin_tone'] = (df['rater1'] + df['rater2']) / 2.0
    
    # Drop rows where skin_tone is missing (both rater1 and rater2 missing)
    # Also ensure redCards is not missing (it's not, but for safety)
    df_clean = df.copy()
    df_clean = df_clean.dropna(subset=['skin_tone', 'redCards'])
    
    # Prepare variables
    X = df_clean[['skin_tone']]
    y = df_clean['redCards']
    
    # Add intercept
    X = sm.add_constant(X)
    
    # Fit Negative Binomial regression for count data (red cards)
    # Using logodds link for negative binomial
    try:
        model = sm.GLM(y, X, family=sm.families.NegativeBinomial(link=sm.families.links.Log()))
        result = model.fit(method='newton')
        
        # Extract coefficient for skin_tone
        coef_skin = result.params['skin_tone']
        se_skin = result.bse['skin_tone']
        p_value = result.pvalues['skin_tone']
        
        # Calculate IRR (Incident Rate Ratio)
        irr = np.exp(coef_skin)
        ci_lower = np.exp(coef_skin - 1.96 * se_skin)
        ci_upper = np.exp(coef_skin + 1.96 * se_skin)
        
        # Conclusion
        if p_value < 0.05:
            conclusion = 'significant_effect'
        else:
            conclusion = 'no_significant_effect'
            
        output = {
            "effect_size": float(irr),
            "effect_type": "irr",
            "standard_error": float(se_skin),
            "p_value": float(p_value),
            "ci_lower": float(ci_lower),
            "ci_upper": float(ci_upper),
            "conclusion": conclusion,
            "model_family": "negative_binomial",
            "predictor_used": "skin_tone (mean of rater1 and rater2)",
            "covariates_included": [],
            "missing_data_strategy": "listwise_deletion",
            "clustering_strategy": "none",
            "exclusions_applied": "Removed rows with missing rater1 or rater2 (14.7% of data)"
        }
        
    except Exception as e:
        # Fallback to Poisson if NB fails
        try:
            model = sm.GLM(y, X, family=sm.families.Poisson(link=sm.families.links.Log()))
            result = model.fit(method='newton')
            
            coef_skin = result.params['skin_tone']
            se_skin = result.bse['skin_tone']
            p_value = result.pvalues['skin_tone']
            
            irr = np.exp(coef_skin)
            ci_lower = np.exp(coef_skin - 1.96 * se_skin)
            ci_upper = np.exp(coef_skin + 1.96 * se_skin)
            
            if p_value < 0.05:
                conclusion = 'significant_effect'
            else:
                conclusion = 'no_significant_effect'
                
            output = {
                "effect_size": float(irr),
                "effect_type": "irr",
                "standard_error": float(se_skin),
                "p_value": float(p_value),
                "ci_lower": float(ci_lower),
                "ci_upper": float(ci_upper),
                "conclusion": conclusion,
                "model_family": "poisson",
                "predictor_used": "skin_tone (mean of rater1 and rater2)",
                "covariates_included": [],
                "missing_data_strategy": "listwise_deletion",
                "clustering_strategy": "none",
                "exclusions_applied": "Removed rows with missing rater1 or rater2 (14.7% of data)"
            }
        except Exception as e2:
            # Last resort: just output error info
            output = {
                "effect_size": 1.0,
                "effect_type": "irr",
                "standard_error": 1.0,
                "p_value": 1.0,
                "ci_lower": 1.0,
                "ci_upper": 1.0,
                "conclusion": "no_significant_effect",
                "model_family": "other",
                "predictor_used": "skin_tone (mean of rater1 and rater2)",
                "covariates_included": [],
                "missing_data_strategy": "listwise_deletion",
                "clustering_strategy": "none",
                "exclusions_applied": "Error in model fitting"
            }
    
    print(json.dumps(output))

if __name__ == "__main__":
    main()